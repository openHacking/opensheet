import { expect, test } from '@playwright/test';

test('a waiting Web Lock holder observes the previous holder localStorage write', async ({
  page,
  context,
}) => {
  const other = await context.newPage();
  await Promise.all([page.goto('/#budget'), other.goto('/#budget')]);
  await Promise.all([
    expect(page.locator('#scene-title')).toHaveText('Budget Simulator'),
    expect(other.locator('#scene-title')).toHaveText('Budget Simulator'),
  ]);
  const name = `opensheet.test.visibility.${Date.now()}-${Math.random()}`;
  await page.evaluate((name) => {
    let release!: () => void;
    const pending = new Promise<void>((resolve) => {
      release = resolve;
    });
    (window as any).releaseVisibilityLock = release;
    void navigator.locks.request(name, async () => {
      (window as any).visibilityLockHeld = true;
      await pending;
      localStorage.setItem(name, 'published');
    });
  }, name);
  await expect.poll(() => page.evaluate(() => (window as any).visibilityLockHeld)).toBe(true);
  await other.evaluate((name) => {
    void navigator.locks.request(name, () => {
      (window as any).visibilityObserved = localStorage.getItem(name);
      (window as any).visibilityDone = true;
    });
  }, name);
  await expect
    .poll(() =>
      page.evaluate(
        async (name) => (await navigator.locks.query()).pending?.some((lock) => lock.name === name),
        name,
      ),
    )
    .toBe(true);
  await page.evaluate(() => (window as any).releaseVisibilityLock());
  await expect.poll(() => other.evaluate(() => (window as any).visibilityDone)).toBe(true);
  expect(await other.evaluate(() => (window as any).visibilityObserved)).toBe('published');
  await other.close();
});

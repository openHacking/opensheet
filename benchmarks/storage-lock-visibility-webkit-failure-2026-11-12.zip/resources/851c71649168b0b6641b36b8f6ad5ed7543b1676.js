import { assert } from "/@fs/Volumes/github/private/opensheet/packages/core/src/types.ts";
export function validateNavigationArguments(sheet, row, column, axis, direction) {
  assert(
    typeof sheet === "string" && sheet.length > 0,
    "INVALID_ARGUMENT",
    "Invalid navigation sheet"
  );
  assert(
    Number.isSafeInteger(row) && row >= 0 && Number.isSafeInteger(column) && column >= 0,
    "INVALID_ARGUMENT",
    "Invalid navigation position"
  );
  assert(
    (axis === "row" || axis === "column") && (direction === -1 || direction === 1),
    "INVALID_ARGUMENT",
    "Invalid navigation direction"
  );
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5hdmlnYXRpb24tdmFsaWRhdGlvbi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBhc3NlcnQgfSBmcm9tICcuL3R5cGVzLmpzJztcblxuLyoqIENoZWNrIHRoZSBzYW1lIHVudHJ1c3RlZCByZXF1ZXN0IGJlZm9yZSBkaXNwYXRjaCBhbmQgYXQgdGhlIFdvcmtlciBib3VuZGFyeS4gKi9cbmV4cG9ydCBmdW5jdGlvbiB2YWxpZGF0ZU5hdmlnYXRpb25Bcmd1bWVudHMoXG4gIHNoZWV0OiB1bmtub3duLFxuICByb3c6IHVua25vd24sXG4gIGNvbHVtbjogdW5rbm93bixcbiAgYXhpczogdW5rbm93bixcbiAgZGlyZWN0aW9uOiB1bmtub3duLFxuKSB7XG4gIGFzc2VydChcbiAgICB0eXBlb2Ygc2hlZXQgPT09ICdzdHJpbmcnICYmIHNoZWV0Lmxlbmd0aCA+IDAsXG4gICAgJ0lOVkFMSURfQVJHVU1FTlQnLFxuICAgICdJbnZhbGlkIG5hdmlnYXRpb24gc2hlZXQnLFxuICApO1xuICBhc3NlcnQoXG4gICAgTnVtYmVyLmlzU2FmZUludGVnZXIocm93KSAmJlxuICAgICAgKHJvdyBhcyBudW1iZXIpID49IDAgJiZcbiAgICAgIE51bWJlci5pc1NhZmVJbnRlZ2VyKGNvbHVtbikgJiZcbiAgICAgIChjb2x1bW4gYXMgbnVtYmVyKSA+PSAwLFxuICAgICdJTlZBTElEX0FSR1VNRU5UJyxcbiAgICAnSW52YWxpZCBuYXZpZ2F0aW9uIHBvc2l0aW9uJyxcbiAgKTtcbiAgYXNzZXJ0KFxuICAgIChheGlzID09PSAncm93JyB8fCBheGlzID09PSAnY29sdW1uJykgJiYgKGRpcmVjdGlvbiA9PT0gLTEgfHwgZGlyZWN0aW9uID09PSAxKSxcbiAgICAnSU5WQUxJRF9BUkdVTUVOVCcsXG4gICAgJ0ludmFsaWQgbmF2aWdhdGlvbiBkaXJlY3Rpb24nLFxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLGNBQWM7QUFHaEIsZ0JBQVMsNEJBQ2QsT0FDQSxLQUNBLFFBQ0EsTUFDQSxXQUNBO0FBQ0E7QUFBQSxJQUNFLE9BQU8sVUFBVSxZQUFZLE1BQU0sU0FBUztBQUFBLElBQzVDO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDQTtBQUFBLElBQ0UsT0FBTyxjQUFjLEdBQUcsS0FDckIsT0FBa0IsS0FDbkIsT0FBTyxjQUFjLE1BQU0sS0FDMUIsVUFBcUI7QUFBQSxJQUN4QjtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0E7QUFBQSxLQUNHLFNBQVMsU0FBUyxTQUFTLGNBQWMsY0FBYyxNQUFNLGNBQWM7QUFBQSxJQUM1RTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0Y7IiwibmFtZXMiOltdfQ==
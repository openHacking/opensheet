import { offsetFormula } from "/@fs/Volumes/github/private/opensheet/packages/formula/src/index.ts";
import { assert, toInput } from "/@fs/Volumes/github/private/opensheet/packages/core/src/types.ts";
export function selectiveCopyCell(cell, mode, rowOffset, columnOffset) {
  const position = { row: cell.row + rowOffset, column: cell.column + columnOffset };
  if (mode === "formats")
    return {
      ...position,
      style: {
        ...cell.style,
        ...cell.numberFormat !== void 0 ? { numberFormat: cell.numberFormat } : {}
      }
    };
  const value = cell.value ?? null;
  assert(
    !(mode === "values" && value && typeof value === "object" && value.error === "#LIMIT!"),
    "LIMIT_EXCEEDED",
    "Cannot copy an incomplete calculation"
  );
  let input = mode === "values" ? value && typeof value === "object" ? { type: "error", code: value.error } : toInput(value) : cell.input ?? { type: "blank" };
  if (input.type === "formula")
    input = {
      type: "formula",
      expression: offsetFormula(input.expression, rowOffset, columnOffset)
    };
  return { ...position, input };
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlbGVjdGl2ZS1jb3B5LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IG9mZnNldEZvcm11bGEgfSBmcm9tICdAb3BlbnNoZWV0anMvZm9ybXVsYSc7XG5pbXBvcnQgeyBhc3NlcnQsIHRvSW5wdXQsIHR5cGUgQ2VsbElucHV0IH0gZnJvbSAnLi90eXBlcy5qcyc7XG5pbXBvcnQgdHlwZSB7IENlbGxEYXRhIH0gZnJvbSAnLi93b3JrYm9vay5qcyc7XG5cbi8qKiBDb252ZXJ0IG9uZSBjYXB0dXJlZCBzb3VyY2UgY2VsbCB3aXRob3V0IG11dGF0aW5nIHRoZSBzb3VyY2Ugb3IgZGVzdGluYXRpb24uICovXG5leHBvcnQgZnVuY3Rpb24gc2VsZWN0aXZlQ29weUNlbGwoXG4gIGNlbGw6IENlbGxEYXRhLFxuICBtb2RlOiAndmFsdWVzJyB8ICdmb3JtdWxhcycgfCAnZm9ybWF0cycsXG4gIHJvd09mZnNldDogbnVtYmVyLFxuICBjb2x1bW5PZmZzZXQ6IG51bWJlcixcbikge1xuICBjb25zdCBwb3NpdGlvbiA9IHsgcm93OiBjZWxsLnJvdyArIHJvd09mZnNldCwgY29sdW1uOiBjZWxsLmNvbHVtbiArIGNvbHVtbk9mZnNldCB9O1xuICBpZiAobW9kZSA9PT0gJ2Zvcm1hdHMnKVxuICAgIHJldHVybiB7XG4gICAgICAuLi5wb3NpdGlvbixcbiAgICAgIHN0eWxlOiB7XG4gICAgICAgIC4uLmNlbGwuc3R5bGUsXG4gICAgICAgIC4uLihjZWxsLm51bWJlckZvcm1hdCAhPT0gdW5kZWZpbmVkID8geyBudW1iZXJGb3JtYXQ6IGNlbGwubnVtYmVyRm9ybWF0IH0gOiB7fSksXG4gICAgICB9LFxuICAgIH07XG4gIGNvbnN0IHZhbHVlID0gY2VsbC52YWx1ZSA/PyBudWxsO1xuICBhc3NlcnQoXG4gICAgIShtb2RlID09PSAndmFsdWVzJyAmJiB2YWx1ZSAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmIHZhbHVlLmVycm9yID09PSAnI0xJTUlUIScpLFxuICAgICdMSU1JVF9FWENFRURFRCcsXG4gICAgJ0Nhbm5vdCBjb3B5IGFuIGluY29tcGxldGUgY2FsY3VsYXRpb24nLFxuICApO1xuICBsZXQgaW5wdXQ6IENlbGxJbnB1dCA9XG4gICAgbW9kZSA9PT0gJ3ZhbHVlcydcbiAgICAgID8gdmFsdWUgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0J1xuICAgICAgICA/IHsgdHlwZTogJ2Vycm9yJywgY29kZTogdmFsdWUuZXJyb3IgfVxuICAgICAgICA6IHRvSW5wdXQodmFsdWUpXG4gICAgICA6IChjZWxsLmlucHV0ID8/IHsgdHlwZTogJ2JsYW5rJyB9KTtcbiAgaWYgKGlucHV0LnR5cGUgPT09ICdmb3JtdWxhJylcbiAgICBpbnB1dCA9IHtcbiAgICAgIHR5cGU6ICdmb3JtdWxhJyxcbiAgICAgIGV4cHJlc3Npb246IG9mZnNldEZvcm11bGEoaW5wdXQuZXhwcmVzc2lvbiwgcm93T2Zmc2V0LCBjb2x1bW5PZmZzZXQpLFxuICAgIH07XG4gIHJldHVybiB7IC4uLnBvc2l0aW9uLCBpbnB1dCB9O1xufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLHFCQUFxQjtBQUM5QixTQUFTLFFBQVEsZUFBK0I7QUFJekMsZ0JBQVMsa0JBQ2QsTUFDQSxNQUNBLFdBQ0EsY0FDQTtBQUNBLFFBQU0sV0FBVyxFQUFFLEtBQUssS0FBSyxNQUFNLFdBQVcsUUFBUSxLQUFLLFNBQVMsYUFBYTtBQUNqRixNQUFJLFNBQVM7QUFDWCxXQUFPO0FBQUEsTUFDTCxHQUFHO0FBQUEsTUFDSCxPQUFPO0FBQUEsUUFDTCxHQUFHLEtBQUs7QUFBQSxRQUNSLEdBQUksS0FBSyxpQkFBaUIsU0FBWSxFQUFFLGNBQWMsS0FBSyxhQUFhLElBQUksQ0FBQztBQUFBLE1BQy9FO0FBQUEsSUFDRjtBQUNGLFFBQU0sUUFBUSxLQUFLLFNBQVM7QUFDNUI7QUFBQSxJQUNFLEVBQUUsU0FBUyxZQUFZLFNBQVMsT0FBTyxVQUFVLFlBQVksTUFBTSxVQUFVO0FBQUEsSUFDN0U7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNBLE1BQUksUUFDRixTQUFTLFdBQ0wsU0FBUyxPQUFPLFVBQVUsV0FDeEIsRUFBRSxNQUFNLFNBQVMsTUFBTSxNQUFNLE1BQU0sSUFDbkMsUUFBUSxLQUFLLElBQ2QsS0FBSyxTQUFTLEVBQUUsTUFBTSxRQUFRO0FBQ3JDLE1BQUksTUFBTSxTQUFTO0FBQ2pCLFlBQVE7QUFBQSxNQUNOLE1BQU07QUFBQSxNQUNOLFlBQVksY0FBYyxNQUFNLFlBQVksV0FBVyxZQUFZO0FBQUEsSUFDckU7QUFDRixTQUFPLEVBQUUsR0FBRyxVQUFVLE1BQU07QUFDOUI7IiwibmFtZXMiOltdfQ==
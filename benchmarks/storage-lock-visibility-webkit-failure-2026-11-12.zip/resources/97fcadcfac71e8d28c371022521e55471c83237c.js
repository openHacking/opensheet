import {
  evaluateFormula,
  parseFormula,
  transformReferences,
  functionDefinition,
  Aggregate,
  TextJoin,
  conditional,
  lookup,
  conditionalPlan,
  FormulaError
} from "/@fs/Volumes/github/private/opensheet/packages/formula/src/index.ts";
import { assert, LIMITS, scalarValue } from "/@fs/Volumes/github/private/opensheet/packages/core/src/types.ts";
import { ReferenceIndex } from "/@fs/Volumes/github/private/opensheet/packages/core/src/reference-index.ts";
import { ByteCache } from "/@fs/Volumes/github/private/opensheet/packages/core/src/storage.ts";
export class AsyncCalculation {
  constructor(read, find, budget = 4 * 1024 * 1024, persistedAST, dateSystem = () => "1900") {
    this.read = read;
    this.find = find;
    this.persistedAST = persistedAST;
    this.dateSystem = dateSystem;
    this.cache = new ByteCache(budget, (id) => this.removeCached(id));
  }
  read;
  find;
  persistedAST;
  dateSystem;
  cache;
  dependencies = new ReferenceIndex();
  cacheGeneration = 0;
  scalarGeneration = 0;
  removed = [];
  removing = false;
  get cacheBytes() {
    return this.cache.bytes;
  }
  get cacheBudget() {
    return this.cache.budget;
  }
  removeCached(id) {
    this.cacheGeneration++;
    this.removed.push(id);
    if (this.removing) return;
    this.removing = true;
    try {
      while (this.removed.length) {
        const removed = this.removed.pop();
        this.dependencies.delete(removed);
        const [sheetId, row, column] = removed.split(":");
        for (const dependent of this.dependencies.query(sheetId, {
          startRow: +row,
          endRow: +row + 1,
          startColumn: +column,
          endColumn: +column + 1
        }))
          this.cache.delete(dependent);
      }
    } finally {
      this.removing = false;
    }
  }
  clear() {
    this.cacheGeneration++;
    this.scalarGeneration++;
    this.cache.clear();
    this.dependencies.clear();
  }
  invalidate(ranges) {
    this.cacheGeneration++;
    this.scalarGeneration++;
    const queue = [...ranges], seen = /* @__PURE__ */ new Set();
    while (queue.length) {
      const range = queue.pop();
      for (const id of this.dependencies.query(range.sheetId, range)) {
        if (seen.has(id)) continue;
        seen.add(id);
        this.cache.delete(id);
        const [sheetId, row, column] = id.split(":");
        queue.push({
          sheetId,
          startRow: +row,
          endRow: +row + 1,
          startColumn: +column,
          endColumn: +column + 1
        });
      }
    }
  }
  async value(sheet, row, column, stack = /* @__PURE__ */ new Set(), work, memo) {
    work?.signal?.throwIfAborted();
    if (work && --work.remaining < 0) return { error: "#LIMIT!" };
    const id = `${sheet}:${row}:${column}`;
    const cached = this.cache.get(id);
    if (cached !== void 0) return cached;
    const generation = this.cacheGeneration;
    const scalarGeneration = this.scalarGeneration;
    if (memo) {
      if (memo.generation !== scalarGeneration) {
        memo.cache.clear();
        memo.generation = scalarGeneration;
      }
      const scalar = memo.cache.get(id);
      if (scalar !== void 0) return scalar;
    }
    if (stack.has(id)) return { error: "#CYCLE!" };
    const cell = await this.read(sheet, row, column);
    work?.signal?.throwIfAborted();
    if (!cell || cell.input.type !== "formula") {
      const result2 = cell && cell.input.type !== "formula" ? scalarValue(cell.input) : null;
      if (memo && scalarGeneration === this.scalarGeneration && memo.generation === scalarGeneration) {
        const bytes = 192 + id.length * 2 + (typeof result2 === "string" ? result2.length * 2 : 128);
        memo.cache.set(id, result2, bytes);
      }
      return result2;
    }
    if (stack.size >= 128) return { error: "#LIMIT!" };
    stack.add(id);
    let result;
    let ast;
    try {
      const persisted = await this.persistedAST?.(sheet, row, column);
      ast = persisted ?? parseFormula(cell.input.expression);
      result = await this.evaluate(sheet, ast, stack, work, memo);
    } catch (error) {
      if (work?.signal?.aborted || error.code === "ABORTED") throw error;
      result = { error: error instanceof Error ? error.message : "#VALUE!" };
    } finally {
      stack.delete(id);
    }
    return this.remember(id, sheet, row, column, ast, result, generation);
  }
  /** Reuse bounded scalar references only for the lifetime of one caller-owned read. */
  readSession(minimumScratchBytes = 0) {
    assert(
      Number.isSafeInteger(minimumScratchBytes) && minimumScratchBytes >= 0 && minimumScratchBytes <= 64 * 1024,
      "INVALID_ARGUMENT",
      "Invalid calculation scratch budget"
    );
    const memo = {
      generation: this.scalarGeneration,
      cache: new ByteCache(Math.max(minimumScratchBytes, Math.min(this.cache.budget, 64 * 1024)))
    };
    return (sheet, row, column) => this.value(sheet, row, column, /* @__PURE__ */ new Set(), void 0, memo);
  }
  /** A shared calculation budget for one immutable staged workbook view. */
  validationSession(signal, steps = 1e6) {
    assert(
      Number.isSafeInteger(steps) && steps > 0 && steps <= 1e6,
      "INVALID_ARGUMENT",
      "Invalid validation calculation budget"
    );
    const work = { remaining: steps, signal };
    const staged = new AsyncCalculation(
      this.read,
      this.find,
      this.cache.budget,
      void 0,
      this.dateSystem
    );
    const evaluateFormula2 = async (sheet, request) => {
      signal?.throwIfAborted();
      if (--work.remaining < 0) return { error: "#LIMIT!" };
      try {
        const ast = transformReferences(parseFormula(request.expression), (ref) => {
          const row = ref.row + (ref.absoluteRow ? 0 : request.rowOffset);
          const column = ref.column + (ref.absoluteColumn ? 0 : request.columnOffset);
          return row < 0 || row >= LIMITS.rows || column < 0 || column >= LIMITS.columns ? null : { ...ref, row, column };
        });
        return await staged.evaluate(sheet, ast, /* @__PURE__ */ new Set(), work);
      } catch (error) {
        if (signal?.aborted || error.code === "ABORTED") throw error;
        return { error: error instanceof Error ? error.message : "#VALUE!" };
      }
    };
    return {
      forSheet: (sheet) => ({
        read: (row, column) => staged.value(sheet, row, column, /* @__PURE__ */ new Set(), work),
        evaluateFormula: (request) => evaluateFormula2(sheet, request)
      })
    };
  }
  async evaluate(sheet, ast, stack, shared, memo) {
    const work = shared ?? { remaining: 1e7 };
    let textWork;
    const ref = async (r) => {
      if (work.remaining % 1024 === 0) await new Promise((resolve) => setTimeout(resolve, 0));
      work.signal?.throwIfAborted();
      if (--work.remaining < 0) return { error: "#LIMIT!" };
      const target = r.sheet ? this.find(r.sheet) : sheet;
      return target ? this.value(target, r.row, r.column, stack, shared, memo) : { error: "#REF!" };
    };
    const literal = (value) => ({ kind: "literal", value });
    const run = async (ast2) => {
      if (--work.remaining < 0) return { error: "#LIMIT!" };
      if (ast2.kind === "literal")
        return typeof ast2.value === "number" && !Number.isFinite(ast2.value) ? { error: "#NUM!" } : ast2.value;
      if (ast2.kind === "ref") return ref(ast2);
      if (ast2.kind === "range") return { error: "#VALUE!" };
      if (ast2.kind === "unary")
        return evaluateFormula({ ...ast2, value: literal(await run(ast2.value)) }, () => null);
      if (ast2.kind === "binary") {
        const left = await run(ast2.left);
        if (left && typeof left === "object") return left;
        return evaluateFormula(
          { ...ast2, left: literal(left), right: literal(await run(ast2.right)) },
          () => null
        );
      }
      const definition = functionDefinition(ast2.name);
      if (!definition) return { error: "#NAME?" };
      if (ast2.args.length < definition.minArgs || ast2.args.length > definition.maxArgs)
        return { error: "#VALUE!" };
      if (definition.evaluation === "conditional" || definition.evaluation === "lookup") {
        try {
          const iterator = (definition.evaluation === "lookup" ? lookup : conditional)(
            ast2.name,
            ast2.args,
            textWork ??= { remaining: 1e6 }
          );
          let step = iterator.next();
          while (!step.done) {
            if (work.remaining <= 0) return { error: "#LIMIT!" };
            step = iterator.next(await run(step.value));
          }
          return step.value;
        } catch (error) {
          if (error instanceof FormulaError) return { error: error.code };
          throw error;
        }
      }
      if (ast2.name === "IF") {
        const test = evaluateFormula(
          {
            kind: "call",
            name: "IF",
            args: [literal(await run(ast2.args[0])), literal(true), literal(false)]
          },
          () => null
        );
        return typeof test === "object" && test ? test : run(ast2.args[test ? 1 : 2] ?? literal(false));
      }
      if (ast2.name === "IFS") {
        if (ast2.args.length % 2) return { error: "#VALUE!" };
        for (let i = 0; i < ast2.args.length; i += 2) {
          const test = evaluateFormula(
            {
              kind: "call",
              name: "IF",
              args: [literal(await run(ast2.args[i])), literal(true), literal(false)]
            },
            () => null
          );
          if (test && typeof test === "object") return test;
          if (test) return run(ast2.args[i + 1]);
        }
        return { error: "#N/A" };
      }
      if (ast2.name === "IFERROR" || ast2.name === "IFNA") {
        const v = await run(ast2.args[0]);
        return v && typeof v === "object" && v.error !== "#LIMIT!" && v.error !== "#CYCLE!" && (ast2.name === "IFERROR" || v.error === "#N/A") ? run(ast2.args[1]) : v;
      }
      if (definition.evaluation === "aggregate" || definition.evaluation === "text") {
        const aggregate = definition.evaluation === "aggregate" ? new Aggregate(ast2.name) : ast2.name === "TEXTJOIN" ? new TextJoin(await run(ast2.args[0]), await run(ast2.args[1])) : new TextJoin();
        for (const arg of ast2.name === "TEXTJOIN" ? ast2.args.slice(2) : ast2.args) {
          if (arg.kind !== "range") aggregate.add(await run(arg), arg.kind === "ref");
          else
            for (let r = Math.min(arg.start.row, arg.end.row); r <= Math.max(arg.start.row, arg.end.row); r++)
              for (let c = Math.min(arg.start.column, arg.end.column); c <= Math.max(arg.start.column, arg.end.column); c++) {
                if (work.remaining <= 0) return { error: "#LIMIT!" };
                aggregate.add(await ref({ ...arg.start, row: r, column: c }), true);
              }
        }
        return aggregate.result();
      }
      const args = [];
      for (const arg of ast2.args) {
        const value = await run(arg);
        if (value && typeof value === "object") return value;
        args.push(literal(value));
      }
      return evaluateFormula({ ...ast2, args }, () => null, void 0, this.dateSystem());
    };
    return run(ast);
  }
  remember(id, sheet, row, column, ast, result, generation) {
    if (result && typeof result === "object" && ["#LIMIT!", "#CYCLE!"].includes(result.error))
      return result;
    const refs = [];
    const add = (ref, end = ref) => {
      const target = ref.sheet ? this.find(ref.sheet) : sheet;
      if (target)
        refs.push({
          sheet: target,
          range: {
            startRow: Math.min(ref.row, end.row),
            endRow: Math.max(ref.row, end.row) + 1,
            startColumn: Math.min(ref.column, end.column),
            endColumn: Math.max(ref.column, end.column) + 1
          }
        });
    };
    const visit = (node) => {
      if (node.kind === "ref") add(node);
      else if (node.kind === "range") add(node.start, node.end);
      else if (node.kind === "unary") visit(node.value);
      else if (node.kind === "binary") {
        visit(node.left);
        visit(node.right);
      } else if (node.kind === "call") {
        node.args.forEach(visit);
        if (functionDefinition(node.name)?.evaluation === "conditional") {
          try {
            const plan = conditionalPlan(node.name, node.args);
            if (plan.values)
              add(plan.values.start, {
                ...plan.values.start,
                row: plan.values.start.row + plan.values.rows - 1,
                column: plan.values.start.column + plan.values.columns - 1
              });
          } catch {
          }
        }
      }
    };
    if (ast) visit(ast);
    refs.push({
      sheet,
      range: { startRow: row, endRow: row + 1, startColumn: column, endColumn: column + 1 }
    });
    const bytes = 64 + JSON.stringify(refs).length * 2 + JSON.stringify(result).length * 2;
    if (bytes > this.cache.budget) {
      this.cacheGeneration++;
      return result;
    }
    if (generation !== this.cacheGeneration) return result;
    this.cache.set(id, result, bytes);
    if (generation !== this.cacheGeneration) this.cache.delete(id);
    else this.dependencies.add(id, refs);
    return result;
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzeW5jLWNhbGN1bGF0aW9uLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIGV2YWx1YXRlRm9ybXVsYSxcbiAgcGFyc2VGb3JtdWxhLFxuICB0cmFuc2Zvcm1SZWZlcmVuY2VzLFxuICBmdW5jdGlvbkRlZmluaXRpb24sXG4gIEFnZ3JlZ2F0ZSxcbiAgVGV4dEpvaW4sXG4gIGNvbmRpdGlvbmFsLFxuICBsb29rdXAsXG4gIGNvbmRpdGlvbmFsUGxhbixcbiAgRm9ybXVsYUVycm9yLFxuICB0eXBlIEFTVCxcbiAgdHlwZSBSZWZlcmVuY2UsXG59IGZyb20gJ0BvcGVuc2hlZXRqcy9mb3JtdWxhJztcbmltcG9ydCB7IGFzc2VydCwgTElNSVRTLCB0eXBlIENlbGxWYWx1ZSwgc2NhbGFyVmFsdWUsIHR5cGUgQ2VsbFJlY29yZCB9IGZyb20gJy4vdHlwZXMuanMnO1xuaW1wb3J0IHsgUmVmZXJlbmNlSW5kZXggfSBmcm9tICcuL3JlZmVyZW5jZS1pbmRleC5qcyc7XG5pbXBvcnQgdHlwZSB7IFNlbGVjdGlvbiwgUmVjdCB9IGZyb20gJy4vdHlwZXMuanMnO1xuaW1wb3J0IHsgQnl0ZUNhY2hlIH0gZnJvbSAnLi9zdG9yYWdlLmpzJztcbnR5cGUgRXZhbHVhdGlvbldvcmsgPSB7IHJlbWFpbmluZzogbnVtYmVyOyBzaWduYWw/OiBBYm9ydFNpZ25hbCB9O1xudHlwZSBTY2FsYXJNZW1vID0geyBnZW5lcmF0aW9uOiBudW1iZXI7IGNhY2hlOiBCeXRlQ2FjaGU8Q2VsbFZhbHVlPiB9O1xuZXhwb3J0IGNsYXNzIEFzeW5jQ2FsY3VsYXRpb24ge1xuICBwcml2YXRlIGNhY2hlOiBCeXRlQ2FjaGU8Q2VsbFZhbHVlPjtcbiAgcHJpdmF0ZSBkZXBlbmRlbmNpZXMgPSBuZXcgUmVmZXJlbmNlSW5kZXgoKTtcbiAgcHJpdmF0ZSBjYWNoZUdlbmVyYXRpb24gPSAwO1xuICBwcml2YXRlIHNjYWxhckdlbmVyYXRpb24gPSAwO1xuICBwcml2YXRlIHJlbW92ZWQ6IHN0cmluZ1tdID0gW107XG4gIHByaXZhdGUgcmVtb3ZpbmcgPSBmYWxzZTtcbiAgZ2V0IGNhY2hlQnl0ZXMoKSB7XG4gICAgcmV0dXJuIHRoaXMuY2FjaGUuYnl0ZXM7XG4gIH1cbiAgZ2V0IGNhY2hlQnVkZ2V0KCkge1xuICAgIHJldHVybiB0aGlzLmNhY2hlLmJ1ZGdldDtcbiAgfVxuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIHJlYWQ6IChzaGVldDogc3RyaW5nLCByb3c6IG51bWJlciwgY29sdW1uOiBudW1iZXIpID0+IFByb21pc2U8Q2VsbFJlY29yZCB8IHVuZGVmaW5lZD4sXG4gICAgcHJpdmF0ZSBmaW5kOiAobmFtZTogc3RyaW5nKSA9PiBzdHJpbmcgfCB1bmRlZmluZWQsXG4gICAgYnVkZ2V0ID0gNCAqIDEwMjQgKiAxMDI0LFxuICAgIHByaXZhdGUgcGVyc2lzdGVkQVNUPzogKFxuICAgICAgc2hlZXQ6IHN0cmluZyxcbiAgICAgIHJvdzogbnVtYmVyLFxuICAgICAgY29sdW1uOiBudW1iZXIsXG4gICAgKSA9PiBQcm9taXNlPEFTVCB8IG51bGwgfCB1bmRlZmluZWQ+LFxuICAgIHByaXZhdGUgZGF0ZVN5c3RlbTogKCkgPT4gJzE5MDAnIHwgJzE5MDQnID0gKCkgPT4gJzE5MDAnLFxuICApIHtcbiAgICB0aGlzLmNhY2hlID0gbmV3IEJ5dGVDYWNoZShidWRnZXQsIChpZCkgPT4gdGhpcy5yZW1vdmVDYWNoZWQoaWQpKTtcbiAgfVxuICBwcml2YXRlIHJlbW92ZUNhY2hlZChpZDogc3RyaW5nKSB7XG4gICAgdGhpcy5jYWNoZUdlbmVyYXRpb24rKztcbiAgICB0aGlzLnJlbW92ZWQucHVzaChpZCk7XG4gICAgaWYgKHRoaXMucmVtb3ZpbmcpIHJldHVybjtcbiAgICB0aGlzLnJlbW92aW5nID0gdHJ1ZTtcbiAgICB0cnkge1xuICAgICAgd2hpbGUgKHRoaXMucmVtb3ZlZC5sZW5ndGgpIHtcbiAgICAgICAgY29uc3QgcmVtb3ZlZCA9IHRoaXMucmVtb3ZlZC5wb3AoKSE7XG4gICAgICAgIHRoaXMuZGVwZW5kZW5jaWVzLmRlbGV0ZShyZW1vdmVkKTtcbiAgICAgICAgY29uc3QgW3NoZWV0SWQsIHJvdywgY29sdW1uXSA9IHJlbW92ZWQuc3BsaXQoJzonKTtcbiAgICAgICAgZm9yIChjb25zdCBkZXBlbmRlbnQgb2YgdGhpcy5kZXBlbmRlbmNpZXMucXVlcnkoc2hlZXRJZCwge1xuICAgICAgICAgIHN0YXJ0Um93OiArcm93LFxuICAgICAgICAgIGVuZFJvdzogK3JvdyArIDEsXG4gICAgICAgICAgc3RhcnRDb2x1bW46ICtjb2x1bW4sXG4gICAgICAgICAgZW5kQ29sdW1uOiArY29sdW1uICsgMSxcbiAgICAgICAgfSkpXG4gICAgICAgICAgdGhpcy5jYWNoZS5kZWxldGUoZGVwZW5kZW50KTtcbiAgICAgIH1cbiAgICB9IGZpbmFsbHkge1xuICAgICAgdGhpcy5yZW1vdmluZyA9IGZhbHNlO1xuICAgIH1cbiAgfVxuICBjbGVhcigpIHtcbiAgICB0aGlzLmNhY2hlR2VuZXJhdGlvbisrO1xuICAgIHRoaXMuc2NhbGFyR2VuZXJhdGlvbisrO1xuICAgIHRoaXMuY2FjaGUuY2xlYXIoKTtcbiAgICB0aGlzLmRlcGVuZGVuY2llcy5jbGVhcigpO1xuICB9XG4gIGludmFsaWRhdGUocmFuZ2VzOiBTZWxlY3Rpb25bXSkge1xuICAgIHRoaXMuY2FjaGVHZW5lcmF0aW9uKys7XG4gICAgdGhpcy5zY2FsYXJHZW5lcmF0aW9uKys7XG4gICAgY29uc3QgcXVldWUgPSBbLi4ucmFuZ2VzXSxcbiAgICAgIHNlZW4gPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgICB3aGlsZSAocXVldWUubGVuZ3RoKSB7XG4gICAgICBjb25zdCByYW5nZSA9IHF1ZXVlLnBvcCgpITtcbiAgICAgIGZvciAoY29uc3QgaWQgb2YgdGhpcy5kZXBlbmRlbmNpZXMucXVlcnkocmFuZ2Uuc2hlZXRJZCwgcmFuZ2UpKSB7XG4gICAgICAgIGlmIChzZWVuLmhhcyhpZCkpIGNvbnRpbnVlO1xuICAgICAgICBzZWVuLmFkZChpZCk7XG4gICAgICAgIHRoaXMuY2FjaGUuZGVsZXRlKGlkKTtcbiAgICAgICAgY29uc3QgW3NoZWV0SWQsIHJvdywgY29sdW1uXSA9IGlkLnNwbGl0KCc6Jyk7XG4gICAgICAgIHF1ZXVlLnB1c2goe1xuICAgICAgICAgIHNoZWV0SWQsXG4gICAgICAgICAgc3RhcnRSb3c6ICtyb3csXG4gICAgICAgICAgZW5kUm93OiArcm93ICsgMSxcbiAgICAgICAgICBzdGFydENvbHVtbjogK2NvbHVtbixcbiAgICAgICAgICBlbmRDb2x1bW46ICtjb2x1bW4gKyAxLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgYXN5bmMgdmFsdWUoXG4gICAgc2hlZXQ6IHN0cmluZyxcbiAgICByb3c6IG51bWJlcixcbiAgICBjb2x1bW46IG51bWJlcixcbiAgICBzdGFjayA9IG5ldyBTZXQ8c3RyaW5nPigpLFxuICAgIHdvcms/OiBFdmFsdWF0aW9uV29yayxcbiAgICBtZW1vPzogU2NhbGFyTWVtbyxcbiAgKTogUHJvbWlzZTxDZWxsVmFsdWU+IHtcbiAgICB3b3JrPy5zaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG4gICAgaWYgKHdvcmsgJiYgLS13b3JrLnJlbWFpbmluZyA8IDApIHJldHVybiB7IGVycm9yOiAnI0xJTUlUIScgfTtcbiAgICBjb25zdCBpZCA9IGAke3NoZWV0fToke3Jvd306JHtjb2x1bW59YDtcbiAgICBjb25zdCBjYWNoZWQgPSB0aGlzLmNhY2hlLmdldChpZCk7XG4gICAgaWYgKGNhY2hlZCAhPT0gdW5kZWZpbmVkKSByZXR1cm4gY2FjaGVkO1xuICAgIGNvbnN0IGdlbmVyYXRpb24gPSB0aGlzLmNhY2hlR2VuZXJhdGlvbjtcbiAgICBjb25zdCBzY2FsYXJHZW5lcmF0aW9uID0gdGhpcy5zY2FsYXJHZW5lcmF0aW9uO1xuICAgIGlmIChtZW1vKSB7XG4gICAgICBpZiAobWVtby5nZW5lcmF0aW9uICE9PSBzY2FsYXJHZW5lcmF0aW9uKSB7XG4gICAgICAgIG1lbW8uY2FjaGUuY2xlYXIoKTtcbiAgICAgICAgbWVtby5nZW5lcmF0aW9uID0gc2NhbGFyR2VuZXJhdGlvbjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHNjYWxhciA9IG1lbW8uY2FjaGUuZ2V0KGlkKTtcbiAgICAgIGlmIChzY2FsYXIgIT09IHVuZGVmaW5lZCkgcmV0dXJuIHNjYWxhcjtcbiAgICB9XG4gICAgaWYgKHN0YWNrLmhhcyhpZCkpIHJldHVybiB7IGVycm9yOiAnI0NZQ0xFIScgfTtcbiAgICBjb25zdCBjZWxsID0gYXdhaXQgdGhpcy5yZWFkKHNoZWV0LCByb3csIGNvbHVtbik7XG4gICAgd29yaz8uc2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuICAgIGlmICghY2VsbCB8fCBjZWxsLmlucHV0LnR5cGUgIT09ICdmb3JtdWxhJykge1xuICAgICAgY29uc3QgcmVzdWx0ID0gY2VsbCAmJiBjZWxsLmlucHV0LnR5cGUgIT09ICdmb3JtdWxhJyA/IHNjYWxhclZhbHVlKGNlbGwuaW5wdXQpIDogbnVsbDtcbiAgICAgIGlmIChcbiAgICAgICAgbWVtbyAmJlxuICAgICAgICBzY2FsYXJHZW5lcmF0aW9uID09PSB0aGlzLnNjYWxhckdlbmVyYXRpb24gJiZcbiAgICAgICAgbWVtby5nZW5lcmF0aW9uID09PSBzY2FsYXJHZW5lcmF0aW9uXG4gICAgICApIHtcbiAgICAgICAgY29uc3QgYnl0ZXMgPSAxOTIgKyBpZC5sZW5ndGggKiAyICsgKHR5cGVvZiByZXN1bHQgPT09ICdzdHJpbmcnID8gcmVzdWx0Lmxlbmd0aCAqIDIgOiAxMjgpO1xuICAgICAgICBtZW1vLmNhY2hlLnNldChpZCwgcmVzdWx0LCBieXRlcyk7XG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICBpZiAoc3RhY2suc2l6ZSA+PSAxMjgpIHJldHVybiB7IGVycm9yOiAnI0xJTUlUIScgfTtcbiAgICBzdGFjay5hZGQoaWQpO1xuICAgIGxldCByZXN1bHQ6IENlbGxWYWx1ZTtcbiAgICBsZXQgYXN0OiBBU1QgfCB1bmRlZmluZWQ7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHBlcnNpc3RlZCA9IGF3YWl0IHRoaXMucGVyc2lzdGVkQVNUPy4oc2hlZXQsIHJvdywgY29sdW1uKTtcbiAgICAgIGFzdCA9IHBlcnNpc3RlZCA/PyBwYXJzZUZvcm11bGEoY2VsbC5pbnB1dC5leHByZXNzaW9uKTtcbiAgICAgIHJlc3VsdCA9IGF3YWl0IHRoaXMuZXZhbHVhdGUoc2hlZXQsIGFzdCwgc3RhY2ssIHdvcmssIG1lbW8pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAod29yaz8uc2lnbmFsPy5hYm9ydGVkIHx8IChlcnJvciBhcyB7IGNvZGU/OiBzdHJpbmcgfSkuY29kZSA9PT0gJ0FCT1JURUQnKSB0aHJvdyBlcnJvcjtcbiAgICAgIHJlc3VsdCA9IHsgZXJyb3I6IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogJyNWQUxVRSEnIH07XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHN0YWNrLmRlbGV0ZShpZCk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLnJlbWVtYmVyKGlkLCBzaGVldCwgcm93LCBjb2x1bW4sIGFzdCwgcmVzdWx0LCBnZW5lcmF0aW9uKTtcbiAgfVxuICAvKiogUmV1c2UgYm91bmRlZCBzY2FsYXIgcmVmZXJlbmNlcyBvbmx5IGZvciB0aGUgbGlmZXRpbWUgb2Ygb25lIGNhbGxlci1vd25lZCByZWFkLiAqL1xuICByZWFkU2Vzc2lvbihtaW5pbXVtU2NyYXRjaEJ5dGVzID0gMCkge1xuICAgIGFzc2VydChcbiAgICAgIE51bWJlci5pc1NhZmVJbnRlZ2VyKG1pbmltdW1TY3JhdGNoQnl0ZXMpICYmXG4gICAgICAgIG1pbmltdW1TY3JhdGNoQnl0ZXMgPj0gMCAmJlxuICAgICAgICBtaW5pbXVtU2NyYXRjaEJ5dGVzIDw9IDY0ICogMTAyNCxcbiAgICAgICdJTlZBTElEX0FSR1VNRU5UJyxcbiAgICAgICdJbnZhbGlkIGNhbGN1bGF0aW9uIHNjcmF0Y2ggYnVkZ2V0JyxcbiAgICApO1xuICAgIGNvbnN0IG1lbW86IFNjYWxhck1lbW8gPSB7XG4gICAgICBnZW5lcmF0aW9uOiB0aGlzLnNjYWxhckdlbmVyYXRpb24sXG4gICAgICBjYWNoZTogbmV3IEJ5dGVDYWNoZShNYXRoLm1heChtaW5pbXVtU2NyYXRjaEJ5dGVzLCBNYXRoLm1pbih0aGlzLmNhY2hlLmJ1ZGdldCwgNjQgKiAxMDI0KSkpLFxuICAgIH07XG4gICAgcmV0dXJuIChzaGVldDogc3RyaW5nLCByb3c6IG51bWJlciwgY29sdW1uOiBudW1iZXIpID0+XG4gICAgICB0aGlzLnZhbHVlKHNoZWV0LCByb3csIGNvbHVtbiwgbmV3IFNldCgpLCB1bmRlZmluZWQsIG1lbW8pO1xuICB9XG4gIC8qKiBBIHNoYXJlZCBjYWxjdWxhdGlvbiBidWRnZXQgZm9yIG9uZSBpbW11dGFibGUgc3RhZ2VkIHdvcmtib29rIHZpZXcuICovXG4gIHZhbGlkYXRpb25TZXNzaW9uKHNpZ25hbD86IEFib3J0U2lnbmFsLCBzdGVwcyA9IDFfMDAwXzAwMCkge1xuICAgIGFzc2VydChcbiAgICAgIE51bWJlci5pc1NhZmVJbnRlZ2VyKHN0ZXBzKSAmJiBzdGVwcyA+IDAgJiYgc3RlcHMgPD0gMV8wMDBfMDAwLFxuICAgICAgJ0lOVkFMSURfQVJHVU1FTlQnLFxuICAgICAgJ0ludmFsaWQgdmFsaWRhdGlvbiBjYWxjdWxhdGlvbiBidWRnZXQnLFxuICAgICk7XG4gICAgY29uc3Qgd29yazogRXZhbHVhdGlvbldvcmsgPSB7IHJlbWFpbmluZzogc3RlcHMsIHNpZ25hbCB9O1xuICAgIC8vIFRoZSBwYXJlbnQgY2FjaGUgYW5kIHBlcnNpc3RlZCBBU1RzIGNhbiBiZWxvbmcgdG8gdGhlIHByZS1zdGFnaW5nIHJldmlzaW9uLlxuICAgIC8vIEtlZXAgYm90aCB0aGUgdmFsdWVzIGFuZCBwYXJzZWQgZm9ybXVsYXMgbG9jYWwgdG8gdGhpcyBpbW11dGFibGUgc3RhZ2VkIHZpZXcuXG4gICAgY29uc3Qgc3RhZ2VkID0gbmV3IEFzeW5jQ2FsY3VsYXRpb24oXG4gICAgICB0aGlzLnJlYWQsXG4gICAgICB0aGlzLmZpbmQsXG4gICAgICB0aGlzLmNhY2hlLmJ1ZGdldCxcbiAgICAgIHVuZGVmaW5lZCxcbiAgICAgIHRoaXMuZGF0ZVN5c3RlbSxcbiAgICApO1xuICAgIGNvbnN0IGV2YWx1YXRlRm9ybXVsYSA9IGFzeW5jIChcbiAgICAgIHNoZWV0OiBzdHJpbmcsXG4gICAgICByZXF1ZXN0OiB7IGV4cHJlc3Npb246IHN0cmluZzsgcm93T2Zmc2V0OiBudW1iZXI7IGNvbHVtbk9mZnNldDogbnVtYmVyIH0sXG4gICAgKTogUHJvbWlzZTxDZWxsVmFsdWU+ID0+IHtcbiAgICAgIHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcbiAgICAgIGlmICgtLXdvcmsucmVtYWluaW5nIDwgMCkgcmV0dXJuIHsgZXJyb3I6ICcjTElNSVQhJyB9O1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgYXN0ID0gdHJhbnNmb3JtUmVmZXJlbmNlcyhwYXJzZUZvcm11bGEocmVxdWVzdC5leHByZXNzaW9uKSwgKHJlZikgPT4ge1xuICAgICAgICAgIGNvbnN0IHJvdyA9IHJlZi5yb3cgKyAocmVmLmFic29sdXRlUm93ID8gMCA6IHJlcXVlc3Qucm93T2Zmc2V0KTtcbiAgICAgICAgICBjb25zdCBjb2x1bW4gPSByZWYuY29sdW1uICsgKHJlZi5hYnNvbHV0ZUNvbHVtbiA/IDAgOiByZXF1ZXN0LmNvbHVtbk9mZnNldCk7XG4gICAgICAgICAgcmV0dXJuIHJvdyA8IDAgfHwgcm93ID49IExJTUlUUy5yb3dzIHx8IGNvbHVtbiA8IDAgfHwgY29sdW1uID49IExJTUlUUy5jb2x1bW5zXG4gICAgICAgICAgICA/IG51bGxcbiAgICAgICAgICAgIDogeyAuLi5yZWYsIHJvdywgY29sdW1uIH07XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gYXdhaXQgc3RhZ2VkLmV2YWx1YXRlKHNoZWV0LCBhc3QsIG5ldyBTZXQoKSwgd29yayk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBpZiAoc2lnbmFsPy5hYm9ydGVkIHx8IChlcnJvciBhcyB7IGNvZGU/OiBzdHJpbmcgfSkuY29kZSA9PT0gJ0FCT1JURUQnKSB0aHJvdyBlcnJvcjtcbiAgICAgICAgcmV0dXJuIHsgZXJyb3I6IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogJyNWQUxVRSEnIH07XG4gICAgICB9XG4gICAgfTtcbiAgICByZXR1cm4ge1xuICAgICAgZm9yU2hlZXQ6IChzaGVldDogc3RyaW5nKSA9PiAoe1xuICAgICAgICByZWFkOiAocm93OiBudW1iZXIsIGNvbHVtbjogbnVtYmVyKSA9PiBzdGFnZWQudmFsdWUoc2hlZXQsIHJvdywgY29sdW1uLCBuZXcgU2V0KCksIHdvcmspLFxuICAgICAgICBldmFsdWF0ZUZvcm11bGE6IChyZXF1ZXN0OiBQYXJhbWV0ZXJzPHR5cGVvZiBldmFsdWF0ZUZvcm11bGE+WzFdKSA9PlxuICAgICAgICAgIGV2YWx1YXRlRm9ybXVsYShzaGVldCwgcmVxdWVzdCksXG4gICAgICB9KSxcbiAgICB9O1xuICB9XG4gIHByaXZhdGUgYXN5bmMgZXZhbHVhdGUoXG4gICAgc2hlZXQ6IHN0cmluZyxcbiAgICBhc3Q6IEFTVCxcbiAgICBzdGFjazogU2V0PHN0cmluZz4sXG4gICAgc2hhcmVkPzogRXZhbHVhdGlvbldvcmssXG4gICAgbWVtbz86IFNjYWxhck1lbW8sXG4gICkge1xuICAgIGNvbnN0IHdvcmsgPSBzaGFyZWQgPz8geyByZW1haW5pbmc6IDEwXzAwMF8wMDAgfTtcbiAgICBsZXQgdGV4dFdvcms6IHsgcmVtYWluaW5nOiBudW1iZXIgfSB8IHVuZGVmaW5lZDtcbiAgICBjb25zdCByZWYgPSBhc3luYyAocjogUmVmZXJlbmNlKTogUHJvbWlzZTxDZWxsVmFsdWU+ID0+IHtcbiAgICAgIGlmICh3b3JrLnJlbWFpbmluZyAlIDEwMjQgPT09IDApIGF3YWl0IG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlKSA9PiBzZXRUaW1lb3V0KHJlc29sdmUsIDApKTtcbiAgICAgIHdvcmsuc2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuICAgICAgaWYgKC0td29yay5yZW1haW5pbmcgPCAwKSByZXR1cm4geyBlcnJvcjogJyNMSU1JVCEnIH07XG4gICAgICBjb25zdCB0YXJnZXQgPSByLnNoZWV0ID8gdGhpcy5maW5kKHIuc2hlZXQpIDogc2hlZXQ7XG4gICAgICByZXR1cm4gdGFyZ2V0ID8gdGhpcy52YWx1ZSh0YXJnZXQsIHIucm93LCByLmNvbHVtbiwgc3RhY2ssIHNoYXJlZCwgbWVtbykgOiB7IGVycm9yOiAnI1JFRiEnIH07XG4gICAgfTtcbiAgICBjb25zdCBsaXRlcmFsID0gKHZhbHVlOiBDZWxsVmFsdWUpOiBBU1QgPT4gKHsga2luZDogJ2xpdGVyYWwnLCB2YWx1ZSB9KTtcbiAgICBjb25zdCBydW4gPSBhc3luYyAoYXN0OiBBU1QpOiBQcm9taXNlPENlbGxWYWx1ZT4gPT4ge1xuICAgICAgaWYgKC0td29yay5yZW1haW5pbmcgPCAwKSByZXR1cm4geyBlcnJvcjogJyNMSU1JVCEnIH07XG4gICAgICBpZiAoYXN0LmtpbmQgPT09ICdsaXRlcmFsJylcbiAgICAgICAgcmV0dXJuIHR5cGVvZiBhc3QudmFsdWUgPT09ICdudW1iZXInICYmICFOdW1iZXIuaXNGaW5pdGUoYXN0LnZhbHVlKVxuICAgICAgICAgID8geyBlcnJvcjogJyNOVU0hJyB9XG4gICAgICAgICAgOiBhc3QudmFsdWU7XG4gICAgICBpZiAoYXN0LmtpbmQgPT09ICdyZWYnKSByZXR1cm4gcmVmKGFzdCk7XG4gICAgICBpZiAoYXN0LmtpbmQgPT09ICdyYW5nZScpIHJldHVybiB7IGVycm9yOiAnI1ZBTFVFIScgfTtcbiAgICAgIGlmIChhc3Qua2luZCA9PT0gJ3VuYXJ5JylcbiAgICAgICAgcmV0dXJuIGV2YWx1YXRlRm9ybXVsYSh7IC4uLmFzdCwgdmFsdWU6IGxpdGVyYWwoYXdhaXQgcnVuKGFzdC52YWx1ZSkpIH0sICgpID0+IG51bGwpO1xuICAgICAgaWYgKGFzdC5raW5kID09PSAnYmluYXJ5Jykge1xuICAgICAgICBjb25zdCBsZWZ0ID0gYXdhaXQgcnVuKGFzdC5sZWZ0KTtcbiAgICAgICAgaWYgKGxlZnQgJiYgdHlwZW9mIGxlZnQgPT09ICdvYmplY3QnKSByZXR1cm4gbGVmdDtcbiAgICAgICAgcmV0dXJuIGV2YWx1YXRlRm9ybXVsYShcbiAgICAgICAgICB7IC4uLmFzdCwgbGVmdDogbGl0ZXJhbChsZWZ0KSwgcmlnaHQ6IGxpdGVyYWwoYXdhaXQgcnVuKGFzdC5yaWdodCkpIH0sXG4gICAgICAgICAgKCkgPT4gbnVsbCxcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGRlZmluaXRpb24gPSBmdW5jdGlvbkRlZmluaXRpb24oYXN0Lm5hbWUpO1xuICAgICAgaWYgKCFkZWZpbml0aW9uKSByZXR1cm4geyBlcnJvcjogJyNOQU1FPycgfTtcbiAgICAgIGlmIChhc3QuYXJncy5sZW5ndGggPCBkZWZpbml0aW9uLm1pbkFyZ3MgfHwgYXN0LmFyZ3MubGVuZ3RoID4gZGVmaW5pdGlvbi5tYXhBcmdzKVxuICAgICAgICByZXR1cm4geyBlcnJvcjogJyNWQUxVRSEnIH07XG4gICAgICBpZiAoZGVmaW5pdGlvbi5ldmFsdWF0aW9uID09PSAnY29uZGl0aW9uYWwnIHx8IGRlZmluaXRpb24uZXZhbHVhdGlvbiA9PT0gJ2xvb2t1cCcpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCBpdGVyYXRvciA9IChkZWZpbml0aW9uLmV2YWx1YXRpb24gPT09ICdsb29rdXAnID8gbG9va3VwIDogY29uZGl0aW9uYWwpKFxuICAgICAgICAgICAgYXN0Lm5hbWUsXG4gICAgICAgICAgICBhc3QuYXJncyxcbiAgICAgICAgICAgICh0ZXh0V29yayA/Pz0geyByZW1haW5pbmc6IDFfMDAwXzAwMCB9KSxcbiAgICAgICAgICApO1xuICAgICAgICAgIGxldCBzdGVwID0gaXRlcmF0b3IubmV4dCgpO1xuICAgICAgICAgIHdoaWxlICghc3RlcC5kb25lKSB7XG4gICAgICAgICAgICBpZiAod29yay5yZW1haW5pbmcgPD0gMCkgcmV0dXJuIHsgZXJyb3I6ICcjTElNSVQhJyB9O1xuICAgICAgICAgICAgc3RlcCA9IGl0ZXJhdG9yLm5leHQoYXdhaXQgcnVuKHN0ZXAudmFsdWUpKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHN0ZXAudmFsdWU7XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgRm9ybXVsYUVycm9yKSByZXR1cm4geyBlcnJvcjogZXJyb3IuY29kZSB9O1xuICAgICAgICAgIHRocm93IGVycm9yO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAoYXN0Lm5hbWUgPT09ICdJRicpIHtcbiAgICAgICAgY29uc3QgdGVzdCA9IGV2YWx1YXRlRm9ybXVsYShcbiAgICAgICAgICB7XG4gICAgICAgICAgICBraW5kOiAnY2FsbCcsXG4gICAgICAgICAgICBuYW1lOiAnSUYnLFxuICAgICAgICAgICAgYXJnczogW2xpdGVyYWwoYXdhaXQgcnVuKGFzdC5hcmdzWzBdKSksIGxpdGVyYWwodHJ1ZSksIGxpdGVyYWwoZmFsc2UpXSxcbiAgICAgICAgICB9LFxuICAgICAgICAgICgpID0+IG51bGwsXG4gICAgICAgICk7XG4gICAgICAgIHJldHVybiB0eXBlb2YgdGVzdCA9PT0gJ29iamVjdCcgJiYgdGVzdFxuICAgICAgICAgID8gdGVzdFxuICAgICAgICAgIDogcnVuKGFzdC5hcmdzW3Rlc3QgPyAxIDogMl0gPz8gbGl0ZXJhbChmYWxzZSkpO1xuICAgICAgfVxuICAgICAgaWYgKGFzdC5uYW1lID09PSAnSUZTJykge1xuICAgICAgICBpZiAoYXN0LmFyZ3MubGVuZ3RoICUgMikgcmV0dXJuIHsgZXJyb3I6ICcjVkFMVUUhJyB9O1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGFzdC5hcmdzLmxlbmd0aDsgaSArPSAyKSB7XG4gICAgICAgICAgY29uc3QgdGVzdCA9IGV2YWx1YXRlRm9ybXVsYShcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAga2luZDogJ2NhbGwnLFxuICAgICAgICAgICAgICBuYW1lOiAnSUYnLFxuICAgICAgICAgICAgICBhcmdzOiBbbGl0ZXJhbChhd2FpdCBydW4oYXN0LmFyZ3NbaV0pKSwgbGl0ZXJhbCh0cnVlKSwgbGl0ZXJhbChmYWxzZSldLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICgpID0+IG51bGwsXG4gICAgICAgICAgKTtcbiAgICAgICAgICBpZiAodGVzdCAmJiB0eXBlb2YgdGVzdCA9PT0gJ29iamVjdCcpIHJldHVybiB0ZXN0O1xuICAgICAgICAgIGlmICh0ZXN0KSByZXR1cm4gcnVuKGFzdC5hcmdzW2kgKyAxXSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHsgZXJyb3I6ICcjTi9BJyB9O1xuICAgICAgfVxuICAgICAgaWYgKGFzdC5uYW1lID09PSAnSUZFUlJPUicgfHwgYXN0Lm5hbWUgPT09ICdJRk5BJykge1xuICAgICAgICBjb25zdCB2ID0gYXdhaXQgcnVuKGFzdC5hcmdzWzBdKTtcbiAgICAgICAgcmV0dXJuIHYgJiZcbiAgICAgICAgICB0eXBlb2YgdiA9PT0gJ29iamVjdCcgJiZcbiAgICAgICAgICB2LmVycm9yICE9PSAnI0xJTUlUIScgJiZcbiAgICAgICAgICB2LmVycm9yICE9PSAnI0NZQ0xFIScgJiZcbiAgICAgICAgICAoYXN0Lm5hbWUgPT09ICdJRkVSUk9SJyB8fCB2LmVycm9yID09PSAnI04vQScpXG4gICAgICAgICAgPyBydW4oYXN0LmFyZ3NbMV0pXG4gICAgICAgICAgOiB2O1xuICAgICAgfVxuICAgICAgaWYgKGRlZmluaXRpb24uZXZhbHVhdGlvbiA9PT0gJ2FnZ3JlZ2F0ZScgfHwgZGVmaW5pdGlvbi5ldmFsdWF0aW9uID09PSAndGV4dCcpIHtcbiAgICAgICAgY29uc3QgYWdncmVnYXRlID1cbiAgICAgICAgICBkZWZpbml0aW9uLmV2YWx1YXRpb24gPT09ICdhZ2dyZWdhdGUnXG4gICAgICAgICAgICA/IG5ldyBBZ2dyZWdhdGUoYXN0Lm5hbWUpXG4gICAgICAgICAgICA6IGFzdC5uYW1lID09PSAnVEVYVEpPSU4nXG4gICAgICAgICAgICAgID8gbmV3IFRleHRKb2luKGF3YWl0IHJ1bihhc3QuYXJnc1swXSksIGF3YWl0IHJ1bihhc3QuYXJnc1sxXSkpXG4gICAgICAgICAgICAgIDogbmV3IFRleHRKb2luKCk7XG4gICAgICAgIGZvciAoY29uc3QgYXJnIG9mIGFzdC5uYW1lID09PSAnVEVYVEpPSU4nID8gYXN0LmFyZ3Muc2xpY2UoMikgOiBhc3QuYXJncykge1xuICAgICAgICAgIGlmIChhcmcua2luZCAhPT0gJ3JhbmdlJykgYWdncmVnYXRlLmFkZChhd2FpdCBydW4oYXJnKSwgYXJnLmtpbmQgPT09ICdyZWYnKTtcbiAgICAgICAgICBlbHNlXG4gICAgICAgICAgICBmb3IgKFxuICAgICAgICAgICAgICBsZXQgciA9IE1hdGgubWluKGFyZy5zdGFydC5yb3csIGFyZy5lbmQucm93KTtcbiAgICAgICAgICAgICAgciA8PSBNYXRoLm1heChhcmcuc3RhcnQucm93LCBhcmcuZW5kLnJvdyk7XG4gICAgICAgICAgICAgIHIrK1xuICAgICAgICAgICAgKVxuICAgICAgICAgICAgICBmb3IgKFxuICAgICAgICAgICAgICAgIGxldCBjID0gTWF0aC5taW4oYXJnLnN0YXJ0LmNvbHVtbiwgYXJnLmVuZC5jb2x1bW4pO1xuICAgICAgICAgICAgICAgIGMgPD0gTWF0aC5tYXgoYXJnLnN0YXJ0LmNvbHVtbiwgYXJnLmVuZC5jb2x1bW4pO1xuICAgICAgICAgICAgICAgIGMrK1xuICAgICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICBpZiAod29yay5yZW1haW5pbmcgPD0gMCkgcmV0dXJuIHsgZXJyb3I6ICcjTElNSVQhJyB9O1xuICAgICAgICAgICAgICAgIGFnZ3JlZ2F0ZS5hZGQoYXdhaXQgcmVmKHsgLi4uYXJnLnN0YXJ0LCByb3c6IHIsIGNvbHVtbjogYyB9KSwgdHJ1ZSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYWdncmVnYXRlLnJlc3VsdCgpO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBhcmdzOiBBU1RbXSA9IFtdO1xuICAgICAgZm9yIChjb25zdCBhcmcgb2YgYXN0LmFyZ3MpIHtcbiAgICAgICAgY29uc3QgdmFsdWUgPSBhd2FpdCBydW4oYXJnKTtcbiAgICAgICAgaWYgKHZhbHVlICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcpIHJldHVybiB2YWx1ZTtcbiAgICAgICAgYXJncy5wdXNoKGxpdGVyYWwodmFsdWUpKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBldmFsdWF0ZUZvcm11bGEoeyAuLi5hc3QsIGFyZ3MgfSwgKCkgPT4gbnVsbCwgdW5kZWZpbmVkLCB0aGlzLmRhdGVTeXN0ZW0oKSk7XG4gICAgfTtcbiAgICByZXR1cm4gcnVuKGFzdCk7XG4gIH1cbiAgcHJpdmF0ZSByZW1lbWJlcihcbiAgICBpZDogc3RyaW5nLFxuICAgIHNoZWV0OiBzdHJpbmcsXG4gICAgcm93OiBudW1iZXIsXG4gICAgY29sdW1uOiBudW1iZXIsXG4gICAgYXN0OiBBU1QgfCB1bmRlZmluZWQsXG4gICAgcmVzdWx0OiBDZWxsVmFsdWUsXG4gICAgZ2VuZXJhdGlvbjogbnVtYmVyLFxuICApIHtcbiAgICAvLyBJbnRlcm5hbCBmYWlsdXJlcyBkZXBlbmQgb24gdGhlIGFjdGl2ZSB0cmF2ZXJzYWwgYW5kIGFyZSBub3Qgc3RhYmxlIGNhY2hlZCB2YWx1ZXMuXG4gICAgaWYgKHJlc3VsdCAmJiB0eXBlb2YgcmVzdWx0ID09PSAnb2JqZWN0JyAmJiBbJyNMSU1JVCEnLCAnI0NZQ0xFISddLmluY2x1ZGVzKHJlc3VsdC5lcnJvcikpXG4gICAgICByZXR1cm4gcmVzdWx0O1xuICAgIGNvbnN0IHJlZnM6IEFycmF5PHsgc2hlZXQ6IHN0cmluZzsgcmFuZ2U6IFJlY3QgfT4gPSBbXTtcbiAgICBjb25zdCBhZGQgPSAocmVmOiBSZWZlcmVuY2UsIGVuZCA9IHJlZikgPT4ge1xuICAgICAgY29uc3QgdGFyZ2V0ID0gcmVmLnNoZWV0ID8gdGhpcy5maW5kKHJlZi5zaGVldCkgOiBzaGVldDtcbiAgICAgIGlmICh0YXJnZXQpXG4gICAgICAgIHJlZnMucHVzaCh7XG4gICAgICAgICAgc2hlZXQ6IHRhcmdldCxcbiAgICAgICAgICByYW5nZToge1xuICAgICAgICAgICAgc3RhcnRSb3c6IE1hdGgubWluKHJlZi5yb3csIGVuZC5yb3cpLFxuICAgICAgICAgICAgZW5kUm93OiBNYXRoLm1heChyZWYucm93LCBlbmQucm93KSArIDEsXG4gICAgICAgICAgICBzdGFydENvbHVtbjogTWF0aC5taW4ocmVmLmNvbHVtbiwgZW5kLmNvbHVtbiksXG4gICAgICAgICAgICBlbmRDb2x1bW46IE1hdGgubWF4KHJlZi5jb2x1bW4sIGVuZC5jb2x1bW4pICsgMSxcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9O1xuICAgIGNvbnN0IHZpc2l0ID0gKG5vZGU6IEFTVCkgPT4ge1xuICAgICAgaWYgKG5vZGUua2luZCA9PT0gJ3JlZicpIGFkZChub2RlKTtcbiAgICAgIGVsc2UgaWYgKG5vZGUua2luZCA9PT0gJ3JhbmdlJykgYWRkKG5vZGUuc3RhcnQsIG5vZGUuZW5kKTtcbiAgICAgIGVsc2UgaWYgKG5vZGUua2luZCA9PT0gJ3VuYXJ5JykgdmlzaXQobm9kZS52YWx1ZSk7XG4gICAgICBlbHNlIGlmIChub2RlLmtpbmQgPT09ICdiaW5hcnknKSB7XG4gICAgICAgIHZpc2l0KG5vZGUubGVmdCk7XG4gICAgICAgIHZpc2l0KG5vZGUucmlnaHQpO1xuICAgICAgfSBlbHNlIGlmIChub2RlLmtpbmQgPT09ICdjYWxsJykge1xuICAgICAgICBub2RlLmFyZ3MuZm9yRWFjaCh2aXNpdCk7XG4gICAgICAgIGlmIChmdW5jdGlvbkRlZmluaXRpb24obm9kZS5uYW1lKT8uZXZhbHVhdGlvbiA9PT0gJ2NvbmRpdGlvbmFsJykge1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBwbGFuID0gY29uZGl0aW9uYWxQbGFuKG5vZGUubmFtZSwgbm9kZS5hcmdzKTtcbiAgICAgICAgICAgIGlmIChwbGFuLnZhbHVlcylcbiAgICAgICAgICAgICAgYWRkKHBsYW4udmFsdWVzLnN0YXJ0LCB7XG4gICAgICAgICAgICAgICAgLi4ucGxhbi52YWx1ZXMuc3RhcnQsXG4gICAgICAgICAgICAgICAgcm93OiBwbGFuLnZhbHVlcy5zdGFydC5yb3cgKyBwbGFuLnZhbHVlcy5yb3dzIC0gMSxcbiAgICAgICAgICAgICAgICBjb2x1bW46IHBsYW4udmFsdWVzLnN0YXJ0LmNvbHVtbiArIHBsYW4udmFsdWVzLmNvbHVtbnMgLSAxLFxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAgIC8qIEludmFsaWQgcGxhbnMgaGF2ZSBubyBhZGRpdGlvbmFsIHByb2plY3RlZCBkZXBlbmRlbmNpZXMuICovXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfTtcbiAgICBpZiAoYXN0KSB2aXNpdChhc3QpO1xuICAgIHJlZnMucHVzaCh7XG4gICAgICBzaGVldCxcbiAgICAgIHJhbmdlOiB7IHN0YXJ0Um93OiByb3csIGVuZFJvdzogcm93ICsgMSwgc3RhcnRDb2x1bW46IGNvbHVtbiwgZW5kQ29sdW1uOiBjb2x1bW4gKyAxIH0sXG4gICAgfSk7XG4gICAgY29uc3QgYnl0ZXMgPSA2NCArIEpTT04uc3RyaW5naWZ5KHJlZnMpLmxlbmd0aCAqIDIgKyBKU09OLnN0cmluZ2lmeShyZXN1bHQpLmxlbmd0aCAqIDI7XG4gICAgaWYgKGJ5dGVzID4gdGhpcy5jYWNoZS5idWRnZXQpIHtcbiAgICAgIHRoaXMuY2FjaGVHZW5lcmF0aW9uKys7XG4gICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICBpZiAoZ2VuZXJhdGlvbiAhPT0gdGhpcy5jYWNoZUdlbmVyYXRpb24pIHJldHVybiByZXN1bHQ7XG4gICAgdGhpcy5jYWNoZS5zZXQoaWQsIHJlc3VsdCwgYnl0ZXMpO1xuICAgIGlmIChnZW5lcmF0aW9uICE9PSB0aGlzLmNhY2hlR2VuZXJhdGlvbikgdGhpcy5jYWNoZS5kZWxldGUoaWQpO1xuICAgIGVsc2UgdGhpcy5kZXBlbmRlbmNpZXMuYWRkKGlkLCByZWZzKTtcbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG59XG4iXSwibWFwcGluZ3MiOiJBQUFBO0FBQUEsRUFDRTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLE9BR0s7QUFDUCxTQUFTLFFBQVEsUUFBd0IsbUJBQW9DO0FBQzdFLFNBQVMsc0JBQXNCO0FBRS9CLFNBQVMsaUJBQWlCO0FBR25CLGFBQU0saUJBQWlCO0FBQUEsRUFhNUIsWUFDVSxNQUNBLE1BQ1IsU0FBUyxJQUFJLE9BQU8sTUFDWixjQUtBLGFBQW9DLE1BQU0sUUFDbEQ7QUFUUTtBQUNBO0FBRUE7QUFLQTtBQUVSLFNBQUssUUFBUSxJQUFJLFVBQVUsUUFBUSxDQUFDLE9BQU8sS0FBSyxhQUFhLEVBQUUsQ0FBQztBQUFBLEVBQ2xFO0FBQUEsRUFYVTtBQUFBLEVBQ0E7QUFBQSxFQUVBO0FBQUEsRUFLQTtBQUFBLEVBckJGO0FBQUEsRUFDQSxlQUFlLElBQUksZUFBZTtBQUFBLEVBQ2xDLGtCQUFrQjtBQUFBLEVBQ2xCLG1CQUFtQjtBQUFBLEVBQ25CLFVBQW9CLENBQUM7QUFBQSxFQUNyQixXQUFXO0FBQUEsRUFDbkIsSUFBSSxhQUFhO0FBQ2YsV0FBTyxLQUFLLE1BQU07QUFBQSxFQUNwQjtBQUFBLEVBQ0EsSUFBSSxjQUFjO0FBQ2hCLFdBQU8sS0FBSyxNQUFNO0FBQUEsRUFDcEI7QUFBQSxFQWNRLGFBQWEsSUFBWTtBQUMvQixTQUFLO0FBQ0wsU0FBSyxRQUFRLEtBQUssRUFBRTtBQUNwQixRQUFJLEtBQUssU0FBVTtBQUNuQixTQUFLLFdBQVc7QUFDaEIsUUFBSTtBQUNGLGFBQU8sS0FBSyxRQUFRLFFBQVE7QUFDMUIsY0FBTSxVQUFVLEtBQUssUUFBUSxJQUFJO0FBQ2pDLGFBQUssYUFBYSxPQUFPLE9BQU87QUFDaEMsY0FBTSxDQUFDLFNBQVMsS0FBSyxNQUFNLElBQUksUUFBUSxNQUFNLEdBQUc7QUFDaEQsbUJBQVcsYUFBYSxLQUFLLGFBQWEsTUFBTSxTQUFTO0FBQUEsVUFDdkQsVUFBVSxDQUFDO0FBQUEsVUFDWCxRQUFRLENBQUMsTUFBTTtBQUFBLFVBQ2YsYUFBYSxDQUFDO0FBQUEsVUFDZCxXQUFXLENBQUMsU0FBUztBQUFBLFFBQ3ZCLENBQUM7QUFDQyxlQUFLLE1BQU0sT0FBTyxTQUFTO0FBQUEsTUFDL0I7QUFBQSxJQUNGLFVBQUU7QUFDQSxXQUFLLFdBQVc7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLFFBQVE7QUFDTixTQUFLO0FBQ0wsU0FBSztBQUNMLFNBQUssTUFBTSxNQUFNO0FBQ2pCLFNBQUssYUFBYSxNQUFNO0FBQUEsRUFDMUI7QUFBQSxFQUNBLFdBQVcsUUFBcUI7QUFDOUIsU0FBSztBQUNMLFNBQUs7QUFDTCxVQUFNLFFBQVEsQ0FBQyxHQUFHLE1BQU0sR0FDdEIsT0FBTyxvQkFBSSxJQUFZO0FBQ3pCLFdBQU8sTUFBTSxRQUFRO0FBQ25CLFlBQU0sUUFBUSxNQUFNLElBQUk7QUFDeEIsaUJBQVcsTUFBTSxLQUFLLGFBQWEsTUFBTSxNQUFNLFNBQVMsS0FBSyxHQUFHO0FBQzlELFlBQUksS0FBSyxJQUFJLEVBQUUsRUFBRztBQUNsQixhQUFLLElBQUksRUFBRTtBQUNYLGFBQUssTUFBTSxPQUFPLEVBQUU7QUFDcEIsY0FBTSxDQUFDLFNBQVMsS0FBSyxNQUFNLElBQUksR0FBRyxNQUFNLEdBQUc7QUFDM0MsY0FBTSxLQUFLO0FBQUEsVUFDVDtBQUFBLFVBQ0EsVUFBVSxDQUFDO0FBQUEsVUFDWCxRQUFRLENBQUMsTUFBTTtBQUFBLFVBQ2YsYUFBYSxDQUFDO0FBQUEsVUFDZCxXQUFXLENBQUMsU0FBUztBQUFBLFFBQ3ZCLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLE1BQU0sTUFDSixPQUNBLEtBQ0EsUUFDQSxRQUFRLG9CQUFJLElBQVksR0FDeEIsTUFDQSxNQUNvQjtBQUNwQixVQUFNLFFBQVEsZUFBZTtBQUM3QixRQUFJLFFBQVEsRUFBRSxLQUFLLFlBQVksRUFBRyxRQUFPLEVBQUUsT0FBTyxVQUFVO0FBQzVELFVBQU0sS0FBSyxHQUFHLEtBQUssSUFBSSxHQUFHLElBQUksTUFBTTtBQUNwQyxVQUFNLFNBQVMsS0FBSyxNQUFNLElBQUksRUFBRTtBQUNoQyxRQUFJLFdBQVcsT0FBVyxRQUFPO0FBQ2pDLFVBQU0sYUFBYSxLQUFLO0FBQ3hCLFVBQU0sbUJBQW1CLEtBQUs7QUFDOUIsUUFBSSxNQUFNO0FBQ1IsVUFBSSxLQUFLLGVBQWUsa0JBQWtCO0FBQ3hDLGFBQUssTUFBTSxNQUFNO0FBQ2pCLGFBQUssYUFBYTtBQUFBLE1BQ3BCO0FBQ0EsWUFBTSxTQUFTLEtBQUssTUFBTSxJQUFJLEVBQUU7QUFDaEMsVUFBSSxXQUFXLE9BQVcsUUFBTztBQUFBLElBQ25DO0FBQ0EsUUFBSSxNQUFNLElBQUksRUFBRSxFQUFHLFFBQU8sRUFBRSxPQUFPLFVBQVU7QUFDN0MsVUFBTSxPQUFPLE1BQU0sS0FBSyxLQUFLLE9BQU8sS0FBSyxNQUFNO0FBQy9DLFVBQU0sUUFBUSxlQUFlO0FBQzdCLFFBQUksQ0FBQyxRQUFRLEtBQUssTUFBTSxTQUFTLFdBQVc7QUFDMUMsWUFBTUEsVUFBUyxRQUFRLEtBQUssTUFBTSxTQUFTLFlBQVksWUFBWSxLQUFLLEtBQUssSUFBSTtBQUNqRixVQUNFLFFBQ0EscUJBQXFCLEtBQUssb0JBQzFCLEtBQUssZUFBZSxrQkFDcEI7QUFDQSxjQUFNLFFBQVEsTUFBTSxHQUFHLFNBQVMsS0FBSyxPQUFPQSxZQUFXLFdBQVdBLFFBQU8sU0FBUyxJQUFJO0FBQ3RGLGFBQUssTUFBTSxJQUFJLElBQUlBLFNBQVEsS0FBSztBQUFBLE1BQ2xDO0FBQ0EsYUFBT0E7QUFBQSxJQUNUO0FBQ0EsUUFBSSxNQUFNLFFBQVEsSUFBSyxRQUFPLEVBQUUsT0FBTyxVQUFVO0FBQ2pELFVBQU0sSUFBSSxFQUFFO0FBQ1osUUFBSTtBQUNKLFFBQUk7QUFDSixRQUFJO0FBQ0YsWUFBTSxZQUFZLE1BQU0sS0FBSyxlQUFlLE9BQU8sS0FBSyxNQUFNO0FBQzlELFlBQU0sYUFBYSxhQUFhLEtBQUssTUFBTSxVQUFVO0FBQ3JELGVBQVMsTUFBTSxLQUFLLFNBQVMsT0FBTyxLQUFLLE9BQU8sTUFBTSxJQUFJO0FBQUEsSUFDNUQsU0FBUyxPQUFPO0FBQ2QsVUFBSSxNQUFNLFFBQVEsV0FBWSxNQUE0QixTQUFTLFVBQVcsT0FBTTtBQUNwRixlQUFTLEVBQUUsT0FBTyxpQkFBaUIsUUFBUSxNQUFNLFVBQVUsVUFBVTtBQUFBLElBQ3ZFLFVBQUU7QUFDQSxZQUFNLE9BQU8sRUFBRTtBQUFBLElBQ2pCO0FBQ0EsV0FBTyxLQUFLLFNBQVMsSUFBSSxPQUFPLEtBQUssUUFBUSxLQUFLLFFBQVEsVUFBVTtBQUFBLEVBQ3RFO0FBQUE7QUFBQSxFQUVBLFlBQVksc0JBQXNCLEdBQUc7QUFDbkM7QUFBQSxNQUNFLE9BQU8sY0FBYyxtQkFBbUIsS0FDdEMsdUJBQXVCLEtBQ3ZCLHVCQUF1QixLQUFLO0FBQUEsTUFDOUI7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLFVBQU0sT0FBbUI7QUFBQSxNQUN2QixZQUFZLEtBQUs7QUFBQSxNQUNqQixPQUFPLElBQUksVUFBVSxLQUFLLElBQUkscUJBQXFCLEtBQUssSUFBSSxLQUFLLE1BQU0sUUFBUSxLQUFLLElBQUksQ0FBQyxDQUFDO0FBQUEsSUFDNUY7QUFDQSxXQUFPLENBQUMsT0FBZSxLQUFhLFdBQ2xDLEtBQUssTUFBTSxPQUFPLEtBQUssUUFBUSxvQkFBSSxJQUFJLEdBQUcsUUFBVyxJQUFJO0FBQUEsRUFDN0Q7QUFBQTtBQUFBLEVBRUEsa0JBQWtCLFFBQXNCLFFBQVEsS0FBVztBQUN6RDtBQUFBLE1BQ0UsT0FBTyxjQUFjLEtBQUssS0FBSyxRQUFRLEtBQUssU0FBUztBQUFBLE1BQ3JEO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFDQSxVQUFNLE9BQXVCLEVBQUUsV0FBVyxPQUFPLE9BQU87QUFHeEQsVUFBTSxTQUFTLElBQUk7QUFBQSxNQUNqQixLQUFLO0FBQUEsTUFDTCxLQUFLO0FBQUEsTUFDTCxLQUFLLE1BQU07QUFBQSxNQUNYO0FBQUEsTUFDQSxLQUFLO0FBQUEsSUFDUDtBQUNBLFVBQU1DLG1CQUFrQixPQUN0QixPQUNBLFlBQ3VCO0FBQ3ZCLGNBQVEsZUFBZTtBQUN2QixVQUFJLEVBQUUsS0FBSyxZQUFZLEVBQUcsUUFBTyxFQUFFLE9BQU8sVUFBVTtBQUNwRCxVQUFJO0FBQ0YsY0FBTSxNQUFNLG9CQUFvQixhQUFhLFFBQVEsVUFBVSxHQUFHLENBQUMsUUFBUTtBQUN6RSxnQkFBTSxNQUFNLElBQUksT0FBTyxJQUFJLGNBQWMsSUFBSSxRQUFRO0FBQ3JELGdCQUFNLFNBQVMsSUFBSSxVQUFVLElBQUksaUJBQWlCLElBQUksUUFBUTtBQUM5RCxpQkFBTyxNQUFNLEtBQUssT0FBTyxPQUFPLFFBQVEsU0FBUyxLQUFLLFVBQVUsT0FBTyxVQUNuRSxPQUNBLEVBQUUsR0FBRyxLQUFLLEtBQUssT0FBTztBQUFBLFFBQzVCLENBQUM7QUFDRCxlQUFPLE1BQU0sT0FBTyxTQUFTLE9BQU8sS0FBSyxvQkFBSSxJQUFJLEdBQUcsSUFBSTtBQUFBLE1BQzFELFNBQVMsT0FBTztBQUNkLFlBQUksUUFBUSxXQUFZLE1BQTRCLFNBQVMsVUFBVyxPQUFNO0FBQzlFLGVBQU8sRUFBRSxPQUFPLGlCQUFpQixRQUFRLE1BQU0sVUFBVSxVQUFVO0FBQUEsTUFDckU7QUFBQSxJQUNGO0FBQ0EsV0FBTztBQUFBLE1BQ0wsVUFBVSxDQUFDLFdBQW1CO0FBQUEsUUFDNUIsTUFBTSxDQUFDLEtBQWEsV0FBbUIsT0FBTyxNQUFNLE9BQU8sS0FBSyxRQUFRLG9CQUFJLElBQUksR0FBRyxJQUFJO0FBQUEsUUFDdkYsaUJBQWlCLENBQUMsWUFDaEJBLGlCQUFnQixPQUFPLE9BQU87QUFBQSxNQUNsQztBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUEsRUFDQSxNQUFjLFNBQ1osT0FDQSxLQUNBLE9BQ0EsUUFDQSxNQUNBO0FBQ0EsVUFBTSxPQUFPLFVBQVUsRUFBRSxXQUFXLElBQVc7QUFDL0MsUUFBSTtBQUNKLFVBQU0sTUFBTSxPQUFPLE1BQXFDO0FBQ3RELFVBQUksS0FBSyxZQUFZLFNBQVMsRUFBRyxPQUFNLElBQUksUUFBYyxDQUFDLFlBQVksV0FBVyxTQUFTLENBQUMsQ0FBQztBQUM1RixXQUFLLFFBQVEsZUFBZTtBQUM1QixVQUFJLEVBQUUsS0FBSyxZQUFZLEVBQUcsUUFBTyxFQUFFLE9BQU8sVUFBVTtBQUNwRCxZQUFNLFNBQVMsRUFBRSxRQUFRLEtBQUssS0FBSyxFQUFFLEtBQUssSUFBSTtBQUM5QyxhQUFPLFNBQVMsS0FBSyxNQUFNLFFBQVEsRUFBRSxLQUFLLEVBQUUsUUFBUSxPQUFPLFFBQVEsSUFBSSxJQUFJLEVBQUUsT0FBTyxRQUFRO0FBQUEsSUFDOUY7QUFDQSxVQUFNLFVBQVUsQ0FBQyxXQUEyQixFQUFFLE1BQU0sV0FBVyxNQUFNO0FBQ3JFLFVBQU0sTUFBTSxPQUFPQyxTQUFpQztBQUNsRCxVQUFJLEVBQUUsS0FBSyxZQUFZLEVBQUcsUUFBTyxFQUFFLE9BQU8sVUFBVTtBQUNwRCxVQUFJQSxLQUFJLFNBQVM7QUFDZixlQUFPLE9BQU9BLEtBQUksVUFBVSxZQUFZLENBQUMsT0FBTyxTQUFTQSxLQUFJLEtBQUssSUFDOUQsRUFBRSxPQUFPLFFBQVEsSUFDakJBLEtBQUk7QUFDVixVQUFJQSxLQUFJLFNBQVMsTUFBTyxRQUFPLElBQUlBLElBQUc7QUFDdEMsVUFBSUEsS0FBSSxTQUFTLFFBQVMsUUFBTyxFQUFFLE9BQU8sVUFBVTtBQUNwRCxVQUFJQSxLQUFJLFNBQVM7QUFDZixlQUFPLGdCQUFnQixFQUFFLEdBQUdBLE1BQUssT0FBTyxRQUFRLE1BQU0sSUFBSUEsS0FBSSxLQUFLLENBQUMsRUFBRSxHQUFHLE1BQU0sSUFBSTtBQUNyRixVQUFJQSxLQUFJLFNBQVMsVUFBVTtBQUN6QixjQUFNLE9BQU8sTUFBTSxJQUFJQSxLQUFJLElBQUk7QUFDL0IsWUFBSSxRQUFRLE9BQU8sU0FBUyxTQUFVLFFBQU87QUFDN0MsZUFBTztBQUFBLFVBQ0wsRUFBRSxHQUFHQSxNQUFLLE1BQU0sUUFBUSxJQUFJLEdBQUcsT0FBTyxRQUFRLE1BQU0sSUFBSUEsS0FBSSxLQUFLLENBQUMsRUFBRTtBQUFBLFVBQ3BFLE1BQU07QUFBQSxRQUNSO0FBQUEsTUFDRjtBQUNBLFlBQU0sYUFBYSxtQkFBbUJBLEtBQUksSUFBSTtBQUM5QyxVQUFJLENBQUMsV0FBWSxRQUFPLEVBQUUsT0FBTyxTQUFTO0FBQzFDLFVBQUlBLEtBQUksS0FBSyxTQUFTLFdBQVcsV0FBV0EsS0FBSSxLQUFLLFNBQVMsV0FBVztBQUN2RSxlQUFPLEVBQUUsT0FBTyxVQUFVO0FBQzVCLFVBQUksV0FBVyxlQUFlLGlCQUFpQixXQUFXLGVBQWUsVUFBVTtBQUNqRixZQUFJO0FBQ0YsZ0JBQU0sWUFBWSxXQUFXLGVBQWUsV0FBVyxTQUFTO0FBQUEsWUFDOURBLEtBQUk7QUFBQSxZQUNKQSxLQUFJO0FBQUEsWUFDSCxhQUFhLEVBQUUsV0FBVyxJQUFVO0FBQUEsVUFDdkM7QUFDQSxjQUFJLE9BQU8sU0FBUyxLQUFLO0FBQ3pCLGlCQUFPLENBQUMsS0FBSyxNQUFNO0FBQ2pCLGdCQUFJLEtBQUssYUFBYSxFQUFHLFFBQU8sRUFBRSxPQUFPLFVBQVU7QUFDbkQsbUJBQU8sU0FBUyxLQUFLLE1BQU0sSUFBSSxLQUFLLEtBQUssQ0FBQztBQUFBLFVBQzVDO0FBQ0EsaUJBQU8sS0FBSztBQUFBLFFBQ2QsU0FBUyxPQUFPO0FBQ2QsY0FBSSxpQkFBaUIsYUFBYyxRQUFPLEVBQUUsT0FBTyxNQUFNLEtBQUs7QUFDOUQsZ0JBQU07QUFBQSxRQUNSO0FBQUEsTUFDRjtBQUNBLFVBQUlBLEtBQUksU0FBUyxNQUFNO0FBQ3JCLGNBQU0sT0FBTztBQUFBLFVBQ1g7QUFBQSxZQUNFLE1BQU07QUFBQSxZQUNOLE1BQU07QUFBQSxZQUNOLE1BQU0sQ0FBQyxRQUFRLE1BQU0sSUFBSUEsS0FBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsUUFBUSxJQUFJLEdBQUcsUUFBUSxLQUFLLENBQUM7QUFBQSxVQUN2RTtBQUFBLFVBQ0EsTUFBTTtBQUFBLFFBQ1I7QUFDQSxlQUFPLE9BQU8sU0FBUyxZQUFZLE9BQy9CLE9BQ0EsSUFBSUEsS0FBSSxLQUFLLE9BQU8sSUFBSSxDQUFDLEtBQUssUUFBUSxLQUFLLENBQUM7QUFBQSxNQUNsRDtBQUNBLFVBQUlBLEtBQUksU0FBUyxPQUFPO0FBQ3RCLFlBQUlBLEtBQUksS0FBSyxTQUFTLEVBQUcsUUFBTyxFQUFFLE9BQU8sVUFBVTtBQUNuRCxpQkFBUyxJQUFJLEdBQUcsSUFBSUEsS0FBSSxLQUFLLFFBQVEsS0FBSyxHQUFHO0FBQzNDLGdCQUFNLE9BQU87QUFBQSxZQUNYO0FBQUEsY0FDRSxNQUFNO0FBQUEsY0FDTixNQUFNO0FBQUEsY0FDTixNQUFNLENBQUMsUUFBUSxNQUFNLElBQUlBLEtBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLFFBQVEsSUFBSSxHQUFHLFFBQVEsS0FBSyxDQUFDO0FBQUEsWUFDdkU7QUFBQSxZQUNBLE1BQU07QUFBQSxVQUNSO0FBQ0EsY0FBSSxRQUFRLE9BQU8sU0FBUyxTQUFVLFFBQU87QUFDN0MsY0FBSSxLQUFNLFFBQU8sSUFBSUEsS0FBSSxLQUFLLElBQUksQ0FBQyxDQUFDO0FBQUEsUUFDdEM7QUFDQSxlQUFPLEVBQUUsT0FBTyxPQUFPO0FBQUEsTUFDekI7QUFDQSxVQUFJQSxLQUFJLFNBQVMsYUFBYUEsS0FBSSxTQUFTLFFBQVE7QUFDakQsY0FBTSxJQUFJLE1BQU0sSUFBSUEsS0FBSSxLQUFLLENBQUMsQ0FBQztBQUMvQixlQUFPLEtBQ0wsT0FBTyxNQUFNLFlBQ2IsRUFBRSxVQUFVLGFBQ1osRUFBRSxVQUFVLGNBQ1hBLEtBQUksU0FBUyxhQUFhLEVBQUUsVUFBVSxVQUNyQyxJQUFJQSxLQUFJLEtBQUssQ0FBQyxDQUFDLElBQ2Y7QUFBQSxNQUNOO0FBQ0EsVUFBSSxXQUFXLGVBQWUsZUFBZSxXQUFXLGVBQWUsUUFBUTtBQUM3RSxjQUFNLFlBQ0osV0FBVyxlQUFlLGNBQ3RCLElBQUksVUFBVUEsS0FBSSxJQUFJLElBQ3RCQSxLQUFJLFNBQVMsYUFDWCxJQUFJLFNBQVMsTUFBTSxJQUFJQSxLQUFJLEtBQUssQ0FBQyxDQUFDLEdBQUcsTUFBTSxJQUFJQSxLQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFDM0QsSUFBSSxTQUFTO0FBQ3JCLG1CQUFXLE9BQU9BLEtBQUksU0FBUyxhQUFhQSxLQUFJLEtBQUssTUFBTSxDQUFDLElBQUlBLEtBQUksTUFBTTtBQUN4RSxjQUFJLElBQUksU0FBUyxRQUFTLFdBQVUsSUFBSSxNQUFNLElBQUksR0FBRyxHQUFHLElBQUksU0FBUyxLQUFLO0FBQUE7QUFFeEUscUJBQ00sSUFBSSxLQUFLLElBQUksSUFBSSxNQUFNLEtBQUssSUFBSSxJQUFJLEdBQUcsR0FDM0MsS0FBSyxLQUFLLElBQUksSUFBSSxNQUFNLEtBQUssSUFBSSxJQUFJLEdBQUcsR0FDeEM7QUFFQSx1QkFDTSxJQUFJLEtBQUssSUFBSSxJQUFJLE1BQU0sUUFBUSxJQUFJLElBQUksTUFBTSxHQUNqRCxLQUFLLEtBQUssSUFBSSxJQUFJLE1BQU0sUUFBUSxJQUFJLElBQUksTUFBTSxHQUM5QyxLQUNBO0FBQ0Esb0JBQUksS0FBSyxhQUFhLEVBQUcsUUFBTyxFQUFFLE9BQU8sVUFBVTtBQUNuRCwwQkFBVSxJQUFJLE1BQU0sSUFBSSxFQUFFLEdBQUcsSUFBSSxPQUFPLEtBQUssR0FBRyxRQUFRLEVBQUUsQ0FBQyxHQUFHLElBQUk7QUFBQSxjQUNwRTtBQUFBLFFBQ047QUFDQSxlQUFPLFVBQVUsT0FBTztBQUFBLE1BQzFCO0FBRUEsWUFBTSxPQUFjLENBQUM7QUFDckIsaUJBQVcsT0FBT0EsS0FBSSxNQUFNO0FBQzFCLGNBQU0sUUFBUSxNQUFNLElBQUksR0FBRztBQUMzQixZQUFJLFNBQVMsT0FBTyxVQUFVLFNBQVUsUUFBTztBQUMvQyxhQUFLLEtBQUssUUFBUSxLQUFLLENBQUM7QUFBQSxNQUMxQjtBQUNBLGFBQU8sZ0JBQWdCLEVBQUUsR0FBR0EsTUFBSyxLQUFLLEdBQUcsTUFBTSxNQUFNLFFBQVcsS0FBSyxXQUFXLENBQUM7QUFBQSxJQUNuRjtBQUNBLFdBQU8sSUFBSSxHQUFHO0FBQUEsRUFDaEI7QUFBQSxFQUNRLFNBQ04sSUFDQSxPQUNBLEtBQ0EsUUFDQSxLQUNBLFFBQ0EsWUFDQTtBQUVBLFFBQUksVUFBVSxPQUFPLFdBQVcsWUFBWSxDQUFDLFdBQVcsU0FBUyxFQUFFLFNBQVMsT0FBTyxLQUFLO0FBQ3RGLGFBQU87QUFDVCxVQUFNLE9BQThDLENBQUM7QUFDckQsVUFBTSxNQUFNLENBQUMsS0FBZ0IsTUFBTSxRQUFRO0FBQ3pDLFlBQU0sU0FBUyxJQUFJLFFBQVEsS0FBSyxLQUFLLElBQUksS0FBSyxJQUFJO0FBQ2xELFVBQUk7QUFDRixhQUFLLEtBQUs7QUFBQSxVQUNSLE9BQU87QUFBQSxVQUNQLE9BQU87QUFBQSxZQUNMLFVBQVUsS0FBSyxJQUFJLElBQUksS0FBSyxJQUFJLEdBQUc7QUFBQSxZQUNuQyxRQUFRLEtBQUssSUFBSSxJQUFJLEtBQUssSUFBSSxHQUFHLElBQUk7QUFBQSxZQUNyQyxhQUFhLEtBQUssSUFBSSxJQUFJLFFBQVEsSUFBSSxNQUFNO0FBQUEsWUFDNUMsV0FBVyxLQUFLLElBQUksSUFBSSxRQUFRLElBQUksTUFBTSxJQUFJO0FBQUEsVUFDaEQ7QUFBQSxRQUNGLENBQUM7QUFBQSxJQUNMO0FBQ0EsVUFBTSxRQUFRLENBQUMsU0FBYztBQUMzQixVQUFJLEtBQUssU0FBUyxNQUFPLEtBQUksSUFBSTtBQUFBLGVBQ3hCLEtBQUssU0FBUyxRQUFTLEtBQUksS0FBSyxPQUFPLEtBQUssR0FBRztBQUFBLGVBQy9DLEtBQUssU0FBUyxRQUFTLE9BQU0sS0FBSyxLQUFLO0FBQUEsZUFDdkMsS0FBSyxTQUFTLFVBQVU7QUFDL0IsY0FBTSxLQUFLLElBQUk7QUFDZixjQUFNLEtBQUssS0FBSztBQUFBLE1BQ2xCLFdBQVcsS0FBSyxTQUFTLFFBQVE7QUFDL0IsYUFBSyxLQUFLLFFBQVEsS0FBSztBQUN2QixZQUFJLG1CQUFtQixLQUFLLElBQUksR0FBRyxlQUFlLGVBQWU7QUFDL0QsY0FBSTtBQUNGLGtCQUFNLE9BQU8sZ0JBQWdCLEtBQUssTUFBTSxLQUFLLElBQUk7QUFDakQsZ0JBQUksS0FBSztBQUNQLGtCQUFJLEtBQUssT0FBTyxPQUFPO0FBQUEsZ0JBQ3JCLEdBQUcsS0FBSyxPQUFPO0FBQUEsZ0JBQ2YsS0FBSyxLQUFLLE9BQU8sTUFBTSxNQUFNLEtBQUssT0FBTyxPQUFPO0FBQUEsZ0JBQ2hELFFBQVEsS0FBSyxPQUFPLE1BQU0sU0FBUyxLQUFLLE9BQU8sVUFBVTtBQUFBLGNBQzNELENBQUM7QUFBQSxVQUNMLFFBQVE7QUFBQSxVQUVSO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsUUFBSSxJQUFLLE9BQU0sR0FBRztBQUNsQixTQUFLLEtBQUs7QUFBQSxNQUNSO0FBQUEsTUFDQSxPQUFPLEVBQUUsVUFBVSxLQUFLLFFBQVEsTUFBTSxHQUFHLGFBQWEsUUFBUSxXQUFXLFNBQVMsRUFBRTtBQUFBLElBQ3RGLENBQUM7QUFDRCxVQUFNLFFBQVEsS0FBSyxLQUFLLFVBQVUsSUFBSSxFQUFFLFNBQVMsSUFBSSxLQUFLLFVBQVUsTUFBTSxFQUFFLFNBQVM7QUFDckYsUUFBSSxRQUFRLEtBQUssTUFBTSxRQUFRO0FBQzdCLFdBQUs7QUFDTCxhQUFPO0FBQUEsSUFDVDtBQUNBLFFBQUksZUFBZSxLQUFLLGdCQUFpQixRQUFPO0FBQ2hELFNBQUssTUFBTSxJQUFJLElBQUksUUFBUSxLQUFLO0FBQ2hDLFFBQUksZUFBZSxLQUFLLGdCQUFpQixNQUFLLE1BQU0sT0FBTyxFQUFFO0FBQUEsUUFDeEQsTUFBSyxhQUFhLElBQUksSUFBSSxJQUFJO0FBQ25DLFdBQU87QUFBQSxFQUNUO0FBQ0Y7IiwibmFtZXMiOlsicmVzdWx0IiwiZXZhbHVhdGVGb3JtdWxhIiwiYXN0Il19
import { filterColumns } from "/@fs/Volumes/github/private/opensheet/packages/core/src/filter.ts";
import { compareSortKeys, sortColumns, sortKey } from "/@fs/Volumes/github/private/opensheet/packages/core/src/sort-values.ts";
import { FormulaCalculation } from "/@fs/Volumes/github/private/opensheet/packages/core/src/calculation.ts";
import { intersects } from "/@fs/Volumes/github/private/opensheet/packages/core/src/address.ts";
import { checkBounds, validateSnapshot } from "/@fs/Volumes/github/private/opensheet/packages/core/src/model.ts";
import {
  assert,
  key,
  LIMITS
} from "/@fs/Volumes/github/private/opensheet/packages/core/src/types.ts";
import { offsetCellFormula, sheetFor, structuralReferences, transformAll } from "/@fs/Volumes/github/private/opensheet/packages/core/src/commands/helpers.ts";
export function sheetsCommand(s, command) {
  const p = command.payload;
  if (command.type === "core.sheet.add") {
    assert(s.sheets.length < LIMITS.sheets, "LIMIT_EXCEEDED", "Sheet limit reached");
    assert(
      !s.sheets.some(
        (sh2) => sh2.id === p.sheet.id || sh2.name.toLowerCase() === p.sheet.name.toLowerCase()
      ),
      "INVALID_ARGUMENT",
      "Duplicate sheet"
    );
    validateSnapshot({
      ...s,
      sheets: [...s.sheets, p.sheet],
      sheetOrder: [...s.sheetOrder, p.sheet.id]
    });
    s.sheets.push(p.sheet);
    s.sheetOrder.push(p.sheet.id);
    return;
  }
  const sh = sheetFor(s, p.sheetId);
  switch (command.type) {
    case "core.sheet.remove":
      assert(
        s.sheets.length > 1 && s.sheets.some((x) => x.id !== sh.id && !x.hidden),
        "INVALID_ARGUMENT",
        "Cannot remove last visible sheet"
      );
      transformAll(
        s,
        structuralReferences(command, sh.name),
        void 0,
        void 0,
        (sheet) => sheet.id === sh.id
      );
      s.sheets = s.sheets.filter((x) => x.id !== sh.id);
      s.sheetOrder = s.sheetOrder.filter((id) => id !== sh.id);
      break;
    case "core.sheet.rename":
      assert(
        !s.sheets.some((x) => x.id !== sh.id && x.name.toLowerCase() === p.name.toLowerCase()),
        "INVALID_ARGUMENT",
        "Duplicate sheet name"
      );
      transformAll(s, structuralReferences(command, sh.name));
      sh.name = p.name;
      break;
    case "core.sheet.freeze":
      assert(
        p.rows <= sh.rowOrder.length && p.columns <= sh.columnOrder.length,
        "INVALID_RANGE",
        "Invalid freeze"
      );
      sh.freeze = { rows: p.rows, columns: p.columns };
      break;
    case "core.sheet.filter":
      assert(
        !p.filter || filterColumns(p.filter).every((column) => column < sh.columnOrder.length) && ("column" in p.filter || p.filter.headerRows <= sh.rowOrder.length),
        "INVALID_RANGE",
        "Invalid filter column"
      );
      sh.filter = p.filter;
      break;
    case "core.sheet.sort": {
      checkBounds(sh, p.range);
      const keys = sortColumns(p, p.range);
      assert(
        !sh.merges.some((m) => intersects(m, p.range)),
        "INVALID_RANGE",
        "Unmerge before sorting"
      );
      const rows = Array.from(
        { length: p.range.endRow - p.range.startRow },
        (_, i) => p.range.startRow + i
      );
      const calculator = new FormulaCalculation(
        (id) => sheetFor(s, id),
        (name) => s.sheets.find((sheet) => sheet.name.toLowerCase() === name.toLowerCase())?.id,
        s.dateSystem
      );
      const values = new Map(
        rows.map((row) => [
          row,
          keys.map((key2) => sortKey(calculator.value(sh.id, row, key2.column)))
        ])
      );
      calculator.clear();
      rows.sort((a, b) => compareSortKeys(values.get(a), values.get(b), keys) || a - b);
      const copied = rows.map(
        (r) => Array.from({ length: p.range.endColumn - p.range.startColumn }, (_, i) => {
          const x = sh.cells[key(sh.rowOrder[r], sh.columnOrder[p.range.startColumn + i])];
          return x ? JSON.parse(JSON.stringify(x)) : void 0;
        })
      );
      copied.forEach(
        (cells, i) => cells.forEach((x) => {
          if (x?.input.type === "formula")
            x.input.expression = offsetCellFormula(
              x.input.expression,
              p.range.startRow + i - rows[i],
              0
            );
        })
      );
      copied.forEach(
        (cells, i) => cells.forEach((x, j) => {
          const r = p.range.startRow + i, c = p.range.startColumn + j, k = key(sh.rowOrder[r], sh.columnOrder[c]);
          if (!x) {
            delete sh.cells[k];
            return;
          }
          x.rowId = sh.rowOrder[r];
          x.columnId = sh.columnOrder[c];
          delete x.cached;
          sh.cells[k] = x;
        })
      );
      break;
    }
    default:
      assert(false, "UNSUPPORTED_FEATURE", "Unknown command");
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNoZWV0cy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBmaWx0ZXJDb2x1bW5zIH0gZnJvbSAnLi4vZmlsdGVyLmpzJztcbmltcG9ydCB7IGNvbXBhcmVTb3J0S2V5cywgc29ydENvbHVtbnMsIHNvcnRLZXkgfSBmcm9tICcuLi9zb3J0LXZhbHVlcy5qcyc7XG5pbXBvcnQgeyBGb3JtdWxhQ2FsY3VsYXRpb24gfSBmcm9tICcuLi9jYWxjdWxhdGlvbi5qcyc7XG5pbXBvcnQgeyBpbnRlcnNlY3RzIH0gZnJvbSAnLi4vYWRkcmVzcy5qcyc7XG5pbXBvcnQgeyBjaGVja0JvdW5kcywgdmFsaWRhdGVTbmFwc2hvdCB9IGZyb20gJy4uL21vZGVsLmpzJztcbmltcG9ydCB7XG4gIGFzc2VydCxcbiAga2V5LFxuICBMSU1JVFMsXG4gIHR5cGUgQ2VsbFJlY29yZCxcbiAgdHlwZSBDb21tYW5kLFxuICB0eXBlIFdvcmtib29rU25hcHNob3QsXG59IGZyb20gJy4uL3R5cGVzLmpzJztcbmltcG9ydCB7IG9mZnNldENlbGxGb3JtdWxhLCBzaGVldEZvciwgc3RydWN0dXJhbFJlZmVyZW5jZXMsIHRyYW5zZm9ybUFsbCB9IGZyb20gJy4vaGVscGVycy5qcyc7XG5leHBvcnQgZnVuY3Rpb24gc2hlZXRzQ29tbWFuZChzOiBXb3JrYm9va1NuYXBzaG90LCBjb21tYW5kOiBDb21tYW5kKTogdm9pZCB7XG4gIGNvbnN0IHAgPSBjb21tYW5kLnBheWxvYWQgYXMgYW55OyAvLyBWYWxpZGF0ZWQgYmVmb3JlIGRpc3BhdGNoLlxuICBpZiAoY29tbWFuZC50eXBlID09PSAnY29yZS5zaGVldC5hZGQnKSB7XG4gICAgYXNzZXJ0KHMuc2hlZXRzLmxlbmd0aCA8IExJTUlUUy5zaGVldHMsICdMSU1JVF9FWENFRURFRCcsICdTaGVldCBsaW1pdCByZWFjaGVkJyk7XG4gICAgYXNzZXJ0KFxuICAgICAgIXMuc2hlZXRzLnNvbWUoXG4gICAgICAgIChzaCkgPT4gc2guaWQgPT09IHAuc2hlZXQuaWQgfHwgc2gubmFtZS50b0xvd2VyQ2FzZSgpID09PSBwLnNoZWV0Lm5hbWUudG9Mb3dlckNhc2UoKSxcbiAgICAgICksXG4gICAgICAnSU5WQUxJRF9BUkdVTUVOVCcsXG4gICAgICAnRHVwbGljYXRlIHNoZWV0JyxcbiAgICApO1xuICAgIHZhbGlkYXRlU25hcHNob3Qoe1xuICAgICAgLi4ucyxcbiAgICAgIHNoZWV0czogWy4uLnMuc2hlZXRzLCBwLnNoZWV0XSxcbiAgICAgIHNoZWV0T3JkZXI6IFsuLi5zLnNoZWV0T3JkZXIsIHAuc2hlZXQuaWRdLFxuICAgIH0pO1xuICAgIHMuc2hlZXRzLnB1c2gocC5zaGVldCk7XG4gICAgcy5zaGVldE9yZGVyLnB1c2gocC5zaGVldC5pZCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHNoID0gc2hlZXRGb3IocywgcC5zaGVldElkKTtcbiAgc3dpdGNoIChjb21tYW5kLnR5cGUpIHtcbiAgICBjYXNlICdjb3JlLnNoZWV0LnJlbW92ZSc6XG4gICAgICBhc3NlcnQoXG4gICAgICAgIHMuc2hlZXRzLmxlbmd0aCA+IDEgJiYgcy5zaGVldHMuc29tZSgoeCkgPT4geC5pZCAhPT0gc2guaWQgJiYgIXguaGlkZGVuKSxcbiAgICAgICAgJ0lOVkFMSURfQVJHVU1FTlQnLFxuICAgICAgICAnQ2Fubm90IHJlbW92ZSBsYXN0IHZpc2libGUgc2hlZXQnLFxuICAgICAgKTtcbiAgICAgIHRyYW5zZm9ybUFsbChcbiAgICAgICAgcyxcbiAgICAgICAgc3RydWN0dXJhbFJlZmVyZW5jZXMoY29tbWFuZCwgc2gubmFtZSksXG4gICAgICAgIHVuZGVmaW5lZCxcbiAgICAgICAgdW5kZWZpbmVkLFxuICAgICAgICAoc2hlZXQpID0+IHNoZWV0LmlkID09PSBzaC5pZCxcbiAgICAgICk7XG4gICAgICBzLnNoZWV0cyA9IHMuc2hlZXRzLmZpbHRlcigoeCkgPT4geC5pZCAhPT0gc2guaWQpO1xuICAgICAgcy5zaGVldE9yZGVyID0gcy5zaGVldE9yZGVyLmZpbHRlcigoaWQpID0+IGlkICE9PSBzaC5pZCk7XG4gICAgICBicmVhaztcbiAgICBjYXNlICdjb3JlLnNoZWV0LnJlbmFtZSc6XG4gICAgICBhc3NlcnQoXG4gICAgICAgICFzLnNoZWV0cy5zb21lKCh4KSA9PiB4LmlkICE9PSBzaC5pZCAmJiB4Lm5hbWUudG9Mb3dlckNhc2UoKSA9PT0gcC5uYW1lLnRvTG93ZXJDYXNlKCkpLFxuICAgICAgICAnSU5WQUxJRF9BUkdVTUVOVCcsXG4gICAgICAgICdEdXBsaWNhdGUgc2hlZXQgbmFtZScsXG4gICAgICApO1xuICAgICAgdHJhbnNmb3JtQWxsKHMsIHN0cnVjdHVyYWxSZWZlcmVuY2VzKGNvbW1hbmQsIHNoLm5hbWUpKTtcbiAgICAgIHNoLm5hbWUgPSBwLm5hbWU7XG4gICAgICBicmVhaztcbiAgICBjYXNlICdjb3JlLnNoZWV0LmZyZWV6ZSc6XG4gICAgICBhc3NlcnQoXG4gICAgICAgIHAucm93cyA8PSBzaC5yb3dPcmRlci5sZW5ndGggJiYgcC5jb2x1bW5zIDw9IHNoLmNvbHVtbk9yZGVyLmxlbmd0aCxcbiAgICAgICAgJ0lOVkFMSURfUkFOR0UnLFxuICAgICAgICAnSW52YWxpZCBmcmVlemUnLFxuICAgICAgKTtcbiAgICAgIHNoLmZyZWV6ZSA9IHsgcm93czogcC5yb3dzLCBjb2x1bW5zOiBwLmNvbHVtbnMgfTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ2NvcmUuc2hlZXQuZmlsdGVyJzpcbiAgICAgIGFzc2VydChcbiAgICAgICAgIXAuZmlsdGVyIHx8XG4gICAgICAgICAgKGZpbHRlckNvbHVtbnMocC5maWx0ZXIpLmV2ZXJ5KChjb2x1bW4pID0+IGNvbHVtbiA8IHNoLmNvbHVtbk9yZGVyLmxlbmd0aCkgJiZcbiAgICAgICAgICAgICgnY29sdW1uJyBpbiBwLmZpbHRlciB8fCBwLmZpbHRlci5oZWFkZXJSb3dzIDw9IHNoLnJvd09yZGVyLmxlbmd0aCkpLFxuICAgICAgICAnSU5WQUxJRF9SQU5HRScsXG4gICAgICAgICdJbnZhbGlkIGZpbHRlciBjb2x1bW4nLFxuICAgICAgKTtcbiAgICAgIHNoLmZpbHRlciA9IHAuZmlsdGVyO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnY29yZS5zaGVldC5zb3J0Jzoge1xuICAgICAgY2hlY2tCb3VuZHMoc2gsIHAucmFuZ2UpO1xuICAgICAgY29uc3Qga2V5cyA9IHNvcnRDb2x1bW5zKHAsIHAucmFuZ2UpO1xuICAgICAgYXNzZXJ0KFxuICAgICAgICAhc2gubWVyZ2VzLnNvbWUoKG0pID0+IGludGVyc2VjdHMobSwgcC5yYW5nZSkpLFxuICAgICAgICAnSU5WQUxJRF9SQU5HRScsXG4gICAgICAgICdVbm1lcmdlIGJlZm9yZSBzb3J0aW5nJyxcbiAgICAgICk7XG4gICAgICBjb25zdCByb3dzID0gQXJyYXkuZnJvbShcbiAgICAgICAgeyBsZW5ndGg6IHAucmFuZ2UuZW5kUm93IC0gcC5yYW5nZS5zdGFydFJvdyB9LFxuICAgICAgICAoXywgaSkgPT4gcC5yYW5nZS5zdGFydFJvdyArIGksXG4gICAgICApO1xuICAgICAgY29uc3QgY2FsY3VsYXRvciA9IG5ldyBGb3JtdWxhQ2FsY3VsYXRpb24oXG4gICAgICAgIChpZCkgPT4gc2hlZXRGb3IocywgaWQpLFxuICAgICAgICAobmFtZSkgPT4gcy5zaGVldHMuZmluZCgoc2hlZXQpID0+IHNoZWV0Lm5hbWUudG9Mb3dlckNhc2UoKSA9PT0gbmFtZS50b0xvd2VyQ2FzZSgpKT8uaWQsXG4gICAgICAgIHMuZGF0ZVN5c3RlbSxcbiAgICAgICk7XG4gICAgICBjb25zdCB2YWx1ZXMgPSBuZXcgTWFwKFxuICAgICAgICByb3dzLm1hcCgocm93KSA9PiBbXG4gICAgICAgICAgcm93LFxuICAgICAgICAgIGtleXMubWFwKChrZXkpID0+IHNvcnRLZXkoY2FsY3VsYXRvci52YWx1ZShzaC5pZCwgcm93LCBrZXkuY29sdW1uKSkpLFxuICAgICAgICBdKSxcbiAgICAgICk7XG4gICAgICBjYWxjdWxhdG9yLmNsZWFyKCk7XG4gICAgICByb3dzLnNvcnQoKGEsIGIpID0+IGNvbXBhcmVTb3J0S2V5cyh2YWx1ZXMuZ2V0KGEpISwgdmFsdWVzLmdldChiKSEsIGtleXMpIHx8IGEgLSBiKTtcbiAgICAgIGNvbnN0IGNvcGllZCA9IHJvd3MubWFwKChyKSA9PlxuICAgICAgICBBcnJheS5mcm9tKHsgbGVuZ3RoOiBwLnJhbmdlLmVuZENvbHVtbiAtIHAucmFuZ2Uuc3RhcnRDb2x1bW4gfSwgKF8sIGkpID0+IHtcbiAgICAgICAgICBjb25zdCB4ID0gc2guY2VsbHNba2V5KHNoLnJvd09yZGVyW3JdLCBzaC5jb2x1bW5PcmRlcltwLnJhbmdlLnN0YXJ0Q29sdW1uICsgaV0pXTtcbiAgICAgICAgICByZXR1cm4geCA/IChKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KHgpKSBhcyBDZWxsUmVjb3JkKSA6IHVuZGVmaW5lZDtcbiAgICAgICAgfSksXG4gICAgICApO1xuICAgICAgY29waWVkLmZvckVhY2goKGNlbGxzLCBpKSA9PlxuICAgICAgICBjZWxscy5mb3JFYWNoKCh4KSA9PiB7XG4gICAgICAgICAgaWYgKHg/LmlucHV0LnR5cGUgPT09ICdmb3JtdWxhJylcbiAgICAgICAgICAgIHguaW5wdXQuZXhwcmVzc2lvbiA9IG9mZnNldENlbGxGb3JtdWxhKFxuICAgICAgICAgICAgICB4LmlucHV0LmV4cHJlc3Npb24sXG4gICAgICAgICAgICAgIHAucmFuZ2Uuc3RhcnRSb3cgKyBpIC0gcm93c1tpXSxcbiAgICAgICAgICAgICAgMCxcbiAgICAgICAgICAgICk7XG4gICAgICAgIH0pLFxuICAgICAgKTtcbiAgICAgIGNvcGllZC5mb3JFYWNoKChjZWxscywgaSkgPT5cbiAgICAgICAgY2VsbHMuZm9yRWFjaCgoeCwgaikgPT4ge1xuICAgICAgICAgIGNvbnN0IHIgPSBwLnJhbmdlLnN0YXJ0Um93ICsgaSxcbiAgICAgICAgICAgIGMgPSBwLnJhbmdlLnN0YXJ0Q29sdW1uICsgaixcbiAgICAgICAgICAgIGsgPSBrZXkoc2gucm93T3JkZXJbcl0sIHNoLmNvbHVtbk9yZGVyW2NdKTtcbiAgICAgICAgICBpZiAoIXgpIHtcbiAgICAgICAgICAgIGRlbGV0ZSBzaC5jZWxsc1trXTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG4gICAgICAgICAgeC5yb3dJZCA9IHNoLnJvd09yZGVyW3JdO1xuICAgICAgICAgIHguY29sdW1uSWQgPSBzaC5jb2x1bW5PcmRlcltjXTtcbiAgICAgICAgICBkZWxldGUgeC5jYWNoZWQ7XG4gICAgICAgICAgc2guY2VsbHNba10gPSB4O1xuICAgICAgICB9KSxcbiAgICAgICk7XG4gICAgICBicmVhaztcbiAgICB9XG4gICAgZGVmYXVsdDpcbiAgICAgIGFzc2VydChmYWxzZSwgJ1VOU1VQUE9SVEVEX0ZFQVRVUkUnLCAnVW5rbm93biBjb21tYW5kJyk7XG4gIH1cbn1cbiJdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxpQkFBaUIsYUFBYSxlQUFlO0FBQ3RELFNBQVMsMEJBQTBCO0FBQ25DLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsYUFBYSx3QkFBd0I7QUFDOUM7QUFBQSxFQUNFO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxPQUlLO0FBQ1AsU0FBUyxtQkFBbUIsVUFBVSxzQkFBc0Isb0JBQW9CO0FBQ3pFLGdCQUFTLGNBQWMsR0FBcUIsU0FBd0I7QUFDekUsUUFBTSxJQUFJLFFBQVE7QUFDbEIsTUFBSSxRQUFRLFNBQVMsa0JBQWtCO0FBQ3JDLFdBQU8sRUFBRSxPQUFPLFNBQVMsT0FBTyxRQUFRLGtCQUFrQixxQkFBcUI7QUFDL0U7QUFBQSxNQUNFLENBQUMsRUFBRSxPQUFPO0FBQUEsUUFDUixDQUFDQSxRQUFPQSxJQUFHLE9BQU8sRUFBRSxNQUFNLE1BQU1BLElBQUcsS0FBSyxZQUFZLE1BQU0sRUFBRSxNQUFNLEtBQUssWUFBWTtBQUFBLE1BQ3JGO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EscUJBQWlCO0FBQUEsTUFDZixHQUFHO0FBQUEsTUFDSCxRQUFRLENBQUMsR0FBRyxFQUFFLFFBQVEsRUFBRSxLQUFLO0FBQUEsTUFDN0IsWUFBWSxDQUFDLEdBQUcsRUFBRSxZQUFZLEVBQUUsTUFBTSxFQUFFO0FBQUEsSUFDMUMsQ0FBQztBQUNELE1BQUUsT0FBTyxLQUFLLEVBQUUsS0FBSztBQUNyQixNQUFFLFdBQVcsS0FBSyxFQUFFLE1BQU0sRUFBRTtBQUM1QjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLEtBQUssU0FBUyxHQUFHLEVBQUUsT0FBTztBQUNoQyxVQUFRLFFBQVEsTUFBTTtBQUFBLElBQ3BCLEtBQUs7QUFDSDtBQUFBLFFBQ0UsRUFBRSxPQUFPLFNBQVMsS0FBSyxFQUFFLE9BQU8sS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLEdBQUcsTUFBTSxDQUFDLEVBQUUsTUFBTTtBQUFBLFFBQ3ZFO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFDQTtBQUFBLFFBQ0U7QUFBQSxRQUNBLHFCQUFxQixTQUFTLEdBQUcsSUFBSTtBQUFBLFFBQ3JDO0FBQUEsUUFDQTtBQUFBLFFBQ0EsQ0FBQyxVQUFVLE1BQU0sT0FBTyxHQUFHO0FBQUEsTUFDN0I7QUFDQSxRQUFFLFNBQVMsRUFBRSxPQUFPLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxHQUFHLEVBQUU7QUFDaEQsUUFBRSxhQUFhLEVBQUUsV0FBVyxPQUFPLENBQUMsT0FBTyxPQUFPLEdBQUcsRUFBRTtBQUN2RDtBQUFBLElBQ0YsS0FBSztBQUNIO0FBQUEsUUFDRSxDQUFDLEVBQUUsT0FBTyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sR0FBRyxNQUFNLEVBQUUsS0FBSyxZQUFZLE1BQU0sRUFBRSxLQUFLLFlBQVksQ0FBQztBQUFBLFFBQ3JGO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFDQSxtQkFBYSxHQUFHLHFCQUFxQixTQUFTLEdBQUcsSUFBSSxDQUFDO0FBQ3RELFNBQUcsT0FBTyxFQUFFO0FBQ1o7QUFBQSxJQUNGLEtBQUs7QUFDSDtBQUFBLFFBQ0UsRUFBRSxRQUFRLEdBQUcsU0FBUyxVQUFVLEVBQUUsV0FBVyxHQUFHLFlBQVk7QUFBQSxRQUM1RDtBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBQ0EsU0FBRyxTQUFTLEVBQUUsTUFBTSxFQUFFLE1BQU0sU0FBUyxFQUFFLFFBQVE7QUFDL0M7QUFBQSxJQUNGLEtBQUs7QUFDSDtBQUFBLFFBQ0UsQ0FBQyxFQUFFLFVBQ0EsY0FBYyxFQUFFLE1BQU0sRUFBRSxNQUFNLENBQUMsV0FBVyxTQUFTLEdBQUcsWUFBWSxNQUFNLE1BQ3RFLFlBQVksRUFBRSxVQUFVLEVBQUUsT0FBTyxjQUFjLEdBQUcsU0FBUztBQUFBLFFBQ2hFO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFDQSxTQUFHLFNBQVMsRUFBRTtBQUNkO0FBQUEsSUFDRixLQUFLLG1CQUFtQjtBQUN0QixrQkFBWSxJQUFJLEVBQUUsS0FBSztBQUN2QixZQUFNLE9BQU8sWUFBWSxHQUFHLEVBQUUsS0FBSztBQUNuQztBQUFBLFFBQ0UsQ0FBQyxHQUFHLE9BQU8sS0FBSyxDQUFDLE1BQU0sV0FBVyxHQUFHLEVBQUUsS0FBSyxDQUFDO0FBQUEsUUFDN0M7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUNBLFlBQU0sT0FBTyxNQUFNO0FBQUEsUUFDakIsRUFBRSxRQUFRLEVBQUUsTUFBTSxTQUFTLEVBQUUsTUFBTSxTQUFTO0FBQUEsUUFDNUMsQ0FBQyxHQUFHLE1BQU0sRUFBRSxNQUFNLFdBQVc7QUFBQSxNQUMvQjtBQUNBLFlBQU0sYUFBYSxJQUFJO0FBQUEsUUFDckIsQ0FBQyxPQUFPLFNBQVMsR0FBRyxFQUFFO0FBQUEsUUFDdEIsQ0FBQyxTQUFTLEVBQUUsT0FBTyxLQUFLLENBQUMsVUFBVSxNQUFNLEtBQUssWUFBWSxNQUFNLEtBQUssWUFBWSxDQUFDLEdBQUc7QUFBQSxRQUNyRixFQUFFO0FBQUEsTUFDSjtBQUNBLFlBQU0sU0FBUyxJQUFJO0FBQUEsUUFDakIsS0FBSyxJQUFJLENBQUMsUUFBUTtBQUFBLFVBQ2hCO0FBQUEsVUFDQSxLQUFLLElBQUksQ0FBQ0MsU0FBUSxRQUFRLFdBQVcsTUFBTSxHQUFHLElBQUksS0FBS0EsS0FBSSxNQUFNLENBQUMsQ0FBQztBQUFBLFFBQ3JFLENBQUM7QUFBQSxNQUNIO0FBQ0EsaUJBQVcsTUFBTTtBQUNqQixXQUFLLEtBQUssQ0FBQyxHQUFHLE1BQU0sZ0JBQWdCLE9BQU8sSUFBSSxDQUFDLEdBQUksT0FBTyxJQUFJLENBQUMsR0FBSSxJQUFJLEtBQUssSUFBSSxDQUFDO0FBQ2xGLFlBQU0sU0FBUyxLQUFLO0FBQUEsUUFBSSxDQUFDLE1BQ3ZCLE1BQU0sS0FBSyxFQUFFLFFBQVEsRUFBRSxNQUFNLFlBQVksRUFBRSxNQUFNLFlBQVksR0FBRyxDQUFDLEdBQUcsTUFBTTtBQUN4RSxnQkFBTSxJQUFJLEdBQUcsTUFBTSxJQUFJLEdBQUcsU0FBUyxDQUFDLEdBQUcsR0FBRyxZQUFZLEVBQUUsTUFBTSxjQUFjLENBQUMsQ0FBQyxDQUFDO0FBQy9FLGlCQUFPLElBQUssS0FBSyxNQUFNLEtBQUssVUFBVSxDQUFDLENBQUMsSUFBbUI7QUFBQSxRQUM3RCxDQUFDO0FBQUEsTUFDSDtBQUNBLGFBQU87QUFBQSxRQUFRLENBQUMsT0FBTyxNQUNyQixNQUFNLFFBQVEsQ0FBQyxNQUFNO0FBQ25CLGNBQUksR0FBRyxNQUFNLFNBQVM7QUFDcEIsY0FBRSxNQUFNLGFBQWE7QUFBQSxjQUNuQixFQUFFLE1BQU07QUFBQSxjQUNSLEVBQUUsTUFBTSxXQUFXLElBQUksS0FBSyxDQUFDO0FBQUEsY0FDN0I7QUFBQSxZQUNGO0FBQUEsUUFDSixDQUFDO0FBQUEsTUFDSDtBQUNBLGFBQU87QUFBQSxRQUFRLENBQUMsT0FBTyxNQUNyQixNQUFNLFFBQVEsQ0FBQyxHQUFHLE1BQU07QUFDdEIsZ0JBQU0sSUFBSSxFQUFFLE1BQU0sV0FBVyxHQUMzQixJQUFJLEVBQUUsTUFBTSxjQUFjLEdBQzFCLElBQUksSUFBSSxHQUFHLFNBQVMsQ0FBQyxHQUFHLEdBQUcsWUFBWSxDQUFDLENBQUM7QUFDM0MsY0FBSSxDQUFDLEdBQUc7QUFDTixtQkFBTyxHQUFHLE1BQU0sQ0FBQztBQUNqQjtBQUFBLFVBQ0Y7QUFDQSxZQUFFLFFBQVEsR0FBRyxTQUFTLENBQUM7QUFDdkIsWUFBRSxXQUFXLEdBQUcsWUFBWSxDQUFDO0FBQzdCLGlCQUFPLEVBQUU7QUFDVCxhQUFHLE1BQU0sQ0FBQyxJQUFJO0FBQUEsUUFDaEIsQ0FBQztBQUFBLE1BQ0g7QUFDQTtBQUFBLElBQ0Y7QUFBQSxJQUNBO0FBQ0UsYUFBTyxPQUFPLHVCQUF1QixpQkFBaUI7QUFBQSxFQUMxRDtBQUNGOyIsIm5hbWVzIjpbInNoIiwia2V5Il19
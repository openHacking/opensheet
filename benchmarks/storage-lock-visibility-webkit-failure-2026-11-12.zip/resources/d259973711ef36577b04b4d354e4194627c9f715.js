import { checked } from "/@fs/Volumes/github/private/opensheet/packages/formula/src/coercion.ts";
import { criterion } from "/@fs/Volumes/github/private/opensheet/packages/formula/src/criteria.ts";
import { fail } from "/@fs/Volumes/github/private/opensheet/packages/formula/src/errors.ts";
import { area, cell } from "/@fs/Volumes/github/private/opensheet/packages/formula/src/ranges.ts";
export function conditionalPlan(name, args) {
  const count = name.startsWith("COUNT");
  const multiple = name.endsWith("IFS");
  const ranges = [], tests = [];
  let values;
  if (!multiple) {
    ranges.push(area(args[0]));
    tests.push(args[1]);
    if (!count) {
      values = args[2] ? area(args[2]) : ranges[0];
      values = { ...values, rows: ranges[0].rows, columns: ranges[0].columns };
    }
  } else {
    const offset = count ? 0 : 1;
    if ((args.length - offset) % 2) fail();
    if (!count) values = area(args[0]);
    for (let i = offset; i < args.length; i += 2) {
      ranges.push(area(args[i]));
      tests.push(args[i + 1]);
    }
    const shape = values ?? ranges[0];
    if (ranges.some((r) => r.rows !== shape.rows || r.columns !== shape.columns)) fail();
  }
  return { ranges, tests, values, count, average: name.startsWith("AVERAGE") };
}
export function* conditional(name, args, work = { remaining: 1e6 }) {
  const plan = conditionalPlan(name, args);
  const predicates = [];
  for (const test of plan.tests) predicates.push(criterion(yield test, work));
  let sum = 0, count = 0;
  const shape = plan.ranges[0];
  for (let row = 0; row < shape.rows; row++)
    for (let column = 0; column < shape.columns; column++) {
      let matches = true;
      for (let i = 0; i < plan.ranges.length; i++) {
        const value2 = yield cell(plan.ranges[i], row, column);
        if (!predicates[i](value2)) {
          matches = false;
          break;
        }
      }
      if (!matches) continue;
      if (plan.count) {
        count++;
        continue;
      }
      const value = checked(yield cell(plan.values, row, column));
      if (typeof value === "number") {
        sum += value;
        count++;
      }
    }
  if (plan.count) return count;
  if (plan.average && !count) return { error: "#DIV/0!" };
  const result = plan.average ? sum / count : sum;
  return Number.isFinite(result) ? result : { error: "#NUM!" };
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbmRpdGlvbmFsLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNoZWNrZWQgfSBmcm9tICcuL2NvZXJjaW9uLmpzJztcbmltcG9ydCB7IGNyaXRlcmlvbiB9IGZyb20gJy4vY3JpdGVyaWEuanMnO1xuaW1wb3J0IHsgZmFpbCB9IGZyb20gJy4vZXJyb3JzLmpzJztcbmltcG9ydCB7IGFyZWEsIGNlbGwsIHR5cGUgQXJlYSB9IGZyb20gJy4vcmFuZ2VzLmpzJztcbmltcG9ydCB0eXBlIHsgQVNULCBGb3JtdWxhVmFsdWUgfSBmcm9tICcuL3R5cGVzLmpzJztcblxuZXhwb3J0IGZ1bmN0aW9uIGNvbmRpdGlvbmFsUGxhbihuYW1lOiBzdHJpbmcsIGFyZ3M6IEFTVFtdKSB7XG4gIGNvbnN0IGNvdW50ID0gbmFtZS5zdGFydHNXaXRoKCdDT1VOVCcpO1xuICBjb25zdCBtdWx0aXBsZSA9IG5hbWUuZW5kc1dpdGgoJ0lGUycpO1xuICBjb25zdCByYW5nZXM6IEFyZWFbXSA9IFtdLFxuICAgIHRlc3RzOiBBU1RbXSA9IFtdO1xuICBsZXQgdmFsdWVzOiBBcmVhIHwgdW5kZWZpbmVkO1xuICBpZiAoIW11bHRpcGxlKSB7XG4gICAgcmFuZ2VzLnB1c2goYXJlYShhcmdzWzBdKSk7XG4gICAgdGVzdHMucHVzaChhcmdzWzFdKTtcbiAgICBpZiAoIWNvdW50KSB7XG4gICAgICB2YWx1ZXMgPSBhcmdzWzJdID8gYXJlYShhcmdzWzJdKSA6IHJhbmdlc1swXTtcbiAgICAgIC8vIFNVTUlGL0FWRVJBR0VJRiBleHRlbmQgdGhlIHZhbHVlIHJhbmdlIGZyb20gaXRzIHRvcC1sZWZ0IHRvIHRoZSBjcml0ZXJpYSBzaGFwZS5cbiAgICAgIHZhbHVlcyA9IHsgLi4udmFsdWVzLCByb3dzOiByYW5nZXNbMF0ucm93cywgY29sdW1uczogcmFuZ2VzWzBdLmNvbHVtbnMgfTtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgY29uc3Qgb2Zmc2V0ID0gY291bnQgPyAwIDogMTtcbiAgICBpZiAoKGFyZ3MubGVuZ3RoIC0gb2Zmc2V0KSAlIDIpIGZhaWwoKTtcbiAgICBpZiAoIWNvdW50KSB2YWx1ZXMgPSBhcmVhKGFyZ3NbMF0pO1xuICAgIGZvciAobGV0IGkgPSBvZmZzZXQ7IGkgPCBhcmdzLmxlbmd0aDsgaSArPSAyKSB7XG4gICAgICByYW5nZXMucHVzaChhcmVhKGFyZ3NbaV0pKTtcbiAgICAgIHRlc3RzLnB1c2goYXJnc1tpICsgMV0pO1xuICAgIH1cbiAgICBjb25zdCBzaGFwZSA9IHZhbHVlcyA/PyByYW5nZXNbMF07XG4gICAgaWYgKHJhbmdlcy5zb21lKChyKSA9PiByLnJvd3MgIT09IHNoYXBlLnJvd3MgfHwgci5jb2x1bW5zICE9PSBzaGFwZS5jb2x1bW5zKSkgZmFpbCgpO1xuICB9XG4gIHJldHVybiB7IHJhbmdlcywgdGVzdHMsIHZhbHVlcywgY291bnQsIGF2ZXJhZ2U6IG5hbWUuc3RhcnRzV2l0aCgnQVZFUkFHRScpIH07XG59XG4vKiogU2hhcmVkIHN5bmNocm9ub3VzL2FzeW5jaHJvbm91cyBleGVjdXRpb24gcGxhbjogb25seSBvbmUgY2VsbCByZXN1bHQgaXMgcmV0YWluZWQuICovXG5leHBvcnQgZnVuY3Rpb24qIGNvbmRpdGlvbmFsKFxuICBuYW1lOiBzdHJpbmcsXG4gIGFyZ3M6IEFTVFtdLFxuICB3b3JrID0geyByZW1haW5pbmc6IDFfMDAwXzAwMCB9LFxuKTogR2VuZXJhdG9yPEFTVCwgRm9ybXVsYVZhbHVlLCBGb3JtdWxhVmFsdWU+IHtcbiAgY29uc3QgcGxhbiA9IGNvbmRpdGlvbmFsUGxhbihuYW1lLCBhcmdzKTtcbiAgY29uc3QgcHJlZGljYXRlcyA9IFtdO1xuICBmb3IgKGNvbnN0IHRlc3Qgb2YgcGxhbi50ZXN0cykgcHJlZGljYXRlcy5wdXNoKGNyaXRlcmlvbih5aWVsZCB0ZXN0LCB3b3JrKSk7XG4gIGxldCBzdW0gPSAwLFxuICAgIGNvdW50ID0gMDtcbiAgY29uc3Qgc2hhcGUgPSBwbGFuLnJhbmdlc1swXTtcbiAgZm9yIChsZXQgcm93ID0gMDsgcm93IDwgc2hhcGUucm93czsgcm93KyspXG4gICAgZm9yIChsZXQgY29sdW1uID0gMDsgY29sdW1uIDwgc2hhcGUuY29sdW1uczsgY29sdW1uKyspIHtcbiAgICAgIGxldCBtYXRjaGVzID0gdHJ1ZTtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcGxhbi5yYW5nZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgY29uc3QgdmFsdWUgPSB5aWVsZCBjZWxsKHBsYW4ucmFuZ2VzW2ldLCByb3csIGNvbHVtbik7XG4gICAgICAgIGlmICghcHJlZGljYXRlc1tpXSh2YWx1ZSkpIHtcbiAgICAgICAgICBtYXRjaGVzID0gZmFsc2U7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmICghbWF0Y2hlcykgY29udGludWU7XG4gICAgICBpZiAocGxhbi5jb3VudCkge1xuICAgICAgICBjb3VudCsrO1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHZhbHVlID0gY2hlY2tlZCh5aWVsZCBjZWxsKHBsYW4udmFsdWVzISwgcm93LCBjb2x1bW4pKTtcbiAgICAgIGlmICh0eXBlb2YgdmFsdWUgPT09ICdudW1iZXInKSB7XG4gICAgICAgIHN1bSArPSB2YWx1ZTtcbiAgICAgICAgY291bnQrKztcbiAgICAgIH1cbiAgICB9XG4gIGlmIChwbGFuLmNvdW50KSByZXR1cm4gY291bnQ7XG4gIGlmIChwbGFuLmF2ZXJhZ2UgJiYgIWNvdW50KSByZXR1cm4geyBlcnJvcjogJyNESVYvMCEnIH07XG4gIGNvbnN0IHJlc3VsdCA9IHBsYW4uYXZlcmFnZSA/IHN1bSAvIGNvdW50IDogc3VtO1xuICByZXR1cm4gTnVtYmVyLmlzRmluaXRlKHJlc3VsdCkgPyByZXN1bHQgOiB7IGVycm9yOiAnI05VTSEnIH07XG59XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsZUFBZTtBQUN4QixTQUFTLGlCQUFpQjtBQUMxQixTQUFTLFlBQVk7QUFDckIsU0FBUyxNQUFNLFlBQXVCO0FBRy9CLGdCQUFTLGdCQUFnQixNQUFjLE1BQWE7QUFDekQsUUFBTSxRQUFRLEtBQUssV0FBVyxPQUFPO0FBQ3JDLFFBQU0sV0FBVyxLQUFLLFNBQVMsS0FBSztBQUNwQyxRQUFNLFNBQWlCLENBQUMsR0FDdEIsUUFBZSxDQUFDO0FBQ2xCLE1BQUk7QUFDSixNQUFJLENBQUMsVUFBVTtBQUNiLFdBQU8sS0FBSyxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDekIsVUFBTSxLQUFLLEtBQUssQ0FBQyxDQUFDO0FBQ2xCLFFBQUksQ0FBQyxPQUFPO0FBQ1YsZUFBUyxLQUFLLENBQUMsSUFBSSxLQUFLLEtBQUssQ0FBQyxDQUFDLElBQUksT0FBTyxDQUFDO0FBRTNDLGVBQVMsRUFBRSxHQUFHLFFBQVEsTUFBTSxPQUFPLENBQUMsRUFBRSxNQUFNLFNBQVMsT0FBTyxDQUFDLEVBQUUsUUFBUTtBQUFBLElBQ3pFO0FBQUEsRUFDRixPQUFPO0FBQ0wsVUFBTSxTQUFTLFFBQVEsSUFBSTtBQUMzQixTQUFLLEtBQUssU0FBUyxVQUFVLEVBQUcsTUFBSztBQUNyQyxRQUFJLENBQUMsTUFBTyxVQUFTLEtBQUssS0FBSyxDQUFDLENBQUM7QUFDakMsYUFBUyxJQUFJLFFBQVEsSUFBSSxLQUFLLFFBQVEsS0FBSyxHQUFHO0FBQzVDLGFBQU8sS0FBSyxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDekIsWUFBTSxLQUFLLEtBQUssSUFBSSxDQUFDLENBQUM7QUFBQSxJQUN4QjtBQUNBLFVBQU0sUUFBUSxVQUFVLE9BQU8sQ0FBQztBQUNoQyxRQUFJLE9BQU8sS0FBSyxDQUFDLE1BQU0sRUFBRSxTQUFTLE1BQU0sUUFBUSxFQUFFLFlBQVksTUFBTSxPQUFPLEVBQUcsTUFBSztBQUFBLEVBQ3JGO0FBQ0EsU0FBTyxFQUFFLFFBQVEsT0FBTyxRQUFRLE9BQU8sU0FBUyxLQUFLLFdBQVcsU0FBUyxFQUFFO0FBQzdFO0FBRU8saUJBQVUsWUFDZixNQUNBLE1BQ0EsT0FBTyxFQUFFLFdBQVcsSUFBVSxHQUNjO0FBQzVDLFFBQU0sT0FBTyxnQkFBZ0IsTUFBTSxJQUFJO0FBQ3ZDLFFBQU0sYUFBYSxDQUFDO0FBQ3BCLGFBQVcsUUFBUSxLQUFLLE1BQU8sWUFBVyxLQUFLLFVBQVUsTUFBTSxNQUFNLElBQUksQ0FBQztBQUMxRSxNQUFJLE1BQU0sR0FDUixRQUFRO0FBQ1YsUUFBTSxRQUFRLEtBQUssT0FBTyxDQUFDO0FBQzNCLFdBQVMsTUFBTSxHQUFHLE1BQU0sTUFBTSxNQUFNO0FBQ2xDLGFBQVMsU0FBUyxHQUFHLFNBQVMsTUFBTSxTQUFTLFVBQVU7QUFDckQsVUFBSSxVQUFVO0FBQ2QsZUFBUyxJQUFJLEdBQUcsSUFBSSxLQUFLLE9BQU8sUUFBUSxLQUFLO0FBQzNDLGNBQU1BLFNBQVEsTUFBTSxLQUFLLEtBQUssT0FBTyxDQUFDLEdBQUcsS0FBSyxNQUFNO0FBQ3BELFlBQUksQ0FBQyxXQUFXLENBQUMsRUFBRUEsTUFBSyxHQUFHO0FBQ3pCLG9CQUFVO0FBQ1Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLFVBQUksQ0FBQyxRQUFTO0FBQ2QsVUFBSSxLQUFLLE9BQU87QUFDZDtBQUNBO0FBQUEsTUFDRjtBQUNBLFlBQU0sUUFBUSxRQUFRLE1BQU0sS0FBSyxLQUFLLFFBQVMsS0FBSyxNQUFNLENBQUM7QUFDM0QsVUFBSSxPQUFPLFVBQVUsVUFBVTtBQUM3QixlQUFPO0FBQ1A7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNGLE1BQUksS0FBSyxNQUFPLFFBQU87QUFDdkIsTUFBSSxLQUFLLFdBQVcsQ0FBQyxNQUFPLFFBQU8sRUFBRSxPQUFPLFVBQVU7QUFDdEQsUUFBTSxTQUFTLEtBQUssVUFBVSxNQUFNLFFBQVE7QUFDNUMsU0FBTyxPQUFPLFNBQVMsTUFBTSxJQUFJLFNBQVMsRUFBRSxPQUFPLFFBQVE7QUFDN0Q7IiwibmFtZXMiOlsidmFsdWUiXX0=
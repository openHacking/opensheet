import { assert, OpenSheetError } from "/@fs/Volumes/github/private/opensheet/packages/core/src/types.ts";
import { yieldToTask } from "/@fs/Volumes/github/private/opensheet/packages/core/src/task-yield.ts";
import { decodeFileMetadata } from "/@fs/Volumes/github/private/opensheet/packages/core/src/file-codec.ts";
function parseBinaryJSON(bytes, part) {
  try {
    return JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
  } catch {
    throw new OpenSheetError("INVALID_ARGUMENT", `Invalid binary ${part} JSON or UTF-8`);
  }
}
export const crc32 = (bytes) => {
  let crc = 4294967295;
  for (const byte of bytes) {
    crc ^= byte;
    for (let i = 0; i < 8; i++) crc = crc >>> 1 ^ (crc & 1 ? 3988292384 : 0);
  }
  return (crc ^ 4294967295) >>> 0;
};
export async function gzipPage(bytes) {
  if (typeof CompressionStream === "undefined") return { codec: 0, bytes };
  const encoded = new Uint8Array(
    await new Response(
      new Blob([bytes]).stream().pipeThrough(new CompressionStream("gzip"))
    ).arrayBuffer()
  );
  return encoded.length <= bytes.length * 0.9 ? { codec: 1, bytes: encoded } : { codec: 0, bytes };
}
function validatePageEncoding(codec, encodedLength, decodedLength, limit) {
  assert(
    Number.isInteger(decodedLength) && decodedLength > 0 && decodedLength <= limit,
    "LIMIT_EXCEEDED",
    "Decoded page exceeds budget"
  );
  if (codec === 0) {
    assert(encodedLength === decodedLength, "INVALID_ARGUMENT", "Page length differs");
  } else {
    assert(
      codec === 1 && typeof DecompressionStream !== "undefined",
      "INVALID_ARGUMENT",
      "Unsupported page codec"
    );
  }
}
export async function unpackPage(bytes, codec, decodedLength, limit = 32 * 1024 * 1024, signal) {
  signal?.throwIfAborted();
  validatePageEncoding(codec, bytes.length, decodedLength, limit);
  if (codec === 0) {
    return bytes;
  }
  const reader = new Blob([bytes]).stream().pipeThrough(new DecompressionStream("gzip")).getReader();
  const result = new Uint8Array(decodedLength);
  let offset = 0;
  let finished = false;
  const abort = () => {
    void reader.cancel().catch(() => {
    });
  };
  signal?.addEventListener("abort", abort, { once: true });
  try {
    while (true) {
      signal?.throwIfAborted();
      let chunk;
      try {
        chunk = await reader.read();
      } catch {
        signal?.throwIfAborted();
        throw new OpenSheetError("CORRUPT_STORAGE", "Invalid compressed page");
      }
      signal?.throwIfAborted();
      const { done, value } = chunk;
      if (done) {
        finished = true;
        break;
      }
      assert(
        offset + value.length <= decodedLength,
        "LIMIT_EXCEEDED",
        "Decompression exceeds declared size"
      );
      result.set(value, offset);
      offset += value.length;
    }
    assert(offset === decodedLength, "INVALID_ARGUMENT", "Decoded length differs");
  } finally {
    signal?.removeEventListener("abort", abort);
    if (!finished) {
      const cancellation = reader.cancel().catch(() => {
      });
      if (!signal?.aborted) await cancellation;
    }
  }
  return result;
}
function assertBinaryHeader(header) {
  assert(
    header[0] === 79 && header[1] === 83 && header[2] === 66,
    "INVALID_ARGUMENT",
    "Invalid binary workbook signature"
  );
  assert(
    header[3] === 3,
    "UNSUPPORTED_VERSION",
    `Binary workbook version ${header[3]} is unsupported; open it with a compatible version and export a schema 3 backup`
  );
}
function hasDirectoryFields(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value) && Object.keys(value).length === 5 && Object.hasOwn(value, "sheet") && Object.hasOwn(value, "row") && Object.hasOwn(value, "column") && Object.hasOwn(value, "offset") && Object.hasOwn(value, "length");
}
const DIRECTORY_ENTRY_OVERHEAD = '{"sheet":,"row":,"column":,"offset":,"length":}'.length;
export class BinaryDirectoryBudget {
  constructor(limit = 32 * 1024 * 1024) {
    this.limit = limit;
  }
  limit;
  bytes = 2;
  // Array brackets.
  count = 0;
  add(entry) {
    const next = this.bytes + (this.count ? 1 : 0) + DIRECTORY_ENTRY_OVERHEAD + String(entry.sheet).length + String(entry.row).length + String(entry.column).length + String(entry.offset).length + String(entry.length).length;
    assert(next <= this.limit, "LIMIT_EXCEEDED", "Binary directory exceeds 32 MiB");
    this.bytes = next;
    this.count++;
  }
}
export async function* writeBinary(metadata, pages, signal) {
  const check = () => assert(!signal?.aborted, "ABORTED", "Export aborted");
  check();
  const text = new TextEncoder().encode(JSON.stringify(metadata));
  assert(text.length <= 32 * 1024 * 1024, "LIMIT_EXCEEDED", "Binary metadata exceeds 32 MiB");
  const header = new Uint8Array(12), hv = new DataView(header.buffer);
  header.set([79, 83, 66, 3]);
  hv.setUint32(4, text.length, true);
  hv.setUint32(8, crc32(text), true);
  yield header;
  yield text;
  let offset = header.length + text.length;
  const entries = [];
  const directoryBudget = new BinaryDirectoryBudget();
  for await (const page of pages) {
    check();
    const packed = await gzipPage(page.bytes);
    check();
    const frame = new Uint8Array(28), view = new DataView(frame.buffer);
    view.setUint32(0, page.sheet, true);
    view.setUint32(4, page.row, true);
    view.setUint32(8, page.column, true);
    view.setUint32(12, packed.codec, true);
    view.setUint32(16, packed.bytes.length, true);
    view.setUint32(20, page.bytes.length, true);
    view.setUint32(24, crc32(packed.bytes), true);
    const entry = {
      sheet: page.sheet,
      row: page.row,
      column: page.column,
      offset,
      length: 28 + packed.bytes.length
    };
    directoryBudget.add(entry);
    entries.push(entry);
    yield frame;
    yield packed.bytes;
    offset += 28 + packed.bytes.length;
    assert(Number.isSafeInteger(offset), "LIMIT_EXCEEDED", "File offset exceeds safe integer");
  }
  check();
  const directory = new TextEncoder().encode(JSON.stringify(entries));
  assert(directory.length <= 32 * 1024 * 1024, "LIMIT_EXCEEDED", "Binary directory exceeds 32 MiB");
  const marker = new Uint8Array(8), mv = new DataView(marker.buffer);
  mv.setUint32(0, 4294967295, true);
  mv.setUint32(4, directory.length, true);
  yield marker;
  yield directory;
  const footer = new Uint8Array(24), fv = new DataView(footer.buffer);
  footer.set([79, 83, 66, 69]);
  fv.setBigUint64(4, BigInt(offset + 8), true);
  fv.setBigUint64(12, BigInt(directory.length), true);
  fv.setUint32(20, crc32(directory), true);
  check();
  yield footer;
}
class StreamReader {
  constructor(source, signal) {
    this.signal = signal;
    signal?.throwIfAborted();
    this.reader = (source instanceof Blob ? source.stream() : source instanceof Uint8Array ? new Blob([source]).stream() : source).getReader();
    signal?.addEventListener("abort", this.abort, { once: true });
  }
  signal;
  reader;
  chunk = new Uint8Array(0);
  at = 0;
  chunksSinceCheck = 0;
  lastYield = performance.now();
  offset = 0;
  abort = () => {
    void this.reader.cancel().catch(() => {
    });
  };
  async nextChunk() {
    while (true) {
      const item = await this.reader.read();
      this.signal?.throwIfAborted();
      if (item.done) return void 0;
      assert(
        ArrayBuffer.isView(item.value) && Object.prototype.toString.call(item.value) === "[object Uint8Array]",
        "INVALID_ARGUMENT",
        "Binary stream must contain Uint8Array chunks"
      );
      if (++this.chunksSinceCheck >= 64) {
        this.chunksSinceCheck = 0;
        if (performance.now() - this.lastYield >= 8) {
          await yieldToTask();
          this.lastYield = performance.now();
          this.signal?.throwIfAborted();
        }
      }
      if (item.value.length) return item.value;
    }
  }
  async read(length) {
    this.signal?.throwIfAborted();
    assert(
      Number.isInteger(length) && length >= 0 && length <= 32 * 1024 * 1024,
      "LIMIT_EXCEEDED",
      "File section exceeds 32 MiB"
    );
    const result = new Uint8Array(length);
    let at = 0;
    while (at < length) {
      if (this.at === this.chunk.length) {
        const chunk = await this.nextChunk();
        assert(chunk, "INVALID_ARGUMENT", "Truncated binary file");
        this.chunk = chunk;
        this.at = 0;
      }
      const count = Math.min(length - at, this.chunk.length - this.at);
      result.set(this.chunk.subarray(this.at, this.at + count), at);
      at += count;
      this.at += count;
      this.offset += count;
    }
    return result;
  }
  async end() {
    this.signal?.throwIfAborted();
    const done = this.at === this.chunk.length && !await this.nextChunk();
    this.signal?.throwIfAborted();
    assert(done, "INVALID_ARGUMENT", "Trailing binary data");
  }
  async close() {
    this.signal?.removeEventListener("abort", this.abort);
    const cancellation = this.reader.cancel().catch(() => {
    });
    if (!this.signal?.aborted) await cancellation;
    this.reader.releaseLock();
  }
}
export async function* readBinary(source, options = {}) {
  const reader = new StreamReader(source, options.signal);
  const entries = [];
  const seen = /* @__PURE__ */ new Set();
  const directoryBudget = new BinaryDirectoryBudget();
  try {
    const header = await reader.read(12), hv = new DataView(header.buffer);
    assertBinaryHeader(header);
    const text = await reader.read(hv.getUint32(4, true));
    assert(crc32(text) === hv.getUint32(8, true), "INVALID_ARGUMENT", "Header checksum differs");
    const metadata = parseBinaryJSON(text, "metadata");
    const snapshot = decodeFileMetadata(metadata);
    assert(
      metadata.sheets.every((sheet) => sheet.blocks.length === 0),
      "INVALID_ARGUMENT",
      "Binary metadata contains inline blocks"
    );
    yield { metadata, snapshot };
    while (true) {
      const offset = reader.offset, first = await reader.read(4), sheet = new DataView(first.buffer).getUint32(0, true);
      if (sheet === 4294967295) {
        const size = new DataView((await reader.read(4)).buffer).getUint32(0, true), directoryOffset = reader.offset, directory = await reader.read(size), footer = await reader.read(24), fv = new DataView(footer.buffer);
        assert(
          footer[0] === 79 && footer[1] === 83 && footer[2] === 66 && footer[3] === 69 && fv.getBigUint64(4, true) === BigInt(directoryOffset) && fv.getBigUint64(12, true) === BigInt(size) && fv.getUint32(20, true) === crc32(directory),
          "INVALID_ARGUMENT",
          "Invalid file directory"
        );
        const listed = parseBinaryJSON(directory, "directory");
        assert(
          Array.isArray(listed) && listed.length === entries.length,
          "INVALID_ARGUMENT",
          "Directory differs from pages"
        );
        for (let index = 0; index < entries.length; index++) {
          const item = listed[index], expected = entries[index];
          assert(
            hasDirectoryFields(item) && item.sheet === expected.sheet && item.row === expected.row && item.column === expected.column && item.offset === expected.offset && item.length === expected.length,
            "INVALID_ARGUMENT",
            "Directory differs from pages"
          );
        }
        await reader.end();
        break;
      }
      const rest = await reader.read(24), view = new DataView(rest.buffer), row = view.getUint32(0, true), column = view.getUint32(4, true), codec = view.getUint32(8, true), length = view.getUint32(12, true), decodedLength = view.getUint32(16, true), checksum = view.getUint32(20, true);
      assert(sheet < metadata.sheets.length, "INVALID_ARGUMENT", "Unknown binary page sheet");
      const address = `${sheet}/${row}/${column}`;
      assert(!seen.has(address), "INVALID_ARGUMENT", "Duplicate binary page");
      assert(Number.isSafeInteger(offset), "LIMIT_EXCEEDED", "File offset exceeds safe integer");
      const entry = { sheet, row, column, offset, length: 28 + length };
      directoryBudget.add(entry);
      seen.add(address);
      validatePageEncoding(codec, length, decodedLength, 32 * 1024 * 1024);
      const bytes = await reader.read(length);
      assert(crc32(bytes) === checksum, "INVALID_ARGUMENT", "Page checksum differs");
      entries.push(entry);
      yield {
        sheet,
        row,
        column,
        bytes: await unpackPage(bytes, codec, decodedLength, void 0, options.signal)
      };
    }
  } finally {
    await reader.close();
  }
}
export class BinaryReader {
  constructor(source, metadata, directory) {
    this.source = source;
    this.metadata = metadata;
    this.directory = directory;
  }
  source;
  metadata;
  directory;
  static async open(input) {
    const source = input instanceof Blob ? input : new Blob([input]);
    assert(source.size >= 36, "INVALID_ARGUMENT", "Truncated binary file");
    const header = new Uint8Array(await source.slice(0, 12).arrayBuffer()), hv = new DataView(header.buffer);
    assertBinaryHeader(header);
    const footer = new Uint8Array(await source.slice(-24).arrayBuffer()), fv = new DataView(footer.buffer), offset = Number(fv.getBigUint64(4, true)), length = Number(fv.getBigUint64(12, true));
    assert(
      footer[0] === 79 && footer[1] === 83 && footer[2] === 66 && footer[3] === 69 && Number.isSafeInteger(offset) && Number.isSafeInteger(length) && offset >= 8 && length <= 32 * 1024 * 1024 && offset + length === source.size - 24,
      "INVALID_ARGUMENT",
      "Invalid directory bounds"
    );
    const marker = new DataView(await source.slice(offset - 8, offset).arrayBuffer());
    assert(
      marker.getUint32(0, true) === 4294967295 && marker.getUint32(4, true) === length,
      "INVALID_ARGUMENT",
      "Invalid directory marker"
    );
    const directory = new Uint8Array(await source.slice(offset, offset + length).arrayBuffer());
    assert(
      crc32(directory) === fv.getUint32(20, true),
      "INVALID_ARGUMENT",
      "Directory checksum differs"
    );
    const size = hv.getUint32(4, true);
    assert(
      size <= 32 * 1024 * 1024 && 12 + size <= offset - 8,
      "INVALID_ARGUMENT",
      "Invalid metadata bounds"
    );
    const text = new Uint8Array(await source.slice(12, 12 + size).arrayBuffer());
    assert(crc32(text) === hv.getUint32(8, true), "INVALID_ARGUMENT", "Header checksum differs");
    const metadata = parseBinaryJSON(text, "metadata");
    decodeFileMetadata(metadata);
    assert(
      metadata.sheets.every((sheet) => sheet.blocks.length === 0),
      "INVALID_ARGUMENT",
      "Binary metadata contains inline blocks"
    );
    const seen = /* @__PURE__ */ new Set();
    const entries = parseBinaryJSON(directory, "directory");
    assert(Array.isArray(entries), "INVALID_ARGUMENT", "Invalid directory");
    let end = 12 + size;
    for (const entry of entries) {
      assert(
        hasDirectoryFields(entry) && Number.isInteger(entry.sheet) && entry.sheet >= 0 && entry.sheet < metadata.sheets.length && Number.isInteger(entry.row) && entry.row >= 0 && Number.isInteger(entry.column) && entry.column >= 0 && entry.offset === end && Number.isInteger(entry.length) && entry.length >= 28 && entry.offset + entry.length <= offset - 8,
        "INVALID_ARGUMENT",
        "Invalid directory entry"
      );
      assert(
        entry.length <= 32 * 1024 * 1024 + 28,
        "LIMIT_EXCEEDED",
        "Encoded page exceeds 32 MiB"
      );
      const address = `${entry.sheet}/${entry.row}/${entry.column}`;
      assert(!seen.has(address), "INVALID_ARGUMENT", "Duplicate directory page");
      seen.add(address);
      end += entry.length;
    }
    assert(end === offset - 8, "INVALID_ARGUMENT", "Invalid page coverage");
    return new BinaryReader(source, metadata, entries);
  }
  async page(index) {
    assert(Number.isInteger(index) && index >= 0, "INVALID_ARGUMENT", "Unknown page");
    const storedEntry = this.directory[index];
    assert(storedEntry, "INVALID_ARGUMENT", "Unknown page");
    assert(hasDirectoryFields(storedEntry), "INVALID_ARGUMENT", "Invalid directory entry");
    const entry = { ...storedEntry };
    assert(
      Number.isSafeInteger(entry.offset) && entry.offset >= 0 && Number.isSafeInteger(entry.length) && entry.length >= 28 && entry.offset + entry.length <= this.source.size,
      "INVALID_ARGUMENT",
      "Invalid directory entry"
    );
    assert(entry.length <= 32 * 1024 * 1024 + 28, "LIMIT_EXCEEDED", "Encoded page exceeds 32 MiB");
    const headerOnly = entry.length > 64 * 1024;
    const bytes = new Uint8Array(
      await this.source.slice(entry.offset, entry.offset + (headerOnly ? 28 : entry.length)).arrayBuffer()
    ), view = new DataView(bytes.buffer);
    assert(
      view.getUint32(0, true) === entry.sheet && view.getUint32(4, true) === entry.row && view.getUint32(8, true) === entry.column && view.getUint32(16, true) === entry.length - 28,
      "INVALID_ARGUMENT",
      "Invalid page frame"
    );
    const codec = view.getUint32(12, true), decodedLength = view.getUint32(20, true);
    validatePageEncoding(codec, entry.length - 28, decodedLength, 32 * 1024 * 1024);
    const payload = headerOnly ? new Uint8Array(
      await this.source.slice(entry.offset + 28, entry.offset + entry.length).arrayBuffer()
    ) : bytes.subarray(28);
    assert(crc32(payload) === view.getUint32(24, true), "INVALID_ARGUMENT", "Invalid page frame");
    return unpackPage(payload, codec, decodedLength);
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJpbmFyeS1maWxlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGFzc2VydCwgT3BlblNoZWV0RXJyb3IsIHR5cGUgV29ya2Jvb2tTbmFwc2hvdCB9IGZyb20gJy4vdHlwZXMuanMnO1xuaW1wb3J0IHsgeWllbGRUb1Rhc2sgfSBmcm9tICcuL3Rhc2steWllbGQuanMnO1xuaW1wb3J0IHsgZGVjb2RlRmlsZU1ldGFkYXRhLCB0eXBlIFdvcmtib29rRmlsZSB9IGZyb20gJy4vZmlsZS1jb2RlYy5qcyc7XG5mdW5jdGlvbiBwYXJzZUJpbmFyeUpTT04oYnl0ZXM6IFVpbnQ4QXJyYXksIHBhcnQ6ICdtZXRhZGF0YScgfCAnZGlyZWN0b3J5Jyk6IHVua25vd24ge1xuICB0cnkge1xuICAgIHJldHVybiBKU09OLnBhcnNlKG5ldyBUZXh0RGVjb2RlcigndXRmLTgnLCB7IGZhdGFsOiB0cnVlIH0pLmRlY29kZShieXRlcykpO1xuICB9IGNhdGNoIHtcbiAgICB0aHJvdyBuZXcgT3BlblNoZWV0RXJyb3IoJ0lOVkFMSURfQVJHVU1FTlQnLCBgSW52YWxpZCBiaW5hcnkgJHtwYXJ0fSBKU09OIG9yIFVURi04YCk7XG4gIH1cbn1cbmV4cG9ydCBjb25zdCBjcmMzMiA9IChieXRlczogVWludDhBcnJheSkgPT4ge1xuICBsZXQgY3JjID0gMHhmZmZmZmZmZjtcbiAgZm9yIChjb25zdCBieXRlIG9mIGJ5dGVzKSB7XG4gICAgY3JjIF49IGJ5dGU7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCA4OyBpKyspIGNyYyA9IChjcmMgPj4+IDEpIF4gKGNyYyAmIDEgPyAweGVkYjg4MzIwIDogMCk7XG4gIH1cbiAgcmV0dXJuIChjcmMgXiAweGZmZmZmZmZmKSA+Pj4gMDtcbn07XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ3ppcFBhZ2UoYnl0ZXM6IFVpbnQ4QXJyYXkpOiBQcm9taXNlPHsgY29kZWM6IG51bWJlcjsgYnl0ZXM6IFVpbnQ4QXJyYXkgfT4ge1xuICBpZiAodHlwZW9mIENvbXByZXNzaW9uU3RyZWFtID09PSAndW5kZWZpbmVkJykgcmV0dXJuIHsgY29kZWM6IDAsIGJ5dGVzIH07XG4gIGNvbnN0IGVuY29kZWQgPSBuZXcgVWludDhBcnJheShcbiAgICBhd2FpdCBuZXcgUmVzcG9uc2UoXG4gICAgICBuZXcgQmxvYihbYnl0ZXMgYXMgQmxvYlBhcnRdKS5zdHJlYW0oKS5waXBlVGhyb3VnaChuZXcgQ29tcHJlc3Npb25TdHJlYW0oJ2d6aXAnKSksXG4gICAgKS5hcnJheUJ1ZmZlcigpLFxuICApO1xuICByZXR1cm4gZW5jb2RlZC5sZW5ndGggPD0gYnl0ZXMubGVuZ3RoICogMC45ID8geyBjb2RlYzogMSwgYnl0ZXM6IGVuY29kZWQgfSA6IHsgY29kZWM6IDAsIGJ5dGVzIH07XG59XG5mdW5jdGlvbiB2YWxpZGF0ZVBhZ2VFbmNvZGluZyhcbiAgY29kZWM6IG51bWJlcixcbiAgZW5jb2RlZExlbmd0aDogbnVtYmVyLFxuICBkZWNvZGVkTGVuZ3RoOiBudW1iZXIsXG4gIGxpbWl0OiBudW1iZXIsXG4pIHtcbiAgYXNzZXJ0KFxuICAgIE51bWJlci5pc0ludGVnZXIoZGVjb2RlZExlbmd0aCkgJiYgZGVjb2RlZExlbmd0aCA+IDAgJiYgZGVjb2RlZExlbmd0aCA8PSBsaW1pdCxcbiAgICAnTElNSVRfRVhDRUVERUQnLFxuICAgICdEZWNvZGVkIHBhZ2UgZXhjZWVkcyBidWRnZXQnLFxuICApO1xuICBpZiAoY29kZWMgPT09IDApIHtcbiAgICBhc3NlcnQoZW5jb2RlZExlbmd0aCA9PT0gZGVjb2RlZExlbmd0aCwgJ0lOVkFMSURfQVJHVU1FTlQnLCAnUGFnZSBsZW5ndGggZGlmZmVycycpO1xuICB9IGVsc2Uge1xuICAgIGFzc2VydChcbiAgICAgIGNvZGVjID09PSAxICYmIHR5cGVvZiBEZWNvbXByZXNzaW9uU3RyZWFtICE9PSAndW5kZWZpbmVkJyxcbiAgICAgICdJTlZBTElEX0FSR1VNRU5UJyxcbiAgICAgICdVbnN1cHBvcnRlZCBwYWdlIGNvZGVjJyxcbiAgICApO1xuICB9XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdW5wYWNrUGFnZShcbiAgYnl0ZXM6IFVpbnQ4QXJyYXksXG4gIGNvZGVjOiBudW1iZXIsXG4gIGRlY29kZWRMZW5ndGg6IG51bWJlcixcbiAgbGltaXQgPSAzMiAqIDEwMjQgKiAxMDI0LFxuICBzaWduYWw/OiBBYm9ydFNpZ25hbCxcbikge1xuICBzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG4gIHZhbGlkYXRlUGFnZUVuY29kaW5nKGNvZGVjLCBieXRlcy5sZW5ndGgsIGRlY29kZWRMZW5ndGgsIGxpbWl0KTtcbiAgaWYgKGNvZGVjID09PSAwKSB7XG4gICAgcmV0dXJuIGJ5dGVzO1xuICB9XG4gIGNvbnN0IHJlYWRlciA9IG5ldyBCbG9iKFtieXRlcyBhcyBCbG9iUGFydF0pXG4gICAgLnN0cmVhbSgpXG4gICAgLnBpcGVUaHJvdWdoKG5ldyBEZWNvbXByZXNzaW9uU3RyZWFtKCdnemlwJykpXG4gICAgLmdldFJlYWRlcigpO1xuICBjb25zdCByZXN1bHQgPSBuZXcgVWludDhBcnJheShkZWNvZGVkTGVuZ3RoKTtcbiAgbGV0IG9mZnNldCA9IDA7XG4gIGxldCBmaW5pc2hlZCA9IGZhbHNlO1xuICBjb25zdCBhYm9ydCA9ICgpID0+IHtcbiAgICB2b2lkIHJlYWRlci5jYW5jZWwoKS5jYXRjaCgoKSA9PiB7fSk7XG4gIH07XG4gIHNpZ25hbD8uYWRkRXZlbnRMaXN0ZW5lcignYWJvcnQnLCBhYm9ydCwgeyBvbmNlOiB0cnVlIH0pO1xuICB0cnkge1xuICAgIHdoaWxlICh0cnVlKSB7XG4gICAgICBzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG4gICAgICBsZXQgY2h1bms6IFJlYWRhYmxlU3RyZWFtUmVhZFJlc3VsdDxVaW50OEFycmF5PjtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNodW5rID0gYXdhaXQgcmVhZGVyLnJlYWQoKTtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICBzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG4gICAgICAgIHRocm93IG5ldyBPcGVuU2hlZXRFcnJvcignQ09SUlVQVF9TVE9SQUdFJywgJ0ludmFsaWQgY29tcHJlc3NlZCBwYWdlJyk7XG4gICAgICB9XG4gICAgICBzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG4gICAgICBjb25zdCB7IGRvbmUsIHZhbHVlIH0gPSBjaHVuaztcbiAgICAgIGlmIChkb25lKSB7XG4gICAgICAgIGZpbmlzaGVkID0gdHJ1ZTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBhc3NlcnQoXG4gICAgICAgIG9mZnNldCArIHZhbHVlLmxlbmd0aCA8PSBkZWNvZGVkTGVuZ3RoLFxuICAgICAgICAnTElNSVRfRVhDRUVERUQnLFxuICAgICAgICAnRGVjb21wcmVzc2lvbiBleGNlZWRzIGRlY2xhcmVkIHNpemUnLFxuICAgICAgKTtcbiAgICAgIHJlc3VsdC5zZXQodmFsdWUsIG9mZnNldCk7XG4gICAgICBvZmZzZXQgKz0gdmFsdWUubGVuZ3RoO1xuICAgIH1cbiAgICBhc3NlcnQob2Zmc2V0ID09PSBkZWNvZGVkTGVuZ3RoLCAnSU5WQUxJRF9BUkdVTUVOVCcsICdEZWNvZGVkIGxlbmd0aCBkaWZmZXJzJyk7XG4gIH0gZmluYWxseSB7XG4gICAgc2lnbmFsPy5yZW1vdmVFdmVudExpc3RlbmVyKCdhYm9ydCcsIGFib3J0KTtcbiAgICAvLyBUaGUgc3RyZWFtIGFuZCByZWFkZXIgYXJlIHByaXZhdGUgdG8gdGhpcyBmdW5jdGlvbi4gV2ViS2l0IGNhbiBoYW5nIGluXG4gICAgLy8gcmVsZWFzZUxvY2soKSBldmVuIGFmdGVyIGRlY29tcHJlc3Npb24gaGFzIGZpbmlzaGVkOyB0aGVyZSBpcyBubyBjYWxsZXJcbiAgICAvLyB0aGF0IG5lZWRzIHRoZSBsb2NrIHJldHVybmVkLiBPbmx5IGNhbmNlbCBhbiB1bmZpbmlzaGVkIHN0cmVhbS5cbiAgICBpZiAoIWZpbmlzaGVkKSB7XG4gICAgICBjb25zdCBjYW5jZWxsYXRpb24gPSByZWFkZXIuY2FuY2VsKCkuY2F0Y2goKCkgPT4ge30pO1xuICAgICAgaWYgKCFzaWduYWw/LmFib3J0ZWQpIGF3YWl0IGNhbmNlbGxhdGlvbjtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHJlc3VsdDtcbn1cbmZ1bmN0aW9uIGFzc2VydEJpbmFyeUhlYWRlcihoZWFkZXI6IFVpbnQ4QXJyYXkpIHtcbiAgYXNzZXJ0KFxuICAgIGhlYWRlclswXSA9PT0gNzkgJiYgaGVhZGVyWzFdID09PSA4MyAmJiBoZWFkZXJbMl0gPT09IDY2LFxuICAgICdJTlZBTElEX0FSR1VNRU5UJyxcbiAgICAnSW52YWxpZCBiaW5hcnkgd29ya2Jvb2sgc2lnbmF0dXJlJyxcbiAgKTtcbiAgYXNzZXJ0KFxuICAgIGhlYWRlclszXSA9PT0gMyxcbiAgICAnVU5TVVBQT1JURURfVkVSU0lPTicsXG4gICAgYEJpbmFyeSB3b3JrYm9vayB2ZXJzaW9uICR7aGVhZGVyWzNdfSBpcyB1bnN1cHBvcnRlZDsgb3BlbiBpdCB3aXRoIGEgY29tcGF0aWJsZSB2ZXJzaW9uIGFuZCBleHBvcnQgYSBzY2hlbWEgMyBiYWNrdXBgLFxuICApO1xufVxudHlwZSBFbnRyeSA9IHsgc2hlZXQ6IG51bWJlcjsgcm93OiBudW1iZXI7IGNvbHVtbjogbnVtYmVyOyBvZmZzZXQ6IG51bWJlcjsgbGVuZ3RoOiBudW1iZXIgfTtcbmZ1bmN0aW9uIGhhc0RpcmVjdG9yeUZpZWxkcyh2YWx1ZTogdW5rbm93bik6IHZhbHVlIGlzIEVudHJ5IHtcbiAgcmV0dXJuIChcbiAgICB2YWx1ZSAhPT0gbnVsbCAmJlxuICAgIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiZcbiAgICAhQXJyYXkuaXNBcnJheSh2YWx1ZSkgJiZcbiAgICBPYmplY3Qua2V5cyh2YWx1ZSkubGVuZ3RoID09PSA1ICYmXG4gICAgT2JqZWN0Lmhhc093bih2YWx1ZSwgJ3NoZWV0JykgJiZcbiAgICBPYmplY3QuaGFzT3duKHZhbHVlLCAncm93JykgJiZcbiAgICBPYmplY3QuaGFzT3duKHZhbHVlLCAnY29sdW1uJykgJiZcbiAgICBPYmplY3QuaGFzT3duKHZhbHVlLCAnb2Zmc2V0JykgJiZcbiAgICBPYmplY3QuaGFzT3duKHZhbHVlLCAnbGVuZ3RoJylcbiAgKTtcbn1cbmNvbnN0IERJUkVDVE9SWV9FTlRSWV9PVkVSSEVBRCA9ICd7XCJzaGVldFwiOixcInJvd1wiOixcImNvbHVtblwiOixcIm9mZnNldFwiOixcImxlbmd0aFwiOn0nLmxlbmd0aDtcbi8qKiBUcmFjayB0aGUgZXhhY3QgQVNDSUkgSlNPTiBkaXJlY3Rvcnkgc2l6ZSBiZWZvcmUgcmV0YWluaW5nIGFub3RoZXIgZW50cnkuICovXG5leHBvcnQgY2xhc3MgQmluYXJ5RGlyZWN0b3J5QnVkZ2V0IHtcbiAgcHJpdmF0ZSBieXRlcyA9IDI7IC8vIEFycmF5IGJyYWNrZXRzLlxuICBwcml2YXRlIGNvdW50ID0gMDtcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBsaW1pdCA9IDMyICogMTAyNCAqIDEwMjQpIHt9XG4gIGFkZChlbnRyeTogRW50cnkpIHtcbiAgICBjb25zdCBuZXh0ID1cbiAgICAgIHRoaXMuYnl0ZXMgK1xuICAgICAgKHRoaXMuY291bnQgPyAxIDogMCkgK1xuICAgICAgRElSRUNUT1JZX0VOVFJZX09WRVJIRUFEICtcbiAgICAgIFN0cmluZyhlbnRyeS5zaGVldCkubGVuZ3RoICtcbiAgICAgIFN0cmluZyhlbnRyeS5yb3cpLmxlbmd0aCArXG4gICAgICBTdHJpbmcoZW50cnkuY29sdW1uKS5sZW5ndGggK1xuICAgICAgU3RyaW5nKGVudHJ5Lm9mZnNldCkubGVuZ3RoICtcbiAgICAgIFN0cmluZyhlbnRyeS5sZW5ndGgpLmxlbmd0aDtcbiAgICBhc3NlcnQobmV4dCA8PSB0aGlzLmxpbWl0LCAnTElNSVRfRVhDRUVERUQnLCAnQmluYXJ5IGRpcmVjdG9yeSBleGNlZWRzIDMyIE1pQicpO1xuICAgIHRoaXMuYnl0ZXMgPSBuZXh0O1xuICAgIHRoaXMuY291bnQrKztcbiAgfVxufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uKiB3cml0ZUJpbmFyeShcbiAgbWV0YWRhdGE6IFdvcmtib29rRmlsZSxcbiAgcGFnZXM6IEFzeW5jSXRlcmFibGU8eyBzaGVldDogbnVtYmVyOyByb3c6IG51bWJlcjsgY29sdW1uOiBudW1iZXI7IGJ5dGVzOiBVaW50OEFycmF5IH0+LFxuICBzaWduYWw/OiBBYm9ydFNpZ25hbCxcbik6IEFzeW5jR2VuZXJhdG9yPFVpbnQ4QXJyYXk+IHtcbiAgY29uc3QgY2hlY2sgPSAoKSA9PiBhc3NlcnQoIXNpZ25hbD8uYWJvcnRlZCwgJ0FCT1JURUQnLCAnRXhwb3J0IGFib3J0ZWQnKTtcbiAgY2hlY2soKTtcbiAgY29uc3QgdGV4dCA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShKU09OLnN0cmluZ2lmeShtZXRhZGF0YSkpO1xuICBhc3NlcnQodGV4dC5sZW5ndGggPD0gMzIgKiAxMDI0ICogMTAyNCwgJ0xJTUlUX0VYQ0VFREVEJywgJ0JpbmFyeSBtZXRhZGF0YSBleGNlZWRzIDMyIE1pQicpO1xuICBjb25zdCBoZWFkZXIgPSBuZXcgVWludDhBcnJheSgxMiksXG4gICAgaHYgPSBuZXcgRGF0YVZpZXcoaGVhZGVyLmJ1ZmZlcik7XG4gIGhlYWRlci5zZXQoWzc5LCA4MywgNjYsIDNdKTtcbiAgaHYuc2V0VWludDMyKDQsIHRleHQubGVuZ3RoLCB0cnVlKTtcbiAgaHYuc2V0VWludDMyKDgsIGNyYzMyKHRleHQpLCB0cnVlKTtcbiAgeWllbGQgaGVhZGVyO1xuICB5aWVsZCB0ZXh0O1xuICBsZXQgb2Zmc2V0ID0gaGVhZGVyLmxlbmd0aCArIHRleHQubGVuZ3RoO1xuICBjb25zdCBlbnRyaWVzOiBFbnRyeVtdID0gW107XG4gIGNvbnN0IGRpcmVjdG9yeUJ1ZGdldCA9IG5ldyBCaW5hcnlEaXJlY3RvcnlCdWRnZXQoKTtcbiAgZm9yIGF3YWl0IChjb25zdCBwYWdlIG9mIHBhZ2VzKSB7XG4gICAgY2hlY2soKTtcbiAgICBjb25zdCBwYWNrZWQgPSBhd2FpdCBnemlwUGFnZShwYWdlLmJ5dGVzKTtcbiAgICBjaGVjaygpO1xuICAgIGNvbnN0IGZyYW1lID0gbmV3IFVpbnQ4QXJyYXkoMjgpLFxuICAgICAgdmlldyA9IG5ldyBEYXRhVmlldyhmcmFtZS5idWZmZXIpO1xuICAgIHZpZXcuc2V0VWludDMyKDAsIHBhZ2Uuc2hlZXQsIHRydWUpO1xuICAgIHZpZXcuc2V0VWludDMyKDQsIHBhZ2Uucm93LCB0cnVlKTtcbiAgICB2aWV3LnNldFVpbnQzMig4LCBwYWdlLmNvbHVtbiwgdHJ1ZSk7XG4gICAgdmlldy5zZXRVaW50MzIoMTIsIHBhY2tlZC5jb2RlYywgdHJ1ZSk7XG4gICAgdmlldy5zZXRVaW50MzIoMTYsIHBhY2tlZC5ieXRlcy5sZW5ndGgsIHRydWUpO1xuICAgIHZpZXcuc2V0VWludDMyKDIwLCBwYWdlLmJ5dGVzLmxlbmd0aCwgdHJ1ZSk7XG4gICAgdmlldy5zZXRVaW50MzIoMjQsIGNyYzMyKHBhY2tlZC5ieXRlcyksIHRydWUpO1xuICAgIGNvbnN0IGVudHJ5ID0ge1xuICAgICAgc2hlZXQ6IHBhZ2Uuc2hlZXQsXG4gICAgICByb3c6IHBhZ2Uucm93LFxuICAgICAgY29sdW1uOiBwYWdlLmNvbHVtbixcbiAgICAgIG9mZnNldCxcbiAgICAgIGxlbmd0aDogMjggKyBwYWNrZWQuYnl0ZXMubGVuZ3RoLFxuICAgIH07XG4gICAgZGlyZWN0b3J5QnVkZ2V0LmFkZChlbnRyeSk7XG4gICAgZW50cmllcy5wdXNoKGVudHJ5KTtcbiAgICB5aWVsZCBmcmFtZTtcbiAgICB5aWVsZCBwYWNrZWQuYnl0ZXM7XG4gICAgb2Zmc2V0ICs9IDI4ICsgcGFja2VkLmJ5dGVzLmxlbmd0aDtcbiAgICBhc3NlcnQoTnVtYmVyLmlzU2FmZUludGVnZXIob2Zmc2V0KSwgJ0xJTUlUX0VYQ0VFREVEJywgJ0ZpbGUgb2Zmc2V0IGV4Y2VlZHMgc2FmZSBpbnRlZ2VyJyk7XG4gIH1cbiAgY2hlY2soKTtcbiAgY29uc3QgZGlyZWN0b3J5ID0gbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKEpTT04uc3RyaW5naWZ5KGVudHJpZXMpKTtcbiAgYXNzZXJ0KGRpcmVjdG9yeS5sZW5ndGggPD0gMzIgKiAxMDI0ICogMTAyNCwgJ0xJTUlUX0VYQ0VFREVEJywgJ0JpbmFyeSBkaXJlY3RvcnkgZXhjZWVkcyAzMiBNaUInKTtcbiAgY29uc3QgbWFya2VyID0gbmV3IFVpbnQ4QXJyYXkoOCksXG4gICAgbXYgPSBuZXcgRGF0YVZpZXcobWFya2VyLmJ1ZmZlcik7XG4gIG12LnNldFVpbnQzMigwLCAweGZmZmZmZmZmLCB0cnVlKTtcbiAgbXYuc2V0VWludDMyKDQsIGRpcmVjdG9yeS5sZW5ndGgsIHRydWUpO1xuICB5aWVsZCBtYXJrZXI7XG4gIHlpZWxkIGRpcmVjdG9yeTtcbiAgY29uc3QgZm9vdGVyID0gbmV3IFVpbnQ4QXJyYXkoMjQpLFxuICAgIGZ2ID0gbmV3IERhdGFWaWV3KGZvb3Rlci5idWZmZXIpO1xuICBmb290ZXIuc2V0KFs3OSwgODMsIDY2LCA2OV0pO1xuICBmdi5zZXRCaWdVaW50NjQoNCwgQmlnSW50KG9mZnNldCArIDgpLCB0cnVlKTtcbiAgZnYuc2V0QmlnVWludDY0KDEyLCBCaWdJbnQoZGlyZWN0b3J5Lmxlbmd0aCksIHRydWUpO1xuICBmdi5zZXRVaW50MzIoMjAsIGNyYzMyKGRpcmVjdG9yeSksIHRydWUpO1xuICBjaGVjaygpO1xuICB5aWVsZCBmb290ZXI7XG59XG5jbGFzcyBTdHJlYW1SZWFkZXIge1xuICBwcml2YXRlIHJlYWRlcjogUmVhZGFibGVTdHJlYW1EZWZhdWx0UmVhZGVyPFVpbnQ4QXJyYXk+O1xuICBwcml2YXRlIGNodW5rOiBVaW50OEFycmF5ID0gbmV3IFVpbnQ4QXJyYXkoMCk7XG4gIHByaXZhdGUgYXQgPSAwO1xuICBwcml2YXRlIGNodW5rc1NpbmNlQ2hlY2sgPSAwO1xuICBwcml2YXRlIGxhc3RZaWVsZCA9IHBlcmZvcm1hbmNlLm5vdygpO1xuICBvZmZzZXQgPSAwO1xuICBwcml2YXRlIGFib3J0ID0gKCkgPT4ge1xuICAgIHZvaWQgdGhpcy5yZWFkZXIuY2FuY2VsKCkuY2F0Y2goKCkgPT4ge30pO1xuICB9O1xuICBjb25zdHJ1Y3RvcihcbiAgICBzb3VyY2U6IEJsb2IgfCBVaW50OEFycmF5IHwgUmVhZGFibGVTdHJlYW08VWludDhBcnJheT4sXG4gICAgcHJpdmF0ZSBzaWduYWw/OiBBYm9ydFNpZ25hbCxcbiAgKSB7XG4gICAgc2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuICAgIHRoaXMucmVhZGVyID0gKFxuICAgICAgc291cmNlIGluc3RhbmNlb2YgQmxvYlxuICAgICAgICA/IHNvdXJjZS5zdHJlYW0oKVxuICAgICAgICA6IHNvdXJjZSBpbnN0YW5jZW9mIFVpbnQ4QXJyYXlcbiAgICAgICAgICA/IG5ldyBCbG9iKFtzb3VyY2UgYXMgQmxvYlBhcnRdKS5zdHJlYW0oKVxuICAgICAgICAgIDogc291cmNlXG4gICAgKS5nZXRSZWFkZXIoKTtcbiAgICBzaWduYWw/LmFkZEV2ZW50TGlzdGVuZXIoJ2Fib3J0JywgdGhpcy5hYm9ydCwgeyBvbmNlOiB0cnVlIH0pO1xuICB9XG4gIHByaXZhdGUgYXN5bmMgbmV4dENodW5rKCk6IFByb21pc2U8VWludDhBcnJheSB8IHVuZGVmaW5lZD4ge1xuICAgIHdoaWxlICh0cnVlKSB7XG4gICAgICBjb25zdCBpdGVtID0gYXdhaXQgdGhpcy5yZWFkZXIucmVhZCgpO1xuICAgICAgdGhpcy5zaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG4gICAgICBpZiAoaXRlbS5kb25lKSByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgYXNzZXJ0KFxuICAgICAgICBBcnJheUJ1ZmZlci5pc1ZpZXcoaXRlbS52YWx1ZSkgJiZcbiAgICAgICAgICBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwoaXRlbS52YWx1ZSkgPT09ICdbb2JqZWN0IFVpbnQ4QXJyYXldJyxcbiAgICAgICAgJ0lOVkFMSURfQVJHVU1FTlQnLFxuICAgICAgICAnQmluYXJ5IHN0cmVhbSBtdXN0IGNvbnRhaW4gVWludDhBcnJheSBjaHVua3MnLFxuICAgICAgKTtcbiAgICAgIC8vIEJvdGggZW1wdHkgYW5kIHRpbnkgbm9uZW1wdHkgY2h1bmtzIG11c3QgYWxsb3cgdGltZXItZHJpdmVuIGNhbmNlbGxhdGlvbi5cbiAgICAgIGlmICgrK3RoaXMuY2h1bmtzU2luY2VDaGVjayA+PSA2NCkge1xuICAgICAgICB0aGlzLmNodW5rc1NpbmNlQ2hlY2sgPSAwO1xuICAgICAgICBpZiAocGVyZm9ybWFuY2Uubm93KCkgLSB0aGlzLmxhc3RZaWVsZCA+PSA4KSB7XG4gICAgICAgICAgYXdhaXQgeWllbGRUb1Rhc2soKTtcbiAgICAgICAgICB0aGlzLmxhc3RZaWVsZCA9IHBlcmZvcm1hbmNlLm5vdygpO1xuICAgICAgICAgIHRoaXMuc2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAoaXRlbS52YWx1ZS5sZW5ndGgpIHJldHVybiBpdGVtLnZhbHVlO1xuICAgIH1cbiAgfVxuICBhc3luYyByZWFkKGxlbmd0aDogbnVtYmVyKSB7XG4gICAgdGhpcy5zaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG4gICAgYXNzZXJ0KFxuICAgICAgTnVtYmVyLmlzSW50ZWdlcihsZW5ndGgpICYmIGxlbmd0aCA+PSAwICYmIGxlbmd0aCA8PSAzMiAqIDEwMjQgKiAxMDI0LFxuICAgICAgJ0xJTUlUX0VYQ0VFREVEJyxcbiAgICAgICdGaWxlIHNlY3Rpb24gZXhjZWVkcyAzMiBNaUInLFxuICAgICk7XG4gICAgY29uc3QgcmVzdWx0ID0gbmV3IFVpbnQ4QXJyYXkobGVuZ3RoKTtcbiAgICBsZXQgYXQgPSAwO1xuICAgIHdoaWxlIChhdCA8IGxlbmd0aCkge1xuICAgICAgaWYgKHRoaXMuYXQgPT09IHRoaXMuY2h1bmsubGVuZ3RoKSB7XG4gICAgICAgIGNvbnN0IGNodW5rID0gYXdhaXQgdGhpcy5uZXh0Q2h1bmsoKTtcbiAgICAgICAgYXNzZXJ0KGNodW5rLCAnSU5WQUxJRF9BUkdVTUVOVCcsICdUcnVuY2F0ZWQgYmluYXJ5IGZpbGUnKTtcbiAgICAgICAgdGhpcy5jaHVuayA9IGNodW5rO1xuICAgICAgICB0aGlzLmF0ID0gMDtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGNvdW50ID0gTWF0aC5taW4obGVuZ3RoIC0gYXQsIHRoaXMuY2h1bmsubGVuZ3RoIC0gdGhpcy5hdCk7XG4gICAgICByZXN1bHQuc2V0KHRoaXMuY2h1bmsuc3ViYXJyYXkodGhpcy5hdCwgdGhpcy5hdCArIGNvdW50KSwgYXQpO1xuICAgICAgYXQgKz0gY291bnQ7XG4gICAgICB0aGlzLmF0ICs9IGNvdW50O1xuICAgICAgdGhpcy5vZmZzZXQgKz0gY291bnQ7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cbiAgYXN5bmMgZW5kKCkge1xuICAgIHRoaXMuc2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuICAgIGNvbnN0IGRvbmUgPSB0aGlzLmF0ID09PSB0aGlzLmNodW5rLmxlbmd0aCAmJiAhKGF3YWl0IHRoaXMubmV4dENodW5rKCkpO1xuICAgIHRoaXMuc2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuICAgIGFzc2VydChkb25lLCAnSU5WQUxJRF9BUkdVTUVOVCcsICdUcmFpbGluZyBiaW5hcnkgZGF0YScpO1xuICB9XG4gIGFzeW5jIGNsb3NlKCkge1xuICAgIHRoaXMuc2lnbmFsPy5yZW1vdmVFdmVudExpc3RlbmVyKCdhYm9ydCcsIHRoaXMuYWJvcnQpO1xuICAgIGNvbnN0IGNhbmNlbGxhdGlvbiA9IHRoaXMucmVhZGVyLmNhbmNlbCgpLmNhdGNoKCgpID0+IHt9KTtcbiAgICBpZiAoIXRoaXMuc2lnbmFsPy5hYm9ydGVkKSBhd2FpdCBjYW5jZWxsYXRpb247XG4gICAgdGhpcy5yZWFkZXIucmVsZWFzZUxvY2soKTtcbiAgfVxufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uKiByZWFkQmluYXJ5KFxuICBzb3VyY2U6IEJsb2IgfCBVaW50OEFycmF5IHwgUmVhZGFibGVTdHJlYW08VWludDhBcnJheT4sXG4gIG9wdGlvbnM6IHsgc2lnbmFsPzogQWJvcnRTaWduYWwgfSA9IHt9LFxuKTogQXN5bmNHZW5lcmF0b3I8XG4gIHwgeyBtZXRhZGF0YTogV29ya2Jvb2tGaWxlOyBzbmFwc2hvdDogV29ya2Jvb2tTbmFwc2hvdCB9XG4gIHwgeyBzaGVldDogbnVtYmVyOyByb3c6IG51bWJlcjsgY29sdW1uOiBudW1iZXI7IGJ5dGVzOiBVaW50OEFycmF5IH1cbj4ge1xuICBjb25zdCByZWFkZXIgPSBuZXcgU3RyZWFtUmVhZGVyKHNvdXJjZSwgb3B0aW9ucy5zaWduYWwpO1xuICBjb25zdCBlbnRyaWVzOiBFbnRyeVtdID0gW107XG4gIGNvbnN0IHNlZW4gPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgY29uc3QgZGlyZWN0b3J5QnVkZ2V0ID0gbmV3IEJpbmFyeURpcmVjdG9yeUJ1ZGdldCgpO1xuICB0cnkge1xuICAgIGNvbnN0IGhlYWRlciA9IGF3YWl0IHJlYWRlci5yZWFkKDEyKSxcbiAgICAgIGh2ID0gbmV3IERhdGFWaWV3KGhlYWRlci5idWZmZXIpO1xuICAgIGFzc2VydEJpbmFyeUhlYWRlcihoZWFkZXIpO1xuICAgIGNvbnN0IHRleHQgPSBhd2FpdCByZWFkZXIucmVhZChodi5nZXRVaW50MzIoNCwgdHJ1ZSkpO1xuICAgIGFzc2VydChjcmMzMih0ZXh0KSA9PT0gaHYuZ2V0VWludDMyKDgsIHRydWUpLCAnSU5WQUxJRF9BUkdVTUVOVCcsICdIZWFkZXIgY2hlY2tzdW0gZGlmZmVycycpO1xuICAgIGNvbnN0IG1ldGFkYXRhID0gcGFyc2VCaW5hcnlKU09OKHRleHQsICdtZXRhZGF0YScpIGFzIFdvcmtib29rRmlsZTtcbiAgICBjb25zdCBzbmFwc2hvdCA9IGRlY29kZUZpbGVNZXRhZGF0YShtZXRhZGF0YSk7XG4gICAgYXNzZXJ0KFxuICAgICAgbWV0YWRhdGEuc2hlZXRzLmV2ZXJ5KChzaGVldCkgPT4gc2hlZXQuYmxvY2tzLmxlbmd0aCA9PT0gMCksXG4gICAgICAnSU5WQUxJRF9BUkdVTUVOVCcsXG4gICAgICAnQmluYXJ5IG1ldGFkYXRhIGNvbnRhaW5zIGlubGluZSBibG9ja3MnLFxuICAgICk7XG4gICAgeWllbGQgeyBtZXRhZGF0YSwgc25hcHNob3QgfTtcbiAgICB3aGlsZSAodHJ1ZSkge1xuICAgICAgY29uc3Qgb2Zmc2V0ID0gcmVhZGVyLm9mZnNldCxcbiAgICAgICAgZmlyc3QgPSBhd2FpdCByZWFkZXIucmVhZCg0KSxcbiAgICAgICAgc2hlZXQgPSBuZXcgRGF0YVZpZXcoZmlyc3QuYnVmZmVyKS5nZXRVaW50MzIoMCwgdHJ1ZSk7XG4gICAgICBpZiAoc2hlZXQgPT09IDB4ZmZmZmZmZmYpIHtcbiAgICAgICAgY29uc3Qgc2l6ZSA9IG5ldyBEYXRhVmlldygoYXdhaXQgcmVhZGVyLnJlYWQoNCkpLmJ1ZmZlcikuZ2V0VWludDMyKDAsIHRydWUpLFxuICAgICAgICAgIGRpcmVjdG9yeU9mZnNldCA9IHJlYWRlci5vZmZzZXQsXG4gICAgICAgICAgZGlyZWN0b3J5ID0gYXdhaXQgcmVhZGVyLnJlYWQoc2l6ZSksXG4gICAgICAgICAgZm9vdGVyID0gYXdhaXQgcmVhZGVyLnJlYWQoMjQpLFxuICAgICAgICAgIGZ2ID0gbmV3IERhdGFWaWV3KGZvb3Rlci5idWZmZXIpO1xuICAgICAgICBhc3NlcnQoXG4gICAgICAgICAgZm9vdGVyWzBdID09PSA3OSAmJlxuICAgICAgICAgICAgZm9vdGVyWzFdID09PSA4MyAmJlxuICAgICAgICAgICAgZm9vdGVyWzJdID09PSA2NiAmJlxuICAgICAgICAgICAgZm9vdGVyWzNdID09PSA2OSAmJlxuICAgICAgICAgICAgZnYuZ2V0QmlnVWludDY0KDQsIHRydWUpID09PSBCaWdJbnQoZGlyZWN0b3J5T2Zmc2V0KSAmJlxuICAgICAgICAgICAgZnYuZ2V0QmlnVWludDY0KDEyLCB0cnVlKSA9PT0gQmlnSW50KHNpemUpICYmXG4gICAgICAgICAgICBmdi5nZXRVaW50MzIoMjAsIHRydWUpID09PSBjcmMzMihkaXJlY3RvcnkpLFxuICAgICAgICAgICdJTlZBTElEX0FSR1VNRU5UJyxcbiAgICAgICAgICAnSW52YWxpZCBmaWxlIGRpcmVjdG9yeScsXG4gICAgICAgICk7XG4gICAgICAgIGNvbnN0IGxpc3RlZCA9IHBhcnNlQmluYXJ5SlNPTihkaXJlY3RvcnksICdkaXJlY3RvcnknKTtcbiAgICAgICAgYXNzZXJ0KFxuICAgICAgICAgIEFycmF5LmlzQXJyYXkobGlzdGVkKSAmJiBsaXN0ZWQubGVuZ3RoID09PSBlbnRyaWVzLmxlbmd0aCxcbiAgICAgICAgICAnSU5WQUxJRF9BUkdVTUVOVCcsXG4gICAgICAgICAgJ0RpcmVjdG9yeSBkaWZmZXJzIGZyb20gcGFnZXMnLFxuICAgICAgICApO1xuICAgICAgICBmb3IgKGxldCBpbmRleCA9IDA7IGluZGV4IDwgZW50cmllcy5sZW5ndGg7IGluZGV4KyspIHtcbiAgICAgICAgICBjb25zdCBpdGVtID0gbGlzdGVkW2luZGV4XSxcbiAgICAgICAgICAgIGV4cGVjdGVkID0gZW50cmllc1tpbmRleF07XG4gICAgICAgICAgYXNzZXJ0KFxuICAgICAgICAgICAgaGFzRGlyZWN0b3J5RmllbGRzKGl0ZW0pICYmXG4gICAgICAgICAgICAgIGl0ZW0uc2hlZXQgPT09IGV4cGVjdGVkLnNoZWV0ICYmXG4gICAgICAgICAgICAgIGl0ZW0ucm93ID09PSBleHBlY3RlZC5yb3cgJiZcbiAgICAgICAgICAgICAgaXRlbS5jb2x1bW4gPT09IGV4cGVjdGVkLmNvbHVtbiAmJlxuICAgICAgICAgICAgICBpdGVtLm9mZnNldCA9PT0gZXhwZWN0ZWQub2Zmc2V0ICYmXG4gICAgICAgICAgICAgIGl0ZW0ubGVuZ3RoID09PSBleHBlY3RlZC5sZW5ndGgsXG4gICAgICAgICAgICAnSU5WQUxJRF9BUkdVTUVOVCcsXG4gICAgICAgICAgICAnRGlyZWN0b3J5IGRpZmZlcnMgZnJvbSBwYWdlcycsXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICBhd2FpdCByZWFkZXIuZW5kKCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgY29uc3QgcmVzdCA9IGF3YWl0IHJlYWRlci5yZWFkKDI0KSxcbiAgICAgICAgdmlldyA9IG5ldyBEYXRhVmlldyhyZXN0LmJ1ZmZlciksXG4gICAgICAgIHJvdyA9IHZpZXcuZ2V0VWludDMyKDAsIHRydWUpLFxuICAgICAgICBjb2x1bW4gPSB2aWV3LmdldFVpbnQzMig0LCB0cnVlKSxcbiAgICAgICAgY29kZWMgPSB2aWV3LmdldFVpbnQzMig4LCB0cnVlKSxcbiAgICAgICAgbGVuZ3RoID0gdmlldy5nZXRVaW50MzIoMTIsIHRydWUpLFxuICAgICAgICBkZWNvZGVkTGVuZ3RoID0gdmlldy5nZXRVaW50MzIoMTYsIHRydWUpLFxuICAgICAgICBjaGVja3N1bSA9IHZpZXcuZ2V0VWludDMyKDIwLCB0cnVlKTtcbiAgICAgIGFzc2VydChzaGVldCA8IG1ldGFkYXRhLnNoZWV0cy5sZW5ndGgsICdJTlZBTElEX0FSR1VNRU5UJywgJ1Vua25vd24gYmluYXJ5IHBhZ2Ugc2hlZXQnKTtcbiAgICAgIGNvbnN0IGFkZHJlc3MgPSBgJHtzaGVldH0vJHtyb3d9LyR7Y29sdW1ufWA7XG4gICAgICBhc3NlcnQoIXNlZW4uaGFzKGFkZHJlc3MpLCAnSU5WQUxJRF9BUkdVTUVOVCcsICdEdXBsaWNhdGUgYmluYXJ5IHBhZ2UnKTtcbiAgICAgIGFzc2VydChOdW1iZXIuaXNTYWZlSW50ZWdlcihvZmZzZXQpLCAnTElNSVRfRVhDRUVERUQnLCAnRmlsZSBvZmZzZXQgZXhjZWVkcyBzYWZlIGludGVnZXInKTtcbiAgICAgIGNvbnN0IGVudHJ5ID0geyBzaGVldCwgcm93LCBjb2x1bW4sIG9mZnNldCwgbGVuZ3RoOiAyOCArIGxlbmd0aCB9O1xuICAgICAgZGlyZWN0b3J5QnVkZ2V0LmFkZChlbnRyeSk7XG4gICAgICBzZWVuLmFkZChhZGRyZXNzKTtcbiAgICAgIHZhbGlkYXRlUGFnZUVuY29kaW5nKGNvZGVjLCBsZW5ndGgsIGRlY29kZWRMZW5ndGgsIDMyICogMTAyNCAqIDEwMjQpO1xuICAgICAgY29uc3QgYnl0ZXMgPSBhd2FpdCByZWFkZXIucmVhZChsZW5ndGgpO1xuICAgICAgYXNzZXJ0KGNyYzMyKGJ5dGVzKSA9PT0gY2hlY2tzdW0sICdJTlZBTElEX0FSR1VNRU5UJywgJ1BhZ2UgY2hlY2tzdW0gZGlmZmVycycpO1xuICAgICAgZW50cmllcy5wdXNoKGVudHJ5KTtcbiAgICAgIHlpZWxkIHtcbiAgICAgICAgc2hlZXQsXG4gICAgICAgIHJvdyxcbiAgICAgICAgY29sdW1uLFxuICAgICAgICBieXRlczogYXdhaXQgdW5wYWNrUGFnZShieXRlcywgY29kZWMsIGRlY29kZWRMZW5ndGgsIHVuZGVmaW5lZCwgb3B0aW9ucy5zaWduYWwpLFxuICAgICAgfTtcbiAgICB9XG4gIH0gZmluYWxseSB7XG4gICAgYXdhaXQgcmVhZGVyLmNsb3NlKCk7XG4gIH1cbn1cbi8qKiBJbmRlcGVuZGVudCBwYWdlIGFjY2VzcyBmb3IgYnJvd3NlciBhbmQgTm9kZSBCbG9iL2J5dGUgcmVhZGVycy4gKi9cbmV4cG9ydCBjbGFzcyBCaW5hcnlSZWFkZXIge1xuICBwcml2YXRlIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgc291cmNlOiBCbG9iLFxuICAgIHJlYWRvbmx5IG1ldGFkYXRhOiBXb3JrYm9va0ZpbGUsXG4gICAgcmVhZG9ubHkgZGlyZWN0b3J5OiBFbnRyeVtdLFxuICApIHt9XG4gIHN0YXRpYyBhc3luYyBvcGVuKGlucHV0OiBCbG9iIHwgVWludDhBcnJheSkge1xuICAgIGNvbnN0IHNvdXJjZSA9IGlucHV0IGluc3RhbmNlb2YgQmxvYiA/IGlucHV0IDogbmV3IEJsb2IoW2lucHV0IGFzIEJsb2JQYXJ0XSk7XG4gICAgYXNzZXJ0KHNvdXJjZS5zaXplID49IDM2LCAnSU5WQUxJRF9BUkdVTUVOVCcsICdUcnVuY2F0ZWQgYmluYXJ5IGZpbGUnKTtcbiAgICBjb25zdCBoZWFkZXIgPSBuZXcgVWludDhBcnJheShhd2FpdCBzb3VyY2Uuc2xpY2UoMCwgMTIpLmFycmF5QnVmZmVyKCkpLFxuICAgICAgaHYgPSBuZXcgRGF0YVZpZXcoaGVhZGVyLmJ1ZmZlcik7XG4gICAgYXNzZXJ0QmluYXJ5SGVhZGVyKGhlYWRlcik7XG4gICAgY29uc3QgZm9vdGVyID0gbmV3IFVpbnQ4QXJyYXkoYXdhaXQgc291cmNlLnNsaWNlKC0yNCkuYXJyYXlCdWZmZXIoKSksXG4gICAgICBmdiA9IG5ldyBEYXRhVmlldyhmb290ZXIuYnVmZmVyKSxcbiAgICAgIG9mZnNldCA9IE51bWJlcihmdi5nZXRCaWdVaW50NjQoNCwgdHJ1ZSkpLFxuICAgICAgbGVuZ3RoID0gTnVtYmVyKGZ2LmdldEJpZ1VpbnQ2NCgxMiwgdHJ1ZSkpO1xuICAgIGFzc2VydChcbiAgICAgIGZvb3RlclswXSA9PT0gNzkgJiZcbiAgICAgICAgZm9vdGVyWzFdID09PSA4MyAmJlxuICAgICAgICBmb290ZXJbMl0gPT09IDY2ICYmXG4gICAgICAgIGZvb3RlclszXSA9PT0gNjkgJiZcbiAgICAgICAgTnVtYmVyLmlzU2FmZUludGVnZXIob2Zmc2V0KSAmJlxuICAgICAgICBOdW1iZXIuaXNTYWZlSW50ZWdlcihsZW5ndGgpICYmXG4gICAgICAgIG9mZnNldCA+PSA4ICYmXG4gICAgICAgIGxlbmd0aCA8PSAzMiAqIDEwMjQgKiAxMDI0ICYmXG4gICAgICAgIG9mZnNldCArIGxlbmd0aCA9PT0gc291cmNlLnNpemUgLSAyNCxcbiAgICAgICdJTlZBTElEX0FSR1VNRU5UJyxcbiAgICAgICdJbnZhbGlkIGRpcmVjdG9yeSBib3VuZHMnLFxuICAgICk7XG4gICAgY29uc3QgbWFya2VyID0gbmV3IERhdGFWaWV3KGF3YWl0IHNvdXJjZS5zbGljZShvZmZzZXQgLSA4LCBvZmZzZXQpLmFycmF5QnVmZmVyKCkpO1xuICAgIGFzc2VydChcbiAgICAgIG1hcmtlci5nZXRVaW50MzIoMCwgdHJ1ZSkgPT09IDB4ZmZmZmZmZmYgJiYgbWFya2VyLmdldFVpbnQzMig0LCB0cnVlKSA9PT0gbGVuZ3RoLFxuICAgICAgJ0lOVkFMSURfQVJHVU1FTlQnLFxuICAgICAgJ0ludmFsaWQgZGlyZWN0b3J5IG1hcmtlcicsXG4gICAgKTtcbiAgICBjb25zdCBkaXJlY3RvcnkgPSBuZXcgVWludDhBcnJheShhd2FpdCBzb3VyY2Uuc2xpY2Uob2Zmc2V0LCBvZmZzZXQgKyBsZW5ndGgpLmFycmF5QnVmZmVyKCkpO1xuICAgIGFzc2VydChcbiAgICAgIGNyYzMyKGRpcmVjdG9yeSkgPT09IGZ2LmdldFVpbnQzMigyMCwgdHJ1ZSksXG4gICAgICAnSU5WQUxJRF9BUkdVTUVOVCcsXG4gICAgICAnRGlyZWN0b3J5IGNoZWNrc3VtIGRpZmZlcnMnLFxuICAgICk7XG5cbiAgICBjb25zdCBzaXplID0gaHYuZ2V0VWludDMyKDQsIHRydWUpO1xuICAgIGFzc2VydChcbiAgICAgIHNpemUgPD0gMzIgKiAxMDI0ICogMTAyNCAmJiAxMiArIHNpemUgPD0gb2Zmc2V0IC0gOCxcbiAgICAgICdJTlZBTElEX0FSR1VNRU5UJyxcbiAgICAgICdJbnZhbGlkIG1ldGFkYXRhIGJvdW5kcycsXG4gICAgKTtcbiAgICBjb25zdCB0ZXh0ID0gbmV3IFVpbnQ4QXJyYXkoYXdhaXQgc291cmNlLnNsaWNlKDEyLCAxMiArIHNpemUpLmFycmF5QnVmZmVyKCkpO1xuICAgIGFzc2VydChjcmMzMih0ZXh0KSA9PT0gaHYuZ2V0VWludDMyKDgsIHRydWUpLCAnSU5WQUxJRF9BUkdVTUVOVCcsICdIZWFkZXIgY2hlY2tzdW0gZGlmZmVycycpO1xuICAgIGNvbnN0IG1ldGFkYXRhID0gcGFyc2VCaW5hcnlKU09OKHRleHQsICdtZXRhZGF0YScpIGFzIFdvcmtib29rRmlsZTtcbiAgICBkZWNvZGVGaWxlTWV0YWRhdGEobWV0YWRhdGEpO1xuICAgIGFzc2VydChcbiAgICAgIG1ldGFkYXRhLnNoZWV0cy5ldmVyeSgoc2hlZXQpID0+IHNoZWV0LmJsb2Nrcy5sZW5ndGggPT09IDApLFxuICAgICAgJ0lOVkFMSURfQVJHVU1FTlQnLFxuICAgICAgJ0JpbmFyeSBtZXRhZGF0YSBjb250YWlucyBpbmxpbmUgYmxvY2tzJyxcbiAgICApO1xuICAgIGNvbnN0IHNlZW4gPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgICBjb25zdCBlbnRyaWVzID0gcGFyc2VCaW5hcnlKU09OKGRpcmVjdG9yeSwgJ2RpcmVjdG9yeScpIGFzIEVudHJ5W107XG4gICAgYXNzZXJ0KEFycmF5LmlzQXJyYXkoZW50cmllcyksICdJTlZBTElEX0FSR1VNRU5UJywgJ0ludmFsaWQgZGlyZWN0b3J5Jyk7XG4gICAgbGV0IGVuZCA9IDEyICsgc2l6ZTtcbiAgICBmb3IgKGNvbnN0IGVudHJ5IG9mIGVudHJpZXMpIHtcbiAgICAgIGFzc2VydChcbiAgICAgICAgaGFzRGlyZWN0b3J5RmllbGRzKGVudHJ5KSAmJlxuICAgICAgICAgIE51bWJlci5pc0ludGVnZXIoZW50cnkuc2hlZXQpICYmXG4gICAgICAgICAgZW50cnkuc2hlZXQgPj0gMCAmJlxuICAgICAgICAgIGVudHJ5LnNoZWV0IDwgbWV0YWRhdGEuc2hlZXRzLmxlbmd0aCAmJlxuICAgICAgICAgIE51bWJlci5pc0ludGVnZXIoZW50cnkucm93KSAmJlxuICAgICAgICAgIGVudHJ5LnJvdyA+PSAwICYmXG4gICAgICAgICAgTnVtYmVyLmlzSW50ZWdlcihlbnRyeS5jb2x1bW4pICYmXG4gICAgICAgICAgZW50cnkuY29sdW1uID49IDAgJiZcbiAgICAgICAgICBlbnRyeS5vZmZzZXQgPT09IGVuZCAmJlxuICAgICAgICAgIE51bWJlci5pc0ludGVnZXIoZW50cnkubGVuZ3RoKSAmJlxuICAgICAgICAgIGVudHJ5Lmxlbmd0aCA+PSAyOCAmJlxuICAgICAgICAgIGVudHJ5Lm9mZnNldCArIGVudHJ5Lmxlbmd0aCA8PSBvZmZzZXQgLSA4LFxuICAgICAgICAnSU5WQUxJRF9BUkdVTUVOVCcsXG4gICAgICAgICdJbnZhbGlkIGRpcmVjdG9yeSBlbnRyeScsXG4gICAgICApO1xuICAgICAgYXNzZXJ0KFxuICAgICAgICBlbnRyeS5sZW5ndGggPD0gMzIgKiAxMDI0ICogMTAyNCArIDI4LFxuICAgICAgICAnTElNSVRfRVhDRUVERUQnLFxuICAgICAgICAnRW5jb2RlZCBwYWdlIGV4Y2VlZHMgMzIgTWlCJyxcbiAgICAgICk7XG4gICAgICBjb25zdCBhZGRyZXNzID0gYCR7ZW50cnkuc2hlZXR9LyR7ZW50cnkucm93fS8ke2VudHJ5LmNvbHVtbn1gO1xuICAgICAgYXNzZXJ0KCFzZWVuLmhhcyhhZGRyZXNzKSwgJ0lOVkFMSURfQVJHVU1FTlQnLCAnRHVwbGljYXRlIGRpcmVjdG9yeSBwYWdlJyk7XG4gICAgICBzZWVuLmFkZChhZGRyZXNzKTtcbiAgICAgIGVuZCArPSBlbnRyeS5sZW5ndGg7XG4gICAgfVxuICAgIGFzc2VydChlbmQgPT09IG9mZnNldCAtIDgsICdJTlZBTElEX0FSR1VNRU5UJywgJ0ludmFsaWQgcGFnZSBjb3ZlcmFnZScpO1xuICAgIHJldHVybiBuZXcgQmluYXJ5UmVhZGVyKHNvdXJjZSwgbWV0YWRhdGEsIGVudHJpZXMpO1xuICB9XG4gIGFzeW5jIHBhZ2UoaW5kZXg6IG51bWJlcikge1xuICAgIGFzc2VydChOdW1iZXIuaXNJbnRlZ2VyKGluZGV4KSAmJiBpbmRleCA+PSAwLCAnSU5WQUxJRF9BUkdVTUVOVCcsICdVbmtub3duIHBhZ2UnKTtcbiAgICBjb25zdCBzdG9yZWRFbnRyeSA9IHRoaXMuZGlyZWN0b3J5W2luZGV4XTtcbiAgICBhc3NlcnQoc3RvcmVkRW50cnksICdJTlZBTElEX0FSR1VNRU5UJywgJ1Vua25vd24gcGFnZScpO1xuICAgIGFzc2VydChoYXNEaXJlY3RvcnlGaWVsZHMoc3RvcmVkRW50cnkpLCAnSU5WQUxJRF9BUkdVTUVOVCcsICdJbnZhbGlkIGRpcmVjdG9yeSBlbnRyeScpO1xuICAgIGNvbnN0IGVudHJ5ID0geyAuLi5zdG9yZWRFbnRyeSB9O1xuICAgIGFzc2VydChcbiAgICAgIE51bWJlci5pc1NhZmVJbnRlZ2VyKGVudHJ5Lm9mZnNldCkgJiZcbiAgICAgICAgZW50cnkub2Zmc2V0ID49IDAgJiZcbiAgICAgICAgTnVtYmVyLmlzU2FmZUludGVnZXIoZW50cnkubGVuZ3RoKSAmJlxuICAgICAgICBlbnRyeS5sZW5ndGggPj0gMjggJiZcbiAgICAgICAgZW50cnkub2Zmc2V0ICsgZW50cnkubGVuZ3RoIDw9IHRoaXMuc291cmNlLnNpemUsXG4gICAgICAnSU5WQUxJRF9BUkdVTUVOVCcsXG4gICAgICAnSW52YWxpZCBkaXJlY3RvcnkgZW50cnknLFxuICAgICk7XG4gICAgYXNzZXJ0KGVudHJ5Lmxlbmd0aCA8PSAzMiAqIDEwMjQgKiAxMDI0ICsgMjgsICdMSU1JVF9FWENFRURFRCcsICdFbmNvZGVkIHBhZ2UgZXhjZWVkcyAzMiBNaUInKTtcbiAgICAvLyBBdm9pZCBhbiBleHRyYSBhc3luY2hyb25vdXMgQmxvYiByZWFkIGZvciBzbWFsbCBwYWdlcywgd2hpbGUgcmVqZWN0aW5nXG4gICAgLy8gaW52YWxpZCBsYXJnZSBmcmFtZXMgYmVmb3JlIG1hdGVyaWFsaXppbmcgdGhlaXIgcGF5bG9hZC5cbiAgICBjb25zdCBoZWFkZXJPbmx5ID0gZW50cnkubGVuZ3RoID4gNjQgKiAxMDI0O1xuICAgIGNvbnN0IGJ5dGVzID0gbmV3IFVpbnQ4QXJyYXkoXG4gICAgICAgIGF3YWl0IHRoaXMuc291cmNlXG4gICAgICAgICAgLnNsaWNlKGVudHJ5Lm9mZnNldCwgZW50cnkub2Zmc2V0ICsgKGhlYWRlck9ubHkgPyAyOCA6IGVudHJ5Lmxlbmd0aCkpXG4gICAgICAgICAgLmFycmF5QnVmZmVyKCksXG4gICAgICApLFxuICAgICAgdmlldyA9IG5ldyBEYXRhVmlldyhieXRlcy5idWZmZXIpO1xuICAgIGFzc2VydChcbiAgICAgIHZpZXcuZ2V0VWludDMyKDAsIHRydWUpID09PSBlbnRyeS5zaGVldCAmJlxuICAgICAgICB2aWV3LmdldFVpbnQzMig0LCB0cnVlKSA9PT0gZW50cnkucm93ICYmXG4gICAgICAgIHZpZXcuZ2V0VWludDMyKDgsIHRydWUpID09PSBlbnRyeS5jb2x1bW4gJiZcbiAgICAgICAgdmlldy5nZXRVaW50MzIoMTYsIHRydWUpID09PSBlbnRyeS5sZW5ndGggLSAyOCxcbiAgICAgICdJTlZBTElEX0FSR1VNRU5UJyxcbiAgICAgICdJbnZhbGlkIHBhZ2UgZnJhbWUnLFxuICAgICk7XG4gICAgY29uc3QgY29kZWMgPSB2aWV3LmdldFVpbnQzMigxMiwgdHJ1ZSksXG4gICAgICBkZWNvZGVkTGVuZ3RoID0gdmlldy5nZXRVaW50MzIoMjAsIHRydWUpO1xuICAgIHZhbGlkYXRlUGFnZUVuY29kaW5nKGNvZGVjLCBlbnRyeS5sZW5ndGggLSAyOCwgZGVjb2RlZExlbmd0aCwgMzIgKiAxMDI0ICogMTAyNCk7XG4gICAgY29uc3QgcGF5bG9hZCA9IGhlYWRlck9ubHlcbiAgICAgID8gbmV3IFVpbnQ4QXJyYXkoXG4gICAgICAgICAgYXdhaXQgdGhpcy5zb3VyY2Uuc2xpY2UoZW50cnkub2Zmc2V0ICsgMjgsIGVudHJ5Lm9mZnNldCArIGVudHJ5Lmxlbmd0aCkuYXJyYXlCdWZmZXIoKSxcbiAgICAgICAgKVxuICAgICAgOiBieXRlcy5zdWJhcnJheSgyOCk7XG4gICAgYXNzZXJ0KGNyYzMyKHBheWxvYWQpID09PSB2aWV3LmdldFVpbnQzMigyNCwgdHJ1ZSksICdJTlZBTElEX0FSR1VNRU5UJywgJ0ludmFsaWQgcGFnZSBmcmFtZScpO1xuICAgIHJldHVybiB1bnBhY2tQYWdlKHBheWxvYWQsIGNvZGVjLCBkZWNvZGVkTGVuZ3RoKTtcbiAgfVxufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLFFBQVEsc0JBQTZDO0FBQzlELFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsMEJBQTZDO0FBQ3RELFNBQVMsZ0JBQWdCLE9BQW1CLE1BQXlDO0FBQ25GLE1BQUk7QUFDRixXQUFPLEtBQUssTUFBTSxJQUFJLFlBQVksU0FBUyxFQUFFLE9BQU8sS0FBSyxDQUFDLEVBQUUsT0FBTyxLQUFLLENBQUM7QUFBQSxFQUMzRSxRQUFRO0FBQ04sVUFBTSxJQUFJLGVBQWUsb0JBQW9CLGtCQUFrQixJQUFJLGdCQUFnQjtBQUFBLEVBQ3JGO0FBQ0Y7QUFDTyxhQUFNLFFBQVEsQ0FBQyxVQUFzQjtBQUMxQyxNQUFJLE1BQU07QUFDVixhQUFXLFFBQVEsT0FBTztBQUN4QixXQUFPO0FBQ1AsYUFBUyxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUssT0FBTyxRQUFRLEtBQU0sTUFBTSxJQUFJLGFBQWE7QUFBQSxFQUMxRTtBQUNBLFVBQVEsTUFBTSxnQkFBZ0I7QUFDaEM7QUFDQSxzQkFBc0IsU0FBUyxPQUFrRTtBQUMvRixNQUFJLE9BQU8sc0JBQXNCLFlBQWEsUUFBTyxFQUFFLE9BQU8sR0FBRyxNQUFNO0FBQ3ZFLFFBQU0sVUFBVSxJQUFJO0FBQUEsSUFDbEIsTUFBTSxJQUFJO0FBQUEsTUFDUixJQUFJLEtBQUssQ0FBQyxLQUFpQixDQUFDLEVBQUUsT0FBTyxFQUFFLFlBQVksSUFBSSxrQkFBa0IsTUFBTSxDQUFDO0FBQUEsSUFDbEYsRUFBRSxZQUFZO0FBQUEsRUFDaEI7QUFDQSxTQUFPLFFBQVEsVUFBVSxNQUFNLFNBQVMsTUFBTSxFQUFFLE9BQU8sR0FBRyxPQUFPLFFBQVEsSUFBSSxFQUFFLE9BQU8sR0FBRyxNQUFNO0FBQ2pHO0FBQ0EsU0FBUyxxQkFDUCxPQUNBLGVBQ0EsZUFDQSxPQUNBO0FBQ0E7QUFBQSxJQUNFLE9BQU8sVUFBVSxhQUFhLEtBQUssZ0JBQWdCLEtBQUssaUJBQWlCO0FBQUEsSUFDekU7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNBLE1BQUksVUFBVSxHQUFHO0FBQ2YsV0FBTyxrQkFBa0IsZUFBZSxvQkFBb0IscUJBQXFCO0FBQUEsRUFDbkYsT0FBTztBQUNMO0FBQUEsTUFDRSxVQUFVLEtBQUssT0FBTyx3QkFBd0I7QUFBQSxNQUM5QztBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBQ0Esc0JBQXNCLFdBQ3BCLE9BQ0EsT0FDQSxlQUNBLFFBQVEsS0FBSyxPQUFPLE1BQ3BCLFFBQ0E7QUFDQSxVQUFRLGVBQWU7QUFDdkIsdUJBQXFCLE9BQU8sTUFBTSxRQUFRLGVBQWUsS0FBSztBQUM5RCxNQUFJLFVBQVUsR0FBRztBQUNmLFdBQU87QUFBQSxFQUNUO0FBQ0EsUUFBTSxTQUFTLElBQUksS0FBSyxDQUFDLEtBQWlCLENBQUMsRUFDeEMsT0FBTyxFQUNQLFlBQVksSUFBSSxvQkFBb0IsTUFBTSxDQUFDLEVBQzNDLFVBQVU7QUFDYixRQUFNLFNBQVMsSUFBSSxXQUFXLGFBQWE7QUFDM0MsTUFBSSxTQUFTO0FBQ2IsTUFBSSxXQUFXO0FBQ2YsUUFBTSxRQUFRLE1BQU07QUFDbEIsU0FBSyxPQUFPLE9BQU8sRUFBRSxNQUFNLE1BQU07QUFBQSxJQUFDLENBQUM7QUFBQSxFQUNyQztBQUNBLFVBQVEsaUJBQWlCLFNBQVMsT0FBTyxFQUFFLE1BQU0sS0FBSyxDQUFDO0FBQ3ZELE1BQUk7QUFDRixXQUFPLE1BQU07QUFDWCxjQUFRLGVBQWU7QUFDdkIsVUFBSTtBQUNKLFVBQUk7QUFDRixnQkFBUSxNQUFNLE9BQU8sS0FBSztBQUFBLE1BQzVCLFFBQVE7QUFDTixnQkFBUSxlQUFlO0FBQ3ZCLGNBQU0sSUFBSSxlQUFlLG1CQUFtQix5QkFBeUI7QUFBQSxNQUN2RTtBQUNBLGNBQVEsZUFBZTtBQUN2QixZQUFNLEVBQUUsTUFBTSxNQUFNLElBQUk7QUFDeEIsVUFBSSxNQUFNO0FBQ1IsbUJBQVc7QUFDWDtBQUFBLE1BQ0Y7QUFDQTtBQUFBLFFBQ0UsU0FBUyxNQUFNLFVBQVU7QUFBQSxRQUN6QjtBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBQ0EsYUFBTyxJQUFJLE9BQU8sTUFBTTtBQUN4QixnQkFBVSxNQUFNO0FBQUEsSUFDbEI7QUFDQSxXQUFPLFdBQVcsZUFBZSxvQkFBb0Isd0JBQXdCO0FBQUEsRUFDL0UsVUFBRTtBQUNBLFlBQVEsb0JBQW9CLFNBQVMsS0FBSztBQUkxQyxRQUFJLENBQUMsVUFBVTtBQUNiLFlBQU0sZUFBZSxPQUFPLE9BQU8sRUFBRSxNQUFNLE1BQU07QUFBQSxNQUFDLENBQUM7QUFDbkQsVUFBSSxDQUFDLFFBQVEsUUFBUyxPQUFNO0FBQUEsSUFDOUI7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUyxtQkFBbUIsUUFBb0I7QUFDOUM7QUFBQSxJQUNFLE9BQU8sQ0FBQyxNQUFNLE1BQU0sT0FBTyxDQUFDLE1BQU0sTUFBTSxPQUFPLENBQUMsTUFBTTtBQUFBLElBQ3REO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDQTtBQUFBLElBQ0UsT0FBTyxDQUFDLE1BQU07QUFBQSxJQUNkO0FBQUEsSUFDQSwyQkFBMkIsT0FBTyxDQUFDLENBQUM7QUFBQSxFQUN0QztBQUNGO0FBRUEsU0FBUyxtQkFBbUIsT0FBZ0M7QUFDMUQsU0FDRSxVQUFVLFFBQ1YsT0FBTyxVQUFVLFlBQ2pCLENBQUMsTUFBTSxRQUFRLEtBQUssS0FDcEIsT0FBTyxLQUFLLEtBQUssRUFBRSxXQUFXLEtBQzlCLE9BQU8sT0FBTyxPQUFPLE9BQU8sS0FDNUIsT0FBTyxPQUFPLE9BQU8sS0FBSyxLQUMxQixPQUFPLE9BQU8sT0FBTyxRQUFRLEtBQzdCLE9BQU8sT0FBTyxPQUFPLFFBQVEsS0FDN0IsT0FBTyxPQUFPLE9BQU8sUUFBUTtBQUVqQztBQUNBLE1BQU0sMkJBQTJCLGtEQUFrRDtBQUU1RSxhQUFNLHNCQUFzQjtBQUFBLEVBR2pDLFlBQW9CLFFBQVEsS0FBSyxPQUFPLE1BQU07QUFBMUI7QUFBQSxFQUEyQjtBQUFBLEVBQTNCO0FBQUEsRUFGWixRQUFRO0FBQUE7QUFBQSxFQUNSLFFBQVE7QUFBQSxFQUVoQixJQUFJLE9BQWM7QUFDaEIsVUFBTSxPQUNKLEtBQUssU0FDSixLQUFLLFFBQVEsSUFBSSxLQUNsQiwyQkFDQSxPQUFPLE1BQU0sS0FBSyxFQUFFLFNBQ3BCLE9BQU8sTUFBTSxHQUFHLEVBQUUsU0FDbEIsT0FBTyxNQUFNLE1BQU0sRUFBRSxTQUNyQixPQUFPLE1BQU0sTUFBTSxFQUFFLFNBQ3JCLE9BQU8sTUFBTSxNQUFNLEVBQUU7QUFDdkIsV0FBTyxRQUFRLEtBQUssT0FBTyxrQkFBa0IsaUNBQWlDO0FBQzlFLFNBQUssUUFBUTtBQUNiLFNBQUs7QUFBQSxFQUNQO0FBQ0Y7QUFDQSx1QkFBdUIsWUFDckIsVUFDQSxPQUNBLFFBQzRCO0FBQzVCLFFBQU0sUUFBUSxNQUFNLE9BQU8sQ0FBQyxRQUFRLFNBQVMsV0FBVyxnQkFBZ0I7QUFDeEUsUUFBTTtBQUNOLFFBQU0sT0FBTyxJQUFJLFlBQVksRUFBRSxPQUFPLEtBQUssVUFBVSxRQUFRLENBQUM7QUFDOUQsU0FBTyxLQUFLLFVBQVUsS0FBSyxPQUFPLE1BQU0sa0JBQWtCLGdDQUFnQztBQUMxRixRQUFNLFNBQVMsSUFBSSxXQUFXLEVBQUUsR0FDOUIsS0FBSyxJQUFJLFNBQVMsT0FBTyxNQUFNO0FBQ2pDLFNBQU8sSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsQ0FBQztBQUMxQixLQUFHLFVBQVUsR0FBRyxLQUFLLFFBQVEsSUFBSTtBQUNqQyxLQUFHLFVBQVUsR0FBRyxNQUFNLElBQUksR0FBRyxJQUFJO0FBQ2pDLFFBQU07QUFDTixRQUFNO0FBQ04sTUFBSSxTQUFTLE9BQU8sU0FBUyxLQUFLO0FBQ2xDLFFBQU0sVUFBbUIsQ0FBQztBQUMxQixRQUFNLGtCQUFrQixJQUFJLHNCQUFzQjtBQUNsRCxtQkFBaUIsUUFBUSxPQUFPO0FBQzlCLFVBQU07QUFDTixVQUFNLFNBQVMsTUFBTSxTQUFTLEtBQUssS0FBSztBQUN4QyxVQUFNO0FBQ04sVUFBTSxRQUFRLElBQUksV0FBVyxFQUFFLEdBQzdCLE9BQU8sSUFBSSxTQUFTLE1BQU0sTUFBTTtBQUNsQyxTQUFLLFVBQVUsR0FBRyxLQUFLLE9BQU8sSUFBSTtBQUNsQyxTQUFLLFVBQVUsR0FBRyxLQUFLLEtBQUssSUFBSTtBQUNoQyxTQUFLLFVBQVUsR0FBRyxLQUFLLFFBQVEsSUFBSTtBQUNuQyxTQUFLLFVBQVUsSUFBSSxPQUFPLE9BQU8sSUFBSTtBQUNyQyxTQUFLLFVBQVUsSUFBSSxPQUFPLE1BQU0sUUFBUSxJQUFJO0FBQzVDLFNBQUssVUFBVSxJQUFJLEtBQUssTUFBTSxRQUFRLElBQUk7QUFDMUMsU0FBSyxVQUFVLElBQUksTUFBTSxPQUFPLEtBQUssR0FBRyxJQUFJO0FBQzVDLFVBQU0sUUFBUTtBQUFBLE1BQ1osT0FBTyxLQUFLO0FBQUEsTUFDWixLQUFLLEtBQUs7QUFBQSxNQUNWLFFBQVEsS0FBSztBQUFBLE1BQ2I7QUFBQSxNQUNBLFFBQVEsS0FBSyxPQUFPLE1BQU07QUFBQSxJQUM1QjtBQUNBLG9CQUFnQixJQUFJLEtBQUs7QUFDekIsWUFBUSxLQUFLLEtBQUs7QUFDbEIsVUFBTTtBQUNOLFVBQU0sT0FBTztBQUNiLGNBQVUsS0FBSyxPQUFPLE1BQU07QUFDNUIsV0FBTyxPQUFPLGNBQWMsTUFBTSxHQUFHLGtCQUFrQixrQ0FBa0M7QUFBQSxFQUMzRjtBQUNBLFFBQU07QUFDTixRQUFNLFlBQVksSUFBSSxZQUFZLEVBQUUsT0FBTyxLQUFLLFVBQVUsT0FBTyxDQUFDO0FBQ2xFLFNBQU8sVUFBVSxVQUFVLEtBQUssT0FBTyxNQUFNLGtCQUFrQixpQ0FBaUM7QUFDaEcsUUFBTSxTQUFTLElBQUksV0FBVyxDQUFDLEdBQzdCLEtBQUssSUFBSSxTQUFTLE9BQU8sTUFBTTtBQUNqQyxLQUFHLFVBQVUsR0FBRyxZQUFZLElBQUk7QUFDaEMsS0FBRyxVQUFVLEdBQUcsVUFBVSxRQUFRLElBQUk7QUFDdEMsUUFBTTtBQUNOLFFBQU07QUFDTixRQUFNLFNBQVMsSUFBSSxXQUFXLEVBQUUsR0FDOUIsS0FBSyxJQUFJLFNBQVMsT0FBTyxNQUFNO0FBQ2pDLFNBQU8sSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLEVBQUUsQ0FBQztBQUMzQixLQUFHLGFBQWEsR0FBRyxPQUFPLFNBQVMsQ0FBQyxHQUFHLElBQUk7QUFDM0MsS0FBRyxhQUFhLElBQUksT0FBTyxVQUFVLE1BQU0sR0FBRyxJQUFJO0FBQ2xELEtBQUcsVUFBVSxJQUFJLE1BQU0sU0FBUyxHQUFHLElBQUk7QUFDdkMsUUFBTTtBQUNOLFFBQU07QUFDUjtBQUNBLE1BQU0sYUFBYTtBQUFBLEVBVWpCLFlBQ0UsUUFDUSxRQUNSO0FBRFE7QUFFUixZQUFRLGVBQWU7QUFDdkIsU0FBSyxVQUNILGtCQUFrQixPQUNkLE9BQU8sT0FBTyxJQUNkLGtCQUFrQixhQUNoQixJQUFJLEtBQUssQ0FBQyxNQUFrQixDQUFDLEVBQUUsT0FBTyxJQUN0QyxRQUNOLFVBQVU7QUFDWixZQUFRLGlCQUFpQixTQUFTLEtBQUssT0FBTyxFQUFFLE1BQU0sS0FBSyxDQUFDO0FBQUEsRUFDOUQ7QUFBQSxFQVhVO0FBQUEsRUFYRjtBQUFBLEVBQ0EsUUFBb0IsSUFBSSxXQUFXLENBQUM7QUFBQSxFQUNwQyxLQUFLO0FBQUEsRUFDTCxtQkFBbUI7QUFBQSxFQUNuQixZQUFZLFlBQVksSUFBSTtBQUFBLEVBQ3BDLFNBQVM7QUFBQSxFQUNELFFBQVEsTUFBTTtBQUNwQixTQUFLLEtBQUssT0FBTyxPQUFPLEVBQUUsTUFBTSxNQUFNO0FBQUEsSUFBQyxDQUFDO0FBQUEsRUFDMUM7QUFBQSxFQWVBLE1BQWMsWUFBNkM7QUFDekQsV0FBTyxNQUFNO0FBQ1gsWUFBTSxPQUFPLE1BQU0sS0FBSyxPQUFPLEtBQUs7QUFDcEMsV0FBSyxRQUFRLGVBQWU7QUFDNUIsVUFBSSxLQUFLLEtBQU0sUUFBTztBQUN0QjtBQUFBLFFBQ0UsWUFBWSxPQUFPLEtBQUssS0FBSyxLQUMzQixPQUFPLFVBQVUsU0FBUyxLQUFLLEtBQUssS0FBSyxNQUFNO0FBQUEsUUFDakQ7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUVBLFVBQUksRUFBRSxLQUFLLG9CQUFvQixJQUFJO0FBQ2pDLGFBQUssbUJBQW1CO0FBQ3hCLFlBQUksWUFBWSxJQUFJLElBQUksS0FBSyxhQUFhLEdBQUc7QUFDM0MsZ0JBQU0sWUFBWTtBQUNsQixlQUFLLFlBQVksWUFBWSxJQUFJO0FBQ2pDLGVBQUssUUFBUSxlQUFlO0FBQUEsUUFDOUI7QUFBQSxNQUNGO0FBQ0EsVUFBSSxLQUFLLE1BQU0sT0FBUSxRQUFPLEtBQUs7QUFBQSxJQUNyQztBQUFBLEVBQ0Y7QUFBQSxFQUNBLE1BQU0sS0FBSyxRQUFnQjtBQUN6QixTQUFLLFFBQVEsZUFBZTtBQUM1QjtBQUFBLE1BQ0UsT0FBTyxVQUFVLE1BQU0sS0FBSyxVQUFVLEtBQUssVUFBVSxLQUFLLE9BQU87QUFBQSxNQUNqRTtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsVUFBTSxTQUFTLElBQUksV0FBVyxNQUFNO0FBQ3BDLFFBQUksS0FBSztBQUNULFdBQU8sS0FBSyxRQUFRO0FBQ2xCLFVBQUksS0FBSyxPQUFPLEtBQUssTUFBTSxRQUFRO0FBQ2pDLGNBQU0sUUFBUSxNQUFNLEtBQUssVUFBVTtBQUNuQyxlQUFPLE9BQU8sb0JBQW9CLHVCQUF1QjtBQUN6RCxhQUFLLFFBQVE7QUFDYixhQUFLLEtBQUs7QUFBQSxNQUNaO0FBQ0EsWUFBTSxRQUFRLEtBQUssSUFBSSxTQUFTLElBQUksS0FBSyxNQUFNLFNBQVMsS0FBSyxFQUFFO0FBQy9ELGFBQU8sSUFBSSxLQUFLLE1BQU0sU0FBUyxLQUFLLElBQUksS0FBSyxLQUFLLEtBQUssR0FBRyxFQUFFO0FBQzVELFlBQU07QUFDTixXQUFLLE1BQU07QUFDWCxXQUFLLFVBQVU7QUFBQSxJQUNqQjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFDQSxNQUFNLE1BQU07QUFDVixTQUFLLFFBQVEsZUFBZTtBQUM1QixVQUFNLE9BQU8sS0FBSyxPQUFPLEtBQUssTUFBTSxVQUFVLENBQUUsTUFBTSxLQUFLLFVBQVU7QUFDckUsU0FBSyxRQUFRLGVBQWU7QUFDNUIsV0FBTyxNQUFNLG9CQUFvQixzQkFBc0I7QUFBQSxFQUN6RDtBQUFBLEVBQ0EsTUFBTSxRQUFRO0FBQ1osU0FBSyxRQUFRLG9CQUFvQixTQUFTLEtBQUssS0FBSztBQUNwRCxVQUFNLGVBQWUsS0FBSyxPQUFPLE9BQU8sRUFBRSxNQUFNLE1BQU07QUFBQSxJQUFDLENBQUM7QUFDeEQsUUFBSSxDQUFDLEtBQUssUUFBUSxRQUFTLE9BQU07QUFDakMsU0FBSyxPQUFPLFlBQVk7QUFBQSxFQUMxQjtBQUNGO0FBQ0EsdUJBQXVCLFdBQ3JCLFFBQ0EsVUFBb0MsQ0FBQyxHQUlyQztBQUNBLFFBQU0sU0FBUyxJQUFJLGFBQWEsUUFBUSxRQUFRLE1BQU07QUFDdEQsUUFBTSxVQUFtQixDQUFDO0FBQzFCLFFBQU0sT0FBTyxvQkFBSSxJQUFZO0FBQzdCLFFBQU0sa0JBQWtCLElBQUksc0JBQXNCO0FBQ2xELE1BQUk7QUFDRixVQUFNLFNBQVMsTUFBTSxPQUFPLEtBQUssRUFBRSxHQUNqQyxLQUFLLElBQUksU0FBUyxPQUFPLE1BQU07QUFDakMsdUJBQW1CLE1BQU07QUFDekIsVUFBTSxPQUFPLE1BQU0sT0FBTyxLQUFLLEdBQUcsVUFBVSxHQUFHLElBQUksQ0FBQztBQUNwRCxXQUFPLE1BQU0sSUFBSSxNQUFNLEdBQUcsVUFBVSxHQUFHLElBQUksR0FBRyxvQkFBb0IseUJBQXlCO0FBQzNGLFVBQU0sV0FBVyxnQkFBZ0IsTUFBTSxVQUFVO0FBQ2pELFVBQU0sV0FBVyxtQkFBbUIsUUFBUTtBQUM1QztBQUFBLE1BQ0UsU0FBUyxPQUFPLE1BQU0sQ0FBQyxVQUFVLE1BQU0sT0FBTyxXQUFXLENBQUM7QUFBQSxNQUMxRDtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsVUFBTSxFQUFFLFVBQVUsU0FBUztBQUMzQixXQUFPLE1BQU07QUFDWCxZQUFNLFNBQVMsT0FBTyxRQUNwQixRQUFRLE1BQU0sT0FBTyxLQUFLLENBQUMsR0FDM0IsUUFBUSxJQUFJLFNBQVMsTUFBTSxNQUFNLEVBQUUsVUFBVSxHQUFHLElBQUk7QUFDdEQsVUFBSSxVQUFVLFlBQVk7QUFDeEIsY0FBTSxPQUFPLElBQUksVUFBVSxNQUFNLE9BQU8sS0FBSyxDQUFDLEdBQUcsTUFBTSxFQUFFLFVBQVUsR0FBRyxJQUFJLEdBQ3hFLGtCQUFrQixPQUFPLFFBQ3pCLFlBQVksTUFBTSxPQUFPLEtBQUssSUFBSSxHQUNsQyxTQUFTLE1BQU0sT0FBTyxLQUFLLEVBQUUsR0FDN0IsS0FBSyxJQUFJLFNBQVMsT0FBTyxNQUFNO0FBQ2pDO0FBQUEsVUFDRSxPQUFPLENBQUMsTUFBTSxNQUNaLE9BQU8sQ0FBQyxNQUFNLE1BQ2QsT0FBTyxDQUFDLE1BQU0sTUFDZCxPQUFPLENBQUMsTUFBTSxNQUNkLEdBQUcsYUFBYSxHQUFHLElBQUksTUFBTSxPQUFPLGVBQWUsS0FDbkQsR0FBRyxhQUFhLElBQUksSUFBSSxNQUFNLE9BQU8sSUFBSSxLQUN6QyxHQUFHLFVBQVUsSUFBSSxJQUFJLE1BQU0sTUFBTSxTQUFTO0FBQUEsVUFDNUM7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUNBLGNBQU0sU0FBUyxnQkFBZ0IsV0FBVyxXQUFXO0FBQ3JEO0FBQUEsVUFDRSxNQUFNLFFBQVEsTUFBTSxLQUFLLE9BQU8sV0FBVyxRQUFRO0FBQUEsVUFDbkQ7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUNBLGlCQUFTLFFBQVEsR0FBRyxRQUFRLFFBQVEsUUFBUSxTQUFTO0FBQ25ELGdCQUFNLE9BQU8sT0FBTyxLQUFLLEdBQ3ZCLFdBQVcsUUFBUSxLQUFLO0FBQzFCO0FBQUEsWUFDRSxtQkFBbUIsSUFBSSxLQUNyQixLQUFLLFVBQVUsU0FBUyxTQUN4QixLQUFLLFFBQVEsU0FBUyxPQUN0QixLQUFLLFdBQVcsU0FBUyxVQUN6QixLQUFLLFdBQVcsU0FBUyxVQUN6QixLQUFLLFdBQVcsU0FBUztBQUFBLFlBQzNCO0FBQUEsWUFDQTtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQ0EsY0FBTSxPQUFPLElBQUk7QUFDakI7QUFBQSxNQUNGO0FBQ0EsWUFBTSxPQUFPLE1BQU0sT0FBTyxLQUFLLEVBQUUsR0FDL0IsT0FBTyxJQUFJLFNBQVMsS0FBSyxNQUFNLEdBQy9CLE1BQU0sS0FBSyxVQUFVLEdBQUcsSUFBSSxHQUM1QixTQUFTLEtBQUssVUFBVSxHQUFHLElBQUksR0FDL0IsUUFBUSxLQUFLLFVBQVUsR0FBRyxJQUFJLEdBQzlCLFNBQVMsS0FBSyxVQUFVLElBQUksSUFBSSxHQUNoQyxnQkFBZ0IsS0FBSyxVQUFVLElBQUksSUFBSSxHQUN2QyxXQUFXLEtBQUssVUFBVSxJQUFJLElBQUk7QUFDcEMsYUFBTyxRQUFRLFNBQVMsT0FBTyxRQUFRLG9CQUFvQiwyQkFBMkI7QUFDdEYsWUFBTSxVQUFVLEdBQUcsS0FBSyxJQUFJLEdBQUcsSUFBSSxNQUFNO0FBQ3pDLGFBQU8sQ0FBQyxLQUFLLElBQUksT0FBTyxHQUFHLG9CQUFvQix1QkFBdUI7QUFDdEUsYUFBTyxPQUFPLGNBQWMsTUFBTSxHQUFHLGtCQUFrQixrQ0FBa0M7QUFDekYsWUFBTSxRQUFRLEVBQUUsT0FBTyxLQUFLLFFBQVEsUUFBUSxRQUFRLEtBQUssT0FBTztBQUNoRSxzQkFBZ0IsSUFBSSxLQUFLO0FBQ3pCLFdBQUssSUFBSSxPQUFPO0FBQ2hCLDJCQUFxQixPQUFPLFFBQVEsZUFBZSxLQUFLLE9BQU8sSUFBSTtBQUNuRSxZQUFNLFFBQVEsTUFBTSxPQUFPLEtBQUssTUFBTTtBQUN0QyxhQUFPLE1BQU0sS0FBSyxNQUFNLFVBQVUsb0JBQW9CLHVCQUF1QjtBQUM3RSxjQUFRLEtBQUssS0FBSztBQUNsQixZQUFNO0FBQUEsUUFDSjtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQSxPQUFPLE1BQU0sV0FBVyxPQUFPLE9BQU8sZUFBZSxRQUFXLFFBQVEsTUFBTTtBQUFBLE1BQ2hGO0FBQUEsSUFDRjtBQUFBLEVBQ0YsVUFBRTtBQUNBLFVBQU0sT0FBTyxNQUFNO0FBQUEsRUFDckI7QUFDRjtBQUVPLGFBQU0sYUFBYTtBQUFBLEVBQ2hCLFlBQ0UsUUFDQyxVQUNBLFdBQ1Q7QUFIUTtBQUNDO0FBQ0E7QUFBQSxFQUNSO0FBQUEsRUFITztBQUFBLEVBQ0M7QUFBQSxFQUNBO0FBQUEsRUFFWCxhQUFhLEtBQUssT0FBMEI7QUFDMUMsVUFBTSxTQUFTLGlCQUFpQixPQUFPLFFBQVEsSUFBSSxLQUFLLENBQUMsS0FBaUIsQ0FBQztBQUMzRSxXQUFPLE9BQU8sUUFBUSxJQUFJLG9CQUFvQix1QkFBdUI7QUFDckUsVUFBTSxTQUFTLElBQUksV0FBVyxNQUFNLE9BQU8sTUFBTSxHQUFHLEVBQUUsRUFBRSxZQUFZLENBQUMsR0FDbkUsS0FBSyxJQUFJLFNBQVMsT0FBTyxNQUFNO0FBQ2pDLHVCQUFtQixNQUFNO0FBQ3pCLFVBQU0sU0FBUyxJQUFJLFdBQVcsTUFBTSxPQUFPLE1BQU0sR0FBRyxFQUFFLFlBQVksQ0FBQyxHQUNqRSxLQUFLLElBQUksU0FBUyxPQUFPLE1BQU0sR0FDL0IsU0FBUyxPQUFPLEdBQUcsYUFBYSxHQUFHLElBQUksQ0FBQyxHQUN4QyxTQUFTLE9BQU8sR0FBRyxhQUFhLElBQUksSUFBSSxDQUFDO0FBQzNDO0FBQUEsTUFDRSxPQUFPLENBQUMsTUFBTSxNQUNaLE9BQU8sQ0FBQyxNQUFNLE1BQ2QsT0FBTyxDQUFDLE1BQU0sTUFDZCxPQUFPLENBQUMsTUFBTSxNQUNkLE9BQU8sY0FBYyxNQUFNLEtBQzNCLE9BQU8sY0FBYyxNQUFNLEtBQzNCLFVBQVUsS0FDVixVQUFVLEtBQUssT0FBTyxRQUN0QixTQUFTLFdBQVcsT0FBTyxPQUFPO0FBQUEsTUFDcEM7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLFVBQU0sU0FBUyxJQUFJLFNBQVMsTUFBTSxPQUFPLE1BQU0sU0FBUyxHQUFHLE1BQU0sRUFBRSxZQUFZLENBQUM7QUFDaEY7QUFBQSxNQUNFLE9BQU8sVUFBVSxHQUFHLElBQUksTUFBTSxjQUFjLE9BQU8sVUFBVSxHQUFHLElBQUksTUFBTTtBQUFBLE1BQzFFO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFDQSxVQUFNLFlBQVksSUFBSSxXQUFXLE1BQU0sT0FBTyxNQUFNLFFBQVEsU0FBUyxNQUFNLEVBQUUsWUFBWSxDQUFDO0FBQzFGO0FBQUEsTUFDRSxNQUFNLFNBQVMsTUFBTSxHQUFHLFVBQVUsSUFBSSxJQUFJO0FBQUEsTUFDMUM7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUVBLFVBQU0sT0FBTyxHQUFHLFVBQVUsR0FBRyxJQUFJO0FBQ2pDO0FBQUEsTUFDRSxRQUFRLEtBQUssT0FBTyxRQUFRLEtBQUssUUFBUSxTQUFTO0FBQUEsTUFDbEQ7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLFVBQU0sT0FBTyxJQUFJLFdBQVcsTUFBTSxPQUFPLE1BQU0sSUFBSSxLQUFLLElBQUksRUFBRSxZQUFZLENBQUM7QUFDM0UsV0FBTyxNQUFNLElBQUksTUFBTSxHQUFHLFVBQVUsR0FBRyxJQUFJLEdBQUcsb0JBQW9CLHlCQUF5QjtBQUMzRixVQUFNLFdBQVcsZ0JBQWdCLE1BQU0sVUFBVTtBQUNqRCx1QkFBbUIsUUFBUTtBQUMzQjtBQUFBLE1BQ0UsU0FBUyxPQUFPLE1BQU0sQ0FBQyxVQUFVLE1BQU0sT0FBTyxXQUFXLENBQUM7QUFBQSxNQUMxRDtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsVUFBTSxPQUFPLG9CQUFJLElBQVk7QUFDN0IsVUFBTSxVQUFVLGdCQUFnQixXQUFXLFdBQVc7QUFDdEQsV0FBTyxNQUFNLFFBQVEsT0FBTyxHQUFHLG9CQUFvQixtQkFBbUI7QUFDdEUsUUFBSSxNQUFNLEtBQUs7QUFDZixlQUFXLFNBQVMsU0FBUztBQUMzQjtBQUFBLFFBQ0UsbUJBQW1CLEtBQUssS0FDdEIsT0FBTyxVQUFVLE1BQU0sS0FBSyxLQUM1QixNQUFNLFNBQVMsS0FDZixNQUFNLFFBQVEsU0FBUyxPQUFPLFVBQzlCLE9BQU8sVUFBVSxNQUFNLEdBQUcsS0FDMUIsTUFBTSxPQUFPLEtBQ2IsT0FBTyxVQUFVLE1BQU0sTUFBTSxLQUM3QixNQUFNLFVBQVUsS0FDaEIsTUFBTSxXQUFXLE9BQ2pCLE9BQU8sVUFBVSxNQUFNLE1BQU0sS0FDN0IsTUFBTSxVQUFVLE1BQ2hCLE1BQU0sU0FBUyxNQUFNLFVBQVUsU0FBUztBQUFBLFFBQzFDO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFDQTtBQUFBLFFBQ0UsTUFBTSxVQUFVLEtBQUssT0FBTyxPQUFPO0FBQUEsUUFDbkM7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUNBLFlBQU0sVUFBVSxHQUFHLE1BQU0sS0FBSyxJQUFJLE1BQU0sR0FBRyxJQUFJLE1BQU0sTUFBTTtBQUMzRCxhQUFPLENBQUMsS0FBSyxJQUFJLE9BQU8sR0FBRyxvQkFBb0IsMEJBQTBCO0FBQ3pFLFdBQUssSUFBSSxPQUFPO0FBQ2hCLGFBQU8sTUFBTTtBQUFBLElBQ2Y7QUFDQSxXQUFPLFFBQVEsU0FBUyxHQUFHLG9CQUFvQix1QkFBdUI7QUFDdEUsV0FBTyxJQUFJLGFBQWEsUUFBUSxVQUFVLE9BQU87QUFBQSxFQUNuRDtBQUFBLEVBQ0EsTUFBTSxLQUFLLE9BQWU7QUFDeEIsV0FBTyxPQUFPLFVBQVUsS0FBSyxLQUFLLFNBQVMsR0FBRyxvQkFBb0IsY0FBYztBQUNoRixVQUFNLGNBQWMsS0FBSyxVQUFVLEtBQUs7QUFDeEMsV0FBTyxhQUFhLG9CQUFvQixjQUFjO0FBQ3RELFdBQU8sbUJBQW1CLFdBQVcsR0FBRyxvQkFBb0IseUJBQXlCO0FBQ3JGLFVBQU0sUUFBUSxFQUFFLEdBQUcsWUFBWTtBQUMvQjtBQUFBLE1BQ0UsT0FBTyxjQUFjLE1BQU0sTUFBTSxLQUMvQixNQUFNLFVBQVUsS0FDaEIsT0FBTyxjQUFjLE1BQU0sTUFBTSxLQUNqQyxNQUFNLFVBQVUsTUFDaEIsTUFBTSxTQUFTLE1BQU0sVUFBVSxLQUFLLE9BQU87QUFBQSxNQUM3QztBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsV0FBTyxNQUFNLFVBQVUsS0FBSyxPQUFPLE9BQU8sSUFBSSxrQkFBa0IsNkJBQTZCO0FBRzdGLFVBQU0sYUFBYSxNQUFNLFNBQVMsS0FBSztBQUN2QyxVQUFNLFFBQVEsSUFBSTtBQUFBLE1BQ2QsTUFBTSxLQUFLLE9BQ1IsTUFBTSxNQUFNLFFBQVEsTUFBTSxVQUFVLGFBQWEsS0FBSyxNQUFNLE9BQU8sRUFDbkUsWUFBWTtBQUFBLElBQ2pCLEdBQ0EsT0FBTyxJQUFJLFNBQVMsTUFBTSxNQUFNO0FBQ2xDO0FBQUEsTUFDRSxLQUFLLFVBQVUsR0FBRyxJQUFJLE1BQU0sTUFBTSxTQUNoQyxLQUFLLFVBQVUsR0FBRyxJQUFJLE1BQU0sTUFBTSxPQUNsQyxLQUFLLFVBQVUsR0FBRyxJQUFJLE1BQU0sTUFBTSxVQUNsQyxLQUFLLFVBQVUsSUFBSSxJQUFJLE1BQU0sTUFBTSxTQUFTO0FBQUEsTUFDOUM7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLFVBQU0sUUFBUSxLQUFLLFVBQVUsSUFBSSxJQUFJLEdBQ25DLGdCQUFnQixLQUFLLFVBQVUsSUFBSSxJQUFJO0FBQ3pDLHlCQUFxQixPQUFPLE1BQU0sU0FBUyxJQUFJLGVBQWUsS0FBSyxPQUFPLElBQUk7QUFDOUUsVUFBTSxVQUFVLGFBQ1osSUFBSTtBQUFBLE1BQ0YsTUFBTSxLQUFLLE9BQU8sTUFBTSxNQUFNLFNBQVMsSUFBSSxNQUFNLFNBQVMsTUFBTSxNQUFNLEVBQUUsWUFBWTtBQUFBLElBQ3RGLElBQ0EsTUFBTSxTQUFTLEVBQUU7QUFDckIsV0FBTyxNQUFNLE9BQU8sTUFBTSxLQUFLLFVBQVUsSUFBSSxJQUFJLEdBQUcsb0JBQW9CLG9CQUFvQjtBQUM1RixXQUFPLFdBQVcsU0FBUyxPQUFPLGFBQWE7QUFBQSxFQUNqRDtBQUNGOyIsIm5hbWVzIjpbXX0=
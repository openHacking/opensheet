import { checked, number, truth } from "/@fs/Volumes/github/private/opensheet/packages/formula/src/coercion.ts";
import { fail, FormulaError } from "/@fs/Volumes/github/private/opensheet/packages/formula/src/errors.ts";
export const FORMULA_TEXT_LIMIT = 32767;
export function formulaText(value) {
  checked(value);
  return value === null ? "" : typeof value === "boolean" ? value ? "TRUE" : "FALSE" : String(value);
}
const bounded = (value) => value.length <= FORMULA_TEXT_LIMIT ? value : fail();
function length(value) {
  let count = 0;
  for (const _point of value) count++;
  return count;
}
function slice(value, start, count) {
  if (!count) return "";
  let index = 0, offset = 0, begin;
  for (const point of value) {
    if (index === start) begin = offset;
    if (index === start + count) return bounded(value.slice(begin, offset));
    offset += point.length;
    index++;
  }
  return begin === void 0 ? "" : bounded(value.slice(begin));
}
const characters = (value) => {
  const count = number(value);
  if (count < 0) fail();
  return Math.trunc(count);
};
export function evaluateText(name, values) {
  if (!["LEFT", "RIGHT", "MID", "LEN", "TRIM", "UPPER", "LOWER"].includes(name)) return void 0;
  const value = formulaText(values[0]);
  if (name === "LEN") return length(value);
  if (name === "TRIM") return bounded(value.replace(/ +/g, " ").replace(/^ | $/g, ""));
  if (name === "UPPER") return bounded(value.toUpperCase());
  if (name === "LOWER") return bounded(value.toLowerCase());
  if (name === "MID") {
    const start = number(values[1]);
    if (start < 1) fail();
    return slice(value, Math.trunc(start) - 1, characters(values[2]));
  }
  const count = values.length > 1 ? characters(values[1]) : 1;
  return slice(value, name === "LEFT" ? 0 : Math.max(0, length(value) - count), count);
}
export class TextJoin {
  value = "";
  hasValue = false;
  size = 0;
  delimiter = "";
  ignoreEmpty = false;
  error;
  constructor(delimiter = "", ignoreEmpty = false) {
    const internal = [delimiter, ignoreEmpty].find(
      (value) => value && typeof value === "object" && ["#LIMIT!", "#CYCLE!"].includes(value.error)
    );
    if (internal && typeof internal === "object") {
      this.error = internal;
      return;
    }
    try {
      this.delimiter = formulaText(delimiter);
      this.ignoreEmpty = truth(ignoreEmpty);
    } catch (error) {
      if (!(error instanceof FormulaError)) throw error;
      this.error = { error: error.code };
    }
  }
  add(value, _referenced = false) {
    if (value && typeof value === "object" && ["#LIMIT!", "#CYCLE!"].includes(value.error)) {
      if (!this.error || !["#LIMIT!", "#CYCLE!"].includes(this.error.error)) this.error = value;
      this.value = "";
      return;
    }
    if (this.error) return;
    try {
      const text = formulaText(value);
      if (this.ignoreEmpty && !text) return;
      const size = this.size + text.length + (this.hasValue ? this.delimiter.length : 0);
      if (size > FORMULA_TEXT_LIMIT) fail();
      if (this.hasValue && this.delimiter) this.value += this.delimiter;
      if (text) this.value += text;
      this.hasValue = true;
      this.size = size;
    } catch (error) {
      if (!(error instanceof FormulaError)) throw error;
      this.error = { error: error.code };
      this.value = "";
    }
  }
  result() {
    return this.error ?? this.value;
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRleHQudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY2hlY2tlZCwgbnVtYmVyLCB0cnV0aCB9IGZyb20gJy4vY29lcmNpb24uanMnO1xuaW1wb3J0IHsgZmFpbCwgRm9ybXVsYUVycm9yIH0gZnJvbSAnLi9lcnJvcnMuanMnO1xuaW1wb3J0IHR5cGUgeyBGb3JtdWxhVmFsdWUgfSBmcm9tICcuL3R5cGVzLmpzJztcblxuZXhwb3J0IGNvbnN0IEZPUk1VTEFfVEVYVF9MSU1JVCA9IDMyNzY3O1xuZXhwb3J0IGZ1bmN0aW9uIGZvcm11bGFUZXh0KHZhbHVlOiBGb3JtdWxhVmFsdWUpOiBzdHJpbmcge1xuICBjaGVja2VkKHZhbHVlKTtcbiAgcmV0dXJuIHZhbHVlID09PSBudWxsXG4gICAgPyAnJ1xuICAgIDogdHlwZW9mIHZhbHVlID09PSAnYm9vbGVhbidcbiAgICAgID8gdmFsdWVcbiAgICAgICAgPyAnVFJVRSdcbiAgICAgICAgOiAnRkFMU0UnXG4gICAgICA6IFN0cmluZyh2YWx1ZSk7XG59XG5jb25zdCBib3VuZGVkID0gKHZhbHVlOiBzdHJpbmcpID0+ICh2YWx1ZS5sZW5ndGggPD0gRk9STVVMQV9URVhUX0xJTUlUID8gdmFsdWUgOiBmYWlsKCkpO1xuZnVuY3Rpb24gbGVuZ3RoKHZhbHVlOiBzdHJpbmcpIHtcbiAgbGV0IGNvdW50ID0gMDtcbiAgZm9yIChjb25zdCBfcG9pbnQgb2YgdmFsdWUpIGNvdW50Kys7XG4gIHJldHVybiBjb3VudDtcbn1cbmZ1bmN0aW9uIHNsaWNlKHZhbHVlOiBzdHJpbmcsIHN0YXJ0OiBudW1iZXIsIGNvdW50OiBudW1iZXIpIHtcbiAgaWYgKCFjb3VudCkgcmV0dXJuICcnO1xuICBsZXQgaW5kZXggPSAwLFxuICAgIG9mZnNldCA9IDAsXG4gICAgYmVnaW46IG51bWJlciB8IHVuZGVmaW5lZDtcbiAgZm9yIChjb25zdCBwb2ludCBvZiB2YWx1ZSkge1xuICAgIGlmIChpbmRleCA9PT0gc3RhcnQpIGJlZ2luID0gb2Zmc2V0O1xuICAgIGlmIChpbmRleCA9PT0gc3RhcnQgKyBjb3VudCkgcmV0dXJuIGJvdW5kZWQodmFsdWUuc2xpY2UoYmVnaW4sIG9mZnNldCkpO1xuICAgIG9mZnNldCArPSBwb2ludC5sZW5ndGg7XG4gICAgaW5kZXgrKztcbiAgfVxuICByZXR1cm4gYmVnaW4gPT09IHVuZGVmaW5lZCA/ICcnIDogYm91bmRlZCh2YWx1ZS5zbGljZShiZWdpbikpO1xufVxuY29uc3QgY2hhcmFjdGVycyA9ICh2YWx1ZTogRm9ybXVsYVZhbHVlKSA9PiB7XG4gIGNvbnN0IGNvdW50ID0gbnVtYmVyKHZhbHVlKTtcbiAgaWYgKGNvdW50IDwgMCkgZmFpbCgpO1xuICByZXR1cm4gTWF0aC50cnVuYyhjb3VudCk7XG59O1xuXG5leHBvcnQgZnVuY3Rpb24gZXZhbHVhdGVUZXh0KG5hbWU6IHN0cmluZywgdmFsdWVzOiBGb3JtdWxhVmFsdWVbXSk6IEZvcm11bGFWYWx1ZSB8IHVuZGVmaW5lZCB7XG4gIGlmICghWydMRUZUJywgJ1JJR0hUJywgJ01JRCcsICdMRU4nLCAnVFJJTScsICdVUFBFUicsICdMT1dFUiddLmluY2x1ZGVzKG5hbWUpKSByZXR1cm4gdW5kZWZpbmVkO1xuICBjb25zdCB2YWx1ZSA9IGZvcm11bGFUZXh0KHZhbHVlc1swXSk7XG4gIGlmIChuYW1lID09PSAnTEVOJykgcmV0dXJuIGxlbmd0aCh2YWx1ZSk7XG4gIGlmIChuYW1lID09PSAnVFJJTScpIHJldHVybiBib3VuZGVkKHZhbHVlLnJlcGxhY2UoLyArL2csICcgJykucmVwbGFjZSgvXiB8ICQvZywgJycpKTtcbiAgaWYgKG5hbWUgPT09ICdVUFBFUicpIHJldHVybiBib3VuZGVkKHZhbHVlLnRvVXBwZXJDYXNlKCkpO1xuICBpZiAobmFtZSA9PT0gJ0xPV0VSJykgcmV0dXJuIGJvdW5kZWQodmFsdWUudG9Mb3dlckNhc2UoKSk7XG4gIGlmIChuYW1lID09PSAnTUlEJykge1xuICAgIGNvbnN0IHN0YXJ0ID0gbnVtYmVyKHZhbHVlc1sxXSk7XG4gICAgaWYgKHN0YXJ0IDwgMSkgZmFpbCgpO1xuICAgIHJldHVybiBzbGljZSh2YWx1ZSwgTWF0aC50cnVuYyhzdGFydCkgLSAxLCBjaGFyYWN0ZXJzKHZhbHVlc1syXSkpO1xuICB9XG4gIGNvbnN0IGNvdW50ID0gdmFsdWVzLmxlbmd0aCA+IDEgPyBjaGFyYWN0ZXJzKHZhbHVlc1sxXSkgOiAxO1xuICByZXR1cm4gc2xpY2UodmFsdWUsIG5hbWUgPT09ICdMRUZUJyA/IDAgOiBNYXRoLm1heCgwLCBsZW5ndGgodmFsdWUpIC0gY291bnQpLCBjb3VudCk7XG59XG5cbi8qKiBTdHJlYW1pbmcgdGV4dCBhZ2dyZWdhdGlvbiB3aXRoIGJvdW5kZWQgb3V0cHV0LCBzaGFyZWQgYnkgYm90aCBldmFsdWF0b3IgcGF0aHMuICovXG5leHBvcnQgY2xhc3MgVGV4dEpvaW4ge1xuICBwcml2YXRlIHZhbHVlID0gJyc7XG4gIHByaXZhdGUgaGFzVmFsdWUgPSBmYWxzZTtcbiAgcHJpdmF0ZSBzaXplID0gMDtcbiAgcHJpdmF0ZSBkZWxpbWl0ZXIgPSAnJztcbiAgcHJpdmF0ZSBpZ25vcmVFbXB0eSA9IGZhbHNlO1xuICBwcml2YXRlIGVycm9yPzogeyBlcnJvcjogc3RyaW5nIH07XG4gIGNvbnN0cnVjdG9yKGRlbGltaXRlcjogRm9ybXVsYVZhbHVlID0gJycsIGlnbm9yZUVtcHR5OiBGb3JtdWxhVmFsdWUgPSBmYWxzZSkge1xuICAgIGNvbnN0IGludGVybmFsID0gW2RlbGltaXRlciwgaWdub3JlRW1wdHldLmZpbmQoXG4gICAgICAodmFsdWUpID0+IHZhbHVlICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgWycjTElNSVQhJywgJyNDWUNMRSEnXS5pbmNsdWRlcyh2YWx1ZS5lcnJvciksXG4gICAgKTtcbiAgICBpZiAoaW50ZXJuYWwgJiYgdHlwZW9mIGludGVybmFsID09PSAnb2JqZWN0Jykge1xuICAgICAgdGhpcy5lcnJvciA9IGludGVybmFsO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0cnkge1xuICAgICAgdGhpcy5kZWxpbWl0ZXIgPSBmb3JtdWxhVGV4dChkZWxpbWl0ZXIpO1xuICAgICAgdGhpcy5pZ25vcmVFbXB0eSA9IHRydXRoKGlnbm9yZUVtcHR5KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKCEoZXJyb3IgaW5zdGFuY2VvZiBGb3JtdWxhRXJyb3IpKSB0aHJvdyBlcnJvcjtcbiAgICAgIHRoaXMuZXJyb3IgPSB7IGVycm9yOiBlcnJvci5jb2RlIH07XG4gICAgfVxuICB9XG4gIGFkZCh2YWx1ZTogRm9ybXVsYVZhbHVlLCBfcmVmZXJlbmNlZCA9IGZhbHNlKSB7XG4gICAgLy8gSW50ZXJuYWwgZmFpbHVyZXMgbXVzdCBub3QgYmUgaGlkZGVuIGJ5IGFuIGVhcmxpZXIgb3JkaW5hcnkgZXJyb3IuXG4gICAgaWYgKHZhbHVlICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgWycjTElNSVQhJywgJyNDWUNMRSEnXS5pbmNsdWRlcyh2YWx1ZS5lcnJvcikpIHtcbiAgICAgIGlmICghdGhpcy5lcnJvciB8fCAhWycjTElNSVQhJywgJyNDWUNMRSEnXS5pbmNsdWRlcyh0aGlzLmVycm9yLmVycm9yKSkgdGhpcy5lcnJvciA9IHZhbHVlO1xuICAgICAgdGhpcy52YWx1ZSA9ICcnO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAodGhpcy5lcnJvcikgcmV0dXJuO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB0ZXh0ID0gZm9ybXVsYVRleHQodmFsdWUpO1xuICAgICAgaWYgKHRoaXMuaWdub3JlRW1wdHkgJiYgIXRleHQpIHJldHVybjtcbiAgICAgIGNvbnN0IHNpemUgPSB0aGlzLnNpemUgKyB0ZXh0Lmxlbmd0aCArICh0aGlzLmhhc1ZhbHVlID8gdGhpcy5kZWxpbWl0ZXIubGVuZ3RoIDogMCk7XG4gICAgICBpZiAoc2l6ZSA+IEZPUk1VTEFfVEVYVF9MSU1JVCkgZmFpbCgpO1xuICAgICAgaWYgKHRoaXMuaGFzVmFsdWUgJiYgdGhpcy5kZWxpbWl0ZXIpIHRoaXMudmFsdWUgKz0gdGhpcy5kZWxpbWl0ZXI7XG4gICAgICBpZiAodGV4dCkgdGhpcy52YWx1ZSArPSB0ZXh0O1xuICAgICAgdGhpcy5oYXNWYWx1ZSA9IHRydWU7XG4gICAgICB0aGlzLnNpemUgPSBzaXplO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoIShlcnJvciBpbnN0YW5jZW9mIEZvcm11bGFFcnJvcikpIHRocm93IGVycm9yO1xuICAgICAgdGhpcy5lcnJvciA9IHsgZXJyb3I6IGVycm9yLmNvZGUgfTtcbiAgICAgIHRoaXMudmFsdWUgPSAnJztcbiAgICB9XG4gIH1cbiAgcmVzdWx0KCk6IEZvcm11bGFWYWx1ZSB7XG4gICAgcmV0dXJuIHRoaXMuZXJyb3IgPz8gdGhpcy52YWx1ZTtcbiAgfVxufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLFNBQVMsUUFBUSxhQUFhO0FBQ3ZDLFNBQVMsTUFBTSxvQkFBb0I7QUFHNUIsYUFBTSxxQkFBcUI7QUFDM0IsZ0JBQVMsWUFBWSxPQUE2QjtBQUN2RCxVQUFRLEtBQUs7QUFDYixTQUFPLFVBQVUsT0FDYixLQUNBLE9BQU8sVUFBVSxZQUNmLFFBQ0UsU0FDQSxVQUNGLE9BQU8sS0FBSztBQUNwQjtBQUNBLE1BQU0sVUFBVSxDQUFDLFVBQW1CLE1BQU0sVUFBVSxxQkFBcUIsUUFBUSxLQUFLO0FBQ3RGLFNBQVMsT0FBTyxPQUFlO0FBQzdCLE1BQUksUUFBUTtBQUNaLGFBQVcsVUFBVSxNQUFPO0FBQzVCLFNBQU87QUFDVDtBQUNBLFNBQVMsTUFBTSxPQUFlLE9BQWUsT0FBZTtBQUMxRCxNQUFJLENBQUMsTUFBTyxRQUFPO0FBQ25CLE1BQUksUUFBUSxHQUNWLFNBQVMsR0FDVDtBQUNGLGFBQVcsU0FBUyxPQUFPO0FBQ3pCLFFBQUksVUFBVSxNQUFPLFNBQVE7QUFDN0IsUUFBSSxVQUFVLFFBQVEsTUFBTyxRQUFPLFFBQVEsTUFBTSxNQUFNLE9BQU8sTUFBTSxDQUFDO0FBQ3RFLGNBQVUsTUFBTTtBQUNoQjtBQUFBLEVBQ0Y7QUFDQSxTQUFPLFVBQVUsU0FBWSxLQUFLLFFBQVEsTUFBTSxNQUFNLEtBQUssQ0FBQztBQUM5RDtBQUNBLE1BQU0sYUFBYSxDQUFDLFVBQXdCO0FBQzFDLFFBQU0sUUFBUSxPQUFPLEtBQUs7QUFDMUIsTUFBSSxRQUFRLEVBQUcsTUFBSztBQUNwQixTQUFPLEtBQUssTUFBTSxLQUFLO0FBQ3pCO0FBRU8sZ0JBQVMsYUFBYSxNQUFjLFFBQWtEO0FBQzNGLE1BQUksQ0FBQyxDQUFDLFFBQVEsU0FBUyxPQUFPLE9BQU8sUUFBUSxTQUFTLE9BQU8sRUFBRSxTQUFTLElBQUksRUFBRyxRQUFPO0FBQ3RGLFFBQU0sUUFBUSxZQUFZLE9BQU8sQ0FBQyxDQUFDO0FBQ25DLE1BQUksU0FBUyxNQUFPLFFBQU8sT0FBTyxLQUFLO0FBQ3ZDLE1BQUksU0FBUyxPQUFRLFFBQU8sUUFBUSxNQUFNLFFBQVEsT0FBTyxHQUFHLEVBQUUsUUFBUSxVQUFVLEVBQUUsQ0FBQztBQUNuRixNQUFJLFNBQVMsUUFBUyxRQUFPLFFBQVEsTUFBTSxZQUFZLENBQUM7QUFDeEQsTUFBSSxTQUFTLFFBQVMsUUFBTyxRQUFRLE1BQU0sWUFBWSxDQUFDO0FBQ3hELE1BQUksU0FBUyxPQUFPO0FBQ2xCLFVBQU0sUUFBUSxPQUFPLE9BQU8sQ0FBQyxDQUFDO0FBQzlCLFFBQUksUUFBUSxFQUFHLE1BQUs7QUFDcEIsV0FBTyxNQUFNLE9BQU8sS0FBSyxNQUFNLEtBQUssSUFBSSxHQUFHLFdBQVcsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUFBLEVBQ2xFO0FBQ0EsUUFBTSxRQUFRLE9BQU8sU0FBUyxJQUFJLFdBQVcsT0FBTyxDQUFDLENBQUMsSUFBSTtBQUMxRCxTQUFPLE1BQU0sT0FBTyxTQUFTLFNBQVMsSUFBSSxLQUFLLElBQUksR0FBRyxPQUFPLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSztBQUNyRjtBQUdPLGFBQU0sU0FBUztBQUFBLEVBQ1osUUFBUTtBQUFBLEVBQ1IsV0FBVztBQUFBLEVBQ1gsT0FBTztBQUFBLEVBQ1AsWUFBWTtBQUFBLEVBQ1osY0FBYztBQUFBLEVBQ2Q7QUFBQSxFQUNSLFlBQVksWUFBMEIsSUFBSSxjQUE0QixPQUFPO0FBQzNFLFVBQU0sV0FBVyxDQUFDLFdBQVcsV0FBVyxFQUFFO0FBQUEsTUFDeEMsQ0FBQyxVQUFVLFNBQVMsT0FBTyxVQUFVLFlBQVksQ0FBQyxXQUFXLFNBQVMsRUFBRSxTQUFTLE1BQU0sS0FBSztBQUFBLElBQzlGO0FBQ0EsUUFBSSxZQUFZLE9BQU8sYUFBYSxVQUFVO0FBQzVDLFdBQUssUUFBUTtBQUNiO0FBQUEsSUFDRjtBQUNBLFFBQUk7QUFDRixXQUFLLFlBQVksWUFBWSxTQUFTO0FBQ3RDLFdBQUssY0FBYyxNQUFNLFdBQVc7QUFBQSxJQUN0QyxTQUFTLE9BQU87QUFDZCxVQUFJLEVBQUUsaUJBQWlCLGNBQWUsT0FBTTtBQUM1QyxXQUFLLFFBQVEsRUFBRSxPQUFPLE1BQU0sS0FBSztBQUFBLElBQ25DO0FBQUEsRUFDRjtBQUFBLEVBQ0EsSUFBSSxPQUFxQixjQUFjLE9BQU87QUFFNUMsUUFBSSxTQUFTLE9BQU8sVUFBVSxZQUFZLENBQUMsV0FBVyxTQUFTLEVBQUUsU0FBUyxNQUFNLEtBQUssR0FBRztBQUN0RixVQUFJLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxXQUFXLFNBQVMsRUFBRSxTQUFTLEtBQUssTUFBTSxLQUFLLEVBQUcsTUFBSyxRQUFRO0FBQ3BGLFdBQUssUUFBUTtBQUNiO0FBQUEsSUFDRjtBQUNBLFFBQUksS0FBSyxNQUFPO0FBQ2hCLFFBQUk7QUFDRixZQUFNLE9BQU8sWUFBWSxLQUFLO0FBQzlCLFVBQUksS0FBSyxlQUFlLENBQUMsS0FBTTtBQUMvQixZQUFNLE9BQU8sS0FBSyxPQUFPLEtBQUssVUFBVSxLQUFLLFdBQVcsS0FBSyxVQUFVLFNBQVM7QUFDaEYsVUFBSSxPQUFPLG1CQUFvQixNQUFLO0FBQ3BDLFVBQUksS0FBSyxZQUFZLEtBQUssVUFBVyxNQUFLLFNBQVMsS0FBSztBQUN4RCxVQUFJLEtBQU0sTUFBSyxTQUFTO0FBQ3hCLFdBQUssV0FBVztBQUNoQixXQUFLLE9BQU87QUFBQSxJQUNkLFNBQVMsT0FBTztBQUNkLFVBQUksRUFBRSxpQkFBaUIsY0FBZSxPQUFNO0FBQzVDLFdBQUssUUFBUSxFQUFFLE9BQU8sTUFBTSxLQUFLO0FBQ2pDLFdBQUssUUFBUTtBQUFBLElBQ2Y7QUFBQSxFQUNGO0FBQUEsRUFDQSxTQUF1QjtBQUNyQixXQUFPLEtBQUssU0FBUyxLQUFLO0FBQUEsRUFDNUI7QUFDRjsiLCJuYW1lcyI6W119
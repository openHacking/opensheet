export class FormulaError extends Error {
  constructor(code) {
    super(code);
    this.code = code;
  }
  code;
}
export const fail = (code = "#VALUE!") => {
  throw new FormulaError(code);
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImVycm9ycy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY2xhc3MgRm9ybXVsYUVycm9yIGV4dGVuZHMgRXJyb3Ige1xuICBjb25zdHJ1Y3RvcihwdWJsaWMgY29kZTogc3RyaW5nKSB7XG4gICAgc3VwZXIoY29kZSk7XG4gIH1cbn1cbmV4cG9ydCBjb25zdCBmYWlsID0gKGNvZGUgPSAnI1ZBTFVFIScpOiBuZXZlciA9PiB7XG4gIHRocm93IG5ldyBGb3JtdWxhRXJyb3IoY29kZSk7XG59O1xuIl0sIm1hcHBpbmdzIjoiQUFBTyxhQUFNLHFCQUFxQixNQUFNO0FBQUEsRUFDdEMsWUFBbUIsTUFBYztBQUMvQixVQUFNLElBQUk7QUFETztBQUFBLEVBRW5CO0FBQUEsRUFGbUI7QUFHckI7QUFDTyxhQUFNLE9BQU8sQ0FBQyxPQUFPLGNBQXFCO0FBQy9DLFFBQU0sSUFBSSxhQUFhLElBQUk7QUFDN0I7IiwibmFtZXMiOltdfQ==
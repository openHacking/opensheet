import { checked } from "/@fs/Volumes/github/private/opensheet/packages/formula/src/coercion.ts";
import { fail } from "/@fs/Volumes/github/private/opensheet/packages/formula/src/errors.ts";
const numeric = (value) => /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i.test(value.trim()) && Number.isFinite(Number(value));
export function wildcard(pattern, work = { remaining: 1e6 }) {
  if (pattern.length > 32767) fail("#LIMIT!");
  work.remaining -= pattern.length;
  if (work.remaining < 0) fail("#LIMIT!");
  const tokens = [];
  const points = Array.from(pattern.toLowerCase());
  for (let i = 0; i < points.length; i++) {
    const c = points[i];
    if (c === "~" && i + 1 < points.length && "*?~".includes(points[i + 1]))
      tokens.push({ kind: "literal", value: points[++i] });
    else if (c === "*" && tokens.at(-1)?.kind === "star") continue;
    else
      tokens.push(
        c === "*" ? { kind: "star" } : c === "?" ? { kind: "one" } : { kind: "literal", value: c }
      );
  }
  return (text) => {
    work.remaining -= text.length;
    if (work.remaining < 0) fail("#LIMIT!");
    text = text.toLowerCase();
    let at = 0, token = 0, star = -1, retry = 0;
    const next = (index) => index + (text.codePointAt(index) > 65535 ? 2 : 1);
    while (at < text.length) {
      if (--work.remaining < 0) fail("#LIMIT!");
      const t = tokens[token];
      if (t?.kind === "star") {
        star = token++;
        retry = at;
      } else if (t && (t.kind === "one" || t.value === text.slice(at, next(at)))) {
        at = next(at);
        token++;
      } else if (star >= 0 && retry < text.length) {
        retry = next(retry);
        at = retry;
        token = star + 1;
      } else return false;
    }
    while (tokens[token]?.kind === "star") token++;
    return token === tokens.length;
  };
}
export function criterion(input, work = { remaining: 1e6 }) {
  checked(input);
  let op = "=", target = input === null ? 0 : input;
  if (typeof target === "string") {
    if (target.length > 32767) fail("#LIMIT!");
    work.remaining -= target.length;
    if (work.remaining < 0) fail("#LIMIT!");
    const match = /^(<=|>=|<>|=|<|>)(.*)$/s.exec(target);
    if (match) {
      op = match[1];
      target = match[2];
    }
    if (numeric(target)) target = Number(target);
  }
  const textTarget = typeof target === "string" ? target.toLowerCase() : void 0;
  const pattern = textTarget !== void 0 && /[?*~]/.test(textTarget) && (op === "=" || op === "<>") ? wildcard(textTarget, work) : void 0;
  return (value) => {
    if (value && typeof value === "object") {
      if (value.error === "#LIMIT!" || value.error === "#CYCLE!") return fail(value.error);
      if (textTarget?.startsWith("#") && (op === "=" || op === "<>"))
        return op === "=" ? value.error.toLowerCase() === textTarget : value.error.toLowerCase() !== textTarget;
      return false;
    }
    if (typeof value === "string" && typeof target !== "boolean" && !pattern) {
      work.remaining -= value.length;
      if (work.remaining < 0) fail("#LIMIT!");
    }
    let comparison;
    if (typeof target === "number") {
      const v = value === null ? 0 : typeof value === "string" && numeric(value) ? Number(value) : value;
      if (typeof v !== "number") return op === "<>";
      comparison = v === target ? 0 : v < target ? -1 : 1;
    } else if (typeof target === "boolean") {
      if (typeof value !== "boolean") return op === "<>";
      comparison = Number(value) - Number(target);
    } else {
      if (pattern) {
        const matches = typeof value === "string" && pattern(value);
        return op === "=" ? matches : !matches;
      }
      const v = value === null ? "" : value;
      if (typeof v !== "string") return op === "<>";
      const lower = v.toLowerCase();
      comparison = lower === textTarget ? 0 : lower < textTarget ? -1 : 1;
    }
    return op === "=" ? comparison === 0 : op === "<>" ? comparison !== 0 : op === "<" ? comparison < 0 : op === ">" ? comparison > 0 : op === "<=" ? comparison <= 0 : comparison >= 0;
  };
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNyaXRlcmlhLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNoZWNrZWQgfSBmcm9tICcuL2NvZXJjaW9uLmpzJztcbmltcG9ydCB7IGZhaWwgfSBmcm9tICcuL2Vycm9ycy5qcyc7XG5pbXBvcnQgdHlwZSB7IEZvcm11bGFWYWx1ZSB9IGZyb20gJy4vdHlwZXMuanMnO1xuXG5jb25zdCBudW1lcmljID0gKHZhbHVlOiBzdHJpbmcpID0+XG4gIC9eWystXT8oPzpcXGQrKD86XFwuXFxkKik/fFxcLlxcZCspKD86ZVsrLV0/XFxkKyk/JC9pLnRlc3QodmFsdWUudHJpbSgpKSAmJlxuICBOdW1iZXIuaXNGaW5pdGUoTnVtYmVyKHZhbHVlKSk7XG50eXBlIFRva2VuID0geyBraW5kOiAnc3RhcicgfCAnb25lJyB8ICdsaXRlcmFsJzsgdmFsdWU/OiBzdHJpbmcgfTtcbmV4cG9ydCBmdW5jdGlvbiB3aWxkY2FyZChwYXR0ZXJuOiBzdHJpbmcsIHdvcmsgPSB7IHJlbWFpbmluZzogMV8wMDBfMDAwIH0pIHtcbiAgaWYgKHBhdHRlcm4ubGVuZ3RoID4gMzI3NjcpIGZhaWwoJyNMSU1JVCEnKTtcbiAgd29yay5yZW1haW5pbmcgLT0gcGF0dGVybi5sZW5ndGg7XG4gIGlmICh3b3JrLnJlbWFpbmluZyA8IDApIGZhaWwoJyNMSU1JVCEnKTtcbiAgY29uc3QgdG9rZW5zOiBUb2tlbltdID0gW107XG4gIGNvbnN0IHBvaW50cyA9IEFycmF5LmZyb20ocGF0dGVybi50b0xvd2VyQ2FzZSgpKTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBwb2ludHMubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCBjID0gcG9pbnRzW2ldO1xuICAgIGlmIChjID09PSAnficgJiYgaSArIDEgPCBwb2ludHMubGVuZ3RoICYmICcqP34nLmluY2x1ZGVzKHBvaW50c1tpICsgMV0pKVxuICAgICAgdG9rZW5zLnB1c2goeyBraW5kOiAnbGl0ZXJhbCcsIHZhbHVlOiBwb2ludHNbKytpXSB9KTtcbiAgICBlbHNlIGlmIChjID09PSAnKicgJiYgdG9rZW5zLmF0KC0xKT8ua2luZCA9PT0gJ3N0YXInKSBjb250aW51ZTtcbiAgICBlbHNlXG4gICAgICB0b2tlbnMucHVzaChcbiAgICAgICAgYyA9PT0gJyonID8geyBraW5kOiAnc3RhcicgfSA6IGMgPT09ICc/JyA/IHsga2luZDogJ29uZScgfSA6IHsga2luZDogJ2xpdGVyYWwnLCB2YWx1ZTogYyB9LFxuICAgICAgKTtcbiAgfVxuICByZXR1cm4gKHRleHQ6IHN0cmluZykgPT4ge1xuICAgIHdvcmsucmVtYWluaW5nIC09IHRleHQubGVuZ3RoO1xuICAgIGlmICh3b3JrLnJlbWFpbmluZyA8IDApIGZhaWwoJyNMSU1JVCEnKTtcbiAgICB0ZXh0ID0gdGV4dC50b0xvd2VyQ2FzZSgpO1xuICAgIGxldCBhdCA9IDAsXG4gICAgICB0b2tlbiA9IDAsXG4gICAgICBzdGFyID0gLTEsXG4gICAgICByZXRyeSA9IDA7XG4gICAgY29uc3QgbmV4dCA9IChpbmRleDogbnVtYmVyKSA9PiBpbmRleCArICh0ZXh0LmNvZGVQb2ludEF0KGluZGV4KSEgPiAweGZmZmYgPyAyIDogMSk7XG4gICAgd2hpbGUgKGF0IDwgdGV4dC5sZW5ndGgpIHtcbiAgICAgIGlmICgtLXdvcmsucmVtYWluaW5nIDwgMCkgZmFpbCgnI0xJTUlUIScpO1xuICAgICAgY29uc3QgdCA9IHRva2Vuc1t0b2tlbl07XG4gICAgICBpZiAodD8ua2luZCA9PT0gJ3N0YXInKSB7XG4gICAgICAgIHN0YXIgPSB0b2tlbisrO1xuICAgICAgICByZXRyeSA9IGF0O1xuICAgICAgfSBlbHNlIGlmICh0ICYmICh0LmtpbmQgPT09ICdvbmUnIHx8IHQudmFsdWUgPT09IHRleHQuc2xpY2UoYXQsIG5leHQoYXQpKSkpIHtcbiAgICAgICAgYXQgPSBuZXh0KGF0KTtcbiAgICAgICAgdG9rZW4rKztcbiAgICAgIH0gZWxzZSBpZiAoc3RhciA+PSAwICYmIHJldHJ5IDwgdGV4dC5sZW5ndGgpIHtcbiAgICAgICAgcmV0cnkgPSBuZXh0KHJldHJ5KTtcbiAgICAgICAgYXQgPSByZXRyeTtcbiAgICAgICAgdG9rZW4gPSBzdGFyICsgMTtcbiAgICAgIH0gZWxzZSByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHdoaWxlICh0b2tlbnNbdG9rZW5dPy5raW5kID09PSAnc3RhcicpIHRva2VuKys7XG4gICAgcmV0dXJuIHRva2VuID09PSB0b2tlbnMubGVuZ3RoO1xuICB9O1xufVxuXG4vKiogQ29tcGlsZSBvbmNlIHBlciBjcml0ZXJpb24sIG5ldmVyIGJ1aWxkIGFuIHVudHJ1c3RlZCBiYWNrdHJhY2tpbmcgcmVndWxhciBleHByZXNzaW9uLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNyaXRlcmlvbihcbiAgaW5wdXQ6IEZvcm11bGFWYWx1ZSxcbiAgd29yayA9IHsgcmVtYWluaW5nOiAxXzAwMF8wMDAgfSxcbik6ICh2YWx1ZTogRm9ybXVsYVZhbHVlKSA9PiBib29sZWFuIHtcbiAgY2hlY2tlZChpbnB1dCk7XG4gIGxldCBvcCA9ICc9JyxcbiAgICB0YXJnZXQ6IHN0cmluZyB8IG51bWJlciB8IGJvb2xlYW4gPSBpbnB1dCA9PT0gbnVsbCA/IDAgOiAoaW5wdXQgYXMgc3RyaW5nIHwgbnVtYmVyIHwgYm9vbGVhbik7XG4gIGlmICh0eXBlb2YgdGFyZ2V0ID09PSAnc3RyaW5nJykge1xuICAgIGlmICh0YXJnZXQubGVuZ3RoID4gMzI3NjcpIGZhaWwoJyNMSU1JVCEnKTtcbiAgICB3b3JrLnJlbWFpbmluZyAtPSB0YXJnZXQubGVuZ3RoO1xuICAgIGlmICh3b3JrLnJlbWFpbmluZyA8IDApIGZhaWwoJyNMSU1JVCEnKTtcbiAgICBjb25zdCBtYXRjaCA9IC9eKDw9fD49fDw+fD18PHw+KSguKikkL3MuZXhlYyh0YXJnZXQpO1xuICAgIGlmIChtYXRjaCkge1xuICAgICAgb3AgPSBtYXRjaFsxXTtcbiAgICAgIHRhcmdldCA9IG1hdGNoWzJdO1xuICAgIH1cbiAgICBpZiAobnVtZXJpYyh0YXJnZXQpKSB0YXJnZXQgPSBOdW1iZXIodGFyZ2V0KTtcbiAgfVxuICBjb25zdCB0ZXh0VGFyZ2V0ID0gdHlwZW9mIHRhcmdldCA9PT0gJ3N0cmluZycgPyB0YXJnZXQudG9Mb3dlckNhc2UoKSA6IHVuZGVmaW5lZDtcbiAgY29uc3QgcGF0dGVybiA9XG4gICAgdGV4dFRhcmdldCAhPT0gdW5kZWZpbmVkICYmIC9bPyp+XS8udGVzdCh0ZXh0VGFyZ2V0KSAmJiAob3AgPT09ICc9JyB8fCBvcCA9PT0gJzw+JylcbiAgICAgID8gd2lsZGNhcmQodGV4dFRhcmdldCwgd29yaylcbiAgICAgIDogdW5kZWZpbmVkO1xuICByZXR1cm4gKHZhbHVlKSA9PiB7XG4gICAgaWYgKHZhbHVlICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcpIHtcbiAgICAgIGlmICh2YWx1ZS5lcnJvciA9PT0gJyNMSU1JVCEnIHx8IHZhbHVlLmVycm9yID09PSAnI0NZQ0xFIScpIHJldHVybiBmYWlsKHZhbHVlLmVycm9yKTtcbiAgICAgIGlmICh0ZXh0VGFyZ2V0Py5zdGFydHNXaXRoKCcjJykgJiYgKG9wID09PSAnPScgfHwgb3AgPT09ICc8PicpKVxuICAgICAgICByZXR1cm4gb3AgPT09ICc9J1xuICAgICAgICAgID8gdmFsdWUuZXJyb3IudG9Mb3dlckNhc2UoKSA9PT0gdGV4dFRhcmdldFxuICAgICAgICAgIDogdmFsdWUuZXJyb3IudG9Mb3dlckNhc2UoKSAhPT0gdGV4dFRhcmdldDtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgLy8gU3RyaW5nIG5vcm1hbGl6YXRpb24gYW5kIG51bWVyaWMgcGFyc2luZyB0b3VjaCB0aGUgd2hvbGUgaW5wdXQgZXZlbiB3aGVuXG4gICAgLy8gYSBjb21wYXJpc29uIG9yIHdpbGRjYXJkIG1hdGNoIGNhbiByZWplY3QgYWZ0ZXIgaXRzIGZpcnN0IGNoYXJhY3Rlci5cbiAgICBpZiAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJyAmJiB0eXBlb2YgdGFyZ2V0ICE9PSAnYm9vbGVhbicgJiYgIXBhdHRlcm4pIHtcbiAgICAgIHdvcmsucmVtYWluaW5nIC09IHZhbHVlLmxlbmd0aDtcbiAgICAgIGlmICh3b3JrLnJlbWFpbmluZyA8IDApIGZhaWwoJyNMSU1JVCEnKTtcbiAgICB9XG4gICAgbGV0IGNvbXBhcmlzb246IG51bWJlcjtcbiAgICBpZiAodHlwZW9mIHRhcmdldCA9PT0gJ251bWJlcicpIHtcbiAgICAgIGNvbnN0IHYgPVxuICAgICAgICB2YWx1ZSA9PT0gbnVsbCA/IDAgOiB0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnICYmIG51bWVyaWModmFsdWUpID8gTnVtYmVyKHZhbHVlKSA6IHZhbHVlO1xuICAgICAgaWYgKHR5cGVvZiB2ICE9PSAnbnVtYmVyJykgcmV0dXJuIG9wID09PSAnPD4nO1xuICAgICAgY29tcGFyaXNvbiA9IHYgPT09IHRhcmdldCA/IDAgOiB2IDwgdGFyZ2V0ID8gLTEgOiAxO1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIHRhcmdldCA9PT0gJ2Jvb2xlYW4nKSB7XG4gICAgICBpZiAodHlwZW9mIHZhbHVlICE9PSAnYm9vbGVhbicpIHJldHVybiBvcCA9PT0gJzw+JztcbiAgICAgIGNvbXBhcmlzb24gPSBOdW1iZXIodmFsdWUpIC0gTnVtYmVyKHRhcmdldCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmIChwYXR0ZXJuKSB7XG4gICAgICAgIGNvbnN0IG1hdGNoZXMgPSB0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnICYmIHBhdHRlcm4odmFsdWUpO1xuICAgICAgICByZXR1cm4gb3AgPT09ICc9JyA/IG1hdGNoZXMgOiAhbWF0Y2hlcztcbiAgICAgIH1cbiAgICAgIGNvbnN0IHYgPSB2YWx1ZSA9PT0gbnVsbCA/ICcnIDogdmFsdWU7XG4gICAgICBpZiAodHlwZW9mIHYgIT09ICdzdHJpbmcnKSByZXR1cm4gb3AgPT09ICc8Pic7XG4gICAgICBjb25zdCBsb3dlciA9IHYudG9Mb3dlckNhc2UoKTtcbiAgICAgIGNvbXBhcmlzb24gPSBsb3dlciA9PT0gdGV4dFRhcmdldCA/IDAgOiBsb3dlciA8IHRleHRUYXJnZXQhID8gLTEgOiAxO1xuICAgIH1cbiAgICByZXR1cm4gb3AgPT09ICc9J1xuICAgICAgPyBjb21wYXJpc29uID09PSAwXG4gICAgICA6IG9wID09PSAnPD4nXG4gICAgICAgID8gY29tcGFyaXNvbiAhPT0gMFxuICAgICAgICA6IG9wID09PSAnPCdcbiAgICAgICAgICA/IGNvbXBhcmlzb24gPCAwXG4gICAgICAgICAgOiBvcCA9PT0gJz4nXG4gICAgICAgICAgICA/IGNvbXBhcmlzb24gPiAwXG4gICAgICAgICAgICA6IG9wID09PSAnPD0nXG4gICAgICAgICAgICAgID8gY29tcGFyaXNvbiA8PSAwXG4gICAgICAgICAgICAgIDogY29tcGFyaXNvbiA+PSAwO1xuICB9O1xufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLGVBQWU7QUFDeEIsU0FBUyxZQUFZO0FBR3JCLE1BQU0sVUFBVSxDQUFDLFVBQ2YsZ0RBQWdELEtBQUssTUFBTSxLQUFLLENBQUMsS0FDakUsT0FBTyxTQUFTLE9BQU8sS0FBSyxDQUFDO0FBRXhCLGdCQUFTLFNBQVMsU0FBaUIsT0FBTyxFQUFFLFdBQVcsSUFBVSxHQUFHO0FBQ3pFLE1BQUksUUFBUSxTQUFTLE1BQU8sTUFBSyxTQUFTO0FBQzFDLE9BQUssYUFBYSxRQUFRO0FBQzFCLE1BQUksS0FBSyxZQUFZLEVBQUcsTUFBSyxTQUFTO0FBQ3RDLFFBQU0sU0FBa0IsQ0FBQztBQUN6QixRQUFNLFNBQVMsTUFBTSxLQUFLLFFBQVEsWUFBWSxDQUFDO0FBQy9DLFdBQVMsSUFBSSxHQUFHLElBQUksT0FBTyxRQUFRLEtBQUs7QUFDdEMsVUFBTSxJQUFJLE9BQU8sQ0FBQztBQUNsQixRQUFJLE1BQU0sT0FBTyxJQUFJLElBQUksT0FBTyxVQUFVLE1BQU0sU0FBUyxPQUFPLElBQUksQ0FBQyxDQUFDO0FBQ3BFLGFBQU8sS0FBSyxFQUFFLE1BQU0sV0FBVyxPQUFPLE9BQU8sRUFBRSxDQUFDLEVBQUUsQ0FBQztBQUFBLGFBQzVDLE1BQU0sT0FBTyxPQUFPLEdBQUcsRUFBRSxHQUFHLFNBQVMsT0FBUTtBQUFBO0FBRXBELGFBQU87QUFBQSxRQUNMLE1BQU0sTUFBTSxFQUFFLE1BQU0sT0FBTyxJQUFJLE1BQU0sTUFBTSxFQUFFLE1BQU0sTUFBTSxJQUFJLEVBQUUsTUFBTSxXQUFXLE9BQU8sRUFBRTtBQUFBLE1BQzNGO0FBQUEsRUFDSjtBQUNBLFNBQU8sQ0FBQyxTQUFpQjtBQUN2QixTQUFLLGFBQWEsS0FBSztBQUN2QixRQUFJLEtBQUssWUFBWSxFQUFHLE1BQUssU0FBUztBQUN0QyxXQUFPLEtBQUssWUFBWTtBQUN4QixRQUFJLEtBQUssR0FDUCxRQUFRLEdBQ1IsT0FBTyxJQUNQLFFBQVE7QUFDVixVQUFNLE9BQU8sQ0FBQyxVQUFrQixTQUFTLEtBQUssWUFBWSxLQUFLLElBQUssUUFBUyxJQUFJO0FBQ2pGLFdBQU8sS0FBSyxLQUFLLFFBQVE7QUFDdkIsVUFBSSxFQUFFLEtBQUssWUFBWSxFQUFHLE1BQUssU0FBUztBQUN4QyxZQUFNLElBQUksT0FBTyxLQUFLO0FBQ3RCLFVBQUksR0FBRyxTQUFTLFFBQVE7QUFDdEIsZUFBTztBQUNQLGdCQUFRO0FBQUEsTUFDVixXQUFXLE1BQU0sRUFBRSxTQUFTLFNBQVMsRUFBRSxVQUFVLEtBQUssTUFBTSxJQUFJLEtBQUssRUFBRSxDQUFDLElBQUk7QUFDMUUsYUFBSyxLQUFLLEVBQUU7QUFDWjtBQUFBLE1BQ0YsV0FBVyxRQUFRLEtBQUssUUFBUSxLQUFLLFFBQVE7QUFDM0MsZ0JBQVEsS0FBSyxLQUFLO0FBQ2xCLGFBQUs7QUFDTCxnQkFBUSxPQUFPO0FBQUEsTUFDakIsTUFBTyxRQUFPO0FBQUEsSUFDaEI7QUFDQSxXQUFPLE9BQU8sS0FBSyxHQUFHLFNBQVMsT0FBUTtBQUN2QyxXQUFPLFVBQVUsT0FBTztBQUFBLEVBQzFCO0FBQ0Y7QUFHTyxnQkFBUyxVQUNkLE9BQ0EsT0FBTyxFQUFFLFdBQVcsSUFBVSxHQUNJO0FBQ2xDLFVBQVEsS0FBSztBQUNiLE1BQUksS0FBSyxLQUNQLFNBQW9DLFVBQVUsT0FBTyxJQUFLO0FBQzVELE1BQUksT0FBTyxXQUFXLFVBQVU7QUFDOUIsUUFBSSxPQUFPLFNBQVMsTUFBTyxNQUFLLFNBQVM7QUFDekMsU0FBSyxhQUFhLE9BQU87QUFDekIsUUFBSSxLQUFLLFlBQVksRUFBRyxNQUFLLFNBQVM7QUFDdEMsVUFBTSxRQUFRLDBCQUEwQixLQUFLLE1BQU07QUFDbkQsUUFBSSxPQUFPO0FBQ1QsV0FBSyxNQUFNLENBQUM7QUFDWixlQUFTLE1BQU0sQ0FBQztBQUFBLElBQ2xCO0FBQ0EsUUFBSSxRQUFRLE1BQU0sRUFBRyxVQUFTLE9BQU8sTUFBTTtBQUFBLEVBQzdDO0FBQ0EsUUFBTSxhQUFhLE9BQU8sV0FBVyxXQUFXLE9BQU8sWUFBWSxJQUFJO0FBQ3ZFLFFBQU0sVUFDSixlQUFlLFVBQWEsUUFBUSxLQUFLLFVBQVUsTUFBTSxPQUFPLE9BQU8sT0FBTyxRQUMxRSxTQUFTLFlBQVksSUFBSSxJQUN6QjtBQUNOLFNBQU8sQ0FBQyxVQUFVO0FBQ2hCLFFBQUksU0FBUyxPQUFPLFVBQVUsVUFBVTtBQUN0QyxVQUFJLE1BQU0sVUFBVSxhQUFhLE1BQU0sVUFBVSxVQUFXLFFBQU8sS0FBSyxNQUFNLEtBQUs7QUFDbkYsVUFBSSxZQUFZLFdBQVcsR0FBRyxNQUFNLE9BQU8sT0FBTyxPQUFPO0FBQ3ZELGVBQU8sT0FBTyxNQUNWLE1BQU0sTUFBTSxZQUFZLE1BQU0sYUFDOUIsTUFBTSxNQUFNLFlBQVksTUFBTTtBQUNwQyxhQUFPO0FBQUEsSUFDVDtBQUdBLFFBQUksT0FBTyxVQUFVLFlBQVksT0FBTyxXQUFXLGFBQWEsQ0FBQyxTQUFTO0FBQ3hFLFdBQUssYUFBYSxNQUFNO0FBQ3hCLFVBQUksS0FBSyxZQUFZLEVBQUcsTUFBSyxTQUFTO0FBQUEsSUFDeEM7QUFDQSxRQUFJO0FBQ0osUUFBSSxPQUFPLFdBQVcsVUFBVTtBQUM5QixZQUFNLElBQ0osVUFBVSxPQUFPLElBQUksT0FBTyxVQUFVLFlBQVksUUFBUSxLQUFLLElBQUksT0FBTyxLQUFLLElBQUk7QUFDckYsVUFBSSxPQUFPLE1BQU0sU0FBVSxRQUFPLE9BQU87QUFDekMsbUJBQWEsTUFBTSxTQUFTLElBQUksSUFBSSxTQUFTLEtBQUs7QUFBQSxJQUNwRCxXQUFXLE9BQU8sV0FBVyxXQUFXO0FBQ3RDLFVBQUksT0FBTyxVQUFVLFVBQVcsUUFBTyxPQUFPO0FBQzlDLG1CQUFhLE9BQU8sS0FBSyxJQUFJLE9BQU8sTUFBTTtBQUFBLElBQzVDLE9BQU87QUFDTCxVQUFJLFNBQVM7QUFDWCxjQUFNLFVBQVUsT0FBTyxVQUFVLFlBQVksUUFBUSxLQUFLO0FBQzFELGVBQU8sT0FBTyxNQUFNLFVBQVUsQ0FBQztBQUFBLE1BQ2pDO0FBQ0EsWUFBTSxJQUFJLFVBQVUsT0FBTyxLQUFLO0FBQ2hDLFVBQUksT0FBTyxNQUFNLFNBQVUsUUFBTyxPQUFPO0FBQ3pDLFlBQU0sUUFBUSxFQUFFLFlBQVk7QUFDNUIsbUJBQWEsVUFBVSxhQUFhLElBQUksUUFBUSxhQUFjLEtBQUs7QUFBQSxJQUNyRTtBQUNBLFdBQU8sT0FBTyxNQUNWLGVBQWUsSUFDZixPQUFPLE9BQ0wsZUFBZSxJQUNmLE9BQU8sTUFDTCxhQUFhLElBQ2IsT0FBTyxNQUNMLGFBQWEsSUFDYixPQUFPLE9BQ0wsY0FBYyxJQUNkLGNBQWM7QUFBQSxFQUM1QjtBQUNGOyIsIm5hbWVzIjpbXX0=
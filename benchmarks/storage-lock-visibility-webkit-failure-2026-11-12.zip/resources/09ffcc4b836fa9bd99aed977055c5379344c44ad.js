import { matchesFilter } from "/@fs/Volumes/github/private/opensheet/packages/core/src/filter.ts";
import { yieldToTask } from "/@fs/Volumes/github/private/opensheet/packages/core/src/task-yield.ts";
import { validateSearchArguments } from "/@fs/Volumes/github/private/opensheet/packages/core/src/search-validation.ts";
import { validateNavigationArguments } from "/@fs/Volumes/github/private/opensheet/packages/core/src/navigation-validation.ts";
import { numericSeries } from "/@fs/Volumes/github/private/opensheet/packages/core/src/numeric-series.ts";
import { calendarSeries } from "/@fs/Volumes/github/private/opensheet/packages/core/src/calendar-series.ts";
import { createTileOffsetter, tileCell, validatePasteTile } from "/@fs/Volumes/github/private/opensheet/packages/core/src/paste-tile.ts";
import { compareSortKeys, sortColumns, sortKey } from "/@fs/Volumes/github/private/opensheet/packages/core/src/sort-values.ts";
import { AxisIndex } from "/@fs/Volumes/github/private/opensheet/packages/core/src/axis-index.ts";
import { overlay } from "/@fs/Volumes/github/private/opensheet/packages/core/src/copy-on-write.ts";
import { contains, intersects } from "/@fs/Volumes/github/private/opensheet/packages/core/src/address.ts";
import { parseFormula } from "/@fs/Volumes/github/private/opensheet/packages/formula/src/index.ts";
import { decodeBlock, encodeBlock } from "/@fs/Volumes/github/private/opensheet/packages/core/src/block-codec.ts";
import {
  decodeFileMetadata,
  encodeWorkbookFile,
  decodeFileCells,
  workbookFileSchema
} from "/@fs/Volumes/github/private/opensheet/packages/core/src/file-codec.ts";
import { crc32, gzipPage, unpackPage, readBinary } from "/@fs/Volumes/github/private/opensheet/packages/core/src/binary-file.ts";
import { decodeVerifiedBinaryPage } from "/@fs/Volumes/github/private/opensheet/packages/core/src/binary-verify.ts";
import { parseWorkbookJSON } from "/@fs/Volumes/github/private/opensheet/packages/core/src/json-stream.ts";
import { downgradeValidationMetadata } from "/@fs/Volumes/github/private/opensheet/packages/core/src/validation-file-migration.ts";
import { checkStagedValidation } from "/@fs/Volumes/github/private/opensheet/packages/core/src/validation-batch.ts";
import { validationCandidates } from "/@fs/Volumes/github/private/opensheet/packages/core/src/validation-candidates.ts";
import {
  conditionalViewportWithFormulas,
  validateConditionalRules
} from "/@fs/Volumes/github/private/opensheet/packages/core/src/conditional-format.ts";
import { abortable } from "/@fs/Volumes/github/private/opensheet/packages/core/src/verification-yield.ts";
import { AsyncCalculation } from "/@fs/Volumes/github/private/opensheet/packages/core/src/async-calculation.ts";
import { selectiveCopyCell } from "/@fs/Volumes/github/private/opensheet/packages/core/src/selective-copy.ts";
import { reduceCommand, validateCommand } from "/@fs/Volumes/github/private/opensheet/packages/core/src/commands.ts";
import {
  applyPastedCell,
  createCellFormulaTransformer,
  structuralRangeReferences,
  offsetCellFormula,
  structuralReferences,
  styleId
} from "/@fs/Volumes/github/private/opensheet/packages/core/src/commands/helpers.ts";
import { formatValue } from "/@fs/Volumes/github/private/opensheet/packages/core/src/format.ts";
import { checkBounds, validateJSONValue, validateSnapshot } from "/@fs/Volumes/github/private/opensheet/packages/core/src/model.ts";
import {
  BLOCK_ROWS,
  BLOCK_COLUMNS,
  ByteCache,
  encodedBytes,
  recordBytes
} from "/@fs/Volumes/github/private/opensheet/packages/core/src/storage.ts";
import {
  assert,
  LIMITS,
  OpenSheetError,
  key,
  uid,
  scalarValue
} from "/@fs/Volumes/github/private/opensheet/packages/core/src/types.ts";
function groupAxis(order, start, end, size) {
  const result = /* @__PURE__ */ new Map();
  for (let index = start; index < end; index++) {
    const id = order[index], group = Math.floor(id / size);
    let entries = result.get(group);
    if (!entries) result.set(group, entries = []);
    entries.push({ index, id });
  }
  return result;
}
function changesStyles(command) {
  return command.type === "core.cells.style" || (command.type === "core.cells.paste" || command.type === "core.cells.pasteTile") && command.payload.cells.some(
    (cell) => cell.style !== void 0
  );
}
const CONDITIONAL_READ_PAGE_BUDGET = 1024 * 1024;
const SEARCH_YIELD_TEXT_UNITS = 1024 * 1024;
const encodeMetadata = (metadata) => ({
  ...metadata,
  snapshot: encodeWorkbookFile(metadata.snapshot),
  styleIds: Object.keys(metadata.snapshot.styles)
});
export const blockAddress = (sheet, row, column) => `${sheet}/${Math.floor(row / BLOCK_ROWS)}/${Math.floor(column / BLOCK_COLUMNS)}`;
const prefixRange = (id) => IDBKeyRange.bound(`${id}/`, `${id}/￿`);
export class Engine {
  constructor(db, id, cacheBytes = 64 * 1024 * 1024, progress = () => {
  }) {
    this.db = db;
    this.id = id;
    this.progress = progress;
    const retryBytes = Math.min(2 * 1024 * 1024, Math.floor(cacheBytes / 16));
    this.seen = new ByteCache(retryBytes);
    const calculationBytes = Math.min(4 * 1024 * 1024, Math.floor(cacheBytes / 8));
    this.cache = new ByteCache(Math.max(0, cacheBytes - calculationBytes - retryBytes));
    this.calculator = new AsyncCalculation(
      (s, r, c) => this.cell(s, r, c),
      (name) => this.metadata.snapshot.sheets.find((s) => s.name.toLowerCase() === name.toLowerCase())?.id,
      calculationBytes,
      async (sheet, row, column) => {
        const sh = this.metadata.snapshot.sheets.find((s) => s.id === sheet);
        return (await this.block(
          blockAddress(
            sheet,
            this.metadata.snapshot.sheets.find((s) => s.id === sheet).rowOrder[row],
            this.metadata.snapshot.sheets.find((s) => s.id === sheet).columnOrder[column]
          )
        )).dependencies[key(sh.rowOrder[row], sh.columnOrder[column])];
      },
      () => this.metadata.snapshot.dateSystem
    );
  }
  db;
  id;
  progress;
  head;
  metadata;
  usedBytes = 0;
  allocations = [];
  allocated = /* @__PURE__ */ new Set();
  stagingBytes = 0;
  pins = /* @__PURE__ */ new Set();
  axes = /* @__PURE__ */ new WeakMap();
  axis(ids) {
    let index = this.axes.get(ids);
    if (!index) {
      index = new AxisIndex(ids);
      this.axes.set(ids, index);
    }
    return index;
  }
  indices = /* @__PURE__ */ new WeakMap();
  exportAddresses;
  searchResults = /* @__PURE__ */ new WeakMap();
  compressionQueue = /* @__PURE__ */ new Set();
  directoryEntries = /* @__PURE__ */ new Map();
  observedHeadSignature;
  changed = /* @__PURE__ */ new Set();
  references = /* @__PURE__ */ new Map();
  histories = /* @__PURE__ */ new Map();
  used = {};
  sizes = /* @__PURE__ */ new Map();
  cache;
  cancelled = false;
  importRead;
  poisoned = false;
  writer = false;
  release;
  calculator;
  seen;
  get isWriter() {
    return this.writer;
  }
  async lock() {
    try {
      if (typeof navigator !== "undefined" && navigator.locks?.request) {
        await new Promise((resolve, reject) => {
          void navigator.locks.request(
            `opensheet:${this.db.db.name}:${this.id}`,
            { ifAvailable: true },
            async (lock) => {
              this.writer = !!lock;
              resolve();
              if (lock)
                await new Promise((release) => {
                  this.release = release;
                });
            }
          ).catch(reject);
        });
      } else if (typeof window === "undefined" && typeof self === "undefined") this.writer = true;
      else
        throw new OpenSheetError(
          "WEB_LOCKS_UNAVAILABLE",
          "Web Locks is required for safe multi-tab editing; open this app over HTTPS or localhost in a supported browser"
        );
    } catch (error) {
      if (error?.name === "SecurityError")
        throw new OpenSheetError(
          "WEB_LOCKS_UNAVAILABLE",
          "Web Locks access was denied; open this app over HTTPS or localhost in a supported browser"
        );
      throw error;
    }
  }
  async tryAcquireWriteLock() {
    if (this.writer) return { writer: true, view: this.view() };
    await this.lock();
    if (!this.writer) return { writer: false };
    try {
      await this.reload();
      await this.recover();
      return { writer: true, view: this.view() };
    } catch (error) {
      this.release?.();
      this.release = void 0;
      this.writer = false;
      throw error;
    }
  }
  check() {
    assert(!this.cancelled, "ABORTED", "Operation cancelled");
  }
  begin() {
    assert(!this.poisoned, "WORKER_FAILED", "Reopen the workbook after an uncertain commit");
    this.cancelled = false;
  }
  cancel() {
    this.cancelled = true;
    this.importRead?.abort(new OpenSheetError("ABORTED", "Operation cancelled"));
  }
  async open(input, budget = 256 * 1024 * 1024, preserveOrphans = true) {
    assert(
      Number.isSafeInteger(budget) && budget > 0,
      "INVALID_ARGUMENT",
      "Storage budget must be a positive integer"
    );
    const snapshot = input && ("sheetOrder" in input ? input : decodeFileMetadata({
      ...input,
      sheets: input.sheets.map((s) => ({ ...s, blocks: [] }))
    }));
    await this.lock();
    if (!this.writer) {
      await this.loadReadOnly(true);
      return this.view();
    }
    const storedHead = await this.db.get("heads", this.id);
    const existing = storedHead ? await this.restoreHead(storedHead) : void 0;
    if (existing) {
      this.head = existing;
      this.metadata = await this.readMetadata(this.head.meta);
      assert(this.metadata, "CORRUPT_STORAGE", "Workbook metadata is missing");
      this.checkDirectorySheets();
      await this.filters(this.head, this.metadata);
      await this.recover();
    } else {
      assert(snapshot && this.writer, "INVALID_ARGUMENT", "Workbook does not exist or is locked");
      if (preserveOrphans) {
        const range = prefixRange(this.id);
        const [records, sizes, scratch] = await Promise.all([
          this.db.hasAny("records", range),
          this.db.hasAny("sizes", range),
          this.db.hasAny("scratch", range)
        ]);
        assert(
          !records && !sizes && !scratch,
          "CORRUPT_STORAGE",
          "Workbook head is missing but stored data remains; restore a backup"
        );
      }
      await this.db.write("records", [], [prefixRange(this.id)]);
      await this.db.write("scratch", [], [prefixRange(this.id)]);
      this.head = {
        meta: "",
        blocks: {},
        revision: snapshot.revision,
        past: [],
        future: [],
        historyBytes: 0,
        budget
      };
      this.usedBytes = recordBytes(this.id, this.storedHead(this.head));
      this.metadata = {
        snapshot: { ...snapshot, sheets: snapshot.sheets.map((s) => ({ ...s, cells: {} })) },
        filtered: {}
      };
      if (input && !("sheetOrder" in input)) await this.importJSON(input, budget);
      else await this.replace(snapshot, budget);
    }
    return this.view();
  }
  async liveIds(head = this.head) {
    const ids = /* @__PURE__ */ new Set([
      head.meta,
      ...Object.values(head.blocks).map((p) => p.id),
      ...Object.values(head.directory ?? {}),
      ...head.past,
      ...head.future
    ]);
    for (const id of [...head.past, ...head.future]) {
      const h = await this.readHistory(id);
      ids.add(h.before);
      ids.add(h.after);
      for (const [, a, b] of h.changes) {
        if (a) ids.add(a.id);
        if (b) ids.add(b.id);
      }
    }
    return ids;
  }
  async liveBytes() {
    let total = recordBytes(this.id, this.storedHead(this.head));
    const ids = [...await this.liveIds()];
    const sizes = await this.db.recordSizes(ids);
    ids.forEach((id, i) => {
      total += sizes[i] + recordBytes(id, sizes[i]);
    });
    return total;
  }
  retain(id, delta) {
    if (!id) return;
    const count = (this.references.get(id) ?? 0) + delta;
    assert(count >= 0, "CORRUPT_STORAGE", "Negative record reference count");
    if (count) this.references.set(id, count);
    else this.references.delete(id);
  }
  retainHistory(id, h, delta) {
    this.retain(id, delta);
    this.retain(h.before, delta);
    this.retain(h.after, delta);
    for (const [, a, b] of h.changes) {
      if (a) this.retain(a.id, delta);
      if (b) this.retain(b.id, delta);
    }
  }
  validPointer(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return false;
    const pointer = value;
    return Object.keys(pointer).every(
      (key2) => [
        "id",
        "bytes",
        "count",
        "endRow",
        "endColumn",
        "formulas",
        "styles",
        "rowMask",
        "columnMask"
      ].includes(key2)
    ) && typeof pointer.id === "string" && pointer.id.startsWith(`${this.id}/`) && Number.isSafeInteger(pointer.bytes) && pointer.bytes > 0 && Number.isInteger(pointer.count) && pointer.count >= 0 && pointer.count <= BLOCK_ROWS * BLOCK_COLUMNS && Number.isInteger(pointer.endRow) && pointer.endRow > 0 && pointer.endRow <= LIMITS.rows && Number.isInteger(pointer.endColumn) && pointer.endColumn > 0 && pointer.endColumn <= LIMITS.columns && (pointer.rowMask === void 0 || typeof pointer.rowMask === "string" && /^[\da-f]{1,16}$/i.test(pointer.rowMask)) && (pointer.columnMask === void 0 || Number.isInteger(pointer.columnMask) && pointer.columnMask >= 0 && pointer.columnMask <= 4294967295) && (pointer.formulas === void 0 || Array.isArray(pointer.formulas) && pointer.formulas.every((name) => typeof name === "string")) && (pointer.styles === void 0 || Array.isArray(pointer.styles) && pointer.styles.every((style) => typeof style === "string"));
  }
  async readHistory(id) {
    const history = await this.db.get("records", id);
    const owned = (value) => typeof value === "string" && value.startsWith(`${this.id}/`);
    const pointer = (value) => value === null || this.validPointer(value);
    const address = (value) => {
      if (typeof value !== "string") return false;
      const match = /^[\w-]+\/(0|[1-9]\d*)\/(0|[1-9]\d*)$/.exec(value);
      return !!match && Number(match[1]) <= Math.floor(4294967295 / BLOCK_ROWS) && Number(match[2]) <= Math.floor(4294967295 / BLOCK_COLUMNS);
    };
    assert(
      history && typeof history === "object" && !Array.isArray(history) && Object.keys(history).every(
        (key2) => ["before", "after", "changes", "bytes", "ranges"].includes(key2)
      ) && owned(history.before) && owned(history.after) && Number.isSafeInteger(history.bytes) && history.bytes >= 0 && history.bytes <= 32 * 1024 * 1024 && Array.isArray(history.changes) && history.changes.every(
        (change) => Array.isArray(change) && change.length === 3 && address(change[0]) && (change[1] !== null || change[2] !== null) && pointer(change[1]) && pointer(change[2])
      ) && new Set(history.changes.map((change) => change[0])).size === history.changes.length && Array.isArray(history.ranges) && history.ranges.every(
        (range) => range && typeof range === "object" && !Array.isArray(range) && Object.keys(range).every(
          (key2) => ["sheetId", "startRow", "endRow", "startColumn", "endColumn"].includes(key2)
        ) && typeof range.sheetId === "string" && Number.isInteger(range.startRow) && range.startRow >= 0 && Number.isInteger(range.endRow) && range.endRow > range.startRow && range.endRow <= LIMITS.rows && Number.isInteger(range.startColumn) && range.startColumn >= 0 && Number.isInteger(range.endColumn) && range.endColumn > range.startColumn && range.endColumn <= LIMITS.columns
      ),
      "CORRUPT_STORAGE",
      "Invalid workbook history; open with a compatible version or restore a backup"
    );
    return history;
  }
  async initializeReferences() {
    this.references.clear();
    this.histories.clear();
    this.retain(this.head.meta, 1);
    for (const id of Object.values(this.head.directory ?? {})) this.retain(id, 1);
    for (const p of Object.values(this.head.blocks)) this.retain(p.id, 1);
    let pastBytes = 0;
    const checkedMetadata = /* @__PURE__ */ new Set([this.head.meta]);
    for (const [index, id] of [...this.head.past, ...this.head.future].entries()) {
      const h = await this.readHistory(id);
      for (const metadataId of [h.before, h.after]) {
        if (checkedMetadata.has(metadataId)) continue;
        const { snapshot } = await this.readMetadataEnvelope(metadataId);
        assert(
          Array.isArray(snapshot.sheets) && snapshot.sheets.every(
            (sheet) => Array.isArray(sheet?.blocks) && sheet.blocks.length === 0
          ),
          "CORRUPT_STORAGE",
          "Invalid historical workbook metadata"
        );
        validateJSONValue(snapshot);
        assert(
          workbookFileSchema.safeParse(snapshot).success,
          "CORRUPT_STORAGE",
          "Invalid historical workbook metadata; open with a compatible version or restore a backup"
        );
        checkedMetadata.add(metadataId);
      }
      if (index < this.head.past.length) pastBytes += h.bytes;
      this.histories.set(id, h);
      this.retainHistory(id, h, 1);
    }
    assert(
      pastBytes === this.head.historyBytes,
      "CORRUPT_STORAGE",
      "Workbook history accounting differs; restore a backup"
    );
  }
  async recover() {
    await this.initializeReferences();
    for (const id of this.references.keys()) this.compressionQueue.add(id);
    const live = await this.liveIds();
    const liveList = [...live];
    const ledger = await this.db.recordSizes(liveList);
    this.usedBytes = recordBytes(this.id, this.storedHead(this.head));
    this.sizes.clear();
    liveList.forEach((id, i) => {
      const bytes = ledger[i] + recordBytes(id, ledger[i]);
      this.usedBytes += bytes;
      this.sizes.set(id, bytes);
    });
    for await (const batch of this.db.scan("sizes", prefixRange(this.id))) {
      for (const [, value] of batch)
        assert(
          Number.isSafeInteger(value) && value > 0,
          "CORRUPT_STORAGE",
          "Invalid storage ledger; restore a backup"
        );
    }
    for await (const batch of this.db.scanKeys("sizes", prefixRange(this.id))) {
      const dead = [];
      for (const k of batch) {
        const id = String(k);
        if (!live.has(id)) dead.push(id);
      }
      if (dead.length) await this.db.write("records", [], dead);
    }
    await this.db.write("scratch", [], [prefixRange(this.id)]);
  }
  async reload() {
    if (!this.writer) {
      await this.loadReadOnly(false);
      return this.view();
    }
    const storedHead = await this.db.get("heads", this.id);
    assert(storedHead, "CORRUPT_STORAGE", "Workbook head is missing; restore a backup");
    this.head = await this.restoreHead(storedHead);
    this.metadata = await this.readMetadata(this.head.meta);
    this.checkDirectorySheets();
    this.exportAddresses = void 0;
    this.cache.clear();
    this.calculator.clear();
    this.usedBytes = await this.liveBytes();
    await this.initializeReferences();
    this.used = {};
    return this.view();
  }
  async reloadIfChanged() {
    const current = await this.db.get("heads", this.id);
    assert(current, "CORRUPT_STORAGE", "Workbook head is missing; restore a backup");
    if (JSON.stringify(current) === this.observedHeadSignature) return void 0;
    return this.reload();
  }
  async headExists() {
    return await this.db.get("heads", this.id) !== void 0;
  }
  async loadReadOnly(deriveFilters) {
    const started = Date.now();
    for (let attempt = 0; attempt < 64; attempt++) {
      const stored = await this.db.get("heads", this.id);
      assert(stored, "CORRUPT_STORAGE", "Workbook head is missing; restore a backup");
      const signature = JSON.stringify(stored);
      let failed = false, failure;
      try {
        this.head = await this.restoreHead(stored);
        this.metadata = await this.readMetadata(this.head.meta);
        this.checkDirectorySheets();
        this.exportAddresses = void 0;
        this.cache.clear();
        this.calculator.clear();
        this.used = {};
        if (deriveFilters) await this.filters(this.head, this.metadata);
        this.usedBytes = await this.liveBytes();
        await this.initializeReferences();
      } catch (error) {
        failed = true;
        failure = error;
      }
      const current = await this.db.get("heads", this.id);
      if (JSON.stringify(current) !== signature) {
        if (attempt === 63 || Date.now() - started >= 5e3)
          throw new OpenSheetError(
            "REVISION_CONFLICT",
            "Workbook changed while opening; try again"
          );
        await new Promise((resolve) => setTimeout(resolve, 10));
        continue;
      }
      if (failed) throw failure;
      this.observedHeadSignature = signature;
      return;
    }
  }
  async allocate(value, budget = this.head.budget) {
    this.check();
    const id = `${this.id}/${uid("record")}`;
    const rawBytes = recordBytes(id, value);
    const bytes = rawBytes + recordBytes(id, rawBytes);
    assert(
      this.usedBytes + this.stagingBytes + bytes <= budget,
      "STORAGE_BUDGET",
      "Application storage budget exceeded (including staging and history)"
    );
    await this.db.write("records", [[id, value]]);
    this.usedBytes += bytes;
    this.sizes.set(id, bytes);
    this.allocations.push(id);
    this.allocated.add(id);
    return id;
  }
  async readMetadataEnvelope(id) {
    const stored = await this.db.get("records", id);
    assert(stored, "CORRUPT_STORAGE", "Workbook metadata is missing");
    assert(
      typeof stored === "object" && !Array.isArray(stored) && Object.keys(stored).every(
        (key2) => ["snapshot", "styleIds", "filtered", "importRevision"].includes(key2)
      ),
      "CORRUPT_STORAGE",
      "Unknown stored workbook metadata; open with a compatible version or restore a backup"
    );
    const version = stored.snapshot?.schemaVersion;
    assert(
      Number.isSafeInteger(version) && version > 0,
      "CORRUPT_STORAGE",
      "Invalid stored workbook schema"
    );
    assert(
      version === 3,
      "UNSUPPORTED_VERSION",
      `Stored workbook schema ${version} is unsupported; use a compatible version`
    );
    return stored;
  }
  async readMetadata(id) {
    const stored = await this.readMetadataEnvelope(id);
    const snapshot = decodeFileMetadata(stored.snapshot);
    assert(
      Array.isArray(stored.styleIds) && stored.styleIds.length === stored.snapshot.styles.length && new Set(stored.styleIds).size === stored.styleIds.length && stored.styleIds.every(
        (id2) => /^[-\w]+$/.test(id2) && !["__proto__", "prototype", "constructor"].includes(id2)
      ),
      "CORRUPT_STORAGE",
      "Invalid stored style identities"
    );
    snapshot.styles = Object.fromEntries(
      stored.styleIds.map((id2, i) => [id2, stored.snapshot.styles[i]])
    );
    const { styleIds, ...metadata } = stored;
    return { ...metadata, snapshot };
  }
  compareAddress(a, b) {
    const [sa, ra, ca] = a.split("/"), [sb, rb, cb] = b.split("/");
    return sa < sb ? -1 : sa > sb ? 1 : +ra - +rb || +ca - +cb;
  }
  exportIndex(revision, after, count = 32, sheetId) {
    assert(revision === this.head.revision, "REVISION_CONFLICT", "Workbook changed during export");
    assert(
      Number.isInteger(count) && count > 0 && count <= 64,
      "INVALID_ARGUMENT",
      "Invalid page batch"
    );
    const addresses = this.exportAddresses ??= Object.keys(this.head.blocks).sort(
      (a, b) => this.compareAddress(a, b)
    );
    let low = 0, high = addresses.length;
    const before = (address) => after ? this.compareAddress(address, after) <= 0 : sheetId ? address.split("/")[0] < sheetId : false;
    while (low < high) {
      const mid = low + high >>> 1;
      if (before(addresses[mid])) low = mid + 1;
      else high = mid;
    }
    const output = [];
    for (let i = low; i < addresses.length && output.length < count; i++) {
      const address = addresses[i];
      if (sheetId && !address.startsWith(`${sheetId}/`)) break;
      output.push(address);
    }
    return output;
  }
  exportStyles(revision) {
    assert(revision === this.head.revision, "REVISION_CONFLICT", "Workbook changed during export");
    const used = new Set(
      Object.values(this.head.blocks).flatMap((pointer) => pointer.styles ?? [])
    );
    return Object.keys(this.metadata.snapshot.styles).filter((id) => used.has(id));
  }
  async exportBlock(address, revision) {
    assert(revision === this.head.revision, "REVISION_CONFLICT", "Workbook changed during export");
    const pointer = this.head.blocks[address];
    assert(pointer, "INVALID_ARGUMENT", "Unknown export block");
    const encoded = await this.db.get("records", pointer.id);
    this.check();
    assert(encoded, "CORRUPT_STORAGE", "Export block is missing");
    assert(revision === this.head.revision, "REVISION_CONFLICT", "Workbook changed during export");
    return this.inflate(encoded);
  }
  async inflate(bytes) {
    if (bytes[0] !== 79 || bytes[1] !== 83 || bytes[2] !== 71) return bytes;
    assert(bytes.length >= 12 && bytes[3] === 3, "CORRUPT_STORAGE", "Invalid compressed page");
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const page = await unpackPage(bytes.subarray(12), 1, view.getUint32(4, true));
    assert(
      crc32(page) === view.getUint32(8, true),
      "CORRUPT_STORAGE",
      "Stored page checksum differs"
    );
    return page;
  }
  get hasPendingCompaction() {
    return this.compressionQueue.size > 0;
  }
  async compact(count = 8) {
    if (!this.writer) return;
    for (const id of [...this.compressionQueue].slice(0, count)) {
      this.compressionQueue.delete(id);
      if (!this.references.has(id)) continue;
      const bytes = await this.db.get("records", id);
      if (!(bytes instanceof Uint8Array) || bytes.length < 512 || bytes[2] !== 80) continue;
      const compressed = await gzipPage(bytes);
      if (compressed.codec === 0 || compressed.bytes.length + 12 > bytes.length * 0.9) continue;
      const record = new Uint8Array(compressed.bytes.length + 12), view = new DataView(record.buffer);
      record.set([79, 83, 71, 3]);
      view.setUint32(4, bytes.length, true);
      view.setUint32(8, crc32(bytes), true);
      record.set(compressed.bytes, 12);
      const raw = recordBytes(id, record), size = raw + recordBytes(id, raw), old = this.sizes.get(id);
      if (this.usedBytes + size > this.head.budget) continue;
      await this.db.write("records", [[id, record]]);
      this.sizes.set(id, size);
      this.usedBytes += size - old;
    }
    return {
      bytes: this.usedBytes,
      cacheBytes: this.cache.bytes + this.calculator.cacheBytes + this.seen.bytes
    };
  }
  async collect(candidates) {
    if (this.poisoned) return;
    const dead = [...new Set(candidates)].filter((id) => !this.references.has(id));
    if (dead.length) await this.db.write("records", [], dead);
    for (const id of dead) {
      this.usedBytes -= this.sizes.get(id) ?? 0;
      this.sizes.delete(id);
      this.cache.delete(id);
    }
  }
  async cleanup(candidates) {
    try {
      await this.collect(candidates);
    } catch {
    }
  }
  bucket(address) {
    let hash = 2166136261;
    for (const c of address) hash = Math.imul(hash ^ c.charCodeAt(0), 16777619);
    return String((hash >>> 0) % 256);
  }
  storedHead(head) {
    const { blocks, ...rest } = head;
    return { ...rest, directory: head.directory ?? {} };
  }
  checkDirectorySheets() {
    const sheetIds = new Set(this.metadata.snapshot.sheets.map((sheet) => sheet.id));
    assert(
      Object.keys(this.head.blocks).every((address) => sheetIds.has(address.split("/")[0])),
      "CORRUPT_STORAGE",
      "Block directory references an unknown sheet"
    );
  }
  async restoreHead(head) {
    assert(
      head && typeof head === "object" && !Array.isArray(head),
      "CORRUPT_STORAGE",
      "Invalid workbook head"
    );
    if (Object.hasOwn(head, "engineFormatVersion")) {
      assert(
        Number.isSafeInteger(head.engineFormatVersion) && head.engineFormatVersion > 0,
        "CORRUPT_STORAGE",
        "Invalid workbook engine format version"
      );
      assert(
        head.engineFormatVersion === 1,
        "UNSUPPORTED_VERSION",
        `Workbook engine format ${head.engineFormatVersion} is unsupported; use a compatible version`
      );
    }
    assert(
      Object.keys(head).every(
        (key2) => [
          "engineFormatVersion",
          "directory",
          "meta",
          "revision",
          "past",
          "future",
          "historyBytes",
          "budget"
        ].includes(key2)
      ),
      "CORRUPT_STORAGE",
      "Unknown workbook head fields; open with a compatible version or restore a backup"
    );
    const owned = (value) => typeof value === "string" && value.startsWith(`${this.id}/`);
    assert(
      owned(head.meta) && Number.isSafeInteger(head.revision) && head.revision >= 0 && Number.isSafeInteger(head.budget) && head.budget > 0 && Number.isSafeInteger(head.historyBytes) && head.historyBytes >= 0 && head.historyBytes <= 32 * 1024 * 1024 && Array.isArray(head.past) && Array.isArray(head.future) && head.past.length + head.future.length <= 100 && [...head.past, ...head.future].every(owned) && (/* @__PURE__ */ new Set([...head.past, ...head.future])).size === head.past.length + head.future.length,
      "CORRUPT_STORAGE",
      "Invalid workbook head history"
    );
    assert(
      head.directory && typeof head.directory === "object" && !Array.isArray(head.directory) && !Object.hasOwn(head, "blocks") && Object.entries(head.directory).every(
        ([bucket, id]) => /^(0|[1-9]\d*)$/.test(bucket) && Number(bucket) < 256 && typeof id === "string" && id.startsWith(`${this.id}/`)
      ),
      "CORRUPT_STORAGE",
      "Unsupported workbook database format"
    );
    const blocks = {};
    this.directoryEntries.clear();
    for (const [bucket, id] of Object.entries(head.directory)) {
      const entries = await this.db.get("records", id);
      assert(
        entries && typeof entries === "object" && !Array.isArray(entries),
        "CORRUPT_STORAGE",
        "Invalid block directory"
      );
      for (const [address, pointer] of Object.entries(entries)) {
        const match = /^([\w-]+)\/(0|[1-9]\d*)\/(0|[1-9]\d*)$/.exec(address);
        assert(
          match && Number(match[2]) <= Math.floor(4294967295 / BLOCK_ROWS) && Number(match[3]) <= Math.floor(4294967295 / BLOCK_COLUMNS) && this.bucket(address) === bucket && !Object.hasOwn(blocks, address) && this.validPointer(pointer),
          "CORRUPT_STORAGE",
          "Invalid block directory entry"
        );
      }
      this.directoryEntries.set(bucket, entries);
      Object.assign(blocks, entries);
    }
    return { ...head, blocks };
  }
  async publish(next, metadata, ranges) {
    this.check();
    const previousDirectory = this.head.directory ?? {};
    const directory = { ...previousDirectory }, dirty = /* @__PURE__ */ new Map();
    for (const address of this.changed) {
      const bucket = this.bucket(address);
      if (!dirty.has(bucket)) dirty.set(bucket, { ...this.directoryEntries.get(bucket) });
      const entries = dirty.get(bucket);
      if (next.blocks[address]) entries[address] = next.blocks[address];
      else delete entries[address];
    }
    const oldDirectoryIds = [];
    for (const [bucket, entries] of dirty) {
      if (directory[bucket]) oldDirectoryIds.push(directory[bucket]);
      if (Object.keys(entries).length)
        directory[bucket] = await this.allocate(entries, next.budget);
      else delete directory[bucket];
    }
    next.directory = directory;
    next.engineFormatVersion = 1;
    const bytes = this.usedBytes - recordBytes(this.id, this.storedHead(this.head)) + recordBytes(this.id, this.storedHead(next));
    assert(bytes <= next.budget, "STORAGE_BUDGET", "Application storage budget exceeded");
    this.check();
    await this.db.write("heads", [[this.id, this.storedHead(next)]]);
    try {
      const old = this.head;
      if ([...this.changed].some((a) => !!old.blocks[a] !== !!next.blocks[a]))
        this.exportAddresses = void 0;
      for (const id of Object.values(directory))
        if (!Object.values(previousDirectory).includes(id)) this.retain(id, 1);
      for (const id of oldDirectoryIds) this.retain(id, -1);
      for (const [bucket, entries] of dirty) {
        if (Object.keys(entries).length) this.directoryEntries.set(bucket, entries);
        else this.directoryEntries.delete(bucket);
      }
      const full = next.blocks !== old.blocks && !this.changed.size;
      if (full) {
        for (const p of Object.values(next.blocks)) this.retain(p.id, 1);
        for (const p of Object.values(old.blocks)) this.retain(p.id, -1);
      } else
        for (const address of this.changed) {
          const a = old.blocks[address], b = next.blocks[address];
          if (a?.id === b?.id) continue;
          if (b) this.retain(b.id, 1);
          if (a) this.retain(a.id, -1);
        }
      if (next.meta !== old.meta) {
        this.retain(next.meta, 1);
        this.retain(old.meta, -1);
      }
      const oldHistory = /* @__PURE__ */ new Set([...old.past, ...old.future]), newHistory = /* @__PURE__ */ new Set([...next.past, ...next.future]);
      for (const id of newHistory)
        if (!oldHistory.has(id)) {
          const h = this.histories.get(id) ?? await this.readHistory(id);
          assert(h, "CORRUPT_STORAGE", "Missing new history");
          this.histories.set(id, h);
          this.retainHistory(id, h, 1);
        }
      for (const id of oldHistory)
        if (!newHistory.has(id)) {
          const h = this.histories.get(id);
          this.retainHistory(id, h, -1);
          this.histories.delete(id);
        }
      const priorSheets = new Map(this.metadata.snapshot.sheets.map((sh) => [sh.id, sh]));
      this.head = next;
      this.metadata = metadata;
      if (old.meta !== next.meta) {
        for (const sh of metadata.snapshot.sheets) {
          const prior = priorSheets.get(sh.id);
          if (!prior || prior.merges !== sh.merges || prior.rowOrder.length !== sh.rowOrder.length || prior.columnOrder.length !== sh.columnOrder.length || prior.rowOrder.some((id, i) => id !== sh.rowOrder[i]) || prior.columnOrder.some((id, i) => id !== sh.columnOrder[i]))
            delete this.used[sh.id];
        }
      }
      for (const a of this.changed)
        if (old.blocks[a]?.rowMask !== next.blocks[a]?.rowMask || old.blocks[a]?.columnMask !== next.blocks[a]?.columnMask)
          delete this.used[a.split("/")[0]];
      this.usedBytes = bytes;
      if (ranges) this.calculator.invalidate(ranges);
      else this.calculator.clear();
      await this.cleanup(oldDirectoryIds);
    } catch {
      this.poisoned = true;
      throw new OpenSheetError("WORKER_FAILED", "Commit may have succeeded; reopen the workbook");
    }
  }
  view() {
    const used = this.used;
    for (const s of this.metadata.snapshot.sheets) {
      if (used[s.id]) continue;
      let endRow = 1, endColumn = 1;
      const rows = this.axis(s.rowOrder), cols = this.axis(s.columnOrder);
      for (const [address, p] of Object.entries(this.head.blocks))
        if (address.startsWith(`${s.id}/`)) {
          const [, br, bc] = address.split("/"), mask = BigInt("0x" + (p.rowMask ?? "0"));
          for (let i = 0; i < 64; i++)
            if (mask & 1n << BigInt(i))
              endRow = Math.max(endRow, (rows.get(+br * 64 + i) ?? -1) + 1);
          for (let i = 0; i < 32; i++)
            if ((p.columnMask ?? 0) & 1 << i)
              endColumn = Math.max(endColumn, (cols.get(+bc * 32 + i) ?? -1) + 1);
        }
      for (const m of s.merges) {
        endRow = Math.max(endRow, m.endRow);
        endColumn = Math.max(endColumn, m.endColumn);
      }
      used[s.id] = { startRow: 0, startColumn: 0, endRow, endColumn };
    }
    return {
      snapshot: { ...this.metadata.snapshot, revision: this.head.revision },
      metadataId: this.head.meta,
      revision: this.head.revision,
      importRevision: this.metadata.importRevision,
      filtered: this.metadata.filtered,
      used,
      canUndo: !!this.head.past.length,
      canRedo: !!this.head.future.length,
      bytes: this.usedBytes,
      cacheBytes: this.cache.bytes + this.calculator.cacheBytes + this.seen.bytes,
      budget: this.head.budget
    };
  }
  async block(address, head = this.head, timing) {
    const p = head.blocks[address];
    if (!p) {
      if (timing) timing.absentPages++;
      return decodeBlock(encodeBlock({}, [], [], {}));
    }
    const cached = this.cache.get(p.id);
    if (cached) {
      if (timing) timing.cacheHits++;
      return cached;
    }
    if (timing) timing.cacheMisses++;
    let started = timing ? performance.now() : 0;
    const encoded = await this.db.get("records", p.id);
    if (timing) {
      timing.storageMs += performance.now() - started;
      started = performance.now();
    }
    assert(encoded, "CORRUPT_STORAGE", "Data block is missing");
    const inflated = await this.inflate(encoded);
    if (timing) {
      const now = performance.now();
      timing.inflateMs += now - started;
      started = now;
    }
    const block = decodeBlock(inflated);
    if (timing) {
      const duration = performance.now() - started;
      timing.pageDecodeMs += duration;
      timing.decodeMs = timing.inflateMs + timing.pageDecodeMs;
    }
    this.cache.set(p.id, block, block.bytes);
    return block;
  }
  async cell(sheet, row, column) {
    return this.stagedCell(sheet, row, column, this.head, this.metadata);
  }
  async stagedCell(sheet, row, column, head, metadata, local) {
    this.check();
    const sh = metadata.snapshot.sheets.find((s) => s.id === sheet);
    if (!sh || row < 0 || column < 0 || row >= sh.rowOrder.length || column >= sh.columnOrder.length)
      return { rowId: 0, columnId: 0, input: { type: "error", code: "#REF!" } };
    const address = blockAddress(sheet, sh.rowOrder[row], sh.columnOrder[column]);
    let page = local?.address === address ? local.page : void 0;
    if (!page) {
      page = await this.block(address, head);
      if (local) {
        local.address = page.bytes <= CONDITIONAL_READ_PAGE_BUDGET ? address : void 0;
        local.page = page.bytes <= CONDITIONAL_READ_PAGE_BUDGET ? page : void 0;
      }
    }
    return page.cell(sh.rowOrder[row] % 64 * 32 + sh.columnOrder[column] % 32);
  }
  /** Internal bridge; caller must keep head and metadata immutable until validation returns. */
  async validateStagedCells(head, metadata, sheetId, rules, positions, signal) {
    this.check();
    signal?.throwIfAborted();
    const sheet = metadata.snapshot.sheets.find((candidate) => candidate.id === sheetId);
    assert(sheet, "INVALID_ARGUMENT", "Unknown validation sheet");
    const calculator = new AsyncCalculation(
      (id, row, column) => this.stagedCell(id, row, column, head, metadata),
      (name) => metadata.snapshot.sheets.find(
        (candidate) => candidate.name.toLowerCase() === name.toLowerCase()
      )?.id,
      this.calculator.cacheBudget,
      void 0,
      () => metadata.snapshot.dateSystem
    );
    const reader = calculator.validationSession(signal).forSheet(sheetId);
    const report = await checkStagedValidation(
      rules,
      positions,
      reader.read,
      signal,
      reader.evaluateFormula,
      { rows: sheet.rowOrder.length, columns: sheet.columnOrder.length }
    );
    this.check();
    signal?.throwIfAborted();
    return report;
  }
  /** Internal bridge for directly edited ranges; formula dependents require separate enumeration. */
  async validateStagedRanges(head, metadata, sheetId, rules, ranges, signal) {
    this.check();
    const sheet = metadata.snapshot.sheets.find((candidate) => candidate.id === sheetId);
    assert(sheet, "INVALID_ARGUMENT", "Unknown validation sheet");
    const selected = await validationCandidates(
      rules,
      ranges,
      { rows: sheet.rowOrder.length, columns: sheet.columnOrder.length },
      signal
    );
    this.check();
    return this.validateStagedCells(
      head,
      metadata,
      sheetId,
      selected.rules,
      selected.positions,
      signal
    );
  }
  /** Internal bridge; caller owns an immutable head and metadata until completion. */
  async conditionalStagedViewport(head, metadata, sheetId, rules, positions, signal) {
    this.check();
    signal?.throwIfAborted();
    const sheet = metadata.snapshot.sheets.find((candidate) => candidate.id === sheetId);
    assert(sheet, "INVALID_ARGUMENT", "Unknown conditional formatting sheet");
    const checked = validateConditionalRules(
      rules,
      sheet.rowOrder.length,
      sheet.columnOrder.length
    );
    assert(
      Array.isArray(positions) && positions.length <= 1e4 && positions.length * checked.length <= 1e6,
      "LIMIT_EXCEEDED",
      "Conditional formatting viewport exceeds work budget"
    );
    const snapshot = positions.map(({ row, column }) => {
      assert(
        Number.isInteger(row) && row >= 0 && row < sheet.rowOrder.length && Number.isInteger(column) && column >= 0 && column < sheet.columnOrder.length,
        "INVALID_ARGUMENT",
        "Conditional formatting cell is outside the sheet"
      );
      return { row, column };
    });
    let current;
    const scalarMemo = checked.some((rule) => rule.condition.kind === "formula") ? /* @__PURE__ */ new Map() : void 0;
    let reuseScalars = false;
    const calculator = new AsyncCalculation(
      (id, row, column) => {
        if (id === sheetId && current?.row === row && current.column === column)
          return Promise.resolve(current.cell);
        const address = row * LIMITS.columns + column;
        if (id === sheetId && reuseScalars && scalarMemo?.has(address))
          return Promise.resolve(scalarMemo.get(address));
        return this.stagedCell(id, row, column, head, metadata);
      },
      (name) => metadata.snapshot.sheets.find(
        (candidate) => candidate.name.toLowerCase() === name.toLowerCase()
      )?.id,
      this.calculator.cacheBudget,
      void 0,
      () => metadata.snapshot.dateSystem
    );
    const reader = calculator.validationSession(signal).forSheet(sheetId);
    const cells = [];
    const viewportPage = {};
    let valueText = 0;
    for (const { row, column } of snapshot) {
      this.check();
      signal?.throwIfAborted();
      const cell = await abortable(
        this.stagedCell(sheetId, row, column, head, metadata, viewportPage),
        signal
      );
      current = { row, column, cell };
      let value;
      try {
        value = await abortable(reader.read(row, column), signal);
      } finally {
        current = void 0;
      }
      signal?.throwIfAborted();
      assert(
        !(value && typeof value === "object" && value.error === "#LIMIT!"),
        "LIMIT_EXCEEDED",
        "Conditional formatting calculation exceeded its work budget"
      );
      if (typeof value === "string") {
        valueText += value.length;
        assert(
          valueText <= 1e7,
          "LIMIT_EXCEEDED",
          "Conditional formatting viewport exceeds text work budget"
        );
      }
      if (scalarMemo && (!cell || cell.input.type !== "formula"))
        scalarMemo.set(
          row * LIMITS.columns + column,
          cell ? { rowId: cell.rowId, columnId: cell.columnId, input: cell.input } : void 0
        );
      cells.push({
        row,
        column,
        value,
        base: cell?.styleId ? metadata.snapshot.styles[cell.styleId] ?? {} : {}
      });
    }
    reuseScalars = true;
    const result = await conditionalViewportWithFormulas(
      checked,
      cells,
      reader.evaluateFormula,
      signal
    );
    this.check();
    signal?.throwIfAborted();
    return result;
  }
  /** Find the next occupied-region boundary using stored inputs, not calculated display values. */
  async navigateData(sheetId, row, column, axis, direction) {
    validateNavigationArguments(sheetId, row, column, axis, direction);
    const sh = this.metadata.snapshot.sheets.find((s) => s.id === sheetId);
    assert(sh, "INVALID_ARGUMENT", "Unknown sheet");
    assert(
      row < sh.rowOrder.length && column < sh.columnOrder.length,
      "INVALID_ARGUMENT",
      "Invalid navigation position"
    );
    const head = this.head, revision = head.revision;
    const vertical = axis === "row", start = vertical ? row : column;
    const order = vertical ? sh.rowOrder : sh.columnOrder;
    const axisMeta = vertical ? sh.rows : sh.columns;
    const filtered = vertical ? new Set(this.metadata.filtered[sheetId] ?? []) : void 0;
    const intervals = sh.merges.filter(
      (m) => vertical ? column >= m.startColumn && column < m.endColumn : row >= m.startRow && row < m.endRow
    ).map((m) => ({
      start: vertical ? m.startRow : m.startColumn,
      end: vertical ? m.endRow : m.endColumn,
      row: m.startRow,
      column: m.startColumn
    })).sort((a, b) => a.start - b.start);
    const mergeAt = (index2) => {
      let lo = 0, hi = intervals.length;
      while (lo < hi) {
        const mid = lo + hi >>> 1;
        if (intervals[mid].start <= index2) lo = mid + 1;
        else hi = mid;
      }
      const merge = intervals[lo - 1];
      return merge && index2 < merge.end ? merge : void 0;
    };
    const visible = (index2) => !filtered?.has(index2) && !axisMeta[order[index2]]?.hidden && axisMeta[order[index2]]?.size !== 0;
    let cachedAddress = "", cachedPage;
    const occupied = (index2) => {
      const merge = mergeAt(index2), r = merge?.row ?? (vertical ? index2 : row), c = merge?.column ?? (vertical ? column : index2);
      const rowId = sh.rowOrder[r], columnId = sh.columnOrder[c], address = blockAddress(sheetId, rowId, columnId);
      if (!head.blocks[address]) return false;
      const isFilled = (page) => (page.cell(rowId % 64 * 32 + columnId % 32)?.input.type ?? "blank") !== "blank";
      if (address === cachedAddress) return isFilled(cachedPage);
      return this.block(address, head).then((page) => {
        cachedPage = page;
        cachedAddress = address;
        return isFilled(page);
      });
    };
    const first = occupied(start), initial = typeof first === "boolean" ? first : await first, startMerge = mergeAt(start);
    this.check();
    let index = startMerge ? direction > 0 ? startMerge.end : startMerge.start - 1 : start + direction;
    let last = start, phase = "first", checked = 0;
    while (index >= 0 && index < order.length) {
      this.check();
      if (++checked % 1024 === 0) {
        await yieldToTask();
        this.check();
      }
      if (!visible(index)) {
        index += direction;
        continue;
      }
      const current = occupied(index);
      const filled = typeof current === "boolean" ? current : await current;
      this.check();
      if (phase === "first") phase = initial && filled ? "occupied" : "search";
      if (phase === "occupied" && !filled) break;
      last = index;
      if (phase === "search" && filled) break;
      index += direction;
    }
    return { revision, row: vertical ? last : row, column: vertical ? column : last };
  }
  async read(sheetId, range, values = true, render = true, timing) {
    const sh = this.metadata.snapshot.sheets.find((s) => s.id === sheetId);
    assert(sh, "INVALID_ARGUMENT", "Unknown sheet");
    checkBounds(sh, range);
    assert(
      (range.endRow - range.startRow) * (range.endColumn - range.startColumn) <= 16384,
      "LIMIT_EXCEEDED",
      "Read ranges in batches of at most 16384 cells"
    );
    const cells = {}, calculated = {}, display = {};
    let loadedAddress;
    let loadedPage;
    let calculate;
    let visited = 0;
    for (let row = range.startRow; row < range.endRow; row++)
      for (let column = range.startColumn; column < range.endColumn; column++) {
        this.check();
        if (++visited % 1024 === 0) {
          await new Promise((resolve) => setTimeout(resolve, 0));
          this.check();
        }
        const rowId = sh.rowOrder[row], columnId = sh.columnOrder[column], k = key(rowId, columnId), address = blockAddress(sheetId, rowId, columnId);
        if (address !== loadedAddress) {
          loadedPage = await this.block(address, this.head, timing);
          loadedAddress = address;
        }
        const cell = loadedPage.cell(rowId % 64 * 32 + columnId % 32);
        if (cell) {
          cells[k] = cell;
          if (this.head.revision !== this.metadata.importRevision && cell.cached) {
            cells[k] = { ...cell };
            delete cells[k].cached;
          }
        }
        if (values) {
          const v = cell?.input.type === "formula" ? await (calculate ??= this.calculator.readSession(16 * 1024))(sheetId, row, column) : cell ? scalarValue(cell.input) : null;
          calculated[k] = v;
          if (render)
            display[k] = v && typeof v === "object" && cell?.cached && this.head.revision === this.metadata.importRevision ? formatValue(
              scalarValue(cell.cached),
              cell.numberFormat,
              this.metadata.snapshot.dateSystem
            ) + " †" : formatValue(
              v,
              cell?.numberFormat ?? this.metadata.snapshot.styles[cell?.styleId ?? ""]?.numberFormat,
              this.metadata.snapshot.dateSystem
            );
        }
      }
    return { sheetId, range, cells, calculated, display, revision: this.head.revision };
  }
  async readCells(sheetId, range, fields) {
    const values = fields.includes("value") || fields.includes("display");
    const data = await this.read(sheetId, range, values, fields.includes("display"));
    const sh = this.metadata.snapshot.sheets.find((s) => s.id === sheetId);
    const cells = [];
    for (let row = range.startRow; row < range.endRow; row++)
      for (let column = range.startColumn; column < range.endColumn; column++) {
        const k = key(sh.rowOrder[row], sh.columnOrder[column]), cell = data.cells[k];
        cells.push(this.selectCell(row, column, cell, fields, data.calculated[k], data.display[k]));
      }
    return { revision: this.head.revision, sheetId, range, cells };
  }
  selectCell(row, column, cell, fields, value, display) {
    const output = { row, column };
    for (const field of fields) {
      if (field === "input") output.input = cell?.input ?? { type: "blank" };
      else if (field === "value") output.value = value ?? null;
      else if (field === "display") output.display = display ?? "";
      else if (field === "style")
        output.style = cell?.styleId ? this.metadata.snapshot.styles[cell.styleId] : {};
      else if (field === "numberFormat")
        output.numberFormat = cell?.numberFormat ?? this.metadata.snapshot.styles[cell?.styleId ?? ""]?.numberFormat;
      else if (field === "note") output.note = cell?.note;
      else if (field === "link") output.link = cell?.link;
    }
    return output;
  }
  async scanCells(sheetId, options) {
    const sh = this.metadata.snapshot.sheets.find((s) => s.id === sheetId);
    assert(sh, "INVALID_ARGUMENT", "Unknown sheet");
    const revision = this.head.revision, limit = options.limit ?? 1024, fields = options.fields ?? ["input"];
    assert(
      Number.isInteger(limit) && limit > 0 && limit <= 2048,
      "INVALID_ARGUMENT",
      "Cell page limit must be 1..2048"
    );
    const cursor = options.cursor;
    if (cursor)
      assert(
        cursor.revision === revision && cursor.sheetId === sheetId,
        "REVISION_CONFLICT",
        "Cell cursor expired"
      );
    if (cursor)
      assert(
        Number.isInteger(cursor.offset) && cursor.offset >= 0 && !!this.head.blocks[cursor.address] && cursor.address.startsWith(`${sheetId}/`),
        "INVALID_ARGUMENT",
        "Invalid cell cursor"
      );
    const address = cursor?.address ?? this.exportIndex(revision, void 0, 1, sheetId)[0];
    if (!address) return { revision, cells: [] };
    const page = await this.block(address), source = Object.values(page.cells).sort(
      (a, b) => a.rowId - b.rowId || a.columnId - b.columnId
    ), start = cursor?.offset ?? 0;
    assert(start <= source.length, "INVALID_ARGUMENT", "Invalid cell cursor offset");
    const cells = [];
    for (const cell of source.slice(start, start + limit)) {
      this.check();
      const row = this.axis(sh.rowOrder).get(cell.rowId), column = this.axis(sh.columnOrder).get(cell.columnId);
      const value = fields.includes("value") || fields.includes("display") ? await this.calculator.value(sheetId, row, column) : void 0;
      cells.push(
        this.selectCell(
          row,
          column,
          cell,
          fields,
          value,
          fields.includes("display") ? formatValue(
            value && typeof value === "object" && cell.cached && this.head.revision === this.metadata.importRevision ? scalarValue(cell.cached) : value ?? null,
            cell.numberFormat ?? this.metadata.snapshot.styles[cell.styleId ?? ""]?.numberFormat,
            this.metadata.snapshot.dateSystem
          ) + (value && typeof value === "object" && cell.cached && this.head.revision === this.metadata.importRevision ? " †" : "") : void 0
        )
      );
    }
    const offset = start + cells.length, nextAddress = offset < source.length ? address : this.exportIndex(revision, address, 1, sheetId)[0];
    return {
      revision,
      cells,
      ...nextAddress ? {
        cursor: {
          revision,
          sheetId,
          address: nextAddress,
          offset: nextAddress === address ? offset : 0
        }
      } : {}
    };
  }
  async storeBlock(address, cells, head, metadata, warmCache = true) {
    const sheetId = address.split("/")[0], sh = metadata.snapshot.sheets.find((s) => s.id === sheetId);
    let index = this.indices.get(sh);
    if (!index) {
      index = {
        rows: this.axis(sh.rowOrder),
        cols: this.axis(sh.columnOrder)
      };
      this.indices.set(sh, index);
    }
    const { rows, cols } = index;
    this.changed.add(address);
    const previous = head.blocks[address];
    const discardPrevious = async () => {
      if (previous && this.allocated.has(previous.id) && !this.pins.has(previous.id)) {
        await this.db.write("records", [], [previous.id]);
        this.usedBytes -= this.sizes.get(previous.id) ?? 0;
        this.sizes.delete(previous.id);
        this.cache.delete(previous.id);
        this.allocated.delete(previous.id);
      }
    };
    const formulas = /* @__PURE__ */ new Set();
    const styles = /* @__PURE__ */ new Set();
    const visit = (node) => {
      if (node.kind === "ref") formulas.add(node.sheet ?? sh.name);
      else if (node.kind === "range") {
        formulas.add(node.start.sheet ?? sh.name);
        formulas.add(node.end.sheet ?? sh.name);
      } else if (node.kind === "unary") visit(node.value);
      else if (node.kind === "binary") {
        visit(node.left);
        visit(node.right);
      } else if (node.kind === "call") node.args.forEach(visit);
    };
    let retained = 0, rowLow = 0, rowHigh = 0, columnMask = 0, count = 0, endRow = 1, endColumn = 1;
    for (const [k, c] of Object.entries(cells)) {
      if (c.input.type === "blank" && c.styleId === void 0 && c.numberFormat === void 0 && c.link === void 0 && c.note === void 0) {
        delete cells[k];
        continue;
      }
      retained++;
      const rowBit = c.rowId % 64;
      if (rowBit < 32) rowLow |= 1 << rowBit;
      else rowHigh |= 1 << rowBit - 32;
      columnMask |= 1 << c.columnId % 32;
      if (c.styleId !== void 0) styles.add(c.styleId);
      if (c.input.type !== "blank") count++;
      endRow = Math.max(endRow, rows.get(c.rowId) + 1);
      endColumn = Math.max(endColumn, cols.get(c.columnId) + 1);
      if (c.input.type === "formula") {
        try {
          visit(parseFormula(c.input.expression));
        } catch {
          formulas.add("*");
        }
      }
    }
    if (!retained) {
      delete head.blocks[address];
      await discardPrevious();
      return;
    }
    const encoded = encodeBlock(cells, [], [], {});
    const id = await this.allocate(encoded, head.budget);
    this.compressionQueue.add(id);
    const low = (rowLow >>> 0).toString(16);
    head.blocks[address] = {
      id,
      bytes: this.sizes.get(id),
      count,
      endRow,
      endColumn,
      rowMask: rowHigh ? (rowHigh >>> 0).toString(16) + low.padStart(8, "0") : low,
      columnMask: columnMask >>> 0,
      ...formulas.size ? { formulas: [...formulas] } : {},
      ...styles.size ? { styles: [...styles] } : {}
    };
    if (warmCache) {
      const page = decodeBlock(encoded);
      this.cache.set(id, page, page.bytes);
    }
    await discardPrevious();
  }
  async replace(snapshot, budget = this.head.budget) {
    assert(this.writer, "READ_ONLY", "Workbook is open in another tab");
    this.cancelled = false;
    this.allocations = [];
    this.changed.clear();
    this.allocated.clear();
    this.pins.clear();
    const metadata = {
      importRevision: snapshot.revision,
      snapshot: validateSnapshot({
        ...snapshot,
        sheets: snapshot.sheets.map((s) => ({ ...s, cells: {} }))
      }),
      filtered: {}
    };
    const next = {
      meta: "",
      blocks: {},
      revision: snapshot.revision,
      past: [],
      future: [],
      historyBytes: 0,
      budget
    };
    const old = await this.liveIds();
    for (const address of Object.keys(this.head.blocks)) this.changed.add(address);
    try {
      for (const sh of snapshot.sheets) {
        const rows = new Map(sh.rowOrder.map((id, i) => [id, i])), cols = new Map(sh.columnOrder.map((id, i) => [id, i]));
        const grouped = /* @__PURE__ */ new Map();
        for (const [k, c] of Object.entries(sh.cells)) {
          const r = rows.get(c.rowId), col = cols.get(c.columnId);
          assert(
            r !== void 0 && col !== void 0 && k === key(c.rowId, c.columnId),
            "INVALID_ARGUMENT",
            "Invalid cell identity"
          );
          const a = blockAddress(sh.id, c.rowId, c.columnId);
          if (!grouped.has(a)) grouped.set(a, {});
          grouped.get(a)[k] = c;
        }
        let n = 0;
        for (const [address, cells] of grouped) {
          validateSnapshot({
            ...metadata.snapshot,
            sheets: metadata.snapshot.sheets.map((s) => s.id === sh.id ? { ...s, cells } : s)
          });
          await this.storeBlock(address, cells, next, metadata);
          this.progress({ phase: "import", completed: ++n, total: grouped.size });
        }
      }
      await this.filters(next, metadata);
      next.meta = await this.allocate(encodeMetadata(metadata), budget);
      await this.publish(next, metadata);
      await this.cleanup([...old, ...this.allocations]);
      return this.view();
    } catch (error) {
      await this.cleanup(this.allocations);
      throw error;
    }
  }
  async importJSON(input, budget = this.head.budget) {
    return this.importStaged(input, budget);
  }
  /** Internal migration path. Public native import continues to reject schema 4. */
  async importRuleFreeValidationBackup(input, budget = this.head.budget) {
    assert(
      typeof input === "string" || input instanceof Blob || input instanceof ReadableStream,
      "INVALID_ARGUMENT",
      "Migration requires a JSON source"
    );
    return this.importStaged(input, budget, downgradeValidationMetadata);
  }
  async importStaged(input, budget, convertMetadata) {
    assert(this.writer, "READ_ONLY", "Workbook is open in another tab");
    this.check();
    this.allocations = [];
    this.changed.clear();
    this.allocated.clear();
    this.pins.clear();
    const old = await this.liveIds();
    this.check();
    for (const address of Object.keys(this.head.blocks)) this.changed.add(address);
    let file, binarySnapshot, staged = 0;
    const scratch = `${this.id}/import`;
    let scratchWriteMs = 0;
    const sourceStageStart = performance.now();
    const reader = new AbortController();
    this.importRead = reader;
    const stage = async (value, suffix = "") => {
      this.check();
      const record = [
        `${scratch}/${String(staged++).padStart(10, "0")}${suffix}`,
        value
      ];
      this.stagingBytes += recordBytes(record[0], record[1]);
      assert(
        this.usedBytes + this.stagingBytes <= budget,
        "STORAGE_BUDGET",
        "Import staging exceeds storage budget"
      );
      const writeStart = performance.now();
      await this.db.write("scratch", [record], [], reader.signal);
      scratchWriteMs += performance.now() - writeStart;
      this.progress({ phase: "import-parse", completed: staged });
    };
    try {
      if (input && typeof input === "object" && "binary" in input) {
        for await (const item of readBinary(
          input.binary,
          { signal: reader.signal }
        )) {
          if ("metadata" in item) {
            file = item.metadata;
            binarySnapshot = item.snapshot;
          } else {
            await stage(item.bytes, `/${item.sheet}/${item.row}/${item.column}`);
          }
        }
      } else if (typeof input === "string" || input instanceof Blob || input instanceof ReadableStream) {
        for await (const item of parseWorkbookJSON(input, { signal: reader.signal })) {
          if ("block" in item) await stage(item);
          else file = convertMetadata ? convertMetadata(item.metadata) : item.metadata;
        }
      } else {
        assert(input && Array.isArray(input.sheets), "INVALID_ARGUMENT", "Invalid workbook file");
        file = { ...input, sheets: input.sheets.map((sh) => ({ ...sh, blocks: [] })) };
        for (let i = 0; i < input.sheets.length; i++)
          for (const block of input.sheets[i].blocks) await stage({ sheet: i, block });
      }
      this.progress({
        phase: "import-source-stage",
        completed: staged,
        elapsedMs: performance.now() - sourceStageStart
      });
      this.progress({
        phase: "import-scratch-write",
        completed: staged,
        elapsedMs: scratchWriteMs
      });
      this.check();
      assert(file, "INVALID_ARGUMENT", "Missing workbook metadata");
      const snapshot = binarySnapshot ?? decodeFileMetadata(file);
      snapshot.workbookId = this.id;
      snapshot.revision = this.head.meta ? this.head.revision + 1 : file.revision;
      const metadata = { snapshot, importRevision: snapshot.revision, filtered: {} };
      const next = {
        meta: "",
        blocks: {},
        revision: snapshot.revision,
        past: [],
        future: [],
        historyBytes: 0,
        budget
      };
      const styles = Object.keys(snapshot.styles), styleSet = binarySnapshot ? new Set(styles) : void 0, rows = snapshot.sheets.map((sh) => new Set(sh.rowOrder)), columns = snapshot.sheets.map((sh) => new Set(sh.columnOrder));
      const warmCache = snapshot.sheets.some((sheet) => !!sheet.filter);
      let completed = 0;
      const seen = /* @__PURE__ */ new Set();
      const times = {
        "import-scratch-read": 0,
        "import-decode": 0,
        "import-pages": 0,
        "import-scratch-delete": 0
      };
      let previous = performance.now();
      for await (const batch of this.db.scan("scratch", prefixRange(scratch), 16, 1024 * 1024)) {
        const received = performance.now();
        times["import-scratch-read"] += received - previous;
        for (const [id, item] of batch) {
          const decoding = performance.now();
          this.check();
          const binary = item instanceof Uint8Array;
          const [sheet, row, column] = binary ? String(id).split("/").slice(-3).map(Number) : [item.sheet, item.block.row, item.block.column];
          assert(
            Number.isInteger(sheet) && !!snapshot.sheets[sheet] && binary === !!binarySnapshot,
            "INVALID_ARGUMENT",
            "Unknown imported sheet"
          );
          const sh = snapshot.sheets[sheet], address = `${sh.id}/${row}/${column}`;
          assert(!seen.has(address), "INVALID_ARGUMENT", "Duplicate imported block");
          seen.add(address);
          const cells = binary ? decodeVerifiedBinaryPage(item, row, column, rows[sheet], columns[sheet], styleSet) : decodeFileCells(item.block, styles, rows[sheet], columns[sheet]);
          const decoded = performance.now();
          times["import-decode"] += decoded - decoding;
          await this.storeBlock(address, cells, next, metadata, warmCache);
          const stored = performance.now();
          times["import-pages"] += stored - decoded;
          await this.db.write("scratch", [], [id]);
          times["import-scratch-delete"] += performance.now() - stored;
          this.stagingBytes -= recordBytes(id, item);
          this.progress({ phase: "import-store", completed: ++completed, total: staged });
        }
        previous = performance.now();
      }
      times["import-scratch-read"] += performance.now() - previous;
      for (const [phase, elapsedMs] of Object.entries(times))
        this.progress({ phase, elapsedMs, completed, total: staged });
      await this.filters(next, metadata);
      next.meta = await this.allocate(encodeMetadata(metadata), budget);
      await this.publish(next, metadata);
      await this.cleanup([...old, ...this.allocations]);
      return this.view();
    } catch (error) {
      await this.cleanup(this.allocations);
      throw error;
    } finally {
      this.importRead = void 0;
      try {
        await this.db.write("scratch", [], [prefixRange(scratch)]);
        this.stagingBytes = 0;
      } catch {
        this.poisoned = true;
      }
    }
  }
  importBinary(input) {
    return this.importJSON({ binary: input });
  }
  async generate(count, budget) {
    assert(this.writer, "READ_ONLY", "Workbook is open in another tab");
    assert(
      Number.isSafeInteger(count) && count > 0 && count <= 1e7,
      "INVALID_ARGUMENT",
      "Count exceeds the 100-column dimension boundary"
    );
    this.cancelled = false;
    this.allocations = [];
    this.changed.clear();
    this.allocated.clear();
    this.pins.clear();
    const metadata = structuredClone(this.metadata);
    const sh = metadata.snapshot.sheets[0];
    sh.rowOrder = Array.from({ length: Math.ceil(count / 100) }, (_, i) => i);
    sh.columnOrder = Array.from({ length: 100 }, (_, i) => i);
    sh.nextRowId = sh.rowOrder.length;
    sh.nextColumnId = sh.columnOrder.length;
    sh.cells = {};
    sh.rows = {};
    sh.columns = {};
    sh.merges = [];
    sh.freeze = { rows: 0, columns: 0 };
    sh.filter = null;
    metadata.snapshot.sheets = [sh];
    metadata.snapshot.sheetOrder = [sh.id];
    metadata.snapshot.styles = {};
    metadata.filtered = {};
    const next = {
      meta: "",
      blocks: {},
      revision: this.head.revision + 1,
      past: [],
      future: [],
      historyBytes: 0,
      budget
    };
    const old = await this.liveIds();
    for (const address of Object.keys(this.head.blocks)) this.changed.add(address);
    try {
      for (let r = 0; r < sh.rowOrder.length; r += BLOCK_ROWS)
        for (let c = 0; c < 100; c += BLOCK_COLUMNS) {
          const cells = {};
          for (let row = r; row < Math.min(r + BLOCK_ROWS, sh.rowOrder.length); row++)
            for (let column = c; column < Math.min(c + BLOCK_COLUMNS, 100); column++) {
              const n = row * 100 + column;
              if (n >= count) break;
              const v = fixtureValue(n);
              cells[key(sh.rowOrder[row], sh.columnOrder[column])] = {
                rowId: sh.rowOrder[row],
                columnId: sh.columnOrder[column],
                input: typeof v === "number" ? { type: "number", value: v } : typeof v === "boolean" ? { type: "boolean", value: v } : { type: "string", value: v }
              };
            }
          await this.storeBlock(blockAddress(sh.id, r, c), cells, next, metadata);
          this.progress({
            phase: "generate",
            completed: Math.min(count, (r + BLOCK_ROWS) * 100),
            total: count
          });
        }
      next.meta = await this.allocate(encodeMetadata(metadata), budget);
      await this.publish(next, metadata);
      await this.cleanup([...old, ...this.allocations]);
      return this.view();
    } catch (error) {
      await this.cleanup(this.allocations);
      throw error;
    }
  }
  async filters(head, metadata) {
    metadata.filtered = {};
    if (!metadata.snapshot.sheets.some((sheet) => sheet.filter)) return;
    this.calculator.clear();
    const calculator = new AsyncCalculation(
      (sheet, row, column) => this.stagedCell(sheet, row, column, head, metadata),
      (name) => metadata.snapshot.sheets.find((s) => s.name.toLowerCase() === name.toLowerCase())?.id,
      this.calculator.cacheBudget,
      void 0,
      () => metadata.snapshot.dateSystem
    );
    for (const sh of metadata.snapshot.sheets)
      if (sh.filter) {
        const hidden = [];
        const filter = sh.filter;
        const query = "column" in filter ? filter.query.toLowerCase() : void 0;
        const criteria = "criteria" in filter ? filter.criteria.map((criterion) => ({
          criterion,
          foldedQuery: "value" in criterion && typeof criterion.value === "string" ? criterion.value.toLowerCase() : void 0
        })) : [];
        try {
          const headerRows = "column" in filter ? 1 : filter.headerRows;
          for (let row = headerRows; row < sh.rowOrder.length; row++) {
            this.check();
            let matches;
            if ("column" in filter) {
              const c = await this.stagedCell(sh.id, row, filter.column, head, metadata);
              const value = await calculator.value(sh.id, row, filter.column);
              assert(
                !(value && typeof value === "object" && value.error === "#LIMIT!"),
                "LIMIT_EXCEEDED",
                "Filter calculation exceeded its work budget"
              );
              matches = formatValue(
                value,
                c?.numberFormat ?? metadata.snapshot.styles[c?.styleId ?? ""]?.numberFormat,
                metadata.snapshot.dateSystem
              ).toLowerCase().includes(query);
            } else {
              matches = filter.mode === "all";
              const values = /* @__PURE__ */ new Map();
              for (const { criterion, foldedQuery } of criteria) {
                if (!values.has(criterion.column)) {
                  const value = await calculator.value(sh.id, row, criterion.column);
                  assert(
                    !(value && typeof value === "object" && value.error === "#LIMIT!"),
                    "LIMIT_EXCEEDED",
                    "Filter calculation exceeded its work budget"
                  );
                  values.set(criterion.column, value);
                }
                const match = matchesFilter(values.get(criterion.column), criterion, foldedQuery);
                if (filter.mode === "all" ? !match : match) {
                  matches = match;
                  break;
                }
              }
            }
            if (!matches) hidden.push(row);
          }
        } finally {
          calculator.clear();
        }
        metadata.filtered[sh.id] = hidden;
      }
  }
  addresses(sh, range) {
    const rows = new Set(
      sh.rowOrder.slice(range.startRow, range.endRow).map((id) => Math.floor(id / BLOCK_ROWS))
    );
    const columns = new Set(
      sh.columnOrder.slice(range.startColumn, range.endColumn).map((id) => Math.floor(id / BLOCK_COLUMNS))
    );
    const out = [];
    for (const r of rows) for (const c of columns) out.push(`${sh.id}/${r}/${c}`);
    return out;
  }
  async applyLocal(command, head, metadata) {
    const p = command.payload, sh = metadata.snapshot.sheets.find((s) => s.id === p.sheetId);
    const traversalCells = (p.cells?.length ?? 0) + [p.range, p.target].reduce(
      (total, range) => total + (range ? (range.endRow - range.startRow) * (range.endColumn - range.startColumn) : 0),
      0
    );
    let expectedTextBytes = 0;
    if (command.type === "core.cells.set") {
      for (const item of p.cells) {
        const input = item.expected?.input;
        if (input?.type === "string") expectedTextBytes += input.value.length * 2;
        else if (input?.type === "formula") expectedTextBytes += input.expression.length * 2;
        else if (input?.type === "error") expectedTextBytes += input.code.length * 2;
      }
    }
    assert(
      traversalCells * 512 + expectedTextBytes <= 32 * 1024 * 1024,
      "LIMIT_EXCEEDED",
      "Command exceeds the 32 MiB traversal planning budget; use a streamed operation"
    );
    const addresses = /* @__PURE__ */ new Set();
    if (sh) {
      if (p.cells)
        for (const c of p.cells)
          addresses.add(blockAddress(sh.id, sh.rowOrder[c.row], sh.columnOrder[c.column]));
      for (const range of [p.range, p.target])
        if (range) {
          checkBounds(sh, range);
          for (const a of this.addresses(sh, range)) addresses.add(a);
        }
    }
    let bytes = 0;
    const snapshot = {
      ...metadata.snapshot,
      sheetOrder: [...metadata.snapshot.sheetOrder],
      styles: changesStyles(command) ? { ...metadata.snapshot.styles } : metadata.snapshot.styles,
      sheets: metadata.snapshot.sheets.map((s) => ({
        ...s,
        cells: {},
        rows: command.type === "core.axis.meta" || command.type === "core.axis.visibility" || command.type === "core.axis.visibilityAll" || command.type === "core.axis.resize" ? { ...s.rows } : s.rows,
        columns: command.type === "core.axis.meta" || command.type === "core.axis.visibility" || command.type === "core.axis.visibilityAll" || command.type === "core.axis.resize" ? { ...s.columns } : s.columns,
        merges: command.type === "core.cells.merge" ? s.merges.map((m) => ({ ...m })) : s.merges,
        freeze: s.freeze,
        filter: s.filter
      }))
    };
    const target = snapshot.sheets.find((s) => s.id === p.sheetId);
    const mergeDirty = command.type === "core.cells.merge" ? /* @__PURE__ */ new Set() : void 0;
    if (mergeDirty) assert(target, "INVALID_ARGUMENT", "Sheet no longer exists");
    const mergeRows = mergeDirty && new Set(target.rowOrder.slice(p.range.startRow, p.range.endRow));
    const mergeColumns = mergeDirty && new Set(target.columnOrder.slice(p.range.startColumn, p.range.endColumn));
    const mergeAnchorRow = mergeDirty && target.rowOrder[p.range.startRow];
    const mergeAnchorColumn = mergeDirty && target.columnOrder[p.range.startColumn];
    for (const address of addresses) {
      const block = await this.block(address, head);
      bytes += encodedBytes(block) * 4;
      assert(
        bytes <= 32 * 1024 * 1024,
        "LIMIT_EXCEEDED",
        "Command working set exceeds 32 MiB; use a streamed operation"
      );
      if (mergeDirty) {
        for (const cell of Object.values(block.cells))
          if (mergeRows.has(cell.rowId) && mergeColumns.has(cell.columnId) && (cell.rowId !== mergeAnchorRow || cell.columnId !== mergeAnchorColumn) && (cell.input.type !== "blank" || cell.cached !== void 0)) {
            mergeDirty.add(address);
            break;
          }
      }
      Object.assign(target.cells, structuredClone(block.cells));
    }
    reduceCommand(snapshot, command);
    const pages = /* @__PURE__ */ new Map();
    if (target && (!mergeDirty || mergeDirty.size)) {
      for (const cell of Object.values(target.cells)) {
        const address = blockAddress(target.id, cell.rowId, cell.columnId);
        if (mergeDirty && !mergeDirty.has(address)) continue;
        let page = pages.get(address);
        if (!page) pages.set(address, page = {});
        page[key(cell.rowId, cell.columnId)] = cell;
      }
    }
    for (const address of addresses) {
      if (mergeDirty && !mergeDirty.has(address)) continue;
      await this.storeBlock(address, pages.get(address) ?? {}, head, metadata);
    }
    for (const s of snapshot.sheets) s.cells = {};
    metadata.snapshot = snapshot;
  }
  async execute(inputs, label = "edit") {
    assert(this.writer, "READ_ONLY", "Workbook is open in another tab");
    this.cancelled = false;
    this.allocations = [];
    this.changed.clear();
    this.allocated.clear();
    this.pins.clear();
    const envelope = inputs.length === 1 && "protocolVersion" in inputs[0] ? inputs[0] : void 0;
    let signature = "";
    if (envelope) {
      assert(
        envelope.protocolVersion === 1 && envelope.workbookId === this.id && typeof envelope.commandId === "string" && envelope.commandId.length > 0 && envelope.commandId.length <= 100,
        "INVALID_ARGUMENT",
        "Invalid command envelope"
      );
      signature = JSON.stringify(envelope);
      const old2 = this.seen.get(envelope.commandId);
      if (old2) {
        assert(old2.signature === signature, "INVALID_ARGUMENT", "Command id reused");
        return { view: this.view(), commit: old2.commit, duplicate: true };
      }
      assert(envelope.baseRevision === this.head.revision, "REVISION_CONFLICT", "Workbook changed");
    }
    const commands = inputs.map(validateCommand), old = this.head, metadata = {
      ...this.metadata,
      snapshot: {
        ...this.metadata.snapshot,
        sheetOrder: [...this.metadata.snapshot.sheetOrder],
        styles: this.metadata.snapshot.styles,
        sheets: this.metadata.snapshot.sheets.map((sh) => ({
          ...sh,
          cells: {},
          rows: sh.rows,
          columns: sh.columns,
          merges: sh.merges,
          freeze: sh.freeze,
          filter: sh.filter
        }))
      }
    }, transaction = overlay(old.blocks), next = {
      ...old,
      blocks: transaction.record,
      past: [...old.past],
      future: [...old.future]
    };
    if (commands.length === 1 && (commands[0].type === "core.axis.visibility" || commands[0].type === "core.axis.visibilityAll")) {
      const p = commands[0].payload;
      const sheet = metadata.snapshot.sheets.find((item) => item.id === p.sheetId);
      assert(sheet, "INVALID_ARGUMENT", "Sheet no longer exists");
      const order = p.axis === "row" ? sheet.rowOrder : sheet.columnOrder;
      const axisMetadata = p.axis === "row" ? sheet.rows : sheet.columns;
      const start = commands[0].type === "core.axis.visibilityAll" ? 0 : p.index;
      const end = commands[0].type === "core.axis.visibilityAll" ? order.length : p.index + p.count;
      assert(end <= order.length, "INVALID_RANGE", "Unknown row/column");
      let changes = false;
      for (let i = start; i < end && !changes; i++)
        changes = !!axisMetadata[order[i]]?.hidden !== p.hidden;
      if (!changes) {
        if (envelope) this.seen.set(envelope.commandId, { signature });
        return { view: this.view() };
      }
    }
    const candidates = new Set(this.allocations);
    let metadataDirty = false;
    const ranges = [];
    try {
      for (const command of commands) {
        this.check();
        metadataDirty ||= !(["core.cells.paste", "core.cells.pasteTile"].includes(command.type) && !changesStyles(command)) && ![
          "core.cells.set",
          "core.cells.annotation",
          "core.cells.copy",
          "core.cells.fillDown",
          "core.cells.fillSeries",
          "core.cells.clear",
          "core.cells.replace",
          "core.sheet.sort"
        ].includes(command.type);
        const p = command.payload;
        if (p.sheetId) {
          const sh = metadata.snapshot.sheets.find((s) => s.id === p.sheetId);
          if (p.target) ranges.push({ sheetId: p.sheetId, ...p.target });
          if (p.range) ranges.push({ sheetId: p.sheetId, ...p.range });
          else if (p.cells?.length) {
            let startRow = Infinity, endRow = 0, startColumn = Infinity, endColumn = 0;
            for (const cell of p.cells) {
              startRow = Math.min(startRow, cell.row);
              endRow = Math.max(endRow, cell.row + 1);
              startColumn = Math.min(startColumn, cell.column);
              endColumn = Math.max(endColumn, cell.column + 1);
            }
            ranges.push({
              sheetId: p.sheetId,
              startRow,
              endRow,
              startColumn,
              endColumn
            });
          } else if (sh)
            ranges.push({
              sheetId: sh.id,
              startRow: 0,
              startColumn: 0,
              endRow: sh.rowOrder.length,
              endColumn: sh.columnOrder.length
            });
        }
        if ([
          "core.axis.insert",
          "core.axis.delete",
          "core.sheet.rename",
          "core.sheet.remove"
        ].includes(command.type))
          await this.structural(command, next, metadata);
        else if (command.type === "core.cells.paste")
          await this.pasteCells(command, next, metadata);
        else if (command.type === "core.cells.pasteTile")
          await this.pasteTile(command, next, metadata);
        else if (command.type === "core.cells.copySpecial")
          await this.copySpecial(command, next, metadata);
        else if (command.type === "core.cells.fillDown")
          await this.fillDown(command, next, metadata);
        else if (command.type === "core.cells.fillSeries")
          await this.fillSeries(command, next, metadata);
        else if (command.type === "core.cells.style")
          await this.applyStyle(command, next, metadata);
        else if (command.type === "core.cells.replace")
          await this.replaceText(command, next, metadata);
        else if (command.type === "core.sheet.sort") await this.sort(command, next, metadata);
        else await this.applyLocal(command, next, metadata);
      }
      if (commands.length && commands.every((command) => command.type === "core.cells.replace") && !this.changed.size) {
        if (envelope) this.seen.set(envelope.commandId, { signature });
        return { view: this.view() };
      }
      await this.filters(next, metadata);
      next.revision++;
      next.meta = !metadataDirty ? old.meta : await this.allocate(encodeMetadata(metadata));
      const changes = [];
      for (const a of this.changed)
        if (old.blocks[a] !== next.blocks[a])
          changes.push([a, old.blocks[a] ?? null, next.blocks[a] ?? null]);
      const bytes = changes.reduce((n, [, a, b]) => n + (a?.bytes ?? 0) + (b?.bytes ?? 0), 0) + (next.meta === old.meta ? 0 : encodedBytes(encodeMetadata(metadata)) + encodedBytes(encodeMetadata(this.metadata)));
      assert(
        bytes <= 32 * 1024 * 1024,
        "LIMIT_EXCEEDED",
        "Change exceeds the 32 MiB undo budget; import as a new workbook"
      );
      const history = { before: old.meta, after: next.meta, changes, bytes, ranges };
      next.past.push(await this.allocate(history));
      for (const id of old.future) {
        const h = this.histories.get(id);
        candidates.add(id);
        candidates.add(h.before);
        candidates.add(h.after);
        for (const [, a, b] of h.changes) {
          if (a) candidates.add(a.id);
          if (b) candidates.add(b.id);
        }
      }
      next.future = [];
      next.historyBytes = old.historyBytes + bytes;
      while (next.past.length > 100 || next.historyBytes > 32 * 1024 * 1024) {
        const expired = next.past.shift();
        const h = this.histories.get(expired);
        next.historyBytes -= h.bytes;
        candidates.add(expired);
        candidates.add(h.before);
        candidates.add(h.after);
        for (const [, a, b] of h.changes) {
          if (a) candidates.add(a.id);
          if (b) candidates.add(b.id);
        }
      }
      await this.publish(next, metadata, metadataDirty ? void 0 : ranges);
      await this.cleanup([...candidates, ...this.allocations]);
      for (const [address, pointer] of transaction.changed) {
        if (pointer) old.blocks[address] = pointer;
        else delete old.blocks[address];
      }
      this.head.blocks = old.blocks;
      const commit = {
        commandId: envelope?.commandId ?? uid("cmd"),
        previousRevision: old.revision,
        revision: next.revision,
        source: label,
        commands,
        changedRanges: ranges
      };
      if (envelope) this.seen.set(envelope.commandId, { signature, commit });
      return { view: this.view(), commit };
    } catch (error) {
      await this.cleanup(this.allocations);
      throw error;
    }
  }
  async pasteTile(command, next, metadata) {
    const tile = command.payload;
    const sh = metadata.snapshot.sheets.find((sheet) => sheet.id === tile.sheetId);
    assert(sh, "INVALID_ARGUMENT", "Sheet no longer exists");
    let units = validatePasteTile(sh, tile);
    const charge = (extra) => {
      units += extra;
      assert(
        units <= 32 * 1024 * 1024,
        "LIMIT_EXCEEDED",
        "Expanded clipboard content is too large"
      );
    };
    if (changesStyles(command)) metadata.snapshot.styles = { ...metadata.snapshot.styles };
    const offset = createTileOffsetter();
    const rowGroups = groupAxis(sh.rowOrder, tile.range.startRow, tile.range.endRow, BLOCK_ROWS);
    const columnGroups = groupAxis(
      sh.columnOrder,
      tile.range.startColumn,
      tile.range.endColumn,
      BLOCK_COLUMNS
    );
    for (const rows of rowGroups.values())
      for (const columns of columnGroups.values()) {
        this.check();
        const address = blockAddress(tile.sheetId, rows[0].id, columns[0].id);
        const cells = structuredClone((await this.block(address, next)).cells);
        for (const row of rows)
          for (const column of columns) {
            const position = key(row.id, column.id);
            const target = cells[position] ?? (cells[position] = { rowId: row.id, columnId: column.id, input: { type: "blank" } });
            applyPastedCell(
              metadata.snapshot,
              target,
              tileCell(tile, row.index, column.index, charge, offset)
            );
          }
        await this.storeBlock(address, cells, next, metadata);
      }
  }
  async copySpecial(command, next, metadata) {
    const { sheetId, range, target, mode } = command.payload;
    const sheet = metadata.snapshot.sheets.find((item) => item.id === sheetId);
    assert(sheet, "INVALID_ARGUMENT", "Sheet no longer exists");
    checkBounds(sheet, range);
    checkBounds(sheet, target);
    const rows = range.endRow - range.startRow;
    const columns = range.endColumn - range.startColumn;
    assert(
      rows === target.endRow - target.startRow && columns === target.endColumn - target.startColumn,
      "INVALID_RANGE",
      "Copy ranges must have equal dimensions"
    );
    assert(rows * columns <= LIMITS.rangeCells, "LIMIT_EXCEEDED", "Copy exceeds the cell limit");
    assert(
      !sheet.merges.some((merge) => intersects(merge, range) || intersects(merge, target)),
      "INVALID_RANGE",
      "Unmerge before copying"
    );
    const calculate = mode === "values" ? new AsyncCalculation(
      (id, row, column) => this.stagedCell(id, row, column, next, metadata),
      (name) => metadata.snapshot.sheets.find((s) => s.name.toLowerCase() === name.toLowerCase())?.id,
      this.calculator.cacheBudget,
      void 0,
      () => metadata.snapshot.dateSystem
    ).readSession() : void 0;
    const page = {};
    const cells = [];
    let bytes = 0;
    let visited = 0;
    for (let row = range.startRow; row < range.endRow; row++) {
      for (let column = range.startColumn; column < range.endColumn; column++) {
        this.check();
        if (++visited % 1024 === 0) {
          await yieldToTask();
          this.check();
        }
        const cell = await this.stagedCell(sheetId, row, column, next, metadata, page);
        const style = cell?.styleId ? metadata.snapshot.styles[cell.styleId] : {};
        const item = selectiveCopyCell(
          {
            row,
            column,
            ...mode === "values" ? {
              value: cell?.input.type === "formula" ? await calculate(sheetId, row, column) : cell ? scalarValue(cell.input) : null
            } : {},
            ...mode === "formulas" ? { input: cell?.input } : {},
            ...mode === "formats" ? { style, numberFormat: cell?.numberFormat ?? style?.numberFormat } : {}
          },
          mode,
          target.startRow - range.startRow,
          target.startColumn - range.startColumn
        );
        bytes += JSON.stringify(item).length * 2;
        assert(bytes <= 32 * 1024 * 1024, "LIMIT_EXCEEDED", "Copy working set is too large");
        cells.push(item);
      }
    }
    const paste = validateCommand({ type: "core.cells.paste", payload: { sheetId, cells } });
    await this.pasteCells(paste, next, metadata);
  }
  async pasteCells(command, next, metadata) {
    const { sheetId, cells: incoming } = command.payload;
    const sh = metadata.snapshot.sheets.find((sheet) => sheet.id === sheetId);
    assert(sh, "INVALID_ARGUMENT", "Sheet no longer exists");
    const pages = /* @__PURE__ */ new Map();
    let startRow = Infinity, endRow = 0, startColumn = Infinity, endColumn = 0;
    for (const item of incoming) {
      assert(
        item.row < sh.rowOrder.length && item.column < sh.columnOrder.length,
        "INVALID_RANGE",
        "Range exceeds sheet dimensions"
      );
      startRow = Math.min(startRow, item.row);
      endRow = Math.max(endRow, item.row + 1);
      startColumn = Math.min(startColumn, item.column);
      endColumn = Math.max(endColumn, item.column + 1);
      const address = blockAddress(sheetId, sh.rowOrder[item.row], sh.columnOrder[item.column]);
      let page = pages.get(address);
      if (!page) pages.set(address, page = []);
      page.push(item);
    }
    const merges = sh.merges.filter(
      (merge) => intersects(merge, { startRow, endRow, startColumn, endColumn })
    );
    let checks = 0;
    for (const item of incoming)
      for (const merge of merges) {
        assert(++checks <= 2e6, "LIMIT_EXCEEDED", "Paste merge-check budget exceeded");
        assert(
          !(item.row >= merge.startRow && item.row < merge.endRow && item.column >= merge.startColumn && item.column < merge.endColumn),
          "INVALID_RANGE",
          "Unmerge before pasting cell inputs or formats"
        );
      }
    if (changesStyles(command)) metadata.snapshot.styles = { ...metadata.snapshot.styles };
    for (const [address, page] of pages) {
      this.check();
      const cells = structuredClone((await this.block(address, next)).cells);
      for (const item of page) {
        const rowId = sh.rowOrder[item.row], columnId = sh.columnOrder[item.column];
        const position = key(rowId, columnId);
        const target = cells[position] ?? (cells[position] = { rowId, columnId, input: { type: "blank" } });
        applyPastedCell(metadata.snapshot, target, item);
      }
      await this.storeBlock(address, cells, next, metadata);
    }
  }
  async fillSeries(command, next, metadata) {
    const { sheetId, range, start, step, axis, calendar } = command.payload;
    const sh = metadata.snapshot.sheets.find((sheet) => sheet.id === sheetId);
    assert(sh, "INVALID_ARGUMENT", "Sheet no longer exists");
    checkBounds(sh, range);
    assert(
      (range.endRow - range.startRow) * (range.endColumn - range.startColumn) <= LIMITS.rangeCells,
      "LIMIT_EXCEEDED",
      "Series exceeds the cell limit"
    );
    assert(
      !sh.merges.some((merge) => intersects(merge, range)),
      "INVALID_RANGE",
      "Unmerge before filling a series"
    );
    const count = axis === "row" ? range.endRow - range.startRow : range.endColumn - range.startColumn;
    const values = calendar ? calendarSeries(start, step, count, calendar, metadata.snapshot.dateSystem) : numericSeries(start, step, count);
    const rowGroups = groupAxis(sh.rowOrder, range.startRow, range.endRow, BLOCK_ROWS);
    const columnGroups = groupAxis(
      sh.columnOrder,
      range.startColumn,
      range.endColumn,
      BLOCK_COLUMNS
    );
    for (const rows of rowGroups.values()) {
      for (const columns of columnGroups.values()) {
        this.check();
        const address = blockAddress(sheetId, rows[0].id, columns[0].id);
        const cells = structuredClone((await this.block(address, next)).cells);
        for (const row of rows)
          for (const column of columns) {
            const position = key(row.id, column.id);
            const target = cells[position] ?? (cells[position] = {
              rowId: row.id,
              columnId: column.id,
              input: { type: "blank" }
            });
            target.input = {
              type: "number",
              value: values[axis === "row" ? row.index - range.startRow : column.index - range.startColumn]
            };
            delete target.cached;
          }
        await this.storeBlock(address, cells, next, metadata);
      }
    }
  }
  async applyStyle(command, next, metadata) {
    const { sheetId, range, style } = command.payload;
    const sh = metadata.snapshot.sheets.find((sheet) => sheet.id === sheetId);
    assert(sh, "INVALID_ARGUMENT", "Sheet no longer exists");
    checkBounds(sh, range);
    assert(
      (range.endRow - range.startRow) * (range.endColumn - range.startColumn) <= LIMITS.rangeCells,
      "LIMIT_EXCEEDED",
      "Style range exceeds the cell limit"
    );
    assert(
      sh.merges.every((merge) => !intersects(merge, range) || contains(range, merge)),
      "INVALID_RANGE",
      "Operation cuts through a merged cell"
    );
    metadata.snapshot.styles = { ...metadata.snapshot.styles };
    const styles = /* @__PURE__ */ new Map();
    const rowGroups = groupAxis(sh.rowOrder, range.startRow, range.endRow, BLOCK_ROWS);
    const columnGroups = groupAxis(
      sh.columnOrder,
      range.startColumn,
      range.endColumn,
      BLOCK_COLUMNS
    );
    for (const rows of rowGroups.values()) {
      for (const columns of columnGroups.values()) {
        this.check();
        const address = blockAddress(sheetId, rows[0].id, columns[0].id);
        const cells = structuredClone((await this.block(address, next)).cells);
        for (const row of rows)
          for (const column of columns) {
            const position = key(row.id, column.id);
            const target = cells[position] ?? (cells[position] = {
              rowId: row.id,
              columnId: column.id,
              input: { type: "blank" }
            });
            const prior = target.styleId ?? "";
            let nextStyle = styles.get(prior);
            if (!nextStyle) {
              nextStyle = styleId(metadata.snapshot, {
                ...target.styleId ? metadata.snapshot.styles[target.styleId] : {},
                ...style
              });
              styles.set(prior, nextStyle);
            }
            target.styleId = nextStyle;
            if (style.numberFormat !== void 0) delete target.numberFormat;
          }
        await this.storeBlock(address, cells, next, metadata);
      }
    }
  }
  async fillDown(command, next, metadata) {
    const { sheetId, range } = command.payload;
    const sh = metadata.snapshot.sheets.find((sheet) => sheet.id === sheetId);
    assert(sh, "INVALID_ARGUMENT", "Sheet no longer exists");
    checkBounds(sh, range);
    assert(
      !sh.merges.some((merge) => intersects(merge, range)),
      "INVALID_RANGE",
      "Unmerge before copying or filling"
    );
    const rowGroups = /* @__PURE__ */ new Map();
    const columnGroups = /* @__PURE__ */ new Map();
    for (let index = range.startRow + 1; index < range.endRow; index++) {
      const id = sh.rowOrder[index], group = Math.floor(id / BLOCK_ROWS);
      let values = rowGroups.get(group);
      if (!values) rowGroups.set(group, values = []);
      values.push({ index, id });
    }
    for (let index = range.startColumn; index < range.endColumn; index++) {
      const id = sh.columnOrder[index], group = Math.floor(id / BLOCK_COLUMNS);
      let values = columnGroups.get(group);
      if (!values) columnGroups.set(group, values = []);
      values.push({ index, id });
    }
    const source = /* @__PURE__ */ new Map();
    const sourceId = sh.rowOrder[range.startRow];
    for (const columns of columnGroups.values()) {
      this.check();
      const block = await this.block(blockAddress(sheetId, sourceId, columns[0].id), next);
      const cells = block.cells;
      for (const column of columns) {
        const value = cells[key(sourceId, column.id)];
        if (value) source.set(column.id, structuredClone(value));
      }
    }
    for (const rows of rowGroups.values()) {
      for (const columns of columnGroups.values()) {
        this.check();
        const address = blockAddress(sheetId, rows[0].id, columns[0].id);
        const cells = structuredClone((await this.block(address, next)).cells);
        for (const row of rows)
          for (const column of columns) {
            const position = key(row.id, column.id);
            const original = source.get(column.id);
            if (!original) {
              delete cells[position];
              continue;
            }
            const value = structuredClone(original);
            value.rowId = row.id;
            value.columnId = column.id;
            if (value.input.type === "formula")
              value.input.expression = offsetCellFormula(
                value.input.expression,
                row.index - range.startRow,
                0
              );
            delete value.cached;
            cells[position] = value;
          }
        await this.storeBlock(address, cells, next, metadata);
      }
    }
  }
  async replaceText(command, next, metadata) {
    const id = String(command.payload.sheetId);
    assert(
      metadata.snapshot.sheets.some((sheet) => sheet.id === id),
      "INVALID_ARGUMENT",
      "Unknown sheet"
    );
    const query = String(command.payload.query);
    if (query === command.payload.replacement) return;
    for (const a of Object.keys(next.blocks))
      if (a.startsWith(`${id}/`)) {
        this.check();
        const existing = (await this.block(a, next)).cells;
        if (!Object.values(existing).some(
          (cell) => cell.input.type === "string" && cell.input.value.includes(query)
        ))
          continue;
        const cells = structuredClone(existing);
        const snapshot = {
          ...metadata.snapshot,
          sheets: metadata.snapshot.sheets.map((s) => s.id === id ? { ...s, cells } : s)
        };
        reduceCommand(snapshot, command);
        await this.storeBlock(a, cells, next, metadata);
      }
  }
  async structural(command, next, metadata) {
    const original = metadata.snapshot;
    const transformed = structuredClone(original);
    reduceCommand(transformed, command);
    const axisPayload = command.payload;
    if (command.type === "core.axis.insert" || command.type === "core.axis.delete") {
      const before = original.sheets.find((s) => s.id === axisPayload.sheetId), after = transformed.sheets.find((s) => s.id === axisPayload.sheetId);
      const field = axisPayload.axis === "row" ? "rowOrder" : "columnOrder", index = this.axis(before[field]).clone();
      index.splice(
        axisPayload.index,
        command.type === "core.axis.delete" ? axisPayload.count : 0,
        command.type === "core.axis.insert" ? axisPayload.ids : []
      );
      assert(
        index.toArray().every((id, i) => id === after[field][i]),
        "CORRUPT_STORAGE",
        "Axis sequence differs"
      );
      this.axes.set(after[field], index);
    }
    const payload = command.payload, sourceSheet = original.sheets.find((s) => s.id === payload.sheetId);
    const sourceName = sourceSheet.name.toLowerCase();
    const names = new Map(original.sheets.map((sheet) => [sheet.id, sheet.name]));
    const rewrite = createCellFormulaTransformer(
      structuralReferences(command, sourceSheet.name),
      structuralRangeReferences(command, sourceSheet.name)
    );
    const axisEdit = command.type === "core.axis.insert" || command.type === "core.axis.delete";
    const deleted = command.type === "core.axis.delete" ? new Set(
      (payload.axis === "row" ? sourceSheet.rowOrder : sourceSheet.columnOrder).slice(
        payload.index,
        payload.index + payload.count
      )
    ) : /* @__PURE__ */ new Set();
    const deletedBuckets = new Set(
      [...deleted].map((id) => Math.floor(id / (payload.axis === "row" ? 64 : 32)))
    );
    const remainingBuckets = /* @__PURE__ */ new Set();
    if (command.type === "core.axis.delete") {
      const sheet = transformed.sheets.find((item) => item.id === payload.sheetId);
      const order = payload.axis === "row" ? sheet.rowOrder : sheet.columnOrder;
      const size = payload.axis === "row" ? BLOCK_ROWS : BLOCK_COLUMNS;
      for (const id of order) {
        const bucket = Math.floor(id / size);
        if (deletedBuckets.has(bucket)) remainingBuckets.add(bucket);
        if (remainingBuckets.size === deletedBuckets.size) break;
      }
    }
    metadata.snapshot = transformed;
    for (const [address, pointer] of Object.entries(next.blocks)) {
      this.check();
      const [sheetId, br, bc] = address.split("/");
      const removedSheet = command.type === "core.sheet.remove" && sheetId === sourceSheet.id;
      const deletion = sheetId === sourceSheet.id && deletedBuckets.has(payload.axis === "row" ? +br : +bc);
      const formula = pointer.formulas?.some(
        (name) => name === "*" || name.toLowerCase() === sourceName
      );
      if (removedSheet) {
        this.changed.add(address);
        delete next.blocks[address];
        continue;
      }
      if (deletion && !remainingBuckets.has(payload.axis === "row" ? +br : +bc)) {
        this.changed.add(address);
        delete next.blocks[address];
        continue;
      }
      if (!deletion && !formula) continue;
      const cells = structuredClone((await this.block(address, next)).cells);
      if (deletion) {
        const field = payload.axis === "row" ? "rowId" : "columnId";
        for (const [key2, cell] of Object.entries(cells))
          if (deleted.has(cell[field])) delete cells[key2];
      }
      rewrite(cells, axisEdit ? names.get(sheetId) : void 0);
      await this.storeBlock(address, cells, next, metadata);
    }
  }
  async sort(command, next, metadata) {
    const p = command.payload, sh = metadata.snapshot.sheets.find((s) => s.id === p.sheetId);
    checkBounds(sh, p.range);
    const keys = sortColumns(p, p.range);
    assert(
      !sh.merges.some((m) => intersects(m, p.range)),
      "INVALID_RANGE",
      "Unmerge before sorting"
    );
    const source = { ...next, blocks: { ...next.blocks } };
    for (const block of Object.values(source.blocks)) this.pins.add(block.id);
    let runs = [];
    let scratchBytes = 0;
    let outputComplete = false;
    const compare = (a, b) => compareSortKeys(a.values, b.values, keys) || a.row - b.row;
    const calculationBytes = Math.min(4 * 1024 * 1024, this.cache.budget);
    const workingBudget = 32 * 1024 * 1024 - calculationBytes;
    const calculator = new AsyncCalculation(
      (sheet, row, column) => this.stagedCell(sheet, row, column, source, metadata),
      (name) => metadata.snapshot.sheets.find((s) => s.name.toLowerCase() === name.toLowerCase())?.id,
      calculationBytes,
      void 0,
      () => metadata.snapshot.dateSystem
    );
    try {
      let stageStart = performance.now();
      const totalRows = p.range.endRow - p.range.startRow;
      const runRows = Math.max(
        1,
        Math.min(256, Math.floor(8192 / (p.range.endColumn - p.range.startColumn)))
      );
      for (let row = p.range.startRow; row < p.range.endRow; row += runRows) {
        const batch = [];
        let workingBytes = 0;
        for (let r = row; r < Math.min(row + runRows, p.range.endRow); r++) {
          this.check();
          const cells = [];
          for (let c = p.range.startColumn; c < p.range.endColumn; c++) {
            const cell = (await this.block(blockAddress(sh.id, sh.rowOrder[r], sh.columnOrder[c]), source)).cell(sh.rowOrder[r] % 64 * 32 + sh.columnOrder[c] % 32) ?? null;
            workingBytes += encodedBytes(cell) * 4;
            assert(
              workingBytes <= workingBudget,
              "LIMIT_EXCEEDED",
              "Sort run exceeds the operation working-set budget"
            );
            cells.push(cell);
          }
          const values = [];
          for (const key2 of keys) {
            const input = cells[key2.column - p.range.startColumn]?.input;
            const value = sortKey(
              input?.type === "formula" ? await calculator.value(sh.id, r, key2.column) : input ? scalarValue(input) : null
            );
            workingBytes += encodedBytes(value) * 4;
            assert(
              workingBytes <= workingBudget,
              "LIMIT_EXCEEDED",
              "Sort keys exceed the operation working-set budget"
            );
            values.push(value);
          }
          batch.push({ row: r, cells, values });
        }
        assert(
          encodedBytes(batch) * 4 <= workingBudget,
          "LIMIT_EXCEEDED",
          "Sort run exceeds the 32 MiB operation budget"
        );
        batch.sort(compare);
        const run = `${this.id}/sort/0/${runs.length}`;
        const puts = batch.map((v, i) => [
          `${run}/${String(i).padStart(8, "0")}`,
          v
        ]);
        const runBytes = puts.reduce((total, record) => total + encodedBytes(record), 0);
        scratchBytes += runBytes;
        this.stagingBytes = scratchBytes;
        assert(
          this.usedBytes + scratchBytes <= next.budget,
          "STORAGE_BUDGET",
          "Sort staging exceeds the storage budget"
        );
        await this.db.write("scratch", puts);
        runs.push({
          id: run,
          count: batch.length,
          bytes: runBytes,
          maxRowBytes: Math.max(...batch.map((row2) => encodedBytes(row2) * 4 + 1024))
        });
      }
      this.progress({
        phase: "sort-runs",
        completed: totalRows,
        total: totalRows,
        elapsedMs: performance.now() - stageStart
      });
      stageStart = performance.now();
      let pass = 1;
      while (runs.length > 1) {
        const merged = [];
        for (let i = 0; i < runs.length; i += 2) {
          if (!runs[i + 1]) {
            merged.push(runs[i]);
            continue;
          }
          const left = runs[i], right = runs[i + 1], id = `${this.id}/sort/${pass}/${i}`;
          const maxRowBytes = Math.max(left.maxRowBytes, right.maxRowBytes);
          assert(
            left.maxRowBytes + right.maxRowBytes <= workingBudget,
            "LIMIT_EXCEEDED",
            "Sort merge rows exceed the operation working-set budget"
          );
          const buffered = maxRowBytes <= workingBudget / 6;
          const batchSize = buffered ? Math.min(64, Math.floor(workingBudget / 6 / maxRowBytes)) : 1;
          const db = this.db;
          async function* rows(run) {
            if (batchSize === 1) {
              for (let index = 0; index < run.count; index++) {
                const value = await db.get(
                  "scratch",
                  `${run.id}/${String(index).padStart(8, "0")}`
                );
                assert(value, "CORRUPT_STORAGE", "Missing sort row");
                yield value;
              }
            } else {
              for await (const entries of db.scan(
                "scratch",
                prefixRange(run.id),
                batchSize
              ))
                for (const [, value] of entries) yield value;
            }
          }
          const leftRows = rows(left), rightRows = rows(right);
          let x = await leftRows.next(), y = await rightRows.next();
          let output = 0, bytes = 0;
          let pending = [];
          const flushMerge = async () => {
            if (pending.length) await this.db.write("scratch", pending);
            pending = [];
          };
          try {
            while (!x.done || !y.done) {
              this.check();
              const takeLeft = !x.done && (y.done || compare(x.value, y.value) <= 0);
              const value = takeLeft ? x.value : y.value;
              const record = [
                `${id}/${String(output++).padStart(8, "0")}`,
                value
              ];
              const size = encodedBytes(record);
              scratchBytes += size;
              bytes += size;
              this.stagingBytes = scratchBytes;
              assert(
                this.usedBytes + scratchBytes <= next.budget,
                "STORAGE_BUDGET",
                "Sort merge exceeds the storage budget"
              );
              pending.push(record);
              if (pending.length >= batchSize) await flushMerge();
              if (takeLeft) x = await leftRows.next();
              else y = await rightRows.next();
            }
            await flushMerge();
            assert(output === left.count + right.count, "CORRUPT_STORAGE", "Incomplete sort run");
          } finally {
            await leftRows.return(void 0);
            await rightRows.return(void 0);
          }
          await this.db.write("scratch", [], [prefixRange(left.id), prefixRange(right.id)]);
          scratchBytes -= left.bytes + right.bytes;
          this.stagingBytes = scratchBytes;
          merged.push({ id, count: output, bytes, maxRowBytes });
        }
        runs = merged;
        pass++;
      }
      this.progress({
        phase: "sort-merge",
        completed: totalRows,
        total: totalRows,
        elapsedMs: performance.now() - stageStart
      });
      stageStart = performance.now();
      let position = 0;
      const grouped = /* @__PURE__ */ new Map();
      let groupedBytes = 0, rowBand = -1;
      const flush = async () => {
        for (const [address, cells] of grouped) {
          this.check();
          await this.storeBlock(address, cells, next, metadata);
        }
        grouped.clear();
        groupedBytes = 0;
      };
      for (let row = p.range.startRow; row < p.range.endRow; row++) {
        this.check();
        const entry = await this.db.get(
          "scratch",
          `${runs[0].id}/${String(position++).padStart(8, "0")}`
        );
        const entryBytes = encodedBytes(entry) * 4;
        assert(
          entryBytes <= workingBudget,
          "LIMIT_EXCEEDED",
          "Sort output row exceeds the operation budget"
        );
        const band = Math.floor(sh.rowOrder[row] / 64);
        if (rowBand !== band || groupedBytes + entryBytes > workingBudget) await flush();
        rowBand = band;
        const pageFor = async (address, extra = 0) => {
          if (grouped.has(address) && groupedBytes + entryBytes + extra > workingBudget)
            await flush();
          if (!grouped.has(address)) {
            const cells = (await this.block(address, next)).cells;
            const bytes = encodedBytes(cells) * 4;
            if (groupedBytes + bytes + entryBytes + extra > workingBudget) await flush();
            assert(
              bytes + entryBytes + extra <= workingBudget,
              "LIMIT_EXCEEDED",
              "Sort output page exceeds the operation budget"
            );
            grouped.set(address, structuredClone(cells));
            groupedBytes += bytes;
          }
          return grouped.get(address);
        };
        for (let c = p.range.startColumn; c < p.range.endColumn; c++) {
          const a = blockAddress(sh.id, sh.rowOrder[row], sh.columnOrder[c]);
          let cells = await pageFor(a);
          const k = key(sh.rowOrder[row], sh.columnOrder[c]);
          const cell = entry.cells[c - p.range.startColumn];
          if (!cell) {
            if (cells[k]) groupedBytes -= encodedBytes(cells[k]) * 4;
            delete cells[k];
          } else {
            const copied = structuredClone(cell);
            copied.rowId = sh.rowOrder[row];
            copied.columnId = sh.columnOrder[c];
            delete copied.cached;
            if (copied.input.type === "formula")
              copied.input.expression = offsetCellFormula(
                copied.input.expression,
                row - entry.row,
                0
              );
            const growth = (encodedBytes(copied) - (cells[k] ? encodedBytes(cells[k]) : 0) + (cells[k] ? 0 : k.length + 4)) * 4;
            cells = await pageFor(a, Math.max(0, growth));
            cells[k] = copied;
            groupedBytes += growth;
          }
        }
      }
      await flush();
      this.progress({
        phase: "sort-output",
        completed: totalRows,
        total: totalRows,
        elapsedMs: performance.now() - stageStart
      });
      outputComplete = true;
    } finally {
      calculator.clear();
      try {
        await this.db.write("scratch", [], [prefixRange(`${this.id}/sort`)]);
        this.stagingBytes = 0;
      } catch {
        this.poisoned = true;
        if (outputComplete)
          throw new OpenSheetError("WORKER_FAILED", "Reopen the workbook to recover sort staging");
      }
    }
  }
  async history(redo) {
    assert(this.writer, "READ_ONLY", "Workbook is open in another tab");
    this.cancelled = false;
    this.changed.clear();
    const next = {
      ...this.head,
      blocks: { ...this.head.blocks },
      past: [...this.head.past],
      future: [...this.head.future]
    }, from = redo ? next.future : next.past, to = redo ? next.past : next.future;
    const id = from.pop();
    if (!id) return { view: this.view(), commit: void 0 };
    const h = this.histories.get(id) ?? await this.readHistory(id);
    assert(h, "CORRUPT_STORAGE", "Missing history");
    for (const [a, before, after] of h.changes) {
      this.changed.add(a);
      const p = redo ? after : before;
      if (p) next.blocks[a] = p;
      else delete next.blocks[a];
    }
    next.meta = redo ? h.after : h.before;
    next.revision++;
    to.push(id);
    next.historyBytes += redo ? h.bytes : -h.bytes;
    const metadata = {
      ...next.meta === this.head.meta ? this.metadata : await this.readMetadata(next.meta)
    };
    await this.filters(next, metadata);
    await this.publish(next, metadata, next.meta === this.head.meta ? h.ranges : void 0);
    return {
      view: this.view(),
      commit: {
        commandId: uid("cmd"),
        previousRevision: next.revision - 1,
        revision: next.revision,
        source: redo ? "redo" : "undo",
        commands: [],
        changedRanges: h.ranges
      }
    };
  }
  async search(sheetId, query, after = -1, cooperative = false, direction = "next") {
    this.check();
    validateSearchArguments(sheetId, query, after, direction);
    assert(
      typeof cooperative === "boolean",
      "INVALID_ARGUMENT",
      "Invalid search cancellation mode"
    );
    const sh = this.metadata.snapshot.sheets.find((s) => s.id === sheetId);
    assert(sh, "INVALID_ARGUMENT", "Unknown search sheet");
    const q = query.toLowerCase();
    const reverse = direction === "previous";
    const precedes = (a, b) => reverse ? a > b : a < b;
    const width = sh.columnOrder.length;
    const toResult = (position, count2) => ({
      match: position === void 0 ? void 0 : { row: Math.floor(position / width), column: position % width },
      count: count2
    });
    const head = this.head;
    const cached = this.searchResults.get(head);
    if (cached?.sheetId === sheetId && cached.query === q) {
      const { positions: positions2 } = cached;
      let low = 0, high = positions2.length;
      while (low < high) {
        const mid = low + high >>> 1;
        if (reverse ? positions2[mid] < after : positions2[mid] <= after) low = mid + 1;
        else high = mid;
      }
      return toResult(
        reverse ? positions2[low - 1] ?? positions2.at(-1) : positions2[low] ?? positions2[0],
        positions2.length
      );
    }
    let positions = q.length <= 1024 ? [] : void 0;
    let wrap, next, count = 0;
    const rows = this.axis(sh.rowOrder), cols = this.axis(sh.columnOrder);
    let visited = 0, textUnits = 0;
    for (const [a] of Object.entries(this.head.blocks))
      if (a.startsWith(`${sheetId}/`))
        for (const cell of (await this.block(a)).records()) {
          if (cooperative && ++visited % 16384 === 0) {
            await new Promise((resolve) => setTimeout(resolve, 0));
            textUnits = 0;
          }
          this.check();
          const row = rows.get(cell.rowId), column = cols.get(cell.columnId);
          const value = cell.input.type === "formula" ? await this.calculator.value(sheetId, row, column) : scalarValue(cell.input);
          assert(
            !(value && typeof value === "object" && value.error === "#LIMIT!"),
            "LIMIT_EXCEEDED",
            "Search calculation exceeded its work budget"
          );
          const display = value && typeof value === "object" && cell.cached && this.head.revision === this.metadata.importRevision ? formatValue(
            scalarValue(cell.cached),
            cell.numberFormat,
            this.metadata.snapshot.dateSystem
          ) + " †" : formatValue(
            value,
            cell.numberFormat ?? this.metadata.snapshot.styles[cell.styleId ?? ""]?.numberFormat,
            this.metadata.snapshot.dateSystem
          );
          if (cooperative) {
            textUnits += display.length;
            if (textUnits >= SEARCH_YIELD_TEXT_UNITS) {
              textUnits = 0;
              await new Promise((resolve) => setTimeout(resolve, 0));
              this.check();
            }
          }
          if (!display.toLowerCase().includes(q)) continue;
          count++;
          const position = row * width + column;
          if (positions) {
            if (positions.length === 16384) positions = void 0;
            else positions.push(position);
          }
          if (wrap === void 0 || precedes(position, wrap)) wrap = position;
          if (precedes(after, position) && (next === void 0 || precedes(position, next)))
            next = position;
        }
    this.check();
    if (positions && this.head === head)
      this.searchResults.set(head, {
        sheetId,
        query: q,
        positions: Uint32Array.from(positions).sort()
      });
    return toResult(next ?? wrap, count);
  }
  async clear() {
    assert(this.writer, "READ_ONLY", "Workbook is open in another tab");
    await this.db.deleteWorkbook(this.id, prefixRange(this.id));
    this.cache.clear();
  }
  close() {
    this.writer = false;
    this.release?.();
    this.release = void 0;
    this.db.close();
    this.cache.clear();
    this.seen.clear();
  }
}
export function fixtureValue(n) {
  let x = Math.imul(n + 1, 1664525) + 1013904223 >>> 0;
  if (n % 10 < 6) return n === 0 ? 0 : x / 1e3;
  if (n % 10 === 9) return (n / 10 | 0) % 2 === 1;
  let text = "";
  for (let i = 0; i < 32; i++) {
    x = Math.imul(x, 1664525) + 1013904223 >>> 0;
    text += String.fromCharCode(33 + x % 94);
  }
  return text;
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImVuZ2luZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBtYXRjaGVzRmlsdGVyIH0gZnJvbSAnLi9maWx0ZXIuanMnO1xuaW1wb3J0IHsgeWllbGRUb1Rhc2sgfSBmcm9tICcuL3Rhc2steWllbGQuanMnO1xuaW1wb3J0IHsgdmFsaWRhdGVTZWFyY2hBcmd1bWVudHMgfSBmcm9tICcuL3NlYXJjaC12YWxpZGF0aW9uLmpzJztcbmltcG9ydCB7IHZhbGlkYXRlTmF2aWdhdGlvbkFyZ3VtZW50cyB9IGZyb20gJy4vbmF2aWdhdGlvbi12YWxpZGF0aW9uLmpzJztcbmltcG9ydCB7IG51bWVyaWNTZXJpZXMgfSBmcm9tICcuL251bWVyaWMtc2VyaWVzLmpzJztcbmltcG9ydCB7IGNhbGVuZGFyU2VyaWVzIH0gZnJvbSAnLi9jYWxlbmRhci1zZXJpZXMuanMnO1xuaW1wb3J0IHsgY3JlYXRlVGlsZU9mZnNldHRlciwgdGlsZUNlbGwsIHZhbGlkYXRlUGFzdGVUaWxlLCB0eXBlIFBhc3RlVGlsZSB9IGZyb20gJy4vcGFzdGUtdGlsZS5qcyc7XG5pbXBvcnQgeyBjb21wYXJlU29ydEtleXMsIHNvcnRDb2x1bW5zLCBzb3J0S2V5IH0gZnJvbSAnLi9zb3J0LXZhbHVlcy5qcyc7XG5pbXBvcnQgeyBBeGlzSW5kZXggfSBmcm9tICcuL2F4aXMtaW5kZXguanMnO1xuaW1wb3J0IHsgb3ZlcmxheSB9IGZyb20gJy4vY29weS1vbi13cml0ZS5qcyc7XG5pbXBvcnQgeyBjb250YWlucywgaW50ZXJzZWN0cyB9IGZyb20gJy4vYWRkcmVzcy5qcyc7XG5pbXBvcnQgeyBwYXJzZUZvcm11bGEsIHR5cGUgQVNUIH0gZnJvbSAnQG9wZW5zaGVldGpzL2Zvcm11bGEnO1xuaW1wb3J0IHsgZGVjb2RlQmxvY2ssIGVuY29kZUJsb2NrLCBDb2x1bW5QYWdlLCB0eXBlIEVuY29kZWRCbG9jayB9IGZyb20gJy4vYmxvY2stY29kZWMuanMnO1xuaW1wb3J0IHtcbiAgZGVjb2RlRmlsZU1ldGFkYXRhLFxuICBlbmNvZGVXb3JrYm9va0ZpbGUsXG4gIGRlY29kZUZpbGVDZWxscyxcbiAgd29ya2Jvb2tGaWxlU2NoZW1hLFxuICB0eXBlIFdvcmtib29rRmlsZSxcbn0gZnJvbSAnLi9maWxlLWNvZGVjLmpzJztcbmltcG9ydCB7IGNyYzMyLCBnemlwUGFnZSwgdW5wYWNrUGFnZSwgcmVhZEJpbmFyeSB9IGZyb20gJy4vYmluYXJ5LWZpbGUuanMnO1xuaW1wb3J0IHsgZGVjb2RlVmVyaWZpZWRCaW5hcnlQYWdlIH0gZnJvbSAnLi9iaW5hcnktdmVyaWZ5LmpzJztcbmltcG9ydCB7IHBhcnNlV29ya2Jvb2tKU09OLCB0eXBlIEpTT05Tb3VyY2UgfSBmcm9tICcuL2pzb24tc3RyZWFtLmpzJztcbmltcG9ydCB7IGRvd25ncmFkZVZhbGlkYXRpb25NZXRhZGF0YSB9IGZyb20gJy4vdmFsaWRhdGlvbi1maWxlLW1pZ3JhdGlvbi5qcyc7XG5pbXBvcnQgeyBjaGVja1N0YWdlZFZhbGlkYXRpb24gfSBmcm9tICcuL3ZhbGlkYXRpb24tYmF0Y2guanMnO1xuaW1wb3J0IHsgdmFsaWRhdGlvbkNhbmRpZGF0ZXMgfSBmcm9tICcuL3ZhbGlkYXRpb24tY2FuZGlkYXRlcy5qcyc7XG5pbXBvcnQgdHlwZSB7IFZhbGlkYXRpb25FbnRyeSB9IGZyb20gJy4vdmFsaWRhdGlvbi1tb2RlbC5qcyc7XG5pbXBvcnQge1xuICBjb25kaXRpb25hbFZpZXdwb3J0V2l0aEZvcm11bGFzLFxuICB2YWxpZGF0ZUNvbmRpdGlvbmFsUnVsZXMsXG4gIHR5cGUgQ29uZGl0aW9uYWxSdWxlLFxufSBmcm9tICcuL2NvbmRpdGlvbmFsLWZvcm1hdC5qcyc7XG5pbXBvcnQgeyBhYm9ydGFibGUgfSBmcm9tICcuL3ZlcmlmaWNhdGlvbi15aWVsZC5qcyc7XG5pbXBvcnQgeyBBc3luY0NhbGN1bGF0aW9uIH0gZnJvbSAnLi9hc3luYy1jYWxjdWxhdGlvbi5qcyc7XG5pbXBvcnQgeyBzZWxlY3RpdmVDb3B5Q2VsbCB9IGZyb20gJy4vc2VsZWN0aXZlLWNvcHkuanMnO1xuaW1wb3J0IHsgcmVkdWNlQ29tbWFuZCwgdmFsaWRhdGVDb21tYW5kIH0gZnJvbSAnLi9jb21tYW5kcy5qcyc7XG5pbXBvcnQge1xuICBhcHBseVBhc3RlZENlbGwsXG4gIGNyZWF0ZUNlbGxGb3JtdWxhVHJhbnNmb3JtZXIsXG4gIHN0cnVjdHVyYWxSYW5nZVJlZmVyZW5jZXMsXG4gIG9mZnNldENlbGxGb3JtdWxhLFxuICBzdHJ1Y3R1cmFsUmVmZXJlbmNlcyxcbiAgc3R5bGVJZCxcbiAgdHlwZSBQYXN0ZUNlbGwsXG59IGZyb20gJy4vY29tbWFuZHMvaGVscGVycy5qcyc7XG5pbXBvcnQgeyBmb3JtYXRWYWx1ZSB9IGZyb20gJy4vZm9ybWF0LmpzJztcbmltcG9ydCB7IGNoZWNrQm91bmRzLCB2YWxpZGF0ZUpTT05WYWx1ZSwgdmFsaWRhdGVTbmFwc2hvdCB9IGZyb20gJy4vbW9kZWwuanMnO1xuaW1wb3J0IHtcbiAgQkxPQ0tfUk9XUyxcbiAgQkxPQ0tfQ09MVU1OUyxcbiAgQnl0ZUNhY2hlLFxuICBEYXRhYmFzZSxcbiAgZW5jb2RlZEJ5dGVzLFxuICByZWNvcmRCeXRlcyxcbn0gZnJvbSAnLi9zdG9yYWdlLmpzJztcbmltcG9ydCB7XG4gIGFzc2VydCxcbiAgTElNSVRTLFxuICBPcGVuU2hlZXRFcnJvcixcbiAga2V5LFxuICB1aWQsXG4gIHNjYWxhclZhbHVlLFxuICB0eXBlIENlbGxSZWNvcmQsXG4gIHR5cGUgQ2VsbFN0eWxlLFxuICB0eXBlIENlbGxWYWx1ZSxcbiAgdHlwZSBDb21tYW5kLFxuICB0eXBlIENvbW1hbmRFbnZlbG9wZSxcbiAgdHlwZSBDb21taXQsXG4gIHR5cGUgUmVjdCxcbiAgdHlwZSBTZWxlY3Rpb24sXG4gIHR5cGUgU2hlZXRTbmFwc2hvdCxcbiAgdHlwZSBXb3JrYm9va1NuYXBzaG90LFxufSBmcm9tICcuL3R5cGVzLmpzJztcbmZ1bmN0aW9uIGdyb3VwQXhpcyhvcmRlcjogbnVtYmVyW10sIHN0YXJ0OiBudW1iZXIsIGVuZDogbnVtYmVyLCBzaXplOiBudW1iZXIpIHtcbiAgY29uc3QgcmVzdWx0ID0gbmV3IE1hcDxudW1iZXIsIHsgaW5kZXg6IG51bWJlcjsgaWQ6IG51bWJlciB9W10+KCk7XG4gIGZvciAobGV0IGluZGV4ID0gc3RhcnQ7IGluZGV4IDwgZW5kOyBpbmRleCsrKSB7XG4gICAgY29uc3QgaWQgPSBvcmRlcltpbmRleF0sXG4gICAgICBncm91cCA9IE1hdGguZmxvb3IoaWQgLyBzaXplKTtcbiAgICBsZXQgZW50cmllcyA9IHJlc3VsdC5nZXQoZ3JvdXApO1xuICAgIGlmICghZW50cmllcykgcmVzdWx0LnNldChncm91cCwgKGVudHJpZXMgPSBbXSkpO1xuICAgIGVudHJpZXMucHVzaCh7IGluZGV4LCBpZCB9KTtcbiAgfVxuICByZXR1cm4gcmVzdWx0O1xufVxuZnVuY3Rpb24gY2hhbmdlc1N0eWxlcyhjb21tYW5kOiBDb21tYW5kKTogYm9vbGVhbiB7XG4gIHJldHVybiAoXG4gICAgY29tbWFuZC50eXBlID09PSAnY29yZS5jZWxscy5zdHlsZScgfHxcbiAgICAoKGNvbW1hbmQudHlwZSA9PT0gJ2NvcmUuY2VsbHMucGFzdGUnIHx8IGNvbW1hbmQudHlwZSA9PT0gJ2NvcmUuY2VsbHMucGFzdGVUaWxlJykgJiZcbiAgICAgIChjb21tYW5kLnBheWxvYWQgYXMgeyBjZWxsczogeyBzdHlsZT86IHVua25vd24gfVtdIH0pLmNlbGxzLnNvbWUoXG4gICAgICAgIChjZWxsKSA9PiBjZWxsLnN0eWxlICE9PSB1bmRlZmluZWQsXG4gICAgICApKVxuICApO1xufVxuZXhwb3J0IHR5cGUgQmxvY2sgPSB7IGNlbGxzOiBSZWNvcmQ8c3RyaW5nLCBDZWxsUmVjb3JkPjsgZGVwZW5kZW5jaWVzOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB9O1xudHlwZSBTdGFnZWRSZWFkUGFnZSA9IHsgYWRkcmVzcz86IHN0cmluZzsgcGFnZT86IENvbHVtblBhZ2UgfTtcbmNvbnN0IENPTkRJVElPTkFMX1JFQURfUEFHRV9CVURHRVQgPSAxMDI0ICogMTAyNDtcbmNvbnN0IFNFQVJDSF9ZSUVMRF9URVhUX1VOSVRTID0gMTAyNCAqIDEwMjQ7XG5leHBvcnQgdHlwZSBQb2ludGVyID0ge1xuICBpZDogc3RyaW5nO1xuICBieXRlczogbnVtYmVyO1xuICBjb3VudDogbnVtYmVyO1xuICBlbmRSb3c6IG51bWJlcjtcbiAgZW5kQ29sdW1uOiBudW1iZXI7XG4gIGZvcm11bGFzPzogc3RyaW5nW107XG4gIHN0eWxlcz86IHN0cmluZ1tdO1xuICByb3dNYXNrPzogc3RyaW5nO1xuICBjb2x1bW5NYXNrPzogbnVtYmVyO1xufTtcbnR5cGUgSGVhZCA9IHtcbiAgZW5naW5lRm9ybWF0VmVyc2lvbj86IG51bWJlcjtcbiAgZGlyZWN0b3J5PzogUmVjb3JkPHN0cmluZywgc3RyaW5nPjtcbiAgbWV0YTogc3RyaW5nO1xuICBibG9ja3M6IFJlY29yZDxzdHJpbmcsIFBvaW50ZXI+O1xuICByZXZpc2lvbjogbnVtYmVyO1xuICBwYXN0OiBzdHJpbmdbXTtcbiAgZnV0dXJlOiBzdHJpbmdbXTtcbiAgaGlzdG9yeUJ5dGVzOiBudW1iZXI7XG4gIGJ1ZGdldDogbnVtYmVyO1xufTtcbnR5cGUgTWV0YWRhdGEgPSB7XG4gIGltcG9ydFJldmlzaW9uPzogbnVtYmVyO1xuICBzbmFwc2hvdDogV29ya2Jvb2tTbmFwc2hvdDtcbiAgZmlsdGVyZWQ6IFJlY29yZDxzdHJpbmcsIG51bWJlcltdPjtcbn07XG50eXBlIFN0b3JlZE1ldGFkYXRhID0gT21pdDxNZXRhZGF0YSwgJ3NuYXBzaG90Jz4gJiB7IHNuYXBzaG90OiBXb3JrYm9va0ZpbGU7IHN0eWxlSWRzOiBzdHJpbmdbXSB9O1xuY29uc3QgZW5jb2RlTWV0YWRhdGEgPSAobWV0YWRhdGE6IE1ldGFkYXRhKTogU3RvcmVkTWV0YWRhdGEgPT4gKHtcbiAgLi4ubWV0YWRhdGEsXG4gIHNuYXBzaG90OiBlbmNvZGVXb3JrYm9va0ZpbGUobWV0YWRhdGEuc25hcHNob3QpLFxuICBzdHlsZUlkczogT2JqZWN0LmtleXMobWV0YWRhdGEuc25hcHNob3Quc3R5bGVzKSxcbn0pO1xudHlwZSBIaXN0b3J5ID0ge1xuICBiZWZvcmU6IHN0cmluZztcbiAgYWZ0ZXI6IHN0cmluZztcbiAgY2hhbmdlczogQXJyYXk8W3N0cmluZywgUG9pbnRlciB8IG51bGwsIFBvaW50ZXIgfCBudWxsXT47XG4gIGJ5dGVzOiBudW1iZXI7XG4gIHJhbmdlczogU2VsZWN0aW9uW107XG59O1xuZXhwb3J0IHR5cGUgRW5naW5lVmlldyA9IHtcbiAgbWV0YWRhdGFJZDogc3RyaW5nO1xuICByZXZpc2lvbjogbnVtYmVyO1xuICBpbXBvcnRSZXZpc2lvbj86IG51bWJlcjtcbiAgc25hcHNob3Q6IFdvcmtib29rU25hcHNob3Q7XG4gIGZpbHRlcmVkOiBSZWNvcmQ8c3RyaW5nLCBudW1iZXJbXT47XG4gIHVzZWQ6IFJlY29yZDxzdHJpbmcsIFJlY3Q+O1xuICBjYW5VbmRvOiBib29sZWFuO1xuICBjYW5SZWRvOiBib29sZWFuO1xuICBieXRlczogbnVtYmVyO1xuICBjYWNoZUJ5dGVzOiBudW1iZXI7XG4gIGJ1ZGdldDogbnVtYmVyO1xufTtcbmV4cG9ydCB0eXBlIFByb2dyZXNzID0geyBwaGFzZTogc3RyaW5nOyBjb21wbGV0ZWQ6IG51bWJlcjsgdG90YWw/OiBudW1iZXI7IGVsYXBzZWRNcz86IG51bWJlciB9O1xuZXhwb3J0IHR5cGUgUmVhZFRpbWluZyA9IHtcbiAgY2FjaGVIaXRzOiBudW1iZXI7XG4gIGNhY2hlTWlzc2VzOiBudW1iZXI7XG4gIGFic2VudFBhZ2VzOiBudW1iZXI7XG4gIHN0b3JhZ2VNczogbnVtYmVyO1xuICBkZWNvZGVNczogbnVtYmVyO1xuICBpbmZsYXRlTXM6IG51bWJlcjtcbiAgcGFnZURlY29kZU1zOiBudW1iZXI7XG59O1xuZXhwb3J0IGNvbnN0IGJsb2NrQWRkcmVzcyA9IChzaGVldDogc3RyaW5nLCByb3c6IG51bWJlciwgY29sdW1uOiBudW1iZXIpID0+XG4gIGAke3NoZWV0fS8ke01hdGguZmxvb3Iocm93IC8gQkxPQ0tfUk9XUyl9LyR7TWF0aC5mbG9vcihjb2x1bW4gLyBCTE9DS19DT0xVTU5TKX1gO1xuY29uc3QgcHJlZml4UmFuZ2UgPSAoaWQ6IHN0cmluZykgPT4gSURCS2V5UmFuZ2UuYm91bmQoYCR7aWR9L2AsIGAke2lkfS/vv79gKTtcbmV4cG9ydCBjbGFzcyBFbmdpbmUge1xuICBwcml2YXRlIGhlYWQhOiBIZWFkO1xuICBwcml2YXRlIG1ldGFkYXRhITogTWV0YWRhdGE7XG4gIHByaXZhdGUgdXNlZEJ5dGVzID0gMDtcbiAgcHJpdmF0ZSBhbGxvY2F0aW9uczogc3RyaW5nW10gPSBbXTtcbiAgcHJpdmF0ZSBhbGxvY2F0ZWQgPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgcHJpdmF0ZSBzdGFnaW5nQnl0ZXMgPSAwO1xuICBwcml2YXRlIHBpbnMgPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgcHJpdmF0ZSBheGVzID0gbmV3IFdlYWtNYXA8bnVtYmVyW10sIEF4aXNJbmRleD4oKTtcbiAgcHJpdmF0ZSBheGlzKGlkczogbnVtYmVyW10pIHtcbiAgICBsZXQgaW5kZXggPSB0aGlzLmF4ZXMuZ2V0KGlkcyk7XG4gICAgaWYgKCFpbmRleCkge1xuICAgICAgaW5kZXggPSBuZXcgQXhpc0luZGV4KGlkcyk7XG4gICAgICB0aGlzLmF4ZXMuc2V0KGlkcywgaW5kZXgpO1xuICAgIH1cbiAgICByZXR1cm4gaW5kZXg7XG4gIH1cbiAgcHJpdmF0ZSBpbmRpY2VzID0gbmV3IFdlYWtNYXA8b2JqZWN0LCB7IHJvd3M6IEF4aXNJbmRleDsgY29sczogQXhpc0luZGV4IH0+KCk7XG4gIHByaXZhdGUgZXhwb3J0QWRkcmVzc2VzOiBzdHJpbmdbXSB8IHVuZGVmaW5lZDtcbiAgcHJpdmF0ZSBzZWFyY2hSZXN1bHRzID0gbmV3IFdlYWtNYXA8XG4gICAgSGVhZCxcbiAgICB7IHNoZWV0SWQ6IHN0cmluZzsgcXVlcnk6IHN0cmluZzsgcG9zaXRpb25zOiBVaW50MzJBcnJheSB9XG4gID4oKTtcbiAgcHJpdmF0ZSBjb21wcmVzc2lvblF1ZXVlID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIHByaXZhdGUgZGlyZWN0b3J5RW50cmllcyA9IG5ldyBNYXA8c3RyaW5nLCBSZWNvcmQ8c3RyaW5nLCBQb2ludGVyPj4oKTtcbiAgcHJpdmF0ZSBvYnNlcnZlZEhlYWRTaWduYXR1cmU/OiBzdHJpbmc7XG4gIHByaXZhdGUgY2hhbmdlZCA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICBwcml2YXRlIHJlZmVyZW5jZXMgPSBuZXcgTWFwPHN0cmluZywgbnVtYmVyPigpO1xuICBwcml2YXRlIGhpc3RvcmllcyA9IG5ldyBNYXA8c3RyaW5nLCBIaXN0b3J5PigpO1xuICBwcml2YXRlIHVzZWQ6IFJlY29yZDxzdHJpbmcsIFJlY3Q+ID0ge307XG4gIHByaXZhdGUgc2l6ZXMgPSBuZXcgTWFwPHN0cmluZywgbnVtYmVyPigpO1xuICBwcml2YXRlIGNhY2hlOiBCeXRlQ2FjaGU8Q29sdW1uUGFnZT47XG4gIHByaXZhdGUgY2FuY2VsbGVkID0gZmFsc2U7XG4gIHByaXZhdGUgaW1wb3J0UmVhZD86IEFib3J0Q29udHJvbGxlcjtcbiAgcHJpdmF0ZSBwb2lzb25lZCA9IGZhbHNlO1xuICBwcml2YXRlIHdyaXRlciA9IGZhbHNlO1xuICBwcml2YXRlIHJlbGVhc2U/OiAoKSA9PiB2b2lkO1xuICBwcml2YXRlIGNhbGN1bGF0b3I6IEFzeW5jQ2FsY3VsYXRpb247XG4gIHByaXZhdGUgc2VlbjogQnl0ZUNhY2hlPHsgc2lnbmF0dXJlOiBzdHJpbmc7IGNvbW1pdD86IENvbW1pdCB9PjtcbiAgY29uc3RydWN0b3IoXG4gICAgcHJpdmF0ZSBkYjogRGF0YWJhc2UsXG4gICAgcmVhZG9ubHkgaWQ6IHN0cmluZyxcbiAgICBjYWNoZUJ5dGVzID0gNjQgKiAxMDI0ICogMTAyNCxcbiAgICBwcml2YXRlIHByb2dyZXNzOiAocDogUHJvZ3Jlc3MpID0+IHZvaWQgPSAoKSA9PiB7fSxcbiAgKSB7XG4gICAgY29uc3QgcmV0cnlCeXRlcyA9IE1hdGgubWluKDIgKiAxMDI0ICogMTAyNCwgTWF0aC5mbG9vcihjYWNoZUJ5dGVzIC8gMTYpKTtcbiAgICB0aGlzLnNlZW4gPSBuZXcgQnl0ZUNhY2hlKHJldHJ5Qnl0ZXMpO1xuICAgIGNvbnN0IGNhbGN1bGF0aW9uQnl0ZXMgPSBNYXRoLm1pbig0ICogMTAyNCAqIDEwMjQsIE1hdGguZmxvb3IoY2FjaGVCeXRlcyAvIDgpKTtcbiAgICB0aGlzLmNhY2hlID0gbmV3IEJ5dGVDYWNoZShNYXRoLm1heCgwLCBjYWNoZUJ5dGVzIC0gY2FsY3VsYXRpb25CeXRlcyAtIHJldHJ5Qnl0ZXMpKTtcbiAgICB0aGlzLmNhbGN1bGF0b3IgPSBuZXcgQXN5bmNDYWxjdWxhdGlvbihcbiAgICAgIChzLCByLCBjKSA9PiB0aGlzLmNlbGwocywgciwgYyksXG4gICAgICAobmFtZSkgPT5cbiAgICAgICAgdGhpcy5tZXRhZGF0YS5zbmFwc2hvdC5zaGVldHMuZmluZCgocykgPT4gcy5uYW1lLnRvTG93ZXJDYXNlKCkgPT09IG5hbWUudG9Mb3dlckNhc2UoKSk/LmlkLFxuICAgICAgY2FsY3VsYXRpb25CeXRlcyxcbiAgICAgIGFzeW5jIChzaGVldCwgcm93LCBjb2x1bW4pID0+IHtcbiAgICAgICAgY29uc3Qgc2ggPSB0aGlzLm1ldGFkYXRhLnNuYXBzaG90LnNoZWV0cy5maW5kKChzKSA9PiBzLmlkID09PSBzaGVldCkhO1xuICAgICAgICByZXR1cm4gKFxuICAgICAgICAgIGF3YWl0IHRoaXMuYmxvY2soXG4gICAgICAgICAgICBibG9ja0FkZHJlc3MoXG4gICAgICAgICAgICAgIHNoZWV0LFxuICAgICAgICAgICAgICB0aGlzLm1ldGFkYXRhLnNuYXBzaG90LnNoZWV0cy5maW5kKChzKSA9PiBzLmlkID09PSBzaGVldCkhLnJvd09yZGVyW3Jvd10sXG4gICAgICAgICAgICAgIHRoaXMubWV0YWRhdGEuc25hcHNob3Quc2hlZXRzLmZpbmQoKHMpID0+IHMuaWQgPT09IHNoZWV0KSEuY29sdW1uT3JkZXJbY29sdW1uXSxcbiAgICAgICAgICAgICksXG4gICAgICAgICAgKVxuICAgICAgICApLmRlcGVuZGVuY2llc1trZXkoc2gucm93T3JkZXJbcm93XSwgc2guY29sdW1uT3JkZXJbY29sdW1uXSldIGFzIEFTVCB8IG51bGwgfCB1bmRlZmluZWQ7XG4gICAgICB9LFxuICAgICAgKCkgPT4gdGhpcy5tZXRhZGF0YS5zbmFwc2hvdC5kYXRlU3lzdGVtLFxuICAgICk7XG4gIH1cbiAgZ2V0IGlzV3JpdGVyKCkge1xuICAgIHJldHVybiB0aGlzLndyaXRlcjtcbiAgfVxuICBhc3luYyBsb2NrKCkge1xuICAgIHRyeSB7XG4gICAgICBpZiAodHlwZW9mIG5hdmlnYXRvciAhPT0gJ3VuZGVmaW5lZCcgJiYgbmF2aWdhdG9yLmxvY2tzPy5yZXF1ZXN0KSB7XG4gICAgICAgIGF3YWl0IG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgICB2b2lkIG5hdmlnYXRvci5sb2Nrc1xuICAgICAgICAgICAgLnJlcXVlc3QoXG4gICAgICAgICAgICAgIGBvcGVuc2hlZXQ6JHt0aGlzLmRiLmRiLm5hbWV9OiR7dGhpcy5pZH1gLFxuICAgICAgICAgICAgICB7IGlmQXZhaWxhYmxlOiB0cnVlIH0sXG4gICAgICAgICAgICAgIGFzeW5jIChsb2NrKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy53cml0ZXIgPSAhIWxvY2s7XG4gICAgICAgICAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICAgICAgICAgIGlmIChsb2NrKVxuICAgICAgICAgICAgICAgICAgYXdhaXQgbmV3IFByb21pc2U8dm9pZD4oKHJlbGVhc2UpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5yZWxlYXNlID0gcmVsZWFzZTtcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgKVxuICAgICAgICAgICAgLmNhdGNoKHJlamVjdCk7XG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIGlmICh0eXBlb2Ygd2luZG93ID09PSAndW5kZWZpbmVkJyAmJiB0eXBlb2Ygc2VsZiA9PT0gJ3VuZGVmaW5lZCcpIHRoaXMud3JpdGVyID0gdHJ1ZTtcbiAgICAgIGVsc2VcbiAgICAgICAgdGhyb3cgbmV3IE9wZW5TaGVldEVycm9yKFxuICAgICAgICAgICdXRUJfTE9DS1NfVU5BVkFJTEFCTEUnLFxuICAgICAgICAgICdXZWIgTG9ja3MgaXMgcmVxdWlyZWQgZm9yIHNhZmUgbXVsdGktdGFiIGVkaXRpbmc7IG9wZW4gdGhpcyBhcHAgb3ZlciBIVFRQUyBvciBsb2NhbGhvc3QgaW4gYSBzdXBwb3J0ZWQgYnJvd3NlcicsXG4gICAgICAgICk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmICgoZXJyb3IgYXMgeyBuYW1lPzogdW5rbm93biB9KT8ubmFtZSA9PT0gJ1NlY3VyaXR5RXJyb3InKVxuICAgICAgICB0aHJvdyBuZXcgT3BlblNoZWV0RXJyb3IoXG4gICAgICAgICAgJ1dFQl9MT0NLU19VTkFWQUlMQUJMRScsXG4gICAgICAgICAgJ1dlYiBMb2NrcyBhY2Nlc3Mgd2FzIGRlbmllZDsgb3BlbiB0aGlzIGFwcCBvdmVyIEhUVFBTIG9yIGxvY2FsaG9zdCBpbiBhIHN1cHBvcnRlZCBicm93c2VyJyxcbiAgICAgICAgKTtcbiAgICAgIHRocm93IGVycm9yO1xuICAgIH1cbiAgfVxuICBhc3luYyB0cnlBY3F1aXJlV3JpdGVMb2NrKCkge1xuICAgIGlmICh0aGlzLndyaXRlcikgcmV0dXJuIHsgd3JpdGVyOiB0cnVlLCB2aWV3OiB0aGlzLnZpZXcoKSB9O1xuICAgIGF3YWl0IHRoaXMubG9jaygpO1xuICAgIGlmICghdGhpcy53cml0ZXIpIHJldHVybiB7IHdyaXRlcjogZmFsc2UgfTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgdGhpcy5yZWxvYWQoKTtcbiAgICAgIGF3YWl0IHRoaXMucmVjb3ZlcigpO1xuICAgICAgcmV0dXJuIHsgd3JpdGVyOiB0cnVlLCB2aWV3OiB0aGlzLnZpZXcoKSB9O1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICB0aGlzLnJlbGVhc2U/LigpO1xuICAgICAgdGhpcy5yZWxlYXNlID0gdW5kZWZpbmVkO1xuICAgICAgdGhpcy53cml0ZXIgPSBmYWxzZTtcbiAgICAgIHRocm93IGVycm9yO1xuICAgIH1cbiAgfVxuICBwcml2YXRlIGNoZWNrKCkge1xuICAgIGFzc2VydCghdGhpcy5jYW5jZWxsZWQsICdBQk9SVEVEJywgJ09wZXJhdGlvbiBjYW5jZWxsZWQnKTtcbiAgfVxuICBiZWdpbigpIHtcbiAgICBhc3NlcnQoIXRoaXMucG9pc29uZWQsICdXT1JLRVJfRkFJTEVEJywgJ1Jlb3BlbiB0aGUgd29ya2Jvb2sgYWZ0ZXIgYW4gdW5jZXJ0YWluIGNvbW1pdCcpO1xuICAgIHRoaXMuY2FuY2VsbGVkID0gZmFsc2U7XG4gIH1cbiAgY2FuY2VsKCkge1xuICAgIHRoaXMuY2FuY2VsbGVkID0gdHJ1ZTtcbiAgICB0aGlzLmltcG9ydFJlYWQ/LmFib3J0KG5ldyBPcGVuU2hlZXRFcnJvcignQUJPUlRFRCcsICdPcGVyYXRpb24gY2FuY2VsbGVkJykpO1xuICB9XG4gIGFzeW5jIG9wZW4oXG4gICAgaW5wdXQ/OiBXb3JrYm9va1NuYXBzaG90IHwgV29ya2Jvb2tGaWxlLFxuICAgIGJ1ZGdldCA9IDI1NiAqIDEwMjQgKiAxMDI0LFxuICAgIHByZXNlcnZlT3JwaGFucyA9IHRydWUsXG4gICkge1xuICAgIGFzc2VydChcbiAgICAgIE51bWJlci5pc1NhZmVJbnRlZ2VyKGJ1ZGdldCkgJiYgYnVkZ2V0ID4gMCxcbiAgICAgICdJTlZBTElEX0FSR1VNRU5UJyxcbiAgICAgICdTdG9yYWdlIGJ1ZGdldCBtdXN0IGJlIGEgcG9zaXRpdmUgaW50ZWdlcicsXG4gICAgKTtcbiAgICBjb25zdCBzbmFwc2hvdCA9XG4gICAgICBpbnB1dCAmJlxuICAgICAgKCdzaGVldE9yZGVyJyBpbiBpbnB1dFxuICAgICAgICA/IGlucHV0XG4gICAgICAgIDogZGVjb2RlRmlsZU1ldGFkYXRhKHtcbiAgICAgICAgICAgIC4uLmlucHV0LFxuICAgICAgICAgICAgc2hlZXRzOiBpbnB1dC5zaGVldHMubWFwKChzKSA9PiAoeyAuLi5zLCBibG9ja3M6IFtdIH0pKSxcbiAgICAgICAgICB9KSk7XG4gICAgYXdhaXQgdGhpcy5sb2NrKCk7XG4gICAgaWYgKCF0aGlzLndyaXRlcikge1xuICAgICAgYXdhaXQgdGhpcy5sb2FkUmVhZE9ubHkodHJ1ZSk7XG4gICAgICByZXR1cm4gdGhpcy52aWV3KCk7XG4gICAgfVxuICAgIGNvbnN0IHN0b3JlZEhlYWQgPSBhd2FpdCB0aGlzLmRiLmdldDxIZWFkPignaGVhZHMnLCB0aGlzLmlkKTtcbiAgICBjb25zdCBleGlzdGluZyA9IHN0b3JlZEhlYWQgPyBhd2FpdCB0aGlzLnJlc3RvcmVIZWFkKHN0b3JlZEhlYWQpIDogdW5kZWZpbmVkO1xuICAgIGlmIChleGlzdGluZykge1xuICAgICAgdGhpcy5oZWFkID0gZXhpc3Rpbmc7XG4gICAgICB0aGlzLm1ldGFkYXRhID0gYXdhaXQgdGhpcy5yZWFkTWV0YWRhdGEodGhpcy5oZWFkLm1ldGEpO1xuICAgICAgYXNzZXJ0KHRoaXMubWV0YWRhdGEsICdDT1JSVVBUX1NUT1JBR0UnLCAnV29ya2Jvb2sgbWV0YWRhdGEgaXMgbWlzc2luZycpO1xuICAgICAgdGhpcy5jaGVja0RpcmVjdG9yeVNoZWV0cygpO1xuICAgICAgLy8gVmlzaWJpbGl0eSBpcyBkZXJpdmVkIGZyb20gY2VsbHM7IHNjYWxhciBoaXN0b3J5IGVudHJpZXMgY2FuIHNoYXJlIG1ldGFkYXRhLlxuICAgICAgYXdhaXQgdGhpcy5maWx0ZXJzKHRoaXMuaGVhZCwgdGhpcy5tZXRhZGF0YSk7XG4gICAgICBhd2FpdCB0aGlzLnJlY292ZXIoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgYXNzZXJ0KHNuYXBzaG90ICYmIHRoaXMud3JpdGVyLCAnSU5WQUxJRF9BUkdVTUVOVCcsICdXb3JrYm9vayBkb2VzIG5vdCBleGlzdCBvciBpcyBsb2NrZWQnKTtcbiAgICAgIC8vIEV4aXN0aW5nIHJlY29yZHMgd2l0aG91dCBhIGhlYWQgbWF5IGJlIGFuIGludGVycnVwdGVkIGNyZWF0aW9uIG9yIGxvc3QgdXNlciBkYXRhLlxuICAgICAgaWYgKHByZXNlcnZlT3JwaGFucykge1xuICAgICAgICBjb25zdCByYW5nZSA9IHByZWZpeFJhbmdlKHRoaXMuaWQpO1xuICAgICAgICBjb25zdCBbcmVjb3Jkcywgc2l6ZXMsIHNjcmF0Y2hdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xuICAgICAgICAgIHRoaXMuZGIuaGFzQW55KCdyZWNvcmRzJywgcmFuZ2UpLFxuICAgICAgICAgIHRoaXMuZGIuaGFzQW55KCdzaXplcycsIHJhbmdlKSxcbiAgICAgICAgICB0aGlzLmRiLmhhc0FueSgnc2NyYXRjaCcsIHJhbmdlKSxcbiAgICAgICAgXSk7XG4gICAgICAgIGFzc2VydChcbiAgICAgICAgICAhcmVjb3JkcyAmJiAhc2l6ZXMgJiYgIXNjcmF0Y2gsXG4gICAgICAgICAgJ0NPUlJVUFRfU1RPUkFHRScsXG4gICAgICAgICAgJ1dvcmtib29rIGhlYWQgaXMgbWlzc2luZyBidXQgc3RvcmVkIGRhdGEgcmVtYWluczsgcmVzdG9yZSBhIGJhY2t1cCcsXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBhd2FpdCB0aGlzLmRiLndyaXRlKCdyZWNvcmRzJywgW10sIFtwcmVmaXhSYW5nZSh0aGlzLmlkKV0pO1xuICAgICAgYXdhaXQgdGhpcy5kYi53cml0ZSgnc2NyYXRjaCcsIFtdLCBbcHJlZml4UmFuZ2UodGhpcy5pZCldKTtcbiAgICAgIHRoaXMuaGVhZCA9IHtcbiAgICAgICAgbWV0YTogJycsXG4gICAgICAgIGJsb2Nrczoge30sXG4gICAgICAgIHJldmlzaW9uOiBzbmFwc2hvdC5yZXZpc2lvbixcbiAgICAgICAgcGFzdDogW10sXG4gICAgICAgIGZ1dHVyZTogW10sXG4gICAgICAgIGhpc3RvcnlCeXRlczogMCxcbiAgICAgICAgYnVkZ2V0LFxuICAgICAgfTtcbiAgICAgIHRoaXMudXNlZEJ5dGVzID0gcmVjb3JkQnl0ZXModGhpcy5pZCwgdGhpcy5zdG9yZWRIZWFkKHRoaXMuaGVhZCkpO1xuICAgICAgdGhpcy5tZXRhZGF0YSA9IHtcbiAgICAgICAgc25hcHNob3Q6IHsgLi4uc25hcHNob3QsIHNoZWV0czogc25hcHNob3Quc2hlZXRzLm1hcCgocykgPT4gKHsgLi4ucywgY2VsbHM6IHt9IH0pKSB9LFxuICAgICAgICBmaWx0ZXJlZDoge30sXG4gICAgICB9O1xuICAgICAgaWYgKGlucHV0ICYmICEoJ3NoZWV0T3JkZXInIGluIGlucHV0KSkgYXdhaXQgdGhpcy5pbXBvcnRKU09OKGlucHV0LCBidWRnZXQpO1xuICAgICAgZWxzZSBhd2FpdCB0aGlzLnJlcGxhY2Uoc25hcHNob3QsIGJ1ZGdldCk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLnZpZXcoKTtcbiAgfVxuICBwcml2YXRlIGFzeW5jIGxpdmVJZHMoaGVhZCA9IHRoaXMuaGVhZCkge1xuICAgIGNvbnN0IGlkcyA9IG5ldyBTZXQoW1xuICAgICAgaGVhZC5tZXRhLFxuICAgICAgLi4uT2JqZWN0LnZhbHVlcyhoZWFkLmJsb2NrcykubWFwKChwKSA9PiBwLmlkKSxcbiAgICAgIC4uLk9iamVjdC52YWx1ZXMoaGVhZC5kaXJlY3RvcnkgPz8ge30pLFxuICAgICAgLi4uaGVhZC5wYXN0LFxuICAgICAgLi4uaGVhZC5mdXR1cmUsXG4gICAgXSk7XG4gICAgZm9yIChjb25zdCBpZCBvZiBbLi4uaGVhZC5wYXN0LCAuLi5oZWFkLmZ1dHVyZV0pIHtcbiAgICAgIGNvbnN0IGggPSBhd2FpdCB0aGlzLnJlYWRIaXN0b3J5KGlkKTtcbiAgICAgIGlkcy5hZGQoaC5iZWZvcmUpO1xuICAgICAgaWRzLmFkZChoLmFmdGVyKTtcbiAgICAgIGZvciAoY29uc3QgWywgYSwgYl0gb2YgaC5jaGFuZ2VzKSB7XG4gICAgICAgIGlmIChhKSBpZHMuYWRkKGEuaWQpO1xuICAgICAgICBpZiAoYikgaWRzLmFkZChiLmlkKTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGlkcztcbiAgfVxuICBwcml2YXRlIGFzeW5jIGxpdmVCeXRlcygpIHtcbiAgICBsZXQgdG90YWwgPSByZWNvcmRCeXRlcyh0aGlzLmlkLCB0aGlzLnN0b3JlZEhlYWQodGhpcy5oZWFkKSk7XG4gICAgY29uc3QgaWRzID0gWy4uLihhd2FpdCB0aGlzLmxpdmVJZHMoKSldO1xuICAgIGNvbnN0IHNpemVzID0gYXdhaXQgdGhpcy5kYi5yZWNvcmRTaXplcyhpZHMpO1xuICAgIGlkcy5mb3JFYWNoKChpZCwgaSkgPT4ge1xuICAgICAgdG90YWwgKz0gc2l6ZXNbaV0gKyByZWNvcmRCeXRlcyhpZCwgc2l6ZXNbaV0pO1xuICAgIH0pO1xuICAgIHJldHVybiB0b3RhbDtcbiAgfVxuICBwcml2YXRlIHJldGFpbihpZDogc3RyaW5nLCBkZWx0YTogbnVtYmVyKSB7XG4gICAgaWYgKCFpZCkgcmV0dXJuO1xuICAgIGNvbnN0IGNvdW50ID0gKHRoaXMucmVmZXJlbmNlcy5nZXQoaWQpID8/IDApICsgZGVsdGE7XG4gICAgYXNzZXJ0KGNvdW50ID49IDAsICdDT1JSVVBUX1NUT1JBR0UnLCAnTmVnYXRpdmUgcmVjb3JkIHJlZmVyZW5jZSBjb3VudCcpO1xuICAgIGlmIChjb3VudCkgdGhpcy5yZWZlcmVuY2VzLnNldChpZCwgY291bnQpO1xuICAgIGVsc2UgdGhpcy5yZWZlcmVuY2VzLmRlbGV0ZShpZCk7XG4gIH1cbiAgcHJpdmF0ZSByZXRhaW5IaXN0b3J5KGlkOiBzdHJpbmcsIGg6IEhpc3RvcnksIGRlbHRhOiBudW1iZXIpIHtcbiAgICB0aGlzLnJldGFpbihpZCwgZGVsdGEpO1xuICAgIHRoaXMucmV0YWluKGguYmVmb3JlLCBkZWx0YSk7XG4gICAgdGhpcy5yZXRhaW4oaC5hZnRlciwgZGVsdGEpO1xuICAgIGZvciAoY29uc3QgWywgYSwgYl0gb2YgaC5jaGFuZ2VzKSB7XG4gICAgICBpZiAoYSkgdGhpcy5yZXRhaW4oYS5pZCwgZGVsdGEpO1xuICAgICAgaWYgKGIpIHRoaXMucmV0YWluKGIuaWQsIGRlbHRhKTtcbiAgICB9XG4gIH1cbiAgcHJpdmF0ZSB2YWxpZFBvaW50ZXIodmFsdWU6IHVua25vd24pOiB2YWx1ZSBpcyBQb2ludGVyIHtcbiAgICBpZiAoIXZhbHVlIHx8IHR5cGVvZiB2YWx1ZSAhPT0gJ29iamVjdCcgfHwgQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHJldHVybiBmYWxzZTtcbiAgICBjb25zdCBwb2ludGVyID0gdmFsdWUgYXMgUG9pbnRlcjtcbiAgICByZXR1cm4gKFxuICAgICAgT2JqZWN0LmtleXMocG9pbnRlcikuZXZlcnkoKGtleSkgPT5cbiAgICAgICAgW1xuICAgICAgICAgICdpZCcsXG4gICAgICAgICAgJ2J5dGVzJyxcbiAgICAgICAgICAnY291bnQnLFxuICAgICAgICAgICdlbmRSb3cnLFxuICAgICAgICAgICdlbmRDb2x1bW4nLFxuICAgICAgICAgICdmb3JtdWxhcycsXG4gICAgICAgICAgJ3N0eWxlcycsXG4gICAgICAgICAgJ3Jvd01hc2snLFxuICAgICAgICAgICdjb2x1bW5NYXNrJyxcbiAgICAgICAgXS5pbmNsdWRlcyhrZXkpLFxuICAgICAgKSAmJlxuICAgICAgdHlwZW9mIHBvaW50ZXIuaWQgPT09ICdzdHJpbmcnICYmXG4gICAgICBwb2ludGVyLmlkLnN0YXJ0c1dpdGgoYCR7dGhpcy5pZH0vYCkgJiZcbiAgICAgIE51bWJlci5pc1NhZmVJbnRlZ2VyKHBvaW50ZXIuYnl0ZXMpICYmXG4gICAgICBwb2ludGVyLmJ5dGVzID4gMCAmJlxuICAgICAgTnVtYmVyLmlzSW50ZWdlcihwb2ludGVyLmNvdW50KSAmJlxuICAgICAgcG9pbnRlci5jb3VudCA+PSAwICYmXG4gICAgICBwb2ludGVyLmNvdW50IDw9IEJMT0NLX1JPV1MgKiBCTE9DS19DT0xVTU5TICYmXG4gICAgICBOdW1iZXIuaXNJbnRlZ2VyKHBvaW50ZXIuZW5kUm93KSAmJlxuICAgICAgcG9pbnRlci5lbmRSb3cgPiAwICYmXG4gICAgICBwb2ludGVyLmVuZFJvdyA8PSBMSU1JVFMucm93cyAmJlxuICAgICAgTnVtYmVyLmlzSW50ZWdlcihwb2ludGVyLmVuZENvbHVtbikgJiZcbiAgICAgIHBvaW50ZXIuZW5kQ29sdW1uID4gMCAmJlxuICAgICAgcG9pbnRlci5lbmRDb2x1bW4gPD0gTElNSVRTLmNvbHVtbnMgJiZcbiAgICAgIChwb2ludGVyLnJvd01hc2sgPT09IHVuZGVmaW5lZCB8fFxuICAgICAgICAodHlwZW9mIHBvaW50ZXIucm93TWFzayA9PT0gJ3N0cmluZycgJiYgL15bXFxkYS1mXXsxLDE2fSQvaS50ZXN0KHBvaW50ZXIucm93TWFzaykpKSAmJlxuICAgICAgKHBvaW50ZXIuY29sdW1uTWFzayA9PT0gdW5kZWZpbmVkIHx8XG4gICAgICAgIChOdW1iZXIuaXNJbnRlZ2VyKHBvaW50ZXIuY29sdW1uTWFzaykgJiZcbiAgICAgICAgICBwb2ludGVyLmNvbHVtbk1hc2sgPj0gMCAmJlxuICAgICAgICAgIHBvaW50ZXIuY29sdW1uTWFzayA8PSAweGZmZmZmZmZmKSkgJiZcbiAgICAgIChwb2ludGVyLmZvcm11bGFzID09PSB1bmRlZmluZWQgfHxcbiAgICAgICAgKEFycmF5LmlzQXJyYXkocG9pbnRlci5mb3JtdWxhcykgJiZcbiAgICAgICAgICBwb2ludGVyLmZvcm11bGFzLmV2ZXJ5KChuYW1lKSA9PiB0eXBlb2YgbmFtZSA9PT0gJ3N0cmluZycpKSkgJiZcbiAgICAgIChwb2ludGVyLnN0eWxlcyA9PT0gdW5kZWZpbmVkIHx8XG4gICAgICAgIChBcnJheS5pc0FycmF5KHBvaW50ZXIuc3R5bGVzKSAmJlxuICAgICAgICAgIHBvaW50ZXIuc3R5bGVzLmV2ZXJ5KChzdHlsZSkgPT4gdHlwZW9mIHN0eWxlID09PSAnc3RyaW5nJykpKVxuICAgICk7XG4gIH1cbiAgcHJpdmF0ZSBhc3luYyByZWFkSGlzdG9yeShpZDogc3RyaW5nKTogUHJvbWlzZTxIaXN0b3J5PiB7XG4gICAgY29uc3QgaGlzdG9yeSA9IGF3YWl0IHRoaXMuZGIuZ2V0PEhpc3Rvcnk+KCdyZWNvcmRzJywgaWQpO1xuICAgIGNvbnN0IG93bmVkID0gKHZhbHVlOiB1bmtub3duKSA9PiB0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnICYmIHZhbHVlLnN0YXJ0c1dpdGgoYCR7dGhpcy5pZH0vYCk7XG4gICAgY29uc3QgcG9pbnRlciA9ICh2YWx1ZTogdW5rbm93bikgPT4gdmFsdWUgPT09IG51bGwgfHwgdGhpcy52YWxpZFBvaW50ZXIodmFsdWUpO1xuICAgIGNvbnN0IGFkZHJlc3MgPSAodmFsdWU6IHVua25vd24pID0+IHtcbiAgICAgIGlmICh0eXBlb2YgdmFsdWUgIT09ICdzdHJpbmcnKSByZXR1cm4gZmFsc2U7XG4gICAgICBjb25zdCBtYXRjaCA9IC9eW1xcdy1dK1xcLygwfFsxLTldXFxkKilcXC8oMHxbMS05XVxcZCopJC8uZXhlYyh2YWx1ZSk7XG4gICAgICByZXR1cm4gKFxuICAgICAgICAhIW1hdGNoICYmXG4gICAgICAgIE51bWJlcihtYXRjaFsxXSkgPD0gTWF0aC5mbG9vcigweGZmZmZmZmZmIC8gQkxPQ0tfUk9XUykgJiZcbiAgICAgICAgTnVtYmVyKG1hdGNoWzJdKSA8PSBNYXRoLmZsb29yKDB4ZmZmZmZmZmYgLyBCTE9DS19DT0xVTU5TKVxuICAgICAgKTtcbiAgICB9O1xuICAgIGFzc2VydChcbiAgICAgIGhpc3RvcnkgJiZcbiAgICAgICAgdHlwZW9mIGhpc3RvcnkgPT09ICdvYmplY3QnICYmXG4gICAgICAgICFBcnJheS5pc0FycmF5KGhpc3RvcnkpICYmXG4gICAgICAgIE9iamVjdC5rZXlzKGhpc3RvcnkpLmV2ZXJ5KChrZXkpID0+XG4gICAgICAgICAgWydiZWZvcmUnLCAnYWZ0ZXInLCAnY2hhbmdlcycsICdieXRlcycsICdyYW5nZXMnXS5pbmNsdWRlcyhrZXkpLFxuICAgICAgICApICYmXG4gICAgICAgIG93bmVkKGhpc3RvcnkuYmVmb3JlKSAmJlxuICAgICAgICBvd25lZChoaXN0b3J5LmFmdGVyKSAmJlxuICAgICAgICBOdW1iZXIuaXNTYWZlSW50ZWdlcihoaXN0b3J5LmJ5dGVzKSAmJlxuICAgICAgICBoaXN0b3J5LmJ5dGVzID49IDAgJiZcbiAgICAgICAgaGlzdG9yeS5ieXRlcyA8PSAzMiAqIDEwMjQgKiAxMDI0ICYmXG4gICAgICAgIEFycmF5LmlzQXJyYXkoaGlzdG9yeS5jaGFuZ2VzKSAmJlxuICAgICAgICBoaXN0b3J5LmNoYW5nZXMuZXZlcnkoXG4gICAgICAgICAgKGNoYW5nZSkgPT5cbiAgICAgICAgICAgIEFycmF5LmlzQXJyYXkoY2hhbmdlKSAmJlxuICAgICAgICAgICAgY2hhbmdlLmxlbmd0aCA9PT0gMyAmJlxuICAgICAgICAgICAgYWRkcmVzcyhjaGFuZ2VbMF0pICYmXG4gICAgICAgICAgICAoY2hhbmdlWzFdICE9PSBudWxsIHx8IGNoYW5nZVsyXSAhPT0gbnVsbCkgJiZcbiAgICAgICAgICAgIHBvaW50ZXIoY2hhbmdlWzFdKSAmJlxuICAgICAgICAgICAgcG9pbnRlcihjaGFuZ2VbMl0pLFxuICAgICAgICApICYmXG4gICAgICAgIG5ldyBTZXQoaGlzdG9yeS5jaGFuZ2VzLm1hcCgoY2hhbmdlKSA9PiBjaGFuZ2VbMF0pKS5zaXplID09PSBoaXN0b3J5LmNoYW5nZXMubGVuZ3RoICYmXG4gICAgICAgIEFycmF5LmlzQXJyYXkoaGlzdG9yeS5yYW5nZXMpICYmXG4gICAgICAgIGhpc3RvcnkucmFuZ2VzLmV2ZXJ5KFxuICAgICAgICAgIChyYW5nZSkgPT5cbiAgICAgICAgICAgIHJhbmdlICYmXG4gICAgICAgICAgICB0eXBlb2YgcmFuZ2UgPT09ICdvYmplY3QnICYmXG4gICAgICAgICAgICAhQXJyYXkuaXNBcnJheShyYW5nZSkgJiZcbiAgICAgICAgICAgIE9iamVjdC5rZXlzKHJhbmdlKS5ldmVyeSgoa2V5KSA9PlxuICAgICAgICAgICAgICBbJ3NoZWV0SWQnLCAnc3RhcnRSb3cnLCAnZW5kUm93JywgJ3N0YXJ0Q29sdW1uJywgJ2VuZENvbHVtbiddLmluY2x1ZGVzKGtleSksXG4gICAgICAgICAgICApICYmXG4gICAgICAgICAgICB0eXBlb2YgcmFuZ2Uuc2hlZXRJZCA9PT0gJ3N0cmluZycgJiZcbiAgICAgICAgICAgIE51bWJlci5pc0ludGVnZXIocmFuZ2Uuc3RhcnRSb3cpICYmXG4gICAgICAgICAgICByYW5nZS5zdGFydFJvdyA+PSAwICYmXG4gICAgICAgICAgICBOdW1iZXIuaXNJbnRlZ2VyKHJhbmdlLmVuZFJvdykgJiZcbiAgICAgICAgICAgIHJhbmdlLmVuZFJvdyA+IHJhbmdlLnN0YXJ0Um93ICYmXG4gICAgICAgICAgICByYW5nZS5lbmRSb3cgPD0gTElNSVRTLnJvd3MgJiZcbiAgICAgICAgICAgIE51bWJlci5pc0ludGVnZXIocmFuZ2Uuc3RhcnRDb2x1bW4pICYmXG4gICAgICAgICAgICByYW5nZS5zdGFydENvbHVtbiA+PSAwICYmXG4gICAgICAgICAgICBOdW1iZXIuaXNJbnRlZ2VyKHJhbmdlLmVuZENvbHVtbikgJiZcbiAgICAgICAgICAgIHJhbmdlLmVuZENvbHVtbiA+IHJhbmdlLnN0YXJ0Q29sdW1uICYmXG4gICAgICAgICAgICByYW5nZS5lbmRDb2x1bW4gPD0gTElNSVRTLmNvbHVtbnMsXG4gICAgICAgICksXG4gICAgICAnQ09SUlVQVF9TVE9SQUdFJyxcbiAgICAgICdJbnZhbGlkIHdvcmtib29rIGhpc3Rvcnk7IG9wZW4gd2l0aCBhIGNvbXBhdGlibGUgdmVyc2lvbiBvciByZXN0b3JlIGEgYmFja3VwJyxcbiAgICApO1xuICAgIHJldHVybiBoaXN0b3J5O1xuICB9XG4gIHByaXZhdGUgYXN5bmMgaW5pdGlhbGl6ZVJlZmVyZW5jZXMoKSB7XG4gICAgdGhpcy5yZWZlcmVuY2VzLmNsZWFyKCk7XG4gICAgdGhpcy5oaXN0b3JpZXMuY2xlYXIoKTtcbiAgICB0aGlzLnJldGFpbih0aGlzLmhlYWQubWV0YSwgMSk7XG4gICAgZm9yIChjb25zdCBpZCBvZiBPYmplY3QudmFsdWVzKHRoaXMuaGVhZC5kaXJlY3RvcnkgPz8ge30pKSB0aGlzLnJldGFpbihpZCwgMSk7XG4gICAgZm9yIChjb25zdCBwIG9mIE9iamVjdC52YWx1ZXModGhpcy5oZWFkLmJsb2NrcykpIHRoaXMucmV0YWluKHAuaWQsIDEpO1xuICAgIGxldCBwYXN0Qnl0ZXMgPSAwO1xuICAgIGNvbnN0IGNoZWNrZWRNZXRhZGF0YSA9IG5ldyBTZXQoW3RoaXMuaGVhZC5tZXRhXSk7XG4gICAgZm9yIChjb25zdCBbaW5kZXgsIGlkXSBvZiBbLi4udGhpcy5oZWFkLnBhc3QsIC4uLnRoaXMuaGVhZC5mdXR1cmVdLmVudHJpZXMoKSkge1xuICAgICAgY29uc3QgaCA9IGF3YWl0IHRoaXMucmVhZEhpc3RvcnkoaWQpO1xuICAgICAgZm9yIChjb25zdCBtZXRhZGF0YUlkIG9mIFtoLmJlZm9yZSwgaC5hZnRlcl0pIHtcbiAgICAgICAgaWYgKGNoZWNrZWRNZXRhZGF0YS5oYXMobWV0YWRhdGFJZCkpIGNvbnRpbnVlO1xuICAgICAgICAvLyBSZWZ1c2UgdG8gb3BlbiBhIGhpc3RvcnkgdGhhdCB0aGlzIGVuZ2luZSBjb3VsZCBuZWl0aGVyIHJlc3RvcmUgbm9yIHNhZmVseSBwcnVuZS5cbiAgICAgICAgY29uc3QgeyBzbmFwc2hvdCB9ID0gYXdhaXQgdGhpcy5yZWFkTWV0YWRhdGFFbnZlbG9wZShtZXRhZGF0YUlkKTtcbiAgICAgICAgLy8gUGVyc2lzdGVkIG1ldGFkYXRhIGhhcyBubyBjZWxsIHBhZ2VzLiBWYWxpZGF0ZSBpdHMgY29tcHJlc3NlZCBzaGFwZVxuICAgICAgICAvLyB3aXRob3V0IGFsbG9jYXRpbmcgdGhlIGV4cGFuZGVkIHJvdy9jb2x1bW4gb3JkZXJzIG9mIGVhY2ggcmV2aXNpb24uXG4gICAgICAgIGFzc2VydChcbiAgICAgICAgICBBcnJheS5pc0FycmF5KHNuYXBzaG90LnNoZWV0cykgJiZcbiAgICAgICAgICAgIHNuYXBzaG90LnNoZWV0cy5ldmVyeShcbiAgICAgICAgICAgICAgKHNoZWV0KSA9PiBBcnJheS5pc0FycmF5KHNoZWV0Py5ibG9ja3MpICYmIHNoZWV0LmJsb2Nrcy5sZW5ndGggPT09IDAsXG4gICAgICAgICAgICApLFxuICAgICAgICAgICdDT1JSVVBUX1NUT1JBR0UnLFxuICAgICAgICAgICdJbnZhbGlkIGhpc3RvcmljYWwgd29ya2Jvb2sgbWV0YWRhdGEnLFxuICAgICAgICApO1xuICAgICAgICB2YWxpZGF0ZUpTT05WYWx1ZShzbmFwc2hvdCk7XG4gICAgICAgIGFzc2VydChcbiAgICAgICAgICB3b3JrYm9va0ZpbGVTY2hlbWEuc2FmZVBhcnNlKHNuYXBzaG90KS5zdWNjZXNzLFxuICAgICAgICAgICdDT1JSVVBUX1NUT1JBR0UnLFxuICAgICAgICAgICdJbnZhbGlkIGhpc3RvcmljYWwgd29ya2Jvb2sgbWV0YWRhdGE7IG9wZW4gd2l0aCBhIGNvbXBhdGlibGUgdmVyc2lvbiBvciByZXN0b3JlIGEgYmFja3VwJyxcbiAgICAgICAgKTtcbiAgICAgICAgY2hlY2tlZE1ldGFkYXRhLmFkZChtZXRhZGF0YUlkKTtcbiAgICAgIH1cbiAgICAgIGlmIChpbmRleCA8IHRoaXMuaGVhZC5wYXN0Lmxlbmd0aCkgcGFzdEJ5dGVzICs9IGguYnl0ZXM7XG4gICAgICB0aGlzLmhpc3Rvcmllcy5zZXQoaWQsIGgpO1xuICAgICAgdGhpcy5yZXRhaW5IaXN0b3J5KGlkLCBoLCAxKTtcbiAgICB9XG4gICAgYXNzZXJ0KFxuICAgICAgcGFzdEJ5dGVzID09PSB0aGlzLmhlYWQuaGlzdG9yeUJ5dGVzLFxuICAgICAgJ0NPUlJVUFRfU1RPUkFHRScsXG4gICAgICAnV29ya2Jvb2sgaGlzdG9yeSBhY2NvdW50aW5nIGRpZmZlcnM7IHJlc3RvcmUgYSBiYWNrdXAnLFxuICAgICk7XG4gIH1cbiAgcHJpdmF0ZSBhc3luYyByZWNvdmVyKCkge1xuICAgIGF3YWl0IHRoaXMuaW5pdGlhbGl6ZVJlZmVyZW5jZXMoKTtcbiAgICBmb3IgKGNvbnN0IGlkIG9mIHRoaXMucmVmZXJlbmNlcy5rZXlzKCkpIHRoaXMuY29tcHJlc3Npb25RdWV1ZS5hZGQoaWQpO1xuICAgIGNvbnN0IGxpdmUgPSBhd2FpdCB0aGlzLmxpdmVJZHMoKTtcbiAgICBjb25zdCBsaXZlTGlzdCA9IFsuLi5saXZlXTtcbiAgICBjb25zdCBsZWRnZXIgPSBhd2FpdCB0aGlzLmRiLnJlY29yZFNpemVzKGxpdmVMaXN0KTtcbiAgICB0aGlzLnVzZWRCeXRlcyA9IHJlY29yZEJ5dGVzKHRoaXMuaWQsIHRoaXMuc3RvcmVkSGVhZCh0aGlzLmhlYWQpKTtcbiAgICB0aGlzLnNpemVzLmNsZWFyKCk7XG4gICAgbGl2ZUxpc3QuZm9yRWFjaCgoaWQsIGkpID0+IHtcbiAgICAgIGNvbnN0IGJ5dGVzID0gbGVkZ2VyW2ldICsgcmVjb3JkQnl0ZXMoaWQsIGxlZGdlcltpXSk7XG4gICAgICB0aGlzLnVzZWRCeXRlcyArPSBieXRlcztcbiAgICAgIHRoaXMuc2l6ZXMuc2V0KGlkLCBieXRlcyk7XG4gICAgfSk7XG4gICAgLy8gVmFsaWRhdGUgdGhlIGxlZGdlciBiZWZvcmUgYW55IHJlY2xhbWF0aW9uOyBhIGxhdGUgbWFsZm9ybWVkIGVudHJ5IG11c3Qgbm90XG4gICAgLy8gbGVhdmUgYSBwYXJ0aWFsbHkgY2xlYW5lZCBkYXRhYmFzZSB3aGVuIHJlY292ZXJ5IHJlcG9ydHMgZmFpbHVyZS5cbiAgICBmb3IgYXdhaXQgKGNvbnN0IGJhdGNoIG9mIHRoaXMuZGIuc2NhbjxudW1iZXI+KCdzaXplcycsIHByZWZpeFJhbmdlKHRoaXMuaWQpKSkge1xuICAgICAgZm9yIChjb25zdCBbLCB2YWx1ZV0gb2YgYmF0Y2gpXG4gICAgICAgIGFzc2VydChcbiAgICAgICAgICBOdW1iZXIuaXNTYWZlSW50ZWdlcih2YWx1ZSkgJiYgdmFsdWUgPiAwLFxuICAgICAgICAgICdDT1JSVVBUX1NUT1JBR0UnLFxuICAgICAgICAgICdJbnZhbGlkIHN0b3JhZ2UgbGVkZ2VyOyByZXN0b3JlIGEgYmFja3VwJyxcbiAgICAgICAgKTtcbiAgICB9XG4gICAgZm9yIGF3YWl0IChjb25zdCBiYXRjaCBvZiB0aGlzLmRiLnNjYW5LZXlzKCdzaXplcycsIHByZWZpeFJhbmdlKHRoaXMuaWQpKSkge1xuICAgICAgY29uc3QgZGVhZDogc3RyaW5nW10gPSBbXTtcbiAgICAgIGZvciAoY29uc3QgayBvZiBiYXRjaCkge1xuICAgICAgICBjb25zdCBpZCA9IFN0cmluZyhrKTtcbiAgICAgICAgaWYgKCFsaXZlLmhhcyhpZCkpIGRlYWQucHVzaChpZCk7XG4gICAgICB9XG4gICAgICBpZiAoZGVhZC5sZW5ndGgpIGF3YWl0IHRoaXMuZGIud3JpdGUoJ3JlY29yZHMnLCBbXSwgZGVhZCk7XG4gICAgfVxuICAgIGF3YWl0IHRoaXMuZGIud3JpdGUoJ3NjcmF0Y2gnLCBbXSwgW3ByZWZpeFJhbmdlKHRoaXMuaWQpXSk7XG4gIH1cbiAgYXN5bmMgcmVsb2FkKCkge1xuICAgIGlmICghdGhpcy53cml0ZXIpIHtcbiAgICAgIGF3YWl0IHRoaXMubG9hZFJlYWRPbmx5KGZhbHNlKTtcbiAgICAgIHJldHVybiB0aGlzLnZpZXcoKTtcbiAgICB9XG4gICAgY29uc3Qgc3RvcmVkSGVhZCA9IGF3YWl0IHRoaXMuZGIuZ2V0PEhlYWQ+KCdoZWFkcycsIHRoaXMuaWQpO1xuICAgIGFzc2VydChzdG9yZWRIZWFkLCAnQ09SUlVQVF9TVE9SQUdFJywgJ1dvcmtib29rIGhlYWQgaXMgbWlzc2luZzsgcmVzdG9yZSBhIGJhY2t1cCcpO1xuICAgIHRoaXMuaGVhZCA9IGF3YWl0IHRoaXMucmVzdG9yZUhlYWQoc3RvcmVkSGVhZCk7XG4gICAgdGhpcy5tZXRhZGF0YSA9IGF3YWl0IHRoaXMucmVhZE1ldGFkYXRhKHRoaXMuaGVhZC5tZXRhKTtcbiAgICB0aGlzLmNoZWNrRGlyZWN0b3J5U2hlZXRzKCk7XG4gICAgdGhpcy5leHBvcnRBZGRyZXNzZXMgPSB1bmRlZmluZWQ7XG4gICAgdGhpcy5jYWNoZS5jbGVhcigpO1xuICAgIHRoaXMuY2FsY3VsYXRvci5jbGVhcigpO1xuICAgIHRoaXMudXNlZEJ5dGVzID0gYXdhaXQgdGhpcy5saXZlQnl0ZXMoKTtcbiAgICBhd2FpdCB0aGlzLmluaXRpYWxpemVSZWZlcmVuY2VzKCk7XG4gICAgdGhpcy51c2VkID0ge307XG4gICAgcmV0dXJuIHRoaXMudmlldygpO1xuICB9XG4gIGFzeW5jIHJlbG9hZElmQ2hhbmdlZCgpIHtcbiAgICBjb25zdCBjdXJyZW50ID0gYXdhaXQgdGhpcy5kYi5nZXQ8SGVhZD4oJ2hlYWRzJywgdGhpcy5pZCk7XG4gICAgYXNzZXJ0KGN1cnJlbnQsICdDT1JSVVBUX1NUT1JBR0UnLCAnV29ya2Jvb2sgaGVhZCBpcyBtaXNzaW5nOyByZXN0b3JlIGEgYmFja3VwJyk7XG4gICAgaWYgKEpTT04uc3RyaW5naWZ5KGN1cnJlbnQpID09PSB0aGlzLm9ic2VydmVkSGVhZFNpZ25hdHVyZSkgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICByZXR1cm4gdGhpcy5yZWxvYWQoKTtcbiAgfVxuICBhc3luYyBoZWFkRXhpc3RzKCkge1xuICAgIHJldHVybiAoYXdhaXQgdGhpcy5kYi5nZXQ8SGVhZD4oJ2hlYWRzJywgdGhpcy5pZCkpICE9PSB1bmRlZmluZWQ7XG4gIH1cbiAgcHJpdmF0ZSBhc3luYyBsb2FkUmVhZE9ubHkoZGVyaXZlRmlsdGVyczogYm9vbGVhbikge1xuICAgIGNvbnN0IHN0YXJ0ZWQgPSBEYXRlLm5vdygpO1xuICAgIGZvciAobGV0IGF0dGVtcHQgPSAwOyBhdHRlbXB0IDwgNjQ7IGF0dGVtcHQrKykge1xuICAgICAgY29uc3Qgc3RvcmVkID0gYXdhaXQgdGhpcy5kYi5nZXQ8SGVhZD4oJ2hlYWRzJywgdGhpcy5pZCk7XG4gICAgICBhc3NlcnQoc3RvcmVkLCAnQ09SUlVQVF9TVE9SQUdFJywgJ1dvcmtib29rIGhlYWQgaXMgbWlzc2luZzsgcmVzdG9yZSBhIGJhY2t1cCcpO1xuICAgICAgY29uc3Qgc2lnbmF0dXJlID0gSlNPTi5zdHJpbmdpZnkoc3RvcmVkKTtcbiAgICAgIGxldCBmYWlsZWQgPSBmYWxzZSxcbiAgICAgICAgZmFpbHVyZTogdW5rbm93bjtcbiAgICAgIHRyeSB7XG4gICAgICAgIHRoaXMuaGVhZCA9IGF3YWl0IHRoaXMucmVzdG9yZUhlYWQoc3RvcmVkKTtcbiAgICAgICAgdGhpcy5tZXRhZGF0YSA9IGF3YWl0IHRoaXMucmVhZE1ldGFkYXRhKHRoaXMuaGVhZC5tZXRhKTtcbiAgICAgICAgdGhpcy5jaGVja0RpcmVjdG9yeVNoZWV0cygpO1xuICAgICAgICB0aGlzLmV4cG9ydEFkZHJlc3NlcyA9IHVuZGVmaW5lZDtcbiAgICAgICAgdGhpcy5jYWNoZS5jbGVhcigpO1xuICAgICAgICB0aGlzLmNhbGN1bGF0b3IuY2xlYXIoKTtcbiAgICAgICAgdGhpcy51c2VkID0ge307XG4gICAgICAgIGlmIChkZXJpdmVGaWx0ZXJzKSBhd2FpdCB0aGlzLmZpbHRlcnModGhpcy5oZWFkLCB0aGlzLm1ldGFkYXRhKTtcbiAgICAgICAgdGhpcy51c2VkQnl0ZXMgPSBhd2FpdCB0aGlzLmxpdmVCeXRlcygpO1xuICAgICAgICBhd2FpdCB0aGlzLmluaXRpYWxpemVSZWZlcmVuY2VzKCk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBmYWlsZWQgPSB0cnVlO1xuICAgICAgICBmYWlsdXJlID0gZXJyb3I7XG4gICAgICB9XG4gICAgICBjb25zdCBjdXJyZW50ID0gYXdhaXQgdGhpcy5kYi5nZXQ8SGVhZD4oJ2hlYWRzJywgdGhpcy5pZCk7XG4gICAgICBpZiAoSlNPTi5zdHJpbmdpZnkoY3VycmVudCkgIT09IHNpZ25hdHVyZSkge1xuICAgICAgICBpZiAoYXR0ZW1wdCA9PT0gNjMgfHwgRGF0ZS5ub3coKSAtIHN0YXJ0ZWQgPj0gNTAwMClcbiAgICAgICAgICB0aHJvdyBuZXcgT3BlblNoZWV0RXJyb3IoXG4gICAgICAgICAgICAnUkVWSVNJT05fQ09ORkxJQ1QnLFxuICAgICAgICAgICAgJ1dvcmtib29rIGNoYW5nZWQgd2hpbGUgb3BlbmluZzsgdHJ5IGFnYWluJyxcbiAgICAgICAgICApO1xuICAgICAgICBhd2FpdCBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSkgPT4gc2V0VGltZW91dChyZXNvbHZlLCAxMCkpO1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cbiAgICAgIGlmIChmYWlsZWQpIHRocm93IGZhaWx1cmU7XG4gICAgICB0aGlzLm9ic2VydmVkSGVhZFNpZ25hdHVyZSA9IHNpZ25hdHVyZTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gIH1cbiAgcHJpdmF0ZSBhc3luYyBhbGxvY2F0ZSh2YWx1ZTogdW5rbm93biwgYnVkZ2V0ID0gdGhpcy5oZWFkLmJ1ZGdldCkge1xuICAgIHRoaXMuY2hlY2soKTtcbiAgICBjb25zdCBpZCA9IGAke3RoaXMuaWR9LyR7dWlkKCdyZWNvcmQnKX1gO1xuICAgIGNvbnN0IHJhd0J5dGVzID0gcmVjb3JkQnl0ZXMoaWQsIHZhbHVlKTtcbiAgICBjb25zdCBieXRlcyA9IHJhd0J5dGVzICsgcmVjb3JkQnl0ZXMoaWQsIHJhd0J5dGVzKTtcbiAgICBhc3NlcnQoXG4gICAgICB0aGlzLnVzZWRCeXRlcyArIHRoaXMuc3RhZ2luZ0J5dGVzICsgYnl0ZXMgPD0gYnVkZ2V0LFxuICAgICAgJ1NUT1JBR0VfQlVER0VUJyxcbiAgICAgICdBcHBsaWNhdGlvbiBzdG9yYWdlIGJ1ZGdldCBleGNlZWRlZCAoaW5jbHVkaW5nIHN0YWdpbmcgYW5kIGhpc3RvcnkpJyxcbiAgICApO1xuICAgIGF3YWl0IHRoaXMuZGIud3JpdGUoJ3JlY29yZHMnLCBbW2lkLCB2YWx1ZV1dKTtcbiAgICB0aGlzLnVzZWRCeXRlcyArPSBieXRlcztcbiAgICB0aGlzLnNpemVzLnNldChpZCwgYnl0ZXMpO1xuICAgIHRoaXMuYWxsb2NhdGlvbnMucHVzaChpZCk7XG4gICAgdGhpcy5hbGxvY2F0ZWQuYWRkKGlkKTtcbiAgICByZXR1cm4gaWQ7XG4gIH1cbiAgcHJpdmF0ZSBhc3luYyByZWFkTWV0YWRhdGFFbnZlbG9wZShpZDogc3RyaW5nKTogUHJvbWlzZTxTdG9yZWRNZXRhZGF0YT4ge1xuICAgIGNvbnN0IHN0b3JlZCA9IGF3YWl0IHRoaXMuZGIuZ2V0PFN0b3JlZE1ldGFkYXRhPigncmVjb3JkcycsIGlkKTtcbiAgICBhc3NlcnQoc3RvcmVkLCAnQ09SUlVQVF9TVE9SQUdFJywgJ1dvcmtib29rIG1ldGFkYXRhIGlzIG1pc3NpbmcnKTtcbiAgICBhc3NlcnQoXG4gICAgICB0eXBlb2Ygc3RvcmVkID09PSAnb2JqZWN0JyAmJlxuICAgICAgICAhQXJyYXkuaXNBcnJheShzdG9yZWQpICYmXG4gICAgICAgIE9iamVjdC5rZXlzKHN0b3JlZCkuZXZlcnkoKGtleSkgPT5cbiAgICAgICAgICBbJ3NuYXBzaG90JywgJ3N0eWxlSWRzJywgJ2ZpbHRlcmVkJywgJ2ltcG9ydFJldmlzaW9uJ10uaW5jbHVkZXMoa2V5KSxcbiAgICAgICAgKSxcbiAgICAgICdDT1JSVVBUX1NUT1JBR0UnLFxuICAgICAgJ1Vua25vd24gc3RvcmVkIHdvcmtib29rIG1ldGFkYXRhOyBvcGVuIHdpdGggYSBjb21wYXRpYmxlIHZlcnNpb24gb3IgcmVzdG9yZSBhIGJhY2t1cCcsXG4gICAgKTtcbiAgICBjb25zdCB2ZXJzaW9uID0gc3RvcmVkLnNuYXBzaG90Py5zY2hlbWFWZXJzaW9uO1xuICAgIGFzc2VydChcbiAgICAgIE51bWJlci5pc1NhZmVJbnRlZ2VyKHZlcnNpb24pICYmIHZlcnNpb24gPiAwLFxuICAgICAgJ0NPUlJVUFRfU1RPUkFHRScsXG4gICAgICAnSW52YWxpZCBzdG9yZWQgd29ya2Jvb2sgc2NoZW1hJyxcbiAgICApO1xuICAgIGFzc2VydChcbiAgICAgIHZlcnNpb24gPT09IDMsXG4gICAgICAnVU5TVVBQT1JURURfVkVSU0lPTicsXG4gICAgICBgU3RvcmVkIHdvcmtib29rIHNjaGVtYSAke3ZlcnNpb259IGlzIHVuc3VwcG9ydGVkOyB1c2UgYSBjb21wYXRpYmxlIHZlcnNpb25gLFxuICAgICk7XG4gICAgcmV0dXJuIHN0b3JlZDtcbiAgfVxuICBwcml2YXRlIGFzeW5jIHJlYWRNZXRhZGF0YShpZDogc3RyaW5nKTogUHJvbWlzZTxNZXRhZGF0YT4ge1xuICAgIGNvbnN0IHN0b3JlZCA9IGF3YWl0IHRoaXMucmVhZE1ldGFkYXRhRW52ZWxvcGUoaWQpO1xuICAgIGNvbnN0IHNuYXBzaG90ID0gZGVjb2RlRmlsZU1ldGFkYXRhKHN0b3JlZC5zbmFwc2hvdCk7XG4gICAgYXNzZXJ0KFxuICAgICAgQXJyYXkuaXNBcnJheShzdG9yZWQuc3R5bGVJZHMpICYmXG4gICAgICAgIHN0b3JlZC5zdHlsZUlkcy5sZW5ndGggPT09IHN0b3JlZC5zbmFwc2hvdC5zdHlsZXMubGVuZ3RoICYmXG4gICAgICAgIG5ldyBTZXQoc3RvcmVkLnN0eWxlSWRzKS5zaXplID09PSBzdG9yZWQuc3R5bGVJZHMubGVuZ3RoICYmXG4gICAgICAgIHN0b3JlZC5zdHlsZUlkcy5ldmVyeShcbiAgICAgICAgICAoaWQpID0+IC9eWy1cXHddKyQvLnRlc3QoaWQpICYmICFbJ19fcHJvdG9fXycsICdwcm90b3R5cGUnLCAnY29uc3RydWN0b3InXS5pbmNsdWRlcyhpZCksXG4gICAgICAgICksXG4gICAgICAnQ09SUlVQVF9TVE9SQUdFJyxcbiAgICAgICdJbnZhbGlkIHN0b3JlZCBzdHlsZSBpZGVudGl0aWVzJyxcbiAgICApO1xuICAgIHNuYXBzaG90LnN0eWxlcyA9IE9iamVjdC5mcm9tRW50cmllcyhcbiAgICAgIHN0b3JlZC5zdHlsZUlkcy5tYXAoKGlkLCBpKSA9PiBbaWQsIHN0b3JlZC5zbmFwc2hvdC5zdHlsZXNbaV1dKSxcbiAgICApO1xuICAgIGNvbnN0IHsgc3R5bGVJZHMsIC4uLm1ldGFkYXRhIH0gPSBzdG9yZWQ7XG4gICAgcmV0dXJuIHsgLi4ubWV0YWRhdGEsIHNuYXBzaG90IH07XG4gIH1cbiAgcHJpdmF0ZSBjb21wYXJlQWRkcmVzcyhhOiBzdHJpbmcsIGI6IHN0cmluZykge1xuICAgIGNvbnN0IFtzYSwgcmEsIGNhXSA9IGEuc3BsaXQoJy8nKSxcbiAgICAgIFtzYiwgcmIsIGNiXSA9IGIuc3BsaXQoJy8nKTtcbiAgICByZXR1cm4gc2EgPCBzYiA/IC0xIDogc2EgPiBzYiA/IDEgOiArcmEgLSArcmIgfHwgK2NhIC0gK2NiO1xuICB9XG4gIGV4cG9ydEluZGV4KHJldmlzaW9uOiBudW1iZXIsIGFmdGVyPzogc3RyaW5nLCBjb3VudCA9IDMyLCBzaGVldElkPzogc3RyaW5nKTogc3RyaW5nW10ge1xuICAgIGFzc2VydChyZXZpc2lvbiA9PT0gdGhpcy5oZWFkLnJldmlzaW9uLCAnUkVWSVNJT05fQ09ORkxJQ1QnLCAnV29ya2Jvb2sgY2hhbmdlZCBkdXJpbmcgZXhwb3J0Jyk7XG4gICAgYXNzZXJ0KFxuICAgICAgTnVtYmVyLmlzSW50ZWdlcihjb3VudCkgJiYgY291bnQgPiAwICYmIGNvdW50IDw9IDY0LFxuICAgICAgJ0lOVkFMSURfQVJHVU1FTlQnLFxuICAgICAgJ0ludmFsaWQgcGFnZSBiYXRjaCcsXG4gICAgKTtcbiAgICBjb25zdCBhZGRyZXNzZXMgPSAodGhpcy5leHBvcnRBZGRyZXNzZXMgPz89IE9iamVjdC5rZXlzKHRoaXMuaGVhZC5ibG9ja3MpLnNvcnQoKGEsIGIpID0+XG4gICAgICB0aGlzLmNvbXBhcmVBZGRyZXNzKGEsIGIpLFxuICAgICkpO1xuICAgIGxldCBsb3cgPSAwLFxuICAgICAgaGlnaCA9IGFkZHJlc3Nlcy5sZW5ndGg7XG4gICAgY29uc3QgYmVmb3JlID0gKGFkZHJlc3M6IHN0cmluZykgPT5cbiAgICAgIGFmdGVyXG4gICAgICAgID8gdGhpcy5jb21wYXJlQWRkcmVzcyhhZGRyZXNzLCBhZnRlcikgPD0gMFxuICAgICAgICA6IHNoZWV0SWRcbiAgICAgICAgICA/IGFkZHJlc3Muc3BsaXQoJy8nKVswXSA8IHNoZWV0SWRcbiAgICAgICAgICA6IGZhbHNlO1xuICAgIHdoaWxlIChsb3cgPCBoaWdoKSB7XG4gICAgICBjb25zdCBtaWQgPSAobG93ICsgaGlnaCkgPj4+IDE7XG4gICAgICBpZiAoYmVmb3JlKGFkZHJlc3Nlc1ttaWRdKSkgbG93ID0gbWlkICsgMTtcbiAgICAgIGVsc2UgaGlnaCA9IG1pZDtcbiAgICB9XG4gICAgY29uc3Qgb3V0cHV0OiBzdHJpbmdbXSA9IFtdO1xuICAgIGZvciAobGV0IGkgPSBsb3c7IGkgPCBhZGRyZXNzZXMubGVuZ3RoICYmIG91dHB1dC5sZW5ndGggPCBjb3VudDsgaSsrKSB7XG4gICAgICBjb25zdCBhZGRyZXNzID0gYWRkcmVzc2VzW2ldO1xuICAgICAgaWYgKHNoZWV0SWQgJiYgIWFkZHJlc3Muc3RhcnRzV2l0aChgJHtzaGVldElkfS9gKSkgYnJlYWs7XG4gICAgICBvdXRwdXQucHVzaChhZGRyZXNzKTtcbiAgICB9XG4gICAgcmV0dXJuIG91dHB1dDtcbiAgfVxuICBleHBvcnRTdHlsZXMocmV2aXNpb246IG51bWJlcikge1xuICAgIGFzc2VydChyZXZpc2lvbiA9PT0gdGhpcy5oZWFkLnJldmlzaW9uLCAnUkVWSVNJT05fQ09ORkxJQ1QnLCAnV29ya2Jvb2sgY2hhbmdlZCBkdXJpbmcgZXhwb3J0Jyk7XG4gICAgY29uc3QgdXNlZCA9IG5ldyBTZXQoXG4gICAgICBPYmplY3QudmFsdWVzKHRoaXMuaGVhZC5ibG9ja3MpLmZsYXRNYXAoKHBvaW50ZXIpID0+IHBvaW50ZXIuc3R5bGVzID8/IFtdKSxcbiAgICApO1xuICAgIHJldHVybiBPYmplY3Qua2V5cyh0aGlzLm1ldGFkYXRhLnNuYXBzaG90LnN0eWxlcykuZmlsdGVyKChpZCkgPT4gdXNlZC5oYXMoaWQpKTtcbiAgfVxuICBhc3luYyBleHBvcnRCbG9jayhhZGRyZXNzOiBzdHJpbmcsIHJldmlzaW9uOiBudW1iZXIpOiBQcm9taXNlPEVuY29kZWRCbG9jaz4ge1xuICAgIGFzc2VydChyZXZpc2lvbiA9PT0gdGhpcy5oZWFkLnJldmlzaW9uLCAnUkVWSVNJT05fQ09ORkxJQ1QnLCAnV29ya2Jvb2sgY2hhbmdlZCBkdXJpbmcgZXhwb3J0Jyk7XG4gICAgY29uc3QgcG9pbnRlciA9IHRoaXMuaGVhZC5ibG9ja3NbYWRkcmVzc107XG4gICAgYXNzZXJ0KHBvaW50ZXIsICdJTlZBTElEX0FSR1VNRU5UJywgJ1Vua25vd24gZXhwb3J0IGJsb2NrJyk7XG4gICAgY29uc3QgZW5jb2RlZCA9IGF3YWl0IHRoaXMuZGIuZ2V0PEVuY29kZWRCbG9jaz4oJ3JlY29yZHMnLCBwb2ludGVyLmlkKTtcbiAgICB0aGlzLmNoZWNrKCk7XG4gICAgYXNzZXJ0KGVuY29kZWQsICdDT1JSVVBUX1NUT1JBR0UnLCAnRXhwb3J0IGJsb2NrIGlzIG1pc3NpbmcnKTtcbiAgICBhc3NlcnQocmV2aXNpb24gPT09IHRoaXMuaGVhZC5yZXZpc2lvbiwgJ1JFVklTSU9OX0NPTkZMSUNUJywgJ1dvcmtib29rIGNoYW5nZWQgZHVyaW5nIGV4cG9ydCcpO1xuICAgIHJldHVybiB0aGlzLmluZmxhdGUoZW5jb2RlZCk7XG4gIH1cbiAgcHJpdmF0ZSBhc3luYyBpbmZsYXRlKGJ5dGVzOiBVaW50OEFycmF5KSB7XG4gICAgaWYgKGJ5dGVzWzBdICE9PSA3OSB8fCBieXRlc1sxXSAhPT0gODMgfHwgYnl0ZXNbMl0gIT09IDcxKSByZXR1cm4gYnl0ZXM7XG4gICAgYXNzZXJ0KGJ5dGVzLmxlbmd0aCA+PSAxMiAmJiBieXRlc1szXSA9PT0gMywgJ0NPUlJVUFRfU1RPUkFHRScsICdJbnZhbGlkIGNvbXByZXNzZWQgcGFnZScpO1xuICAgIGNvbnN0IHZpZXcgPSBuZXcgRGF0YVZpZXcoYnl0ZXMuYnVmZmVyLCBieXRlcy5ieXRlT2Zmc2V0LCBieXRlcy5ieXRlTGVuZ3RoKTtcbiAgICBjb25zdCBwYWdlID0gYXdhaXQgdW5wYWNrUGFnZShieXRlcy5zdWJhcnJheSgxMiksIDEsIHZpZXcuZ2V0VWludDMyKDQsIHRydWUpKTtcbiAgICBhc3NlcnQoXG4gICAgICBjcmMzMihwYWdlKSA9PT0gdmlldy5nZXRVaW50MzIoOCwgdHJ1ZSksXG4gICAgICAnQ09SUlVQVF9TVE9SQUdFJyxcbiAgICAgICdTdG9yZWQgcGFnZSBjaGVja3N1bSBkaWZmZXJzJyxcbiAgICApO1xuICAgIHJldHVybiBwYWdlO1xuICB9XG4gIGdldCBoYXNQZW5kaW5nQ29tcGFjdGlvbigpIHtcbiAgICByZXR1cm4gdGhpcy5jb21wcmVzc2lvblF1ZXVlLnNpemUgPiAwO1xuICB9XG4gIGFzeW5jIGNvbXBhY3QoY291bnQgPSA4KSB7XG4gICAgaWYgKCF0aGlzLndyaXRlcikgcmV0dXJuO1xuICAgIGZvciAoY29uc3QgaWQgb2YgWy4uLnRoaXMuY29tcHJlc3Npb25RdWV1ZV0uc2xpY2UoMCwgY291bnQpKSB7XG4gICAgICB0aGlzLmNvbXByZXNzaW9uUXVldWUuZGVsZXRlKGlkKTtcbiAgICAgIGlmICghdGhpcy5yZWZlcmVuY2VzLmhhcyhpZCkpIGNvbnRpbnVlO1xuICAgICAgY29uc3QgYnl0ZXMgPSBhd2FpdCB0aGlzLmRiLmdldDx1bmtub3duPigncmVjb3JkcycsIGlkKTtcbiAgICAgIGlmICghKGJ5dGVzIGluc3RhbmNlb2YgVWludDhBcnJheSkgfHwgYnl0ZXMubGVuZ3RoIDwgNTEyIHx8IGJ5dGVzWzJdICE9PSA4MCkgY29udGludWU7XG4gICAgICBjb25zdCBjb21wcmVzc2VkID0gYXdhaXQgZ3ppcFBhZ2UoYnl0ZXMpO1xuICAgICAgaWYgKGNvbXByZXNzZWQuY29kZWMgPT09IDAgfHwgY29tcHJlc3NlZC5ieXRlcy5sZW5ndGggKyAxMiA+IGJ5dGVzLmxlbmd0aCAqIDAuOSkgY29udGludWU7XG4gICAgICBjb25zdCByZWNvcmQgPSBuZXcgVWludDhBcnJheShjb21wcmVzc2VkLmJ5dGVzLmxlbmd0aCArIDEyKSxcbiAgICAgICAgdmlldyA9IG5ldyBEYXRhVmlldyhyZWNvcmQuYnVmZmVyKTtcbiAgICAgIHJlY29yZC5zZXQoWzc5LCA4MywgNzEsIDNdKTtcbiAgICAgIHZpZXcuc2V0VWludDMyKDQsIGJ5dGVzLmxlbmd0aCwgdHJ1ZSk7XG4gICAgICB2aWV3LnNldFVpbnQzMig4LCBjcmMzMihieXRlcyksIHRydWUpO1xuICAgICAgcmVjb3JkLnNldChjb21wcmVzc2VkLmJ5dGVzLCAxMik7XG4gICAgICBjb25zdCByYXcgPSByZWNvcmRCeXRlcyhpZCwgcmVjb3JkKSxcbiAgICAgICAgc2l6ZSA9IHJhdyArIHJlY29yZEJ5dGVzKGlkLCByYXcpLFxuICAgICAgICBvbGQgPSB0aGlzLnNpemVzLmdldChpZCkhO1xuICAgICAgLy8gSW5jbHVkZSByZXBsYWNlbWVudCBzdGFnaW5nIGJlZm9yZSB0aGUgYXRvbWljIHJlY29yZC9sZWRnZXIgdHJhbnNhY3Rpb24uXG4gICAgICBpZiAodGhpcy51c2VkQnl0ZXMgKyBzaXplID4gdGhpcy5oZWFkLmJ1ZGdldCkgY29udGludWU7XG4gICAgICBhd2FpdCB0aGlzLmRiLndyaXRlKCdyZWNvcmRzJywgW1tpZCwgcmVjb3JkXV0pO1xuICAgICAgdGhpcy5zaXplcy5zZXQoaWQsIHNpemUpO1xuICAgICAgdGhpcy51c2VkQnl0ZXMgKz0gc2l6ZSAtIG9sZDtcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgIGJ5dGVzOiB0aGlzLnVzZWRCeXRlcyxcbiAgICAgIGNhY2hlQnl0ZXM6IHRoaXMuY2FjaGUuYnl0ZXMgKyB0aGlzLmNhbGN1bGF0b3IuY2FjaGVCeXRlcyArIHRoaXMuc2Vlbi5ieXRlcyxcbiAgICB9O1xuICB9XG4gIHByaXZhdGUgYXN5bmMgY29sbGVjdChjYW5kaWRhdGVzOiBJdGVyYWJsZTxzdHJpbmc+KSB7XG4gICAgaWYgKHRoaXMucG9pc29uZWQpIHJldHVybjtcbiAgICBjb25zdCBkZWFkID0gWy4uLm5ldyBTZXQoY2FuZGlkYXRlcyldLmZpbHRlcigoaWQpID0+ICF0aGlzLnJlZmVyZW5jZXMuaGFzKGlkKSk7XG4gICAgaWYgKGRlYWQubGVuZ3RoKSBhd2FpdCB0aGlzLmRiLndyaXRlKCdyZWNvcmRzJywgW10sIGRlYWQpO1xuICAgIGZvciAoY29uc3QgaWQgb2YgZGVhZCkge1xuICAgICAgdGhpcy51c2VkQnl0ZXMgLT0gdGhpcy5zaXplcy5nZXQoaWQpID8/IDA7XG4gICAgICB0aGlzLnNpemVzLmRlbGV0ZShpZCk7XG4gICAgICB0aGlzLmNhY2hlLmRlbGV0ZShpZCk7XG4gICAgfVxuICB9XG4gIHByaXZhdGUgYXN5bmMgY2xlYW51cChjYW5kaWRhdGVzOiBJdGVyYWJsZTxzdHJpbmc+KSB7XG4gICAgLy8gRmFpbGVkIHJlY2xhbWF0aW9uIHJlbWFpbnMgY2hhcmdlZCBhbmQgaXMgcmV0cmllZCBvbiByZW9wZW4uIEl0IG11c3Qgbm90XG4gICAgLy8gcmVwbGFjZSBlaXRoZXIgYSBzdWNjZXNzZnVsIGNvbW1pdCBvciB0aGUgb3JpZ2luYWwgb3BlcmF0aW9uIGVycm9yLlxuICAgIHRyeSB7XG4gICAgICBhd2FpdCB0aGlzLmNvbGxlY3QoY2FuZGlkYXRlcyk7XG4gICAgfSBjYXRjaCB7XG4gICAgICAvKiBLZWVwIHVucmVjbGFpbWVkIGJ5dGVzIGNoYXJnZWQuICovXG4gICAgfVxuICB9XG4gIHByaXZhdGUgYnVja2V0KGFkZHJlc3M6IHN0cmluZykge1xuICAgIGxldCBoYXNoID0gMjE2NjEzNjI2MTtcbiAgICBmb3IgKGNvbnN0IGMgb2YgYWRkcmVzcykgaGFzaCA9IE1hdGguaW11bChoYXNoIF4gYy5jaGFyQ29kZUF0KDApLCAxNjc3NzYxOSk7XG4gICAgcmV0dXJuIFN0cmluZygoaGFzaCA+Pj4gMCkgJSAyNTYpO1xuICB9XG4gIHByaXZhdGUgc3RvcmVkSGVhZChoZWFkOiBIZWFkKSB7XG4gICAgY29uc3QgeyBibG9ja3MsIC4uLnJlc3QgfSA9IGhlYWQ7XG4gICAgcmV0dXJuIHsgLi4ucmVzdCwgZGlyZWN0b3J5OiBoZWFkLmRpcmVjdG9yeSA/PyB7fSB9O1xuICB9XG4gIHByaXZhdGUgY2hlY2tEaXJlY3RvcnlTaGVldHMoKSB7XG4gICAgY29uc3Qgc2hlZXRJZHMgPSBuZXcgU2V0KHRoaXMubWV0YWRhdGEuc25hcHNob3Quc2hlZXRzLm1hcCgoc2hlZXQpID0+IHNoZWV0LmlkKSk7XG4gICAgYXNzZXJ0KFxuICAgICAgT2JqZWN0LmtleXModGhpcy5oZWFkLmJsb2NrcykuZXZlcnkoKGFkZHJlc3MpID0+IHNoZWV0SWRzLmhhcyhhZGRyZXNzLnNwbGl0KCcvJylbMF0pKSxcbiAgICAgICdDT1JSVVBUX1NUT1JBR0UnLFxuICAgICAgJ0Jsb2NrIGRpcmVjdG9yeSByZWZlcmVuY2VzIGFuIHVua25vd24gc2hlZXQnLFxuICAgICk7XG4gIH1cbiAgcHJpdmF0ZSBhc3luYyByZXN0b3JlSGVhZChoZWFkOiBIZWFkKSB7XG4gICAgYXNzZXJ0KFxuICAgICAgaGVhZCAmJiB0eXBlb2YgaGVhZCA9PT0gJ29iamVjdCcgJiYgIUFycmF5LmlzQXJyYXkoaGVhZCksXG4gICAgICAnQ09SUlVQVF9TVE9SQUdFJyxcbiAgICAgICdJbnZhbGlkIHdvcmtib29rIGhlYWQnLFxuICAgICk7XG4gICAgaWYgKE9iamVjdC5oYXNPd24oaGVhZCwgJ2VuZ2luZUZvcm1hdFZlcnNpb24nKSkge1xuICAgICAgYXNzZXJ0KFxuICAgICAgICBOdW1iZXIuaXNTYWZlSW50ZWdlcihoZWFkLmVuZ2luZUZvcm1hdFZlcnNpb24pICYmIGhlYWQuZW5naW5lRm9ybWF0VmVyc2lvbiEgPiAwLFxuICAgICAgICAnQ09SUlVQVF9TVE9SQUdFJyxcbiAgICAgICAgJ0ludmFsaWQgd29ya2Jvb2sgZW5naW5lIGZvcm1hdCB2ZXJzaW9uJyxcbiAgICAgICk7XG4gICAgICBhc3NlcnQoXG4gICAgICAgIGhlYWQuZW5naW5lRm9ybWF0VmVyc2lvbiA9PT0gMSxcbiAgICAgICAgJ1VOU1VQUE9SVEVEX1ZFUlNJT04nLFxuICAgICAgICBgV29ya2Jvb2sgZW5naW5lIGZvcm1hdCAke2hlYWQuZW5naW5lRm9ybWF0VmVyc2lvbn0gaXMgdW5zdXBwb3J0ZWQ7IHVzZSBhIGNvbXBhdGlibGUgdmVyc2lvbmAsXG4gICAgICApO1xuICAgIH1cbiAgICBhc3NlcnQoXG4gICAgICBPYmplY3Qua2V5cyhoZWFkKS5ldmVyeSgoa2V5KSA9PlxuICAgICAgICBbXG4gICAgICAgICAgJ2VuZ2luZUZvcm1hdFZlcnNpb24nLFxuICAgICAgICAgICdkaXJlY3RvcnknLFxuICAgICAgICAgICdtZXRhJyxcbiAgICAgICAgICAncmV2aXNpb24nLFxuICAgICAgICAgICdwYXN0JyxcbiAgICAgICAgICAnZnV0dXJlJyxcbiAgICAgICAgICAnaGlzdG9yeUJ5dGVzJyxcbiAgICAgICAgICAnYnVkZ2V0JyxcbiAgICAgICAgXS5pbmNsdWRlcyhrZXkpLFxuICAgICAgKSxcbiAgICAgICdDT1JSVVBUX1NUT1JBR0UnLFxuICAgICAgJ1Vua25vd24gd29ya2Jvb2sgaGVhZCBmaWVsZHM7IG9wZW4gd2l0aCBhIGNvbXBhdGlibGUgdmVyc2lvbiBvciByZXN0b3JlIGEgYmFja3VwJyxcbiAgICApO1xuICAgIGNvbnN0IG93bmVkID0gKHZhbHVlOiB1bmtub3duKSA9PiB0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnICYmIHZhbHVlLnN0YXJ0c1dpdGgoYCR7dGhpcy5pZH0vYCk7XG4gICAgYXNzZXJ0KFxuICAgICAgb3duZWQoaGVhZC5tZXRhKSAmJlxuICAgICAgICBOdW1iZXIuaXNTYWZlSW50ZWdlcihoZWFkLnJldmlzaW9uKSAmJlxuICAgICAgICBoZWFkLnJldmlzaW9uID49IDAgJiZcbiAgICAgICAgTnVtYmVyLmlzU2FmZUludGVnZXIoaGVhZC5idWRnZXQpICYmXG4gICAgICAgIGhlYWQuYnVkZ2V0ID4gMCAmJlxuICAgICAgICBOdW1iZXIuaXNTYWZlSW50ZWdlcihoZWFkLmhpc3RvcnlCeXRlcykgJiZcbiAgICAgICAgaGVhZC5oaXN0b3J5Qnl0ZXMgPj0gMCAmJlxuICAgICAgICBoZWFkLmhpc3RvcnlCeXRlcyA8PSAzMiAqIDEwMjQgKiAxMDI0ICYmXG4gICAgICAgIEFycmF5LmlzQXJyYXkoaGVhZC5wYXN0KSAmJlxuICAgICAgICBBcnJheS5pc0FycmF5KGhlYWQuZnV0dXJlKSAmJlxuICAgICAgICBoZWFkLnBhc3QubGVuZ3RoICsgaGVhZC5mdXR1cmUubGVuZ3RoIDw9IDEwMCAmJlxuICAgICAgICBbLi4uaGVhZC5wYXN0LCAuLi5oZWFkLmZ1dHVyZV0uZXZlcnkob3duZWQpICYmXG4gICAgICAgIG5ldyBTZXQoWy4uLmhlYWQucGFzdCwgLi4uaGVhZC5mdXR1cmVdKS5zaXplID09PSBoZWFkLnBhc3QubGVuZ3RoICsgaGVhZC5mdXR1cmUubGVuZ3RoLFxuICAgICAgJ0NPUlJVUFRfU1RPUkFHRScsXG4gICAgICAnSW52YWxpZCB3b3JrYm9vayBoZWFkIGhpc3RvcnknLFxuICAgICk7XG4gICAgYXNzZXJ0KFxuICAgICAgaGVhZC5kaXJlY3RvcnkgJiZcbiAgICAgICAgdHlwZW9mIGhlYWQuZGlyZWN0b3J5ID09PSAnb2JqZWN0JyAmJlxuICAgICAgICAhQXJyYXkuaXNBcnJheShoZWFkLmRpcmVjdG9yeSkgJiZcbiAgICAgICAgIU9iamVjdC5oYXNPd24oaGVhZCwgJ2Jsb2NrcycpICYmXG4gICAgICAgIE9iamVjdC5lbnRyaWVzKGhlYWQuZGlyZWN0b3J5KS5ldmVyeShcbiAgICAgICAgICAoW2J1Y2tldCwgaWRdKSA9PlxuICAgICAgICAgICAgL14oMHxbMS05XVxcZCopJC8udGVzdChidWNrZXQpICYmXG4gICAgICAgICAgICBOdW1iZXIoYnVja2V0KSA8IDI1NiAmJlxuICAgICAgICAgICAgdHlwZW9mIGlkID09PSAnc3RyaW5nJyAmJlxuICAgICAgICAgICAgaWQuc3RhcnRzV2l0aChgJHt0aGlzLmlkfS9gKSxcbiAgICAgICAgKSxcbiAgICAgICdDT1JSVVBUX1NUT1JBR0UnLFxuICAgICAgJ1Vuc3VwcG9ydGVkIHdvcmtib29rIGRhdGFiYXNlIGZvcm1hdCcsXG4gICAgKTtcbiAgICBjb25zdCBibG9ja3M6IFJlY29yZDxzdHJpbmcsIFBvaW50ZXI+ID0ge307XG4gICAgdGhpcy5kaXJlY3RvcnlFbnRyaWVzLmNsZWFyKCk7XG4gICAgZm9yIChjb25zdCBbYnVja2V0LCBpZF0gb2YgT2JqZWN0LmVudHJpZXMoaGVhZC5kaXJlY3RvcnkpKSB7XG4gICAgICBjb25zdCBlbnRyaWVzID0gYXdhaXQgdGhpcy5kYi5nZXQ8UmVjb3JkPHN0cmluZywgUG9pbnRlcj4+KCdyZWNvcmRzJywgaWQpO1xuICAgICAgYXNzZXJ0KFxuICAgICAgICBlbnRyaWVzICYmIHR5cGVvZiBlbnRyaWVzID09PSAnb2JqZWN0JyAmJiAhQXJyYXkuaXNBcnJheShlbnRyaWVzKSxcbiAgICAgICAgJ0NPUlJVUFRfU1RPUkFHRScsXG4gICAgICAgICdJbnZhbGlkIGJsb2NrIGRpcmVjdG9yeScsXG4gICAgICApO1xuICAgICAgZm9yIChjb25zdCBbYWRkcmVzcywgcG9pbnRlcl0gb2YgT2JqZWN0LmVudHJpZXMoZW50cmllcykpIHtcbiAgICAgICAgY29uc3QgbWF0Y2ggPSAvXihbXFx3LV0rKVxcLygwfFsxLTldXFxkKilcXC8oMHxbMS05XVxcZCopJC8uZXhlYyhhZGRyZXNzKTtcbiAgICAgICAgYXNzZXJ0KFxuICAgICAgICAgIG1hdGNoICYmXG4gICAgICAgICAgICBOdW1iZXIobWF0Y2hbMl0pIDw9IE1hdGguZmxvb3IoMHhmZmZmZmZmZiAvIEJMT0NLX1JPV1MpICYmXG4gICAgICAgICAgICBOdW1iZXIobWF0Y2hbM10pIDw9IE1hdGguZmxvb3IoMHhmZmZmZmZmZiAvIEJMT0NLX0NPTFVNTlMpICYmXG4gICAgICAgICAgICB0aGlzLmJ1Y2tldChhZGRyZXNzKSA9PT0gYnVja2V0ICYmXG4gICAgICAgICAgICAhT2JqZWN0Lmhhc093bihibG9ja3MsIGFkZHJlc3MpICYmXG4gICAgICAgICAgICB0aGlzLnZhbGlkUG9pbnRlcihwb2ludGVyKSxcbiAgICAgICAgICAnQ09SUlVQVF9TVE9SQUdFJyxcbiAgICAgICAgICAnSW52YWxpZCBibG9jayBkaXJlY3RvcnkgZW50cnknLFxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgdGhpcy5kaXJlY3RvcnlFbnRyaWVzLnNldChidWNrZXQsIGVudHJpZXMpO1xuICAgICAgT2JqZWN0LmFzc2lnbihibG9ja3MsIGVudHJpZXMpO1xuICAgIH1cbiAgICByZXR1cm4geyAuLi5oZWFkLCBibG9ja3MgfTtcbiAgfVxuICBwcml2YXRlIGFzeW5jIHB1Ymxpc2gobmV4dDogSGVhZCwgbWV0YWRhdGE6IE1ldGFkYXRhLCByYW5nZXM/OiBTZWxlY3Rpb25bXSkge1xuICAgIHRoaXMuY2hlY2soKTtcbiAgICBjb25zdCBwcmV2aW91c0RpcmVjdG9yeSA9IHRoaXMuaGVhZC5kaXJlY3RvcnkgPz8ge307XG4gICAgY29uc3QgZGlyZWN0b3J5ID0geyAuLi5wcmV2aW91c0RpcmVjdG9yeSB9LFxuICAgICAgZGlydHkgPSBuZXcgTWFwPHN0cmluZywgUmVjb3JkPHN0cmluZywgUG9pbnRlcj4+KCk7XG4gICAgZm9yIChjb25zdCBhZGRyZXNzIG9mIHRoaXMuY2hhbmdlZCkge1xuICAgICAgY29uc3QgYnVja2V0ID0gdGhpcy5idWNrZXQoYWRkcmVzcyk7XG4gICAgICBpZiAoIWRpcnR5LmhhcyhidWNrZXQpKSBkaXJ0eS5zZXQoYnVja2V0LCB7IC4uLnRoaXMuZGlyZWN0b3J5RW50cmllcy5nZXQoYnVja2V0KSB9KTtcbiAgICAgIGNvbnN0IGVudHJpZXMgPSBkaXJ0eS5nZXQoYnVja2V0KSE7XG4gICAgICBpZiAobmV4dC5ibG9ja3NbYWRkcmVzc10pIGVudHJpZXNbYWRkcmVzc10gPSBuZXh0LmJsb2Nrc1thZGRyZXNzXTtcbiAgICAgIGVsc2UgZGVsZXRlIGVudHJpZXNbYWRkcmVzc107XG4gICAgfVxuICAgIGNvbnN0IG9sZERpcmVjdG9yeUlkczogc3RyaW5nW10gPSBbXTtcbiAgICBmb3IgKGNvbnN0IFtidWNrZXQsIGVudHJpZXNdIG9mIGRpcnR5KSB7XG4gICAgICBpZiAoZGlyZWN0b3J5W2J1Y2tldF0pIG9sZERpcmVjdG9yeUlkcy5wdXNoKGRpcmVjdG9yeVtidWNrZXRdKTtcbiAgICAgIGlmIChPYmplY3Qua2V5cyhlbnRyaWVzKS5sZW5ndGgpXG4gICAgICAgIGRpcmVjdG9yeVtidWNrZXRdID0gYXdhaXQgdGhpcy5hbGxvY2F0ZShlbnRyaWVzLCBuZXh0LmJ1ZGdldCk7XG4gICAgICBlbHNlIGRlbGV0ZSBkaXJlY3RvcnlbYnVja2V0XTtcbiAgICB9XG4gICAgbmV4dC5kaXJlY3RvcnkgPSBkaXJlY3Rvcnk7XG4gICAgbmV4dC5lbmdpbmVGb3JtYXRWZXJzaW9uID0gMTtcbiAgICBjb25zdCBieXRlcyA9XG4gICAgICB0aGlzLnVzZWRCeXRlcyAtXG4gICAgICByZWNvcmRCeXRlcyh0aGlzLmlkLCB0aGlzLnN0b3JlZEhlYWQodGhpcy5oZWFkKSkgK1xuICAgICAgcmVjb3JkQnl0ZXModGhpcy5pZCwgdGhpcy5zdG9yZWRIZWFkKG5leHQpKTtcbiAgICBhc3NlcnQoYnl0ZXMgPD0gbmV4dC5idWRnZXQsICdTVE9SQUdFX0JVREdFVCcsICdBcHBsaWNhdGlvbiBzdG9yYWdlIGJ1ZGdldCBleGNlZWRlZCcpO1xuICAgIHRoaXMuY2hlY2soKTtcbiAgICBhd2FpdCB0aGlzLmRiLndyaXRlKCdoZWFkcycsIFtbdGhpcy5pZCwgdGhpcy5zdG9yZWRIZWFkKG5leHQpXV0pO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBvbGQgPSB0aGlzLmhlYWQ7XG4gICAgICBpZiAoWy4uLnRoaXMuY2hhbmdlZF0uc29tZSgoYSkgPT4gISFvbGQuYmxvY2tzW2FdICE9PSAhIW5leHQuYmxvY2tzW2FdKSlcbiAgICAgICAgdGhpcy5leHBvcnRBZGRyZXNzZXMgPSB1bmRlZmluZWQ7XG4gICAgICBmb3IgKGNvbnN0IGlkIG9mIE9iamVjdC52YWx1ZXMoZGlyZWN0b3J5KSlcbiAgICAgICAgaWYgKCFPYmplY3QudmFsdWVzKHByZXZpb3VzRGlyZWN0b3J5KS5pbmNsdWRlcyhpZCkpIHRoaXMucmV0YWluKGlkLCAxKTtcbiAgICAgIGZvciAoY29uc3QgaWQgb2Ygb2xkRGlyZWN0b3J5SWRzKSB0aGlzLnJldGFpbihpZCwgLTEpO1xuICAgICAgZm9yIChjb25zdCBbYnVja2V0LCBlbnRyaWVzXSBvZiBkaXJ0eSkge1xuICAgICAgICBpZiAoT2JqZWN0LmtleXMoZW50cmllcykubGVuZ3RoKSB0aGlzLmRpcmVjdG9yeUVudHJpZXMuc2V0KGJ1Y2tldCwgZW50cmllcyk7XG4gICAgICAgIGVsc2UgdGhpcy5kaXJlY3RvcnlFbnRyaWVzLmRlbGV0ZShidWNrZXQpO1xuICAgICAgfVxuICAgICAgY29uc3QgZnVsbCA9IG5leHQuYmxvY2tzICE9PSBvbGQuYmxvY2tzICYmICF0aGlzLmNoYW5nZWQuc2l6ZTtcbiAgICAgIGlmIChmdWxsKSB7XG4gICAgICAgIGZvciAoY29uc3QgcCBvZiBPYmplY3QudmFsdWVzKG5leHQuYmxvY2tzKSkgdGhpcy5yZXRhaW4ocC5pZCwgMSk7XG4gICAgICAgIGZvciAoY29uc3QgcCBvZiBPYmplY3QudmFsdWVzKG9sZC5ibG9ja3MpKSB0aGlzLnJldGFpbihwLmlkLCAtMSk7XG4gICAgICB9IGVsc2VcbiAgICAgICAgZm9yIChjb25zdCBhZGRyZXNzIG9mIHRoaXMuY2hhbmdlZCkge1xuICAgICAgICAgIGNvbnN0IGEgPSBvbGQuYmxvY2tzW2FkZHJlc3NdLFxuICAgICAgICAgICAgYiA9IG5leHQuYmxvY2tzW2FkZHJlc3NdO1xuICAgICAgICAgIGlmIChhPy5pZCA9PT0gYj8uaWQpIGNvbnRpbnVlO1xuICAgICAgICAgIGlmIChiKSB0aGlzLnJldGFpbihiLmlkLCAxKTtcbiAgICAgICAgICBpZiAoYSkgdGhpcy5yZXRhaW4oYS5pZCwgLTEpO1xuICAgICAgICB9XG4gICAgICBpZiAobmV4dC5tZXRhICE9PSBvbGQubWV0YSkge1xuICAgICAgICB0aGlzLnJldGFpbihuZXh0Lm1ldGEsIDEpO1xuICAgICAgICB0aGlzLnJldGFpbihvbGQubWV0YSwgLTEpO1xuICAgICAgfVxuICAgICAgY29uc3Qgb2xkSGlzdG9yeSA9IG5ldyBTZXQoWy4uLm9sZC5wYXN0LCAuLi5vbGQuZnV0dXJlXSksXG4gICAgICAgIG5ld0hpc3RvcnkgPSBuZXcgU2V0KFsuLi5uZXh0LnBhc3QsIC4uLm5leHQuZnV0dXJlXSk7XG4gICAgICBmb3IgKGNvbnN0IGlkIG9mIG5ld0hpc3RvcnkpXG4gICAgICAgIGlmICghb2xkSGlzdG9yeS5oYXMoaWQpKSB7XG4gICAgICAgICAgY29uc3QgaCA9IHRoaXMuaGlzdG9yaWVzLmdldChpZCkgPz8gKGF3YWl0IHRoaXMucmVhZEhpc3RvcnkoaWQpKTtcbiAgICAgICAgICBhc3NlcnQoaCwgJ0NPUlJVUFRfU1RPUkFHRScsICdNaXNzaW5nIG5ldyBoaXN0b3J5Jyk7XG4gICAgICAgICAgdGhpcy5oaXN0b3JpZXMuc2V0KGlkLCBoKTtcbiAgICAgICAgICB0aGlzLnJldGFpbkhpc3RvcnkoaWQsIGgsIDEpO1xuICAgICAgICB9XG4gICAgICBmb3IgKGNvbnN0IGlkIG9mIG9sZEhpc3RvcnkpXG4gICAgICAgIGlmICghbmV3SGlzdG9yeS5oYXMoaWQpKSB7XG4gICAgICAgICAgY29uc3QgaCA9IHRoaXMuaGlzdG9yaWVzLmdldChpZCkhO1xuICAgICAgICAgIHRoaXMucmV0YWluSGlzdG9yeShpZCwgaCwgLTEpO1xuICAgICAgICAgIHRoaXMuaGlzdG9yaWVzLmRlbGV0ZShpZCk7XG4gICAgICAgIH1cbiAgICAgIGNvbnN0IHByaW9yU2hlZXRzID0gbmV3IE1hcCh0aGlzLm1ldGFkYXRhLnNuYXBzaG90LnNoZWV0cy5tYXAoKHNoKSA9PiBbc2guaWQsIHNoXSkpO1xuICAgICAgdGhpcy5oZWFkID0gbmV4dDtcbiAgICAgIHRoaXMubWV0YWRhdGEgPSBtZXRhZGF0YTtcbiAgICAgIGlmIChvbGQubWV0YSAhPT0gbmV4dC5tZXRhKSB7XG4gICAgICAgIGZvciAoY29uc3Qgc2ggb2YgbWV0YWRhdGEuc25hcHNob3Quc2hlZXRzKSB7XG4gICAgICAgICAgY29uc3QgcHJpb3IgPSBwcmlvclNoZWV0cy5nZXQoc2guaWQpO1xuICAgICAgICAgIC8vIENvbXBhcmUgaWRlbnRpdHkgb3JkZXIgb25seSB3aGVuIG1ldGFkYXRhIGNoYW5nZXM7IHNjYWxhciBjb21taXRzIHNraXAgdGhpcyB3b3JrLlxuICAgICAgICAgIGlmIChcbiAgICAgICAgICAgICFwcmlvciB8fFxuICAgICAgICAgICAgcHJpb3IubWVyZ2VzICE9PSBzaC5tZXJnZXMgfHxcbiAgICAgICAgICAgIHByaW9yLnJvd09yZGVyLmxlbmd0aCAhPT0gc2gucm93T3JkZXIubGVuZ3RoIHx8XG4gICAgICAgICAgICBwcmlvci5jb2x1bW5PcmRlci5sZW5ndGggIT09IHNoLmNvbHVtbk9yZGVyLmxlbmd0aCB8fFxuICAgICAgICAgICAgcHJpb3Iucm93T3JkZXIuc29tZSgoaWQsIGkpID0+IGlkICE9PSBzaC5yb3dPcmRlcltpXSkgfHxcbiAgICAgICAgICAgIHByaW9yLmNvbHVtbk9yZGVyLnNvbWUoKGlkLCBpKSA9PiBpZCAhPT0gc2guY29sdW1uT3JkZXJbaV0pXG4gICAgICAgICAgKVxuICAgICAgICAgICAgZGVsZXRlIHRoaXMudXNlZFtzaC5pZF07XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGZvciAoY29uc3QgYSBvZiB0aGlzLmNoYW5nZWQpXG4gICAgICAgIGlmIChcbiAgICAgICAgICBvbGQuYmxvY2tzW2FdPy5yb3dNYXNrICE9PSBuZXh0LmJsb2Nrc1thXT8ucm93TWFzayB8fFxuICAgICAgICAgIG9sZC5ibG9ja3NbYV0/LmNvbHVtbk1hc2sgIT09IG5leHQuYmxvY2tzW2FdPy5jb2x1bW5NYXNrXG4gICAgICAgIClcbiAgICAgICAgICBkZWxldGUgdGhpcy51c2VkW2Euc3BsaXQoJy8nKVswXV07XG4gICAgICB0aGlzLnVzZWRCeXRlcyA9IGJ5dGVzO1xuICAgICAgaWYgKHJhbmdlcykgdGhpcy5jYWxjdWxhdG9yLmludmFsaWRhdGUocmFuZ2VzKTtcbiAgICAgIGVsc2UgdGhpcy5jYWxjdWxhdG9yLmNsZWFyKCk7XG4gICAgICBhd2FpdCB0aGlzLmNsZWFudXAob2xkRGlyZWN0b3J5SWRzKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIHRoaXMucG9pc29uZWQgPSB0cnVlO1xuICAgICAgdGhyb3cgbmV3IE9wZW5TaGVldEVycm9yKCdXT1JLRVJfRkFJTEVEJywgJ0NvbW1pdCBtYXkgaGF2ZSBzdWNjZWVkZWQ7IHJlb3BlbiB0aGUgd29ya2Jvb2snKTtcbiAgICB9XG4gIH1cbiAgdmlldygpOiBFbmdpbmVWaWV3IHtcbiAgICBjb25zdCB1c2VkID0gdGhpcy51c2VkO1xuICAgIGZvciAoY29uc3QgcyBvZiB0aGlzLm1ldGFkYXRhLnNuYXBzaG90LnNoZWV0cykge1xuICAgICAgaWYgKHVzZWRbcy5pZF0pIGNvbnRpbnVlO1xuICAgICAgbGV0IGVuZFJvdyA9IDEsXG4gICAgICAgIGVuZENvbHVtbiA9IDE7XG4gICAgICBjb25zdCByb3dzID0gdGhpcy5heGlzKHMucm93T3JkZXIpLFxuICAgICAgICBjb2xzID0gdGhpcy5heGlzKHMuY29sdW1uT3JkZXIpO1xuICAgICAgZm9yIChjb25zdCBbYWRkcmVzcywgcF0gb2YgT2JqZWN0LmVudHJpZXModGhpcy5oZWFkLmJsb2NrcykpXG4gICAgICAgIGlmIChhZGRyZXNzLnN0YXJ0c1dpdGgoYCR7cy5pZH0vYCkpIHtcbiAgICAgICAgICBjb25zdCBbLCBiciwgYmNdID0gYWRkcmVzcy5zcGxpdCgnLycpLFxuICAgICAgICAgICAgbWFzayA9IEJpZ0ludCgnMHgnICsgKHAucm93TWFzayA/PyAnMCcpKTtcbiAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IDY0OyBpKyspXG4gICAgICAgICAgICBpZiAobWFzayAmICgxbiA8PCBCaWdJbnQoaSkpKVxuICAgICAgICAgICAgICBlbmRSb3cgPSBNYXRoLm1heChlbmRSb3csIChyb3dzLmdldCgrYnIgKiA2NCArIGkpID8/IC0xKSArIDEpO1xuICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgMzI7IGkrKylcbiAgICAgICAgICAgIGlmICgocC5jb2x1bW5NYXNrID8/IDApICYgKDEgPDwgaSkpXG4gICAgICAgICAgICAgIGVuZENvbHVtbiA9IE1hdGgubWF4KGVuZENvbHVtbiwgKGNvbHMuZ2V0KCtiYyAqIDMyICsgaSkgPz8gLTEpICsgMSk7XG4gICAgICAgIH1cbiAgICAgIGZvciAoY29uc3QgbSBvZiBzLm1lcmdlcykge1xuICAgICAgICBlbmRSb3cgPSBNYXRoLm1heChlbmRSb3csIG0uZW5kUm93KTtcbiAgICAgICAgZW5kQ29sdW1uID0gTWF0aC5tYXgoZW5kQ29sdW1uLCBtLmVuZENvbHVtbik7XG4gICAgICB9XG4gICAgICB1c2VkW3MuaWRdID0geyBzdGFydFJvdzogMCwgc3RhcnRDb2x1bW46IDAsIGVuZFJvdywgZW5kQ29sdW1uIH07XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICBzbmFwc2hvdDogeyAuLi50aGlzLm1ldGFkYXRhLnNuYXBzaG90LCByZXZpc2lvbjogdGhpcy5oZWFkLnJldmlzaW9uIH0sXG4gICAgICBtZXRhZGF0YUlkOiB0aGlzLmhlYWQubWV0YSxcbiAgICAgIHJldmlzaW9uOiB0aGlzLmhlYWQucmV2aXNpb24sXG4gICAgICBpbXBvcnRSZXZpc2lvbjogdGhpcy5tZXRhZGF0YS5pbXBvcnRSZXZpc2lvbixcbiAgICAgIGZpbHRlcmVkOiB0aGlzLm1ldGFkYXRhLmZpbHRlcmVkLFxuICAgICAgdXNlZCxcbiAgICAgIGNhblVuZG86ICEhdGhpcy5oZWFkLnBhc3QubGVuZ3RoLFxuICAgICAgY2FuUmVkbzogISF0aGlzLmhlYWQuZnV0dXJlLmxlbmd0aCxcbiAgICAgIGJ5dGVzOiB0aGlzLnVzZWRCeXRlcyxcbiAgICAgIGNhY2hlQnl0ZXM6IHRoaXMuY2FjaGUuYnl0ZXMgKyB0aGlzLmNhbGN1bGF0b3IuY2FjaGVCeXRlcyArIHRoaXMuc2Vlbi5ieXRlcyxcbiAgICAgIGJ1ZGdldDogdGhpcy5oZWFkLmJ1ZGdldCxcbiAgICB9O1xuICB9XG4gIHByaXZhdGUgYXN5bmMgYmxvY2soYWRkcmVzczogc3RyaW5nLCBoZWFkID0gdGhpcy5oZWFkLCB0aW1pbmc/OiBSZWFkVGltaW5nKTogUHJvbWlzZTxDb2x1bW5QYWdlPiB7XG4gICAgY29uc3QgcCA9IGhlYWQuYmxvY2tzW2FkZHJlc3NdO1xuICAgIGlmICghcCkge1xuICAgICAgaWYgKHRpbWluZykgdGltaW5nLmFic2VudFBhZ2VzKys7XG4gICAgICByZXR1cm4gZGVjb2RlQmxvY2soZW5jb2RlQmxvY2soe30sIFtdLCBbXSwge30pKTtcbiAgICB9XG4gICAgY29uc3QgY2FjaGVkID0gdGhpcy5jYWNoZS5nZXQocC5pZCk7XG4gICAgaWYgKGNhY2hlZCkge1xuICAgICAgaWYgKHRpbWluZykgdGltaW5nLmNhY2hlSGl0cysrO1xuICAgICAgcmV0dXJuIGNhY2hlZDtcbiAgICB9XG4gICAgaWYgKHRpbWluZykgdGltaW5nLmNhY2hlTWlzc2VzKys7XG4gICAgbGV0IHN0YXJ0ZWQgPSB0aW1pbmcgPyBwZXJmb3JtYW5jZS5ub3coKSA6IDA7XG4gICAgY29uc3QgZW5jb2RlZCA9IGF3YWl0IHRoaXMuZGIuZ2V0PEVuY29kZWRCbG9jaz4oJ3JlY29yZHMnLCBwLmlkKTtcbiAgICBpZiAodGltaW5nKSB7XG4gICAgICB0aW1pbmcuc3RvcmFnZU1zICs9IHBlcmZvcm1hbmNlLm5vdygpIC0gc3RhcnRlZDtcbiAgICAgIHN0YXJ0ZWQgPSBwZXJmb3JtYW5jZS5ub3coKTtcbiAgICB9XG4gICAgYXNzZXJ0KGVuY29kZWQsICdDT1JSVVBUX1NUT1JBR0UnLCAnRGF0YSBibG9jayBpcyBtaXNzaW5nJyk7XG4gICAgY29uc3QgaW5mbGF0ZWQgPSBhd2FpdCB0aGlzLmluZmxhdGUoZW5jb2RlZCk7XG4gICAgaWYgKHRpbWluZykge1xuICAgICAgY29uc3Qgbm93ID0gcGVyZm9ybWFuY2Uubm93KCk7XG4gICAgICB0aW1pbmcuaW5mbGF0ZU1zICs9IG5vdyAtIHN0YXJ0ZWQ7XG4gICAgICBzdGFydGVkID0gbm93O1xuICAgIH1cbiAgICBjb25zdCBibG9jayA9IGRlY29kZUJsb2NrKGluZmxhdGVkKTtcbiAgICBpZiAodGltaW5nKSB7XG4gICAgICBjb25zdCBkdXJhdGlvbiA9IHBlcmZvcm1hbmNlLm5vdygpIC0gc3RhcnRlZDtcbiAgICAgIHRpbWluZy5wYWdlRGVjb2RlTXMgKz0gZHVyYXRpb247XG4gICAgICB0aW1pbmcuZGVjb2RlTXMgPSB0aW1pbmcuaW5mbGF0ZU1zICsgdGltaW5nLnBhZ2VEZWNvZGVNcztcbiAgICB9XG4gICAgdGhpcy5jYWNoZS5zZXQocC5pZCwgYmxvY2ssIGJsb2NrLmJ5dGVzKTtcbiAgICByZXR1cm4gYmxvY2s7XG4gIH1cbiAgYXN5bmMgY2VsbChzaGVldDogc3RyaW5nLCByb3c6IG51bWJlciwgY29sdW1uOiBudW1iZXIpOiBQcm9taXNlPENlbGxSZWNvcmQgfCB1bmRlZmluZWQ+IHtcbiAgICByZXR1cm4gdGhpcy5zdGFnZWRDZWxsKHNoZWV0LCByb3csIGNvbHVtbiwgdGhpcy5oZWFkLCB0aGlzLm1ldGFkYXRhKTtcbiAgfVxuICBwcml2YXRlIGFzeW5jIHN0YWdlZENlbGwoXG4gICAgc2hlZXQ6IHN0cmluZyxcbiAgICByb3c6IG51bWJlcixcbiAgICBjb2x1bW46IG51bWJlcixcbiAgICBoZWFkOiBIZWFkLFxuICAgIG1ldGFkYXRhOiBNZXRhZGF0YSxcbiAgICBsb2NhbD86IFN0YWdlZFJlYWRQYWdlLFxuICApOiBQcm9taXNlPENlbGxSZWNvcmQgfCB1bmRlZmluZWQ+IHtcbiAgICB0aGlzLmNoZWNrKCk7XG4gICAgY29uc3Qgc2ggPSBtZXRhZGF0YS5zbmFwc2hvdC5zaGVldHMuZmluZCgocykgPT4gcy5pZCA9PT0gc2hlZXQpO1xuICAgIGlmIChcbiAgICAgICFzaCB8fFxuICAgICAgcm93IDwgMCB8fFxuICAgICAgY29sdW1uIDwgMCB8fFxuICAgICAgcm93ID49IHNoLnJvd09yZGVyLmxlbmd0aCB8fFxuICAgICAgY29sdW1uID49IHNoLmNvbHVtbk9yZGVyLmxlbmd0aFxuICAgIClcbiAgICAgIHJldHVybiB7IHJvd0lkOiAwLCBjb2x1bW5JZDogMCwgaW5wdXQ6IHsgdHlwZTogJ2Vycm9yJywgY29kZTogJyNSRUYhJyB9IH07XG4gICAgY29uc3QgYWRkcmVzcyA9IGJsb2NrQWRkcmVzcyhzaGVldCwgc2gucm93T3JkZXJbcm93XSwgc2guY29sdW1uT3JkZXJbY29sdW1uXSk7XG4gICAgbGV0IHBhZ2UgPSBsb2NhbD8uYWRkcmVzcyA9PT0gYWRkcmVzcyA/IGxvY2FsLnBhZ2UgOiB1bmRlZmluZWQ7XG4gICAgaWYgKCFwYWdlKSB7XG4gICAgICBwYWdlID0gYXdhaXQgdGhpcy5ibG9jayhhZGRyZXNzLCBoZWFkKTtcbiAgICAgIGlmIChsb2NhbCkge1xuICAgICAgICBsb2NhbC5hZGRyZXNzID0gcGFnZS5ieXRlcyA8PSBDT05ESVRJT05BTF9SRUFEX1BBR0VfQlVER0VUID8gYWRkcmVzcyA6IHVuZGVmaW5lZDtcbiAgICAgICAgbG9jYWwucGFnZSA9IHBhZ2UuYnl0ZXMgPD0gQ09ORElUSU9OQUxfUkVBRF9QQUdFX0JVREdFVCA/IHBhZ2UgOiB1bmRlZmluZWQ7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBwYWdlLmNlbGwoKHNoLnJvd09yZGVyW3Jvd10gJSA2NCkgKiAzMiArIChzaC5jb2x1bW5PcmRlcltjb2x1bW5dICUgMzIpKTtcbiAgfVxuICAvKiogSW50ZXJuYWwgYnJpZGdlOyBjYWxsZXIgbXVzdCBrZWVwIGhlYWQgYW5kIG1ldGFkYXRhIGltbXV0YWJsZSB1bnRpbCB2YWxpZGF0aW9uIHJldHVybnMuICovXG4gIHByaXZhdGUgYXN5bmMgdmFsaWRhdGVTdGFnZWRDZWxscyhcbiAgICBoZWFkOiBIZWFkLFxuICAgIG1ldGFkYXRhOiBNZXRhZGF0YSxcbiAgICBzaGVldElkOiBzdHJpbmcsXG4gICAgcnVsZXM6IHJlYWRvbmx5IFZhbGlkYXRpb25FbnRyeVtdLFxuICAgIHBvc2l0aW9uczogcmVhZG9ubHkgeyByb3c6IG51bWJlcjsgY29sdW1uOiBudW1iZXIgfVtdLFxuICAgIHNpZ25hbD86IEFib3J0U2lnbmFsLFxuICApIHtcbiAgICB0aGlzLmNoZWNrKCk7XG4gICAgc2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuICAgIGNvbnN0IHNoZWV0ID0gbWV0YWRhdGEuc25hcHNob3Quc2hlZXRzLmZpbmQoKGNhbmRpZGF0ZSkgPT4gY2FuZGlkYXRlLmlkID09PSBzaGVldElkKTtcbiAgICBhc3NlcnQoc2hlZXQsICdJTlZBTElEX0FSR1VNRU5UJywgJ1Vua25vd24gdmFsaWRhdGlvbiBzaGVldCcpO1xuICAgIGNvbnN0IGNhbGN1bGF0b3IgPSBuZXcgQXN5bmNDYWxjdWxhdGlvbihcbiAgICAgIChpZCwgcm93LCBjb2x1bW4pID0+IHRoaXMuc3RhZ2VkQ2VsbChpZCwgcm93LCBjb2x1bW4sIGhlYWQsIG1ldGFkYXRhKSxcbiAgICAgIChuYW1lKSA9PlxuICAgICAgICBtZXRhZGF0YS5zbmFwc2hvdC5zaGVldHMuZmluZChcbiAgICAgICAgICAoY2FuZGlkYXRlKSA9PiBjYW5kaWRhdGUubmFtZS50b0xvd2VyQ2FzZSgpID09PSBuYW1lLnRvTG93ZXJDYXNlKCksXG4gICAgICAgICk/LmlkLFxuICAgICAgdGhpcy5jYWxjdWxhdG9yLmNhY2hlQnVkZ2V0LFxuICAgICAgdW5kZWZpbmVkLFxuICAgICAgKCkgPT4gbWV0YWRhdGEuc25hcHNob3QuZGF0ZVN5c3RlbSxcbiAgICApO1xuICAgIGNvbnN0IHJlYWRlciA9IGNhbGN1bGF0b3IudmFsaWRhdGlvblNlc3Npb24oc2lnbmFsKS5mb3JTaGVldChzaGVldElkKTtcbiAgICBjb25zdCByZXBvcnQgPSBhd2FpdCBjaGVja1N0YWdlZFZhbGlkYXRpb24oXG4gICAgICBydWxlcyxcbiAgICAgIHBvc2l0aW9ucyxcbiAgICAgIHJlYWRlci5yZWFkLFxuICAgICAgc2lnbmFsLFxuICAgICAgcmVhZGVyLmV2YWx1YXRlRm9ybXVsYSxcbiAgICAgIHsgcm93czogc2hlZXQucm93T3JkZXIubGVuZ3RoLCBjb2x1bW5zOiBzaGVldC5jb2x1bW5PcmRlci5sZW5ndGggfSxcbiAgICApO1xuICAgIHRoaXMuY2hlY2soKTtcbiAgICBzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG4gICAgcmV0dXJuIHJlcG9ydDtcbiAgfVxuICAvKiogSW50ZXJuYWwgYnJpZGdlIGZvciBkaXJlY3RseSBlZGl0ZWQgcmFuZ2VzOyBmb3JtdWxhIGRlcGVuZGVudHMgcmVxdWlyZSBzZXBhcmF0ZSBlbnVtZXJhdGlvbi4gKi9cbiAgcHJpdmF0ZSBhc3luYyB2YWxpZGF0ZVN0YWdlZFJhbmdlcyhcbiAgICBoZWFkOiBIZWFkLFxuICAgIG1ldGFkYXRhOiBNZXRhZGF0YSxcbiAgICBzaGVldElkOiBzdHJpbmcsXG4gICAgcnVsZXM6IHJlYWRvbmx5IFZhbGlkYXRpb25FbnRyeVtdLFxuICAgIHJhbmdlczogcmVhZG9ubHkgUmVjdFtdLFxuICAgIHNpZ25hbD86IEFib3J0U2lnbmFsLFxuICApIHtcbiAgICB0aGlzLmNoZWNrKCk7XG4gICAgY29uc3Qgc2hlZXQgPSBtZXRhZGF0YS5zbmFwc2hvdC5zaGVldHMuZmluZCgoY2FuZGlkYXRlKSA9PiBjYW5kaWRhdGUuaWQgPT09IHNoZWV0SWQpO1xuICAgIGFzc2VydChzaGVldCwgJ0lOVkFMSURfQVJHVU1FTlQnLCAnVW5rbm93biB2YWxpZGF0aW9uIHNoZWV0Jyk7XG4gICAgY29uc3Qgc2VsZWN0ZWQgPSBhd2FpdCB2YWxpZGF0aW9uQ2FuZGlkYXRlcyhcbiAgICAgIHJ1bGVzLFxuICAgICAgcmFuZ2VzLFxuICAgICAgeyByb3dzOiBzaGVldC5yb3dPcmRlci5sZW5ndGgsIGNvbHVtbnM6IHNoZWV0LmNvbHVtbk9yZGVyLmxlbmd0aCB9LFxuICAgICAgc2lnbmFsLFxuICAgICk7XG4gICAgdGhpcy5jaGVjaygpO1xuICAgIHJldHVybiB0aGlzLnZhbGlkYXRlU3RhZ2VkQ2VsbHMoXG4gICAgICBoZWFkLFxuICAgICAgbWV0YWRhdGEsXG4gICAgICBzaGVldElkLFxuICAgICAgc2VsZWN0ZWQucnVsZXMsXG4gICAgICBzZWxlY3RlZC5wb3NpdGlvbnMsXG4gICAgICBzaWduYWwsXG4gICAgKTtcbiAgfVxuICAvKiogSW50ZXJuYWwgYnJpZGdlOyBjYWxsZXIgb3ducyBhbiBpbW11dGFibGUgaGVhZCBhbmQgbWV0YWRhdGEgdW50aWwgY29tcGxldGlvbi4gKi9cbiAgcHJpdmF0ZSBhc3luYyBjb25kaXRpb25hbFN0YWdlZFZpZXdwb3J0KFxuICAgIGhlYWQ6IEhlYWQsXG4gICAgbWV0YWRhdGE6IE1ldGFkYXRhLFxuICAgIHNoZWV0SWQ6IHN0cmluZyxcbiAgICBydWxlczogcmVhZG9ubHkgQ29uZGl0aW9uYWxSdWxlW10sXG4gICAgcG9zaXRpb25zOiByZWFkb25seSB7IHJvdzogbnVtYmVyOyBjb2x1bW46IG51bWJlciB9W10sXG4gICAgc2lnbmFsPzogQWJvcnRTaWduYWwsXG4gICk6IFByb21pc2U8Q2VsbFN0eWxlW10+IHtcbiAgICB0aGlzLmNoZWNrKCk7XG4gICAgc2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuICAgIGNvbnN0IHNoZWV0ID0gbWV0YWRhdGEuc25hcHNob3Quc2hlZXRzLmZpbmQoKGNhbmRpZGF0ZSkgPT4gY2FuZGlkYXRlLmlkID09PSBzaGVldElkKTtcbiAgICBhc3NlcnQoc2hlZXQsICdJTlZBTElEX0FSR1VNRU5UJywgJ1Vua25vd24gY29uZGl0aW9uYWwgZm9ybWF0dGluZyBzaGVldCcpO1xuICAgIGNvbnN0IGNoZWNrZWQgPSB2YWxpZGF0ZUNvbmRpdGlvbmFsUnVsZXMoXG4gICAgICBydWxlcyxcbiAgICAgIHNoZWV0LnJvd09yZGVyLmxlbmd0aCxcbiAgICAgIHNoZWV0LmNvbHVtbk9yZGVyLmxlbmd0aCxcbiAgICApO1xuICAgIGFzc2VydChcbiAgICAgIEFycmF5LmlzQXJyYXkocG9zaXRpb25zKSAmJlxuICAgICAgICBwb3NpdGlvbnMubGVuZ3RoIDw9IDEwXzAwMCAmJlxuICAgICAgICBwb3NpdGlvbnMubGVuZ3RoICogY2hlY2tlZC5sZW5ndGggPD0gMV8wMDBfMDAwLFxuICAgICAgJ0xJTUlUX0VYQ0VFREVEJyxcbiAgICAgICdDb25kaXRpb25hbCBmb3JtYXR0aW5nIHZpZXdwb3J0IGV4Y2VlZHMgd29yayBidWRnZXQnLFxuICAgICk7XG4gICAgY29uc3Qgc25hcHNob3QgPSBwb3NpdGlvbnMubWFwKCh7IHJvdywgY29sdW1uIH0pID0+IHtcbiAgICAgIGFzc2VydChcbiAgICAgICAgTnVtYmVyLmlzSW50ZWdlcihyb3cpICYmXG4gICAgICAgICAgcm93ID49IDAgJiZcbiAgICAgICAgICByb3cgPCBzaGVldC5yb3dPcmRlci5sZW5ndGggJiZcbiAgICAgICAgICBOdW1iZXIuaXNJbnRlZ2VyKGNvbHVtbikgJiZcbiAgICAgICAgICBjb2x1bW4gPj0gMCAmJlxuICAgICAgICAgIGNvbHVtbiA8IHNoZWV0LmNvbHVtbk9yZGVyLmxlbmd0aCxcbiAgICAgICAgJ0lOVkFMSURfQVJHVU1FTlQnLFxuICAgICAgICAnQ29uZGl0aW9uYWwgZm9ybWF0dGluZyBjZWxsIGlzIG91dHNpZGUgdGhlIHNoZWV0JyxcbiAgICAgICk7XG4gICAgICByZXR1cm4geyByb3csIGNvbHVtbiB9O1xuICAgIH0pO1xuICAgIGxldCBjdXJyZW50OiB7IHJvdzogbnVtYmVyOyBjb2x1bW46IG51bWJlcjsgY2VsbDogQ2VsbFJlY29yZCB8IHVuZGVmaW5lZCB9IHwgdW5kZWZpbmVkO1xuICAgIC8vIFJldGFpbiBvbmx5IHNjYWxhciBpbnB1dHMgYWxyZWFkeSByZWFkIGZvciB0aGlzIGJvdW5kZWQgdmlld3BvcnQuIEZvcm11bGFcbiAgICAvLyBjZWxscyBhcmUgZGVsaWJlcmF0ZWx5IGV4Y2x1ZGVkOiBjeWNsZSBlcnJvcnMgZGVwZW5kIG9uIHRyYXZlcnNhbCBjb250ZXh0LlxuICAgIGNvbnN0IHNjYWxhck1lbW8gPSBjaGVja2VkLnNvbWUoKHJ1bGUpID0+IHJ1bGUuY29uZGl0aW9uLmtpbmQgPT09ICdmb3JtdWxhJylcbiAgICAgID8gbmV3IE1hcDxudW1iZXIsIENlbGxSZWNvcmQgfCB1bmRlZmluZWQ+KClcbiAgICAgIDogdW5kZWZpbmVkO1xuICAgIGxldCByZXVzZVNjYWxhcnMgPSBmYWxzZTtcbiAgICBjb25zdCBjYWxjdWxhdG9yID0gbmV3IEFzeW5jQ2FsY3VsYXRpb24oXG4gICAgICAoaWQsIHJvdywgY29sdW1uKSA9PiB7XG4gICAgICAgIGlmIChpZCA9PT0gc2hlZXRJZCAmJiBjdXJyZW50Py5yb3cgPT09IHJvdyAmJiBjdXJyZW50LmNvbHVtbiA9PT0gY29sdW1uKVxuICAgICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoY3VycmVudC5jZWxsKTtcbiAgICAgICAgY29uc3QgYWRkcmVzcyA9IHJvdyAqIExJTUlUUy5jb2x1bW5zICsgY29sdW1uO1xuICAgICAgICBpZiAoaWQgPT09IHNoZWV0SWQgJiYgcmV1c2VTY2FsYXJzICYmIHNjYWxhck1lbW8/LmhhcyhhZGRyZXNzKSlcbiAgICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHNjYWxhck1lbW8uZ2V0KGFkZHJlc3MpKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuc3RhZ2VkQ2VsbChpZCwgcm93LCBjb2x1bW4sIGhlYWQsIG1ldGFkYXRhKTtcbiAgICAgIH0sXG4gICAgICAobmFtZSkgPT5cbiAgICAgICAgbWV0YWRhdGEuc25hcHNob3Quc2hlZXRzLmZpbmQoXG4gICAgICAgICAgKGNhbmRpZGF0ZSkgPT4gY2FuZGlkYXRlLm5hbWUudG9Mb3dlckNhc2UoKSA9PT0gbmFtZS50b0xvd2VyQ2FzZSgpLFxuICAgICAgICApPy5pZCxcbiAgICAgIHRoaXMuY2FsY3VsYXRvci5jYWNoZUJ1ZGdldCxcbiAgICAgIHVuZGVmaW5lZCxcbiAgICAgICgpID0+IG1ldGFkYXRhLnNuYXBzaG90LmRhdGVTeXN0ZW0sXG4gICAgKTtcbiAgICBjb25zdCByZWFkZXIgPSBjYWxjdWxhdG9yLnZhbGlkYXRpb25TZXNzaW9uKHNpZ25hbCkuZm9yU2hlZXQoc2hlZXRJZCk7XG4gICAgY29uc3QgY2VsbHM6IEFycmF5PHsgcm93OiBudW1iZXI7IGNvbHVtbjogbnVtYmVyOyB2YWx1ZTogQ2VsbFZhbHVlOyBiYXNlOiBDZWxsU3R5bGUgfT4gPSBbXTtcbiAgICBjb25zdCB2aWV3cG9ydFBhZ2U6IFN0YWdlZFJlYWRQYWdlID0ge307XG4gICAgbGV0IHZhbHVlVGV4dCA9IDA7XG4gICAgZm9yIChjb25zdCB7IHJvdywgY29sdW1uIH0gb2Ygc25hcHNob3QpIHtcbiAgICAgIHRoaXMuY2hlY2soKTtcbiAgICAgIHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcbiAgICAgIGNvbnN0IGNlbGwgPSBhd2FpdCBhYm9ydGFibGUoXG4gICAgICAgIHRoaXMuc3RhZ2VkQ2VsbChzaGVldElkLCByb3csIGNvbHVtbiwgaGVhZCwgbWV0YWRhdGEsIHZpZXdwb3J0UGFnZSksXG4gICAgICAgIHNpZ25hbCxcbiAgICAgICk7XG4gICAgICBjdXJyZW50ID0geyByb3csIGNvbHVtbiwgY2VsbCB9O1xuICAgICAgbGV0IHZhbHVlOiBDZWxsVmFsdWU7XG4gICAgICB0cnkge1xuICAgICAgICB2YWx1ZSA9IGF3YWl0IGFib3J0YWJsZShyZWFkZXIucmVhZChyb3csIGNvbHVtbiksIHNpZ25hbCk7XG4gICAgICB9IGZpbmFsbHkge1xuICAgICAgICBjdXJyZW50ID0gdW5kZWZpbmVkO1xuICAgICAgfVxuICAgICAgc2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuICAgICAgYXNzZXJ0KFxuICAgICAgICAhKHZhbHVlICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgdmFsdWUuZXJyb3IgPT09ICcjTElNSVQhJyksXG4gICAgICAgICdMSU1JVF9FWENFRURFRCcsXG4gICAgICAgICdDb25kaXRpb25hbCBmb3JtYXR0aW5nIGNhbGN1bGF0aW9uIGV4Y2VlZGVkIGl0cyB3b3JrIGJ1ZGdldCcsXG4gICAgICApO1xuICAgICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgdmFsdWVUZXh0ICs9IHZhbHVlLmxlbmd0aDtcbiAgICAgICAgYXNzZXJ0KFxuICAgICAgICAgIHZhbHVlVGV4dCA8PSAxMF8wMDBfMDAwLFxuICAgICAgICAgICdMSU1JVF9FWENFRURFRCcsXG4gICAgICAgICAgJ0NvbmRpdGlvbmFsIGZvcm1hdHRpbmcgdmlld3BvcnQgZXhjZWVkcyB0ZXh0IHdvcmsgYnVkZ2V0JyxcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIGlmIChzY2FsYXJNZW1vICYmICghY2VsbCB8fCBjZWxsLmlucHV0LnR5cGUgIT09ICdmb3JtdWxhJykpXG4gICAgICAgIHNjYWxhck1lbW8uc2V0KFxuICAgICAgICAgIHJvdyAqIExJTUlUUy5jb2x1bW5zICsgY29sdW1uLFxuICAgICAgICAgIGNlbGwgPyB7IHJvd0lkOiBjZWxsLnJvd0lkLCBjb2x1bW5JZDogY2VsbC5jb2x1bW5JZCwgaW5wdXQ6IGNlbGwuaW5wdXQgfSA6IHVuZGVmaW5lZCxcbiAgICAgICAgKTtcbiAgICAgIGNlbGxzLnB1c2goe1xuICAgICAgICByb3csXG4gICAgICAgIGNvbHVtbixcbiAgICAgICAgdmFsdWUsXG4gICAgICAgIGJhc2U6IGNlbGw/LnN0eWxlSWQgPyAobWV0YWRhdGEuc25hcHNob3Quc3R5bGVzW2NlbGwuc3R5bGVJZF0gPz8ge30pIDoge30sXG4gICAgICB9KTtcbiAgICB9XG4gICAgcmV1c2VTY2FsYXJzID0gdHJ1ZTtcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBjb25kaXRpb25hbFZpZXdwb3J0V2l0aEZvcm11bGFzKFxuICAgICAgY2hlY2tlZCxcbiAgICAgIGNlbGxzLFxuICAgICAgcmVhZGVyLmV2YWx1YXRlRm9ybXVsYSxcbiAgICAgIHNpZ25hbCxcbiAgICApO1xuICAgIHRoaXMuY2hlY2soKTtcbiAgICBzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfVxuICAvKiogRmluZCB0aGUgbmV4dCBvY2N1cGllZC1yZWdpb24gYm91bmRhcnkgdXNpbmcgc3RvcmVkIGlucHV0cywgbm90IGNhbGN1bGF0ZWQgZGlzcGxheSB2YWx1ZXMuICovXG4gIGFzeW5jIG5hdmlnYXRlRGF0YShcbiAgICBzaGVldElkOiBzdHJpbmcsXG4gICAgcm93OiBudW1iZXIsXG4gICAgY29sdW1uOiBudW1iZXIsXG4gICAgYXhpczogJ3JvdycgfCAnY29sdW1uJyxcbiAgICBkaXJlY3Rpb246IC0xIHwgMSxcbiAgKSB7XG4gICAgdmFsaWRhdGVOYXZpZ2F0aW9uQXJndW1lbnRzKHNoZWV0SWQsIHJvdywgY29sdW1uLCBheGlzLCBkaXJlY3Rpb24pO1xuICAgIGNvbnN0IHNoID0gdGhpcy5tZXRhZGF0YS5zbmFwc2hvdC5zaGVldHMuZmluZCgocykgPT4gcy5pZCA9PT0gc2hlZXRJZCk7XG4gICAgYXNzZXJ0KHNoLCAnSU5WQUxJRF9BUkdVTUVOVCcsICdVbmtub3duIHNoZWV0Jyk7XG4gICAgYXNzZXJ0KFxuICAgICAgcm93IDwgc2gucm93T3JkZXIubGVuZ3RoICYmIGNvbHVtbiA8IHNoLmNvbHVtbk9yZGVyLmxlbmd0aCxcbiAgICAgICdJTlZBTElEX0FSR1VNRU5UJyxcbiAgICAgICdJbnZhbGlkIG5hdmlnYXRpb24gcG9zaXRpb24nLFxuICAgICk7XG4gICAgY29uc3QgaGVhZCA9IHRoaXMuaGVhZCxcbiAgICAgIHJldmlzaW9uID0gaGVhZC5yZXZpc2lvbjtcbiAgICBjb25zdCB2ZXJ0aWNhbCA9IGF4aXMgPT09ICdyb3cnLFxuICAgICAgc3RhcnQgPSB2ZXJ0aWNhbCA/IHJvdyA6IGNvbHVtbjtcbiAgICBjb25zdCBvcmRlciA9IHZlcnRpY2FsID8gc2gucm93T3JkZXIgOiBzaC5jb2x1bW5PcmRlcjtcbiAgICBjb25zdCBheGlzTWV0YSA9IHZlcnRpY2FsID8gc2gucm93cyA6IHNoLmNvbHVtbnM7XG4gICAgY29uc3QgZmlsdGVyZWQgPSB2ZXJ0aWNhbCA/IG5ldyBTZXQodGhpcy5tZXRhZGF0YS5maWx0ZXJlZFtzaGVldElkXSA/PyBbXSkgOiB1bmRlZmluZWQ7XG4gICAgY29uc3QgaW50ZXJ2YWxzID0gc2gubWVyZ2VzXG4gICAgICAuZmlsdGVyKChtKSA9PlxuICAgICAgICB2ZXJ0aWNhbFxuICAgICAgICAgID8gY29sdW1uID49IG0uc3RhcnRDb2x1bW4gJiYgY29sdW1uIDwgbS5lbmRDb2x1bW5cbiAgICAgICAgICA6IHJvdyA+PSBtLnN0YXJ0Um93ICYmIHJvdyA8IG0uZW5kUm93LFxuICAgICAgKVxuICAgICAgLm1hcCgobSkgPT4gKHtcbiAgICAgICAgc3RhcnQ6IHZlcnRpY2FsID8gbS5zdGFydFJvdyA6IG0uc3RhcnRDb2x1bW4sXG4gICAgICAgIGVuZDogdmVydGljYWwgPyBtLmVuZFJvdyA6IG0uZW5kQ29sdW1uLFxuICAgICAgICByb3c6IG0uc3RhcnRSb3csXG4gICAgICAgIGNvbHVtbjogbS5zdGFydENvbHVtbixcbiAgICAgIH0pKVxuICAgICAgLnNvcnQoKGEsIGIpID0+IGEuc3RhcnQgLSBiLnN0YXJ0KTtcbiAgICBjb25zdCBtZXJnZUF0ID0gKGluZGV4OiBudW1iZXIpID0+IHtcbiAgICAgIGxldCBsbyA9IDAsXG4gICAgICAgIGhpID0gaW50ZXJ2YWxzLmxlbmd0aDtcbiAgICAgIHdoaWxlIChsbyA8IGhpKSB7XG4gICAgICAgIGNvbnN0IG1pZCA9IChsbyArIGhpKSA+Pj4gMTtcbiAgICAgICAgaWYgKGludGVydmFsc1ttaWRdLnN0YXJ0IDw9IGluZGV4KSBsbyA9IG1pZCArIDE7XG4gICAgICAgIGVsc2UgaGkgPSBtaWQ7XG4gICAgICB9XG4gICAgICBjb25zdCBtZXJnZSA9IGludGVydmFsc1tsbyAtIDFdO1xuICAgICAgcmV0dXJuIG1lcmdlICYmIGluZGV4IDwgbWVyZ2UuZW5kID8gbWVyZ2UgOiB1bmRlZmluZWQ7XG4gICAgfTtcbiAgICBjb25zdCB2aXNpYmxlID0gKGluZGV4OiBudW1iZXIpID0+XG4gICAgICAhZmlsdGVyZWQ/LmhhcyhpbmRleCkgJiZcbiAgICAgICFheGlzTWV0YVtvcmRlcltpbmRleF1dPy5oaWRkZW4gJiZcbiAgICAgIGF4aXNNZXRhW29yZGVyW2luZGV4XV0/LnNpemUgIT09IDA7XG4gICAgbGV0IGNhY2hlZEFkZHJlc3MgPSAnJyxcbiAgICAgIGNhY2hlZFBhZ2U6IENvbHVtblBhZ2UgfCB1bmRlZmluZWQ7XG4gICAgY29uc3Qgb2NjdXBpZWQgPSAoaW5kZXg6IG51bWJlcik6IGJvb2xlYW4gfCBQcm9taXNlPGJvb2xlYW4+ID0+IHtcbiAgICAgIGNvbnN0IG1lcmdlID0gbWVyZ2VBdChpbmRleCksXG4gICAgICAgIHIgPSBtZXJnZT8ucm93ID8/ICh2ZXJ0aWNhbCA/IGluZGV4IDogcm93KSxcbiAgICAgICAgYyA9IG1lcmdlPy5jb2x1bW4gPz8gKHZlcnRpY2FsID8gY29sdW1uIDogaW5kZXgpO1xuICAgICAgY29uc3Qgcm93SWQgPSBzaC5yb3dPcmRlcltyXSxcbiAgICAgICAgY29sdW1uSWQgPSBzaC5jb2x1bW5PcmRlcltjXSxcbiAgICAgICAgYWRkcmVzcyA9IGJsb2NrQWRkcmVzcyhzaGVldElkLCByb3dJZCwgY29sdW1uSWQpO1xuICAgICAgaWYgKCFoZWFkLmJsb2Nrc1thZGRyZXNzXSkgcmV0dXJuIGZhbHNlO1xuICAgICAgY29uc3QgaXNGaWxsZWQgPSAocGFnZTogQ29sdW1uUGFnZSkgPT5cbiAgICAgICAgKHBhZ2UuY2VsbCgocm93SWQgJSA2NCkgKiAzMiArIChjb2x1bW5JZCAlIDMyKSk/LmlucHV0LnR5cGUgPz8gJ2JsYW5rJykgIT09ICdibGFuayc7XG4gICAgICBpZiAoYWRkcmVzcyA9PT0gY2FjaGVkQWRkcmVzcykgcmV0dXJuIGlzRmlsbGVkKGNhY2hlZFBhZ2UhKTtcbiAgICAgIHJldHVybiB0aGlzLmJsb2NrKGFkZHJlc3MsIGhlYWQpLnRoZW4oKHBhZ2UpID0+IHtcbiAgICAgICAgY2FjaGVkUGFnZSA9IHBhZ2U7XG4gICAgICAgIGNhY2hlZEFkZHJlc3MgPSBhZGRyZXNzO1xuICAgICAgICByZXR1cm4gaXNGaWxsZWQocGFnZSk7XG4gICAgICB9KTtcbiAgICB9O1xuICAgIGNvbnN0IGZpcnN0ID0gb2NjdXBpZWQoc3RhcnQpLFxuICAgICAgaW5pdGlhbCA9IHR5cGVvZiBmaXJzdCA9PT0gJ2Jvb2xlYW4nID8gZmlyc3QgOiBhd2FpdCBmaXJzdCxcbiAgICAgIHN0YXJ0TWVyZ2UgPSBtZXJnZUF0KHN0YXJ0KTtcbiAgICB0aGlzLmNoZWNrKCk7XG4gICAgbGV0IGluZGV4ID0gc3RhcnRNZXJnZVxuICAgICAgPyBkaXJlY3Rpb24gPiAwXG4gICAgICAgID8gc3RhcnRNZXJnZS5lbmRcbiAgICAgICAgOiBzdGFydE1lcmdlLnN0YXJ0IC0gMVxuICAgICAgOiBzdGFydCArIGRpcmVjdGlvbjtcbiAgICBsZXQgbGFzdCA9IHN0YXJ0LFxuICAgICAgcGhhc2U6ICdmaXJzdCcgfCAnb2NjdXBpZWQnIHwgJ3NlYXJjaCcgPSAnZmlyc3QnLFxuICAgICAgY2hlY2tlZCA9IDA7XG4gICAgd2hpbGUgKGluZGV4ID49IDAgJiYgaW5kZXggPCBvcmRlci5sZW5ndGgpIHtcbiAgICAgIHRoaXMuY2hlY2soKTtcbiAgICAgIGlmICgrK2NoZWNrZWQgJSAxMDI0ID09PSAwKSB7XG4gICAgICAgIGF3YWl0IHlpZWxkVG9UYXNrKCk7XG4gICAgICAgIHRoaXMuY2hlY2soKTtcbiAgICAgIH1cbiAgICAgIGlmICghdmlzaWJsZShpbmRleCkpIHtcbiAgICAgICAgaW5kZXggKz0gZGlyZWN0aW9uO1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGN1cnJlbnQgPSBvY2N1cGllZChpbmRleCk7XG4gICAgICBjb25zdCBmaWxsZWQgPSB0eXBlb2YgY3VycmVudCA9PT0gJ2Jvb2xlYW4nID8gY3VycmVudCA6IGF3YWl0IGN1cnJlbnQ7XG4gICAgICB0aGlzLmNoZWNrKCk7XG4gICAgICBpZiAocGhhc2UgPT09ICdmaXJzdCcpIHBoYXNlID0gaW5pdGlhbCAmJiBmaWxsZWQgPyAnb2NjdXBpZWQnIDogJ3NlYXJjaCc7XG4gICAgICBpZiAocGhhc2UgPT09ICdvY2N1cGllZCcgJiYgIWZpbGxlZCkgYnJlYWs7XG4gICAgICBsYXN0ID0gaW5kZXg7XG4gICAgICBpZiAocGhhc2UgPT09ICdzZWFyY2gnICYmIGZpbGxlZCkgYnJlYWs7XG4gICAgICBpbmRleCArPSBkaXJlY3Rpb247XG4gICAgfVxuICAgIHJldHVybiB7IHJldmlzaW9uLCByb3c6IHZlcnRpY2FsID8gbGFzdCA6IHJvdywgY29sdW1uOiB2ZXJ0aWNhbCA/IGNvbHVtbiA6IGxhc3QgfTtcbiAgfVxuICBhc3luYyByZWFkKHNoZWV0SWQ6IHN0cmluZywgcmFuZ2U6IFJlY3QsIHZhbHVlcyA9IHRydWUsIHJlbmRlciA9IHRydWUsIHRpbWluZz86IFJlYWRUaW1pbmcpIHtcbiAgICBjb25zdCBzaCA9IHRoaXMubWV0YWRhdGEuc25hcHNob3Quc2hlZXRzLmZpbmQoKHMpID0+IHMuaWQgPT09IHNoZWV0SWQpO1xuICAgIGFzc2VydChzaCwgJ0lOVkFMSURfQVJHVU1FTlQnLCAnVW5rbm93biBzaGVldCcpO1xuICAgIGNoZWNrQm91bmRzKHNoLCByYW5nZSk7XG4gICAgYXNzZXJ0KFxuICAgICAgKHJhbmdlLmVuZFJvdyAtIHJhbmdlLnN0YXJ0Um93KSAqIChyYW5nZS5lbmRDb2x1bW4gLSByYW5nZS5zdGFydENvbHVtbikgPD0gMTYzODQsXG4gICAgICAnTElNSVRfRVhDRUVERUQnLFxuICAgICAgJ1JlYWQgcmFuZ2VzIGluIGJhdGNoZXMgb2YgYXQgbW9zdCAxNjM4NCBjZWxscycsXG4gICAgKTtcbiAgICBjb25zdCBjZWxsczogUmVjb3JkPHN0cmluZywgQ2VsbFJlY29yZD4gPSB7fSxcbiAgICAgIGNhbGN1bGF0ZWQ6IFJlY29yZDxzdHJpbmcsIENlbGxWYWx1ZT4gPSB7fSxcbiAgICAgIGRpc3BsYXk6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7fTtcbiAgICBsZXQgbG9hZGVkQWRkcmVzczogc3RyaW5nIHwgdW5kZWZpbmVkO1xuICAgIGxldCBsb2FkZWRQYWdlOiBDb2x1bW5QYWdlIHwgdW5kZWZpbmVkO1xuICAgIGxldCBjYWxjdWxhdGU6IFJldHVyblR5cGU8QXN5bmNDYWxjdWxhdGlvblsncmVhZFNlc3Npb24nXT4gfCB1bmRlZmluZWQ7XG4gICAgbGV0IHZpc2l0ZWQgPSAwO1xuICAgIGZvciAobGV0IHJvdyA9IHJhbmdlLnN0YXJ0Um93OyByb3cgPCByYW5nZS5lbmRSb3c7IHJvdysrKVxuICAgICAgZm9yIChsZXQgY29sdW1uID0gcmFuZ2Uuc3RhcnRDb2x1bW47IGNvbHVtbiA8IHJhbmdlLmVuZENvbHVtbjsgY29sdW1uKyspIHtcbiAgICAgICAgdGhpcy5jaGVjaygpO1xuICAgICAgICBpZiAoKyt2aXNpdGVkICUgMTAyNCA9PT0gMCkge1xuICAgICAgICAgIGF3YWl0IG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlKSA9PiBzZXRUaW1lb3V0KHJlc29sdmUsIDApKTtcbiAgICAgICAgICB0aGlzLmNoZWNrKCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgcm93SWQgPSBzaC5yb3dPcmRlcltyb3ddLFxuICAgICAgICAgIGNvbHVtbklkID0gc2guY29sdW1uT3JkZXJbY29sdW1uXSxcbiAgICAgICAgICBrID0ga2V5KHJvd0lkLCBjb2x1bW5JZCksXG4gICAgICAgICAgYWRkcmVzcyA9IGJsb2NrQWRkcmVzcyhzaGVldElkLCByb3dJZCwgY29sdW1uSWQpO1xuICAgICAgICBpZiAoYWRkcmVzcyAhPT0gbG9hZGVkQWRkcmVzcykge1xuICAgICAgICAgIGxvYWRlZFBhZ2UgPSBhd2FpdCB0aGlzLmJsb2NrKGFkZHJlc3MsIHRoaXMuaGVhZCwgdGltaW5nKTtcbiAgICAgICAgICBsb2FkZWRBZGRyZXNzID0gYWRkcmVzcztcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBjZWxsID0gbG9hZGVkUGFnZSEuY2VsbCgocm93SWQgJSA2NCkgKiAzMiArIChjb2x1bW5JZCAlIDMyKSk7XG4gICAgICAgIGlmIChjZWxsKSB7XG4gICAgICAgICAgY2VsbHNba10gPSBjZWxsO1xuICAgICAgICAgIGlmICh0aGlzLmhlYWQucmV2aXNpb24gIT09IHRoaXMubWV0YWRhdGEuaW1wb3J0UmV2aXNpb24gJiYgY2VsbC5jYWNoZWQpIHtcbiAgICAgICAgICAgIGNlbGxzW2tdID0geyAuLi5jZWxsIH07XG4gICAgICAgICAgICBkZWxldGUgY2VsbHNba10uY2FjaGVkO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAodmFsdWVzKSB7XG4gICAgICAgICAgY29uc3QgdiA9XG4gICAgICAgICAgICBjZWxsPy5pbnB1dC50eXBlID09PSAnZm9ybXVsYSdcbiAgICAgICAgICAgICAgPyBhd2FpdCAoY2FsY3VsYXRlID8/PSB0aGlzLmNhbGN1bGF0b3IucmVhZFNlc3Npb24oMTYgKiAxMDI0KSkoc2hlZXRJZCwgcm93LCBjb2x1bW4pXG4gICAgICAgICAgICAgIDogY2VsbFxuICAgICAgICAgICAgICAgID8gc2NhbGFyVmFsdWUoY2VsbC5pbnB1dClcbiAgICAgICAgICAgICAgICA6IG51bGw7XG4gICAgICAgICAgY2FsY3VsYXRlZFtrXSA9IHY7XG4gICAgICAgICAgaWYgKHJlbmRlcilcbiAgICAgICAgICAgIGRpc3BsYXlba10gPVxuICAgICAgICAgICAgICB2ICYmXG4gICAgICAgICAgICAgIHR5cGVvZiB2ID09PSAnb2JqZWN0JyAmJlxuICAgICAgICAgICAgICBjZWxsPy5jYWNoZWQgJiZcbiAgICAgICAgICAgICAgdGhpcy5oZWFkLnJldmlzaW9uID09PSB0aGlzLm1ldGFkYXRhLmltcG9ydFJldmlzaW9uXG4gICAgICAgICAgICAgICAgPyBmb3JtYXRWYWx1ZShcbiAgICAgICAgICAgICAgICAgICAgc2NhbGFyVmFsdWUoY2VsbC5jYWNoZWQpLFxuICAgICAgICAgICAgICAgICAgICBjZWxsLm51bWJlckZvcm1hdCxcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tZXRhZGF0YS5zbmFwc2hvdC5kYXRlU3lzdGVtLFxuICAgICAgICAgICAgICAgICAgKSArICcg4oCgJ1xuICAgICAgICAgICAgICAgIDogZm9ybWF0VmFsdWUoXG4gICAgICAgICAgICAgICAgICAgIHYsXG4gICAgICAgICAgICAgICAgICAgIGNlbGw/Lm51bWJlckZvcm1hdCA/P1xuICAgICAgICAgICAgICAgICAgICAgIHRoaXMubWV0YWRhdGEuc25hcHNob3Quc3R5bGVzW2NlbGw/LnN0eWxlSWQgPz8gJyddPy5udW1iZXJGb3JtYXQsXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubWV0YWRhdGEuc25hcHNob3QuZGF0ZVN5c3RlbSxcbiAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICByZXR1cm4geyBzaGVldElkLCByYW5nZSwgY2VsbHMsIGNhbGN1bGF0ZWQsIGRpc3BsYXksIHJldmlzaW9uOiB0aGlzLmhlYWQucmV2aXNpb24gfTtcbiAgfVxuICBhc3luYyByZWFkQ2VsbHMoc2hlZXRJZDogc3RyaW5nLCByYW5nZTogUmVjdCwgZmllbGRzOiBpbXBvcnQoJy4vd29ya2Jvb2suanMnKS5DZWxsRmllbGRbXSkge1xuICAgIGNvbnN0IHZhbHVlcyA9IGZpZWxkcy5pbmNsdWRlcygndmFsdWUnKSB8fCBmaWVsZHMuaW5jbHVkZXMoJ2Rpc3BsYXknKTtcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgdGhpcy5yZWFkKHNoZWV0SWQsIHJhbmdlLCB2YWx1ZXMsIGZpZWxkcy5pbmNsdWRlcygnZGlzcGxheScpKTtcbiAgICBjb25zdCBzaCA9IHRoaXMubWV0YWRhdGEuc25hcHNob3Quc2hlZXRzLmZpbmQoKHMpID0+IHMuaWQgPT09IHNoZWV0SWQpITtcbiAgICBjb25zdCBjZWxsczogaW1wb3J0KCcuL3dvcmtib29rLmpzJykuQ2VsbERhdGFbXSA9IFtdO1xuICAgIGZvciAobGV0IHJvdyA9IHJhbmdlLnN0YXJ0Um93OyByb3cgPCByYW5nZS5lbmRSb3c7IHJvdysrKVxuICAgICAgZm9yIChsZXQgY29sdW1uID0gcmFuZ2Uuc3RhcnRDb2x1bW47IGNvbHVtbiA8IHJhbmdlLmVuZENvbHVtbjsgY29sdW1uKyspIHtcbiAgICAgICAgY29uc3QgayA9IGtleShzaC5yb3dPcmRlcltyb3ddLCBzaC5jb2x1bW5PcmRlcltjb2x1bW5dKSxcbiAgICAgICAgICBjZWxsID0gZGF0YS5jZWxsc1trXTtcbiAgICAgICAgY2VsbHMucHVzaCh0aGlzLnNlbGVjdENlbGwocm93LCBjb2x1bW4sIGNlbGwsIGZpZWxkcywgZGF0YS5jYWxjdWxhdGVkW2tdLCBkYXRhLmRpc3BsYXlba10pKTtcbiAgICAgIH1cbiAgICByZXR1cm4geyByZXZpc2lvbjogdGhpcy5oZWFkLnJldmlzaW9uLCBzaGVldElkLCByYW5nZSwgY2VsbHMgfTtcbiAgfVxuICBwcml2YXRlIHNlbGVjdENlbGwoXG4gICAgcm93OiBudW1iZXIsXG4gICAgY29sdW1uOiBudW1iZXIsXG4gICAgY2VsbDogQ2VsbFJlY29yZCB8IHVuZGVmaW5lZCxcbiAgICBmaWVsZHM6IGltcG9ydCgnLi93b3JrYm9vay5qcycpLkNlbGxGaWVsZFtdLFxuICAgIHZhbHVlPzogQ2VsbFZhbHVlLFxuICAgIGRpc3BsYXk/OiBzdHJpbmcsXG4gICkge1xuICAgIGNvbnN0IG91dHB1dDogaW1wb3J0KCcuL3dvcmtib29rLmpzJykuQ2VsbERhdGEgPSB7IHJvdywgY29sdW1uIH07XG4gICAgZm9yIChjb25zdCBmaWVsZCBvZiBmaWVsZHMpIHtcbiAgICAgIGlmIChmaWVsZCA9PT0gJ2lucHV0Jykgb3V0cHV0LmlucHV0ID0gY2VsbD8uaW5wdXQgPz8geyB0eXBlOiAnYmxhbmsnIH07XG4gICAgICBlbHNlIGlmIChmaWVsZCA9PT0gJ3ZhbHVlJykgb3V0cHV0LnZhbHVlID0gdmFsdWUgPz8gbnVsbDtcbiAgICAgIGVsc2UgaWYgKGZpZWxkID09PSAnZGlzcGxheScpIG91dHB1dC5kaXNwbGF5ID0gZGlzcGxheSA/PyAnJztcbiAgICAgIGVsc2UgaWYgKGZpZWxkID09PSAnc3R5bGUnKVxuICAgICAgICBvdXRwdXQuc3R5bGUgPSBjZWxsPy5zdHlsZUlkID8gdGhpcy5tZXRhZGF0YS5zbmFwc2hvdC5zdHlsZXNbY2VsbC5zdHlsZUlkXSA6IHt9O1xuICAgICAgZWxzZSBpZiAoZmllbGQgPT09ICdudW1iZXJGb3JtYXQnKVxuICAgICAgICBvdXRwdXQubnVtYmVyRm9ybWF0ID1cbiAgICAgICAgICBjZWxsPy5udW1iZXJGb3JtYXQgPz8gdGhpcy5tZXRhZGF0YS5zbmFwc2hvdC5zdHlsZXNbY2VsbD8uc3R5bGVJZCA/PyAnJ10/Lm51bWJlckZvcm1hdDtcbiAgICAgIGVsc2UgaWYgKGZpZWxkID09PSAnbm90ZScpIG91dHB1dC5ub3RlID0gY2VsbD8ubm90ZTtcbiAgICAgIGVsc2UgaWYgKGZpZWxkID09PSAnbGluaycpIG91dHB1dC5saW5rID0gY2VsbD8ubGluaztcbiAgICB9XG4gICAgcmV0dXJuIG91dHB1dDtcbiAgfVxuICBhc3luYyBzY2FuQ2VsbHMoXG4gICAgc2hlZXRJZDogc3RyaW5nLFxuICAgIG9wdGlvbnM6IHtcbiAgICAgIGN1cnNvcj86IGltcG9ydCgnLi93b3JrYm9vay5qcycpLkNlbGxDdXJzb3I7XG4gICAgICBsaW1pdD86IG51bWJlcjtcbiAgICAgIGZpZWxkcz86IGltcG9ydCgnLi93b3JrYm9vay5qcycpLkNlbGxGaWVsZFtdO1xuICAgIH0sXG4gICkge1xuICAgIGNvbnN0IHNoID0gdGhpcy5tZXRhZGF0YS5zbmFwc2hvdC5zaGVldHMuZmluZCgocykgPT4gcy5pZCA9PT0gc2hlZXRJZCk7XG4gICAgYXNzZXJ0KHNoLCAnSU5WQUxJRF9BUkdVTUVOVCcsICdVbmtub3duIHNoZWV0Jyk7XG4gICAgY29uc3QgcmV2aXNpb24gPSB0aGlzLmhlYWQucmV2aXNpb24sXG4gICAgICBsaW1pdCA9IG9wdGlvbnMubGltaXQgPz8gMTAyNCxcbiAgICAgIGZpZWxkcyA9IG9wdGlvbnMuZmllbGRzID8/IFsnaW5wdXQnXTtcbiAgICBhc3NlcnQoXG4gICAgICBOdW1iZXIuaXNJbnRlZ2VyKGxpbWl0KSAmJiBsaW1pdCA+IDAgJiYgbGltaXQgPD0gMjA0OCxcbiAgICAgICdJTlZBTElEX0FSR1VNRU5UJyxcbiAgICAgICdDZWxsIHBhZ2UgbGltaXQgbXVzdCBiZSAxLi4yMDQ4JyxcbiAgICApO1xuICAgIGNvbnN0IGN1cnNvciA9IG9wdGlvbnMuY3Vyc29yO1xuICAgIGlmIChjdXJzb3IpXG4gICAgICBhc3NlcnQoXG4gICAgICAgIGN1cnNvci5yZXZpc2lvbiA9PT0gcmV2aXNpb24gJiYgY3Vyc29yLnNoZWV0SWQgPT09IHNoZWV0SWQsXG4gICAgICAgICdSRVZJU0lPTl9DT05GTElDVCcsXG4gICAgICAgICdDZWxsIGN1cnNvciBleHBpcmVkJyxcbiAgICAgICk7XG4gICAgaWYgKGN1cnNvcilcbiAgICAgIGFzc2VydChcbiAgICAgICAgTnVtYmVyLmlzSW50ZWdlcihjdXJzb3Iub2Zmc2V0KSAmJlxuICAgICAgICAgIGN1cnNvci5vZmZzZXQgPj0gMCAmJlxuICAgICAgICAgICEhdGhpcy5oZWFkLmJsb2Nrc1tjdXJzb3IuYWRkcmVzc10gJiZcbiAgICAgICAgICBjdXJzb3IuYWRkcmVzcy5zdGFydHNXaXRoKGAke3NoZWV0SWR9L2ApLFxuICAgICAgICAnSU5WQUxJRF9BUkdVTUVOVCcsXG4gICAgICAgICdJbnZhbGlkIGNlbGwgY3Vyc29yJyxcbiAgICAgICk7XG4gICAgY29uc3QgYWRkcmVzcyA9IGN1cnNvcj8uYWRkcmVzcyA/PyB0aGlzLmV4cG9ydEluZGV4KHJldmlzaW9uLCB1bmRlZmluZWQsIDEsIHNoZWV0SWQpWzBdO1xuICAgIGlmICghYWRkcmVzcykgcmV0dXJuIHsgcmV2aXNpb24sIGNlbGxzOiBbXSB9O1xuICAgIGNvbnN0IHBhZ2UgPSBhd2FpdCB0aGlzLmJsb2NrKGFkZHJlc3MpLFxuICAgICAgc291cmNlID0gT2JqZWN0LnZhbHVlcyhwYWdlLmNlbGxzKS5zb3J0KFxuICAgICAgICAoYSwgYikgPT4gYS5yb3dJZCAtIGIucm93SWQgfHwgYS5jb2x1bW5JZCAtIGIuY29sdW1uSWQsXG4gICAgICApLFxuICAgICAgc3RhcnQgPSBjdXJzb3I/Lm9mZnNldCA/PyAwO1xuICAgIGFzc2VydChzdGFydCA8PSBzb3VyY2UubGVuZ3RoLCAnSU5WQUxJRF9BUkdVTUVOVCcsICdJbnZhbGlkIGNlbGwgY3Vyc29yIG9mZnNldCcpO1xuICAgIGNvbnN0IGNlbGxzOiBpbXBvcnQoJy4vd29ya2Jvb2suanMnKS5DZWxsRGF0YVtdID0gW107XG4gICAgZm9yIChjb25zdCBjZWxsIG9mIHNvdXJjZS5zbGljZShzdGFydCwgc3RhcnQgKyBsaW1pdCkpIHtcbiAgICAgIHRoaXMuY2hlY2soKTtcbiAgICAgIGNvbnN0IHJvdyA9IHRoaXMuYXhpcyhzaC5yb3dPcmRlcikuZ2V0KGNlbGwucm93SWQpISxcbiAgICAgICAgY29sdW1uID0gdGhpcy5heGlzKHNoLmNvbHVtbk9yZGVyKS5nZXQoY2VsbC5jb2x1bW5JZCkhO1xuICAgICAgY29uc3QgdmFsdWUgPVxuICAgICAgICBmaWVsZHMuaW5jbHVkZXMoJ3ZhbHVlJykgfHwgZmllbGRzLmluY2x1ZGVzKCdkaXNwbGF5JylcbiAgICAgICAgICA/IGF3YWl0IHRoaXMuY2FsY3VsYXRvci52YWx1ZShzaGVldElkLCByb3csIGNvbHVtbilcbiAgICAgICAgICA6IHVuZGVmaW5lZDtcbiAgICAgIGNlbGxzLnB1c2goXG4gICAgICAgIHRoaXMuc2VsZWN0Q2VsbChcbiAgICAgICAgICByb3csXG4gICAgICAgICAgY29sdW1uLFxuICAgICAgICAgIGNlbGwsXG4gICAgICAgICAgZmllbGRzLFxuICAgICAgICAgIHZhbHVlLFxuICAgICAgICAgIGZpZWxkcy5pbmNsdWRlcygnZGlzcGxheScpXG4gICAgICAgICAgICA/IGZvcm1hdFZhbHVlKFxuICAgICAgICAgICAgICAgIHZhbHVlICYmXG4gICAgICAgICAgICAgICAgICB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmXG4gICAgICAgICAgICAgICAgICBjZWxsLmNhY2hlZCAmJlxuICAgICAgICAgICAgICAgICAgdGhpcy5oZWFkLnJldmlzaW9uID09PSB0aGlzLm1ldGFkYXRhLmltcG9ydFJldmlzaW9uXG4gICAgICAgICAgICAgICAgICA/IHNjYWxhclZhbHVlKGNlbGwuY2FjaGVkKVxuICAgICAgICAgICAgICAgICAgOiAodmFsdWUgPz8gbnVsbCksXG4gICAgICAgICAgICAgICAgY2VsbC5udW1iZXJGb3JtYXQgPz9cbiAgICAgICAgICAgICAgICAgIHRoaXMubWV0YWRhdGEuc25hcHNob3Quc3R5bGVzW2NlbGwuc3R5bGVJZCA/PyAnJ10/Lm51bWJlckZvcm1hdCxcbiAgICAgICAgICAgICAgICB0aGlzLm1ldGFkYXRhLnNuYXBzaG90LmRhdGVTeXN0ZW0sXG4gICAgICAgICAgICAgICkgK1xuICAgICAgICAgICAgICAgICh2YWx1ZSAmJlxuICAgICAgICAgICAgICAgIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiZcbiAgICAgICAgICAgICAgICBjZWxsLmNhY2hlZCAmJlxuICAgICAgICAgICAgICAgIHRoaXMuaGVhZC5yZXZpc2lvbiA9PT0gdGhpcy5tZXRhZGF0YS5pbXBvcnRSZXZpc2lvblxuICAgICAgICAgICAgICAgICAgPyAnIOKAoCdcbiAgICAgICAgICAgICAgICAgIDogJycpXG4gICAgICAgICAgICA6IHVuZGVmaW5lZCxcbiAgICAgICAgKSxcbiAgICAgICk7XG4gICAgfVxuICAgIGNvbnN0IG9mZnNldCA9IHN0YXJ0ICsgY2VsbHMubGVuZ3RoLFxuICAgICAgbmV4dEFkZHJlc3MgPVxuICAgICAgICBvZmZzZXQgPCBzb3VyY2UubGVuZ3RoID8gYWRkcmVzcyA6IHRoaXMuZXhwb3J0SW5kZXgocmV2aXNpb24sIGFkZHJlc3MsIDEsIHNoZWV0SWQpWzBdO1xuICAgIHJldHVybiB7XG4gICAgICByZXZpc2lvbixcbiAgICAgIGNlbGxzLFxuICAgICAgLi4uKG5leHRBZGRyZXNzXG4gICAgICAgID8ge1xuICAgICAgICAgICAgY3Vyc29yOiB7XG4gICAgICAgICAgICAgIHJldmlzaW9uLFxuICAgICAgICAgICAgICBzaGVldElkLFxuICAgICAgICAgICAgICBhZGRyZXNzOiBuZXh0QWRkcmVzcyxcbiAgICAgICAgICAgICAgb2Zmc2V0OiBuZXh0QWRkcmVzcyA9PT0gYWRkcmVzcyA/IG9mZnNldCA6IDAsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH1cbiAgICAgICAgOiB7fSksXG4gICAgfTtcbiAgfVxuICBwcml2YXRlIGFzeW5jIHN0b3JlQmxvY2soXG4gICAgYWRkcmVzczogc3RyaW5nLFxuICAgIGNlbGxzOiBSZWNvcmQ8c3RyaW5nLCBDZWxsUmVjb3JkPixcbiAgICBoZWFkOiBIZWFkLFxuICAgIG1ldGFkYXRhOiBNZXRhZGF0YSxcbiAgICB3YXJtQ2FjaGUgPSB0cnVlLFxuICApIHtcbiAgICBjb25zdCBzaGVldElkID0gYWRkcmVzcy5zcGxpdCgnLycpWzBdLFxuICAgICAgc2ggPSBtZXRhZGF0YS5zbmFwc2hvdC5zaGVldHMuZmluZCgocykgPT4gcy5pZCA9PT0gc2hlZXRJZCkhO1xuICAgIGxldCBpbmRleCA9IHRoaXMuaW5kaWNlcy5nZXQoc2gpO1xuICAgIGlmICghaW5kZXgpIHtcbiAgICAgIGluZGV4ID0ge1xuICAgICAgICByb3dzOiB0aGlzLmF4aXMoc2gucm93T3JkZXIpLFxuICAgICAgICBjb2xzOiB0aGlzLmF4aXMoc2guY29sdW1uT3JkZXIpLFxuICAgICAgfTtcbiAgICAgIHRoaXMuaW5kaWNlcy5zZXQoc2gsIGluZGV4KTtcbiAgICB9XG4gICAgY29uc3QgeyByb3dzLCBjb2xzIH0gPSBpbmRleDtcbiAgICB0aGlzLmNoYW5nZWQuYWRkKGFkZHJlc3MpO1xuICAgIGNvbnN0IHByZXZpb3VzID0gaGVhZC5ibG9ja3NbYWRkcmVzc107XG4gICAgY29uc3QgZGlzY2FyZFByZXZpb3VzID0gYXN5bmMgKCkgPT4ge1xuICAgICAgaWYgKHByZXZpb3VzICYmIHRoaXMuYWxsb2NhdGVkLmhhcyhwcmV2aW91cy5pZCkgJiYgIXRoaXMucGlucy5oYXMocHJldmlvdXMuaWQpKSB7XG4gICAgICAgIGF3YWl0IHRoaXMuZGIud3JpdGUoJ3JlY29yZHMnLCBbXSwgW3ByZXZpb3VzLmlkXSk7XG4gICAgICAgIHRoaXMudXNlZEJ5dGVzIC09IHRoaXMuc2l6ZXMuZ2V0KHByZXZpb3VzLmlkKSA/PyAwO1xuICAgICAgICB0aGlzLnNpemVzLmRlbGV0ZShwcmV2aW91cy5pZCk7XG4gICAgICAgIHRoaXMuY2FjaGUuZGVsZXRlKHByZXZpb3VzLmlkKTtcbiAgICAgICAgdGhpcy5hbGxvY2F0ZWQuZGVsZXRlKHByZXZpb3VzLmlkKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IGZvcm11bGFzID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gICAgY29uc3Qgc3R5bGVzID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gICAgY29uc3QgdmlzaXQgPSAobm9kZTogQVNUKSA9PiB7XG4gICAgICBpZiAobm9kZS5raW5kID09PSAncmVmJykgZm9ybXVsYXMuYWRkKG5vZGUuc2hlZXQgPz8gc2gubmFtZSk7XG4gICAgICBlbHNlIGlmIChub2RlLmtpbmQgPT09ICdyYW5nZScpIHtcbiAgICAgICAgZm9ybXVsYXMuYWRkKG5vZGUuc3RhcnQuc2hlZXQgPz8gc2gubmFtZSk7XG4gICAgICAgIGZvcm11bGFzLmFkZChub2RlLmVuZC5zaGVldCA/PyBzaC5uYW1lKTtcbiAgICAgIH0gZWxzZSBpZiAobm9kZS5raW5kID09PSAndW5hcnknKSB2aXNpdChub2RlLnZhbHVlKTtcbiAgICAgIGVsc2UgaWYgKG5vZGUua2luZCA9PT0gJ2JpbmFyeScpIHtcbiAgICAgICAgdmlzaXQobm9kZS5sZWZ0KTtcbiAgICAgICAgdmlzaXQobm9kZS5yaWdodCk7XG4gICAgICB9IGVsc2UgaWYgKG5vZGUua2luZCA9PT0gJ2NhbGwnKSBub2RlLmFyZ3MuZm9yRWFjaCh2aXNpdCk7XG4gICAgfTtcbiAgICBsZXQgcmV0YWluZWQgPSAwLFxuICAgICAgcm93TG93ID0gMCxcbiAgICAgIHJvd0hpZ2ggPSAwLFxuICAgICAgY29sdW1uTWFzayA9IDAsXG4gICAgICBjb3VudCA9IDAsXG4gICAgICBlbmRSb3cgPSAxLFxuICAgICAgZW5kQ29sdW1uID0gMTtcbiAgICBmb3IgKGNvbnN0IFtrLCBjXSBvZiBPYmplY3QuZW50cmllcyhjZWxscykpIHtcbiAgICAgIGlmIChcbiAgICAgICAgYy5pbnB1dC50eXBlID09PSAnYmxhbmsnICYmXG4gICAgICAgIGMuc3R5bGVJZCA9PT0gdW5kZWZpbmVkICYmXG4gICAgICAgIGMubnVtYmVyRm9ybWF0ID09PSB1bmRlZmluZWQgJiZcbiAgICAgICAgYy5saW5rID09PSB1bmRlZmluZWQgJiZcbiAgICAgICAgYy5ub3RlID09PSB1bmRlZmluZWRcbiAgICAgICkge1xuICAgICAgICBkZWxldGUgY2VsbHNba107XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgcmV0YWluZWQrKztcbiAgICAgIGNvbnN0IHJvd0JpdCA9IGMucm93SWQgJSA2NDtcbiAgICAgIGlmIChyb3dCaXQgPCAzMikgcm93TG93IHw9IDEgPDwgcm93Qml0O1xuICAgICAgZWxzZSByb3dIaWdoIHw9IDEgPDwgKHJvd0JpdCAtIDMyKTtcbiAgICAgIGNvbHVtbk1hc2sgfD0gMSA8PCBjLmNvbHVtbklkICUgMzI7XG4gICAgICBpZiAoYy5zdHlsZUlkICE9PSB1bmRlZmluZWQpIHN0eWxlcy5hZGQoYy5zdHlsZUlkKTtcbiAgICAgIGlmIChjLmlucHV0LnR5cGUgIT09ICdibGFuaycpIGNvdW50Kys7XG4gICAgICBlbmRSb3cgPSBNYXRoLm1heChlbmRSb3csIHJvd3MuZ2V0KGMucm93SWQpISArIDEpO1xuICAgICAgZW5kQ29sdW1uID0gTWF0aC5tYXgoZW5kQ29sdW1uLCBjb2xzLmdldChjLmNvbHVtbklkKSEgKyAxKTtcbiAgICAgIGlmIChjLmlucHV0LnR5cGUgPT09ICdmb3JtdWxhJykge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIHZpc2l0KHBhcnNlRm9ybXVsYShjLmlucHV0LmV4cHJlc3Npb24pKTtcbiAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgZm9ybXVsYXMuYWRkKCcqJyk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKCFyZXRhaW5lZCkge1xuICAgICAgZGVsZXRlIGhlYWQuYmxvY2tzW2FkZHJlc3NdO1xuICAgICAgYXdhaXQgZGlzY2FyZFByZXZpb3VzKCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGVuY29kZWQgPSBlbmNvZGVCbG9jayhjZWxscywgW10sIFtdLCB7fSk7XG4gICAgY29uc3QgaWQgPSBhd2FpdCB0aGlzLmFsbG9jYXRlKGVuY29kZWQsIGhlYWQuYnVkZ2V0KTtcbiAgICB0aGlzLmNvbXByZXNzaW9uUXVldWUuYWRkKGlkKTtcbiAgICBjb25zdCBsb3cgPSAocm93TG93ID4+PiAwKS50b1N0cmluZygxNik7XG4gICAgaGVhZC5ibG9ja3NbYWRkcmVzc10gPSB7XG4gICAgICBpZCxcbiAgICAgIGJ5dGVzOiB0aGlzLnNpemVzLmdldChpZCkhLFxuICAgICAgY291bnQsXG4gICAgICBlbmRSb3csXG4gICAgICBlbmRDb2x1bW4sXG4gICAgICByb3dNYXNrOiByb3dIaWdoID8gKHJvd0hpZ2ggPj4+IDApLnRvU3RyaW5nKDE2KSArIGxvdy5wYWRTdGFydCg4LCAnMCcpIDogbG93LFxuICAgICAgY29sdW1uTWFzazogY29sdW1uTWFzayA+Pj4gMCxcbiAgICAgIC4uLihmb3JtdWxhcy5zaXplID8geyBmb3JtdWxhczogWy4uLmZvcm11bGFzXSB9IDoge30pLFxuICAgICAgLi4uKHN0eWxlcy5zaXplID8geyBzdHlsZXM6IFsuLi5zdHlsZXNdIH0gOiB7fSksXG4gICAgfTtcbiAgICBpZiAod2FybUNhY2hlKSB7XG4gICAgICBjb25zdCBwYWdlID0gZGVjb2RlQmxvY2soZW5jb2RlZCk7XG4gICAgICB0aGlzLmNhY2hlLnNldChpZCwgcGFnZSwgcGFnZS5ieXRlcyk7XG4gICAgfVxuICAgIGF3YWl0IGRpc2NhcmRQcmV2aW91cygpO1xuICB9XG4gIGFzeW5jIHJlcGxhY2Uoc25hcHNob3Q6IFdvcmtib29rU25hcHNob3QsIGJ1ZGdldCA9IHRoaXMuaGVhZC5idWRnZXQpIHtcbiAgICBhc3NlcnQodGhpcy53cml0ZXIsICdSRUFEX09OTFknLCAnV29ya2Jvb2sgaXMgb3BlbiBpbiBhbm90aGVyIHRhYicpO1xuICAgIHRoaXMuY2FuY2VsbGVkID0gZmFsc2U7XG4gICAgdGhpcy5hbGxvY2F0aW9ucyA9IFtdO1xuICAgIHRoaXMuY2hhbmdlZC5jbGVhcigpO1xuICAgIHRoaXMuYWxsb2NhdGVkLmNsZWFyKCk7XG4gICAgdGhpcy5waW5zLmNsZWFyKCk7XG4gICAgLy8gVmFsaWRhdGUgbWV0YWRhdGEgc2VwYXJhdGVseTsgZWFjaCBjZWxsIGlzIHZhbGlkYXRlZCBieSB0aGUgaW1wb3J0ZXIgaW4gYm91bmRlZCBiYXRjaGVzLlxuICAgIGNvbnN0IG1ldGFkYXRhOiBNZXRhZGF0YSA9IHtcbiAgICAgIGltcG9ydFJldmlzaW9uOiBzbmFwc2hvdC5yZXZpc2lvbixcbiAgICAgIHNuYXBzaG90OiB2YWxpZGF0ZVNuYXBzaG90KHtcbiAgICAgICAgLi4uc25hcHNob3QsXG4gICAgICAgIHNoZWV0czogc25hcHNob3Quc2hlZXRzLm1hcCgocykgPT4gKHsgLi4ucywgY2VsbHM6IHt9IH0pKSxcbiAgICAgIH0pLFxuICAgICAgZmlsdGVyZWQ6IHt9LFxuICAgIH07XG4gICAgY29uc3QgbmV4dDogSGVhZCA9IHtcbiAgICAgIG1ldGE6ICcnLFxuICAgICAgYmxvY2tzOiB7fSxcbiAgICAgIHJldmlzaW9uOiBzbmFwc2hvdC5yZXZpc2lvbixcbiAgICAgIHBhc3Q6IFtdLFxuICAgICAgZnV0dXJlOiBbXSxcbiAgICAgIGhpc3RvcnlCeXRlczogMCxcbiAgICAgIGJ1ZGdldCxcbiAgICB9O1xuICAgIGNvbnN0IG9sZCA9IGF3YWl0IHRoaXMubGl2ZUlkcygpO1xuICAgIGZvciAoY29uc3QgYWRkcmVzcyBvZiBPYmplY3Qua2V5cyh0aGlzLmhlYWQuYmxvY2tzKSkgdGhpcy5jaGFuZ2VkLmFkZChhZGRyZXNzKTtcbiAgICB0cnkge1xuICAgICAgZm9yIChjb25zdCBzaCBvZiBzbmFwc2hvdC5zaGVldHMpIHtcbiAgICAgICAgY29uc3Qgcm93cyA9IG5ldyBNYXAoc2gucm93T3JkZXIubWFwKChpZCwgaSkgPT4gW2lkLCBpXSkpLFxuICAgICAgICAgIGNvbHMgPSBuZXcgTWFwKHNoLmNvbHVtbk9yZGVyLm1hcCgoaWQsIGkpID0+IFtpZCwgaV0pKTtcbiAgICAgICAgY29uc3QgZ3JvdXBlZCA9IG5ldyBNYXA8c3RyaW5nLCBSZWNvcmQ8c3RyaW5nLCBDZWxsUmVjb3JkPj4oKTtcbiAgICAgICAgLy8gU25hcHNob3QgaW1wb3J0IGlzIGFuIGV4cGxpY2l0IGZ1bGwtbWVtb3J5IGNvbXBhdGliaWxpdHkgYm91bmRhcnk7IGdlbmVyYXRpb24gdXNlcyBnZW5lcmF0ZSgpLlxuICAgICAgICBmb3IgKGNvbnN0IFtrLCBjXSBvZiBPYmplY3QuZW50cmllcyhzaC5jZWxscykpIHtcbiAgICAgICAgICBjb25zdCByID0gcm93cy5nZXQoYy5yb3dJZCksXG4gICAgICAgICAgICBjb2wgPSBjb2xzLmdldChjLmNvbHVtbklkKTtcbiAgICAgICAgICBhc3NlcnQoXG4gICAgICAgICAgICByICE9PSB1bmRlZmluZWQgJiYgY29sICE9PSB1bmRlZmluZWQgJiYgayA9PT0ga2V5KGMucm93SWQsIGMuY29sdW1uSWQpLFxuICAgICAgICAgICAgJ0lOVkFMSURfQVJHVU1FTlQnLFxuICAgICAgICAgICAgJ0ludmFsaWQgY2VsbCBpZGVudGl0eScsXG4gICAgICAgICAgKTtcbiAgICAgICAgICBjb25zdCBhID0gYmxvY2tBZGRyZXNzKHNoLmlkLCBjLnJvd0lkLCBjLmNvbHVtbklkKTtcbiAgICAgICAgICBpZiAoIWdyb3VwZWQuaGFzKGEpKSBncm91cGVkLnNldChhLCB7fSk7XG4gICAgICAgICAgZ3JvdXBlZC5nZXQoYSkhW2tdID0gYztcbiAgICAgICAgfVxuICAgICAgICBsZXQgbiA9IDA7XG4gICAgICAgIGZvciAoY29uc3QgW2FkZHJlc3MsIGNlbGxzXSBvZiBncm91cGVkKSB7XG4gICAgICAgICAgdmFsaWRhdGVTbmFwc2hvdCh7XG4gICAgICAgICAgICAuLi5tZXRhZGF0YS5zbmFwc2hvdCxcbiAgICAgICAgICAgIHNoZWV0czogbWV0YWRhdGEuc25hcHNob3Quc2hlZXRzLm1hcCgocykgPT4gKHMuaWQgPT09IHNoLmlkID8geyAuLi5zLCBjZWxscyB9IDogcykpLFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIGF3YWl0IHRoaXMuc3RvcmVCbG9jayhhZGRyZXNzLCBjZWxscywgbmV4dCwgbWV0YWRhdGEpO1xuICAgICAgICAgIHRoaXMucHJvZ3Jlc3MoeyBwaGFzZTogJ2ltcG9ydCcsIGNvbXBsZXRlZDogKytuLCB0b3RhbDogZ3JvdXBlZC5zaXplIH0pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBhd2FpdCB0aGlzLmZpbHRlcnMobmV4dCwgbWV0YWRhdGEpO1xuICAgICAgbmV4dC5tZXRhID0gYXdhaXQgdGhpcy5hbGxvY2F0ZShlbmNvZGVNZXRhZGF0YShtZXRhZGF0YSksIGJ1ZGdldCk7XG4gICAgICBhd2FpdCB0aGlzLnB1Ymxpc2gobmV4dCwgbWV0YWRhdGEpO1xuICAgICAgYXdhaXQgdGhpcy5jbGVhbnVwKFsuLi5vbGQsIC4uLnRoaXMuYWxsb2NhdGlvbnNdKTtcbiAgICAgIHJldHVybiB0aGlzLnZpZXcoKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgYXdhaXQgdGhpcy5jbGVhbnVwKHRoaXMuYWxsb2NhdGlvbnMpO1xuICAgICAgdGhyb3cgZXJyb3I7XG4gICAgfVxuICB9XG4gIGFzeW5jIGltcG9ydEpTT04oaW5wdXQ6IFdvcmtib29rRmlsZSB8IEpTT05Tb3VyY2UsIGJ1ZGdldCA9IHRoaXMuaGVhZC5idWRnZXQpIHtcbiAgICByZXR1cm4gdGhpcy5pbXBvcnRTdGFnZWQoaW5wdXQsIGJ1ZGdldCk7XG4gIH1cbiAgLyoqIEludGVybmFsIG1pZ3JhdGlvbiBwYXRoLiBQdWJsaWMgbmF0aXZlIGltcG9ydCBjb250aW51ZXMgdG8gcmVqZWN0IHNjaGVtYSA0LiAqL1xuICBhc3luYyBpbXBvcnRSdWxlRnJlZVZhbGlkYXRpb25CYWNrdXAoaW5wdXQ6IEpTT05Tb3VyY2UsIGJ1ZGdldCA9IHRoaXMuaGVhZC5idWRnZXQpIHtcbiAgICBhc3NlcnQoXG4gICAgICB0eXBlb2YgaW5wdXQgPT09ICdzdHJpbmcnIHx8IGlucHV0IGluc3RhbmNlb2YgQmxvYiB8fCBpbnB1dCBpbnN0YW5jZW9mIFJlYWRhYmxlU3RyZWFtLFxuICAgICAgJ0lOVkFMSURfQVJHVU1FTlQnLFxuICAgICAgJ01pZ3JhdGlvbiByZXF1aXJlcyBhIEpTT04gc291cmNlJyxcbiAgICApO1xuICAgIHJldHVybiB0aGlzLmltcG9ydFN0YWdlZChpbnB1dCwgYnVkZ2V0LCBkb3duZ3JhZGVWYWxpZGF0aW9uTWV0YWRhdGEpO1xuICB9XG4gIHByaXZhdGUgYXN5bmMgaW1wb3J0U3RhZ2VkKFxuICAgIGlucHV0OiBXb3JrYm9va0ZpbGUgfCBKU09OU291cmNlLFxuICAgIGJ1ZGdldDogbnVtYmVyLFxuICAgIGNvbnZlcnRNZXRhZGF0YT86IChpbnB1dDogV29ya2Jvb2tGaWxlKSA9PiBXb3JrYm9va0ZpbGUsXG4gICkge1xuICAgIGFzc2VydCh0aGlzLndyaXRlciwgJ1JFQURfT05MWScsICdXb3JrYm9vayBpcyBvcGVuIGluIGFub3RoZXIgdGFiJyk7XG4gICAgdGhpcy5jaGVjaygpO1xuICAgIHRoaXMuYWxsb2NhdGlvbnMgPSBbXTtcbiAgICB0aGlzLmNoYW5nZWQuY2xlYXIoKTtcbiAgICB0aGlzLmFsbG9jYXRlZC5jbGVhcigpO1xuICAgIHRoaXMucGlucy5jbGVhcigpO1xuICAgIGNvbnN0IG9sZCA9IGF3YWl0IHRoaXMubGl2ZUlkcygpO1xuICAgIHRoaXMuY2hlY2soKTtcbiAgICBmb3IgKGNvbnN0IGFkZHJlc3Mgb2YgT2JqZWN0LmtleXModGhpcy5oZWFkLmJsb2NrcykpIHRoaXMuY2hhbmdlZC5hZGQoYWRkcmVzcyk7XG4gICAgbGV0IGZpbGU6IFdvcmtib29rRmlsZSB8IHVuZGVmaW5lZCxcbiAgICAgIGJpbmFyeVNuYXBzaG90OiBXb3JrYm9va1NuYXBzaG90IHwgdW5kZWZpbmVkLFxuICAgICAgc3RhZ2VkID0gMDtcbiAgICBjb25zdCBzY3JhdGNoID0gYCR7dGhpcy5pZH0vaW1wb3J0YDtcbiAgICBsZXQgc2NyYXRjaFdyaXRlTXMgPSAwO1xuICAgIGNvbnN0IHNvdXJjZVN0YWdlU3RhcnQgPSBwZXJmb3JtYW5jZS5ub3coKTtcbiAgICBjb25zdCByZWFkZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gICAgdGhpcy5pbXBvcnRSZWFkID0gcmVhZGVyO1xuICAgIGNvbnN0IHN0YWdlID0gYXN5bmMgKHZhbHVlOiB1bmtub3duLCBzdWZmaXggPSAnJykgPT4ge1xuICAgICAgdGhpcy5jaGVjaygpO1xuICAgICAgY29uc3QgcmVjb3JkOiBbSURCVmFsaWRLZXksIHVua25vd25dID0gW1xuICAgICAgICBgJHtzY3JhdGNofS8ke1N0cmluZyhzdGFnZWQrKykucGFkU3RhcnQoMTAsICcwJyl9JHtzdWZmaXh9YCxcbiAgICAgICAgdmFsdWUsXG4gICAgICBdO1xuICAgICAgdGhpcy5zdGFnaW5nQnl0ZXMgKz0gcmVjb3JkQnl0ZXMocmVjb3JkWzBdLCByZWNvcmRbMV0pO1xuICAgICAgYXNzZXJ0KFxuICAgICAgICB0aGlzLnVzZWRCeXRlcyArIHRoaXMuc3RhZ2luZ0J5dGVzIDw9IGJ1ZGdldCxcbiAgICAgICAgJ1NUT1JBR0VfQlVER0VUJyxcbiAgICAgICAgJ0ltcG9ydCBzdGFnaW5nIGV4Y2VlZHMgc3RvcmFnZSBidWRnZXQnLFxuICAgICAgKTtcbiAgICAgIGNvbnN0IHdyaXRlU3RhcnQgPSBwZXJmb3JtYW5jZS5ub3coKTtcbiAgICAgIGF3YWl0IHRoaXMuZGIud3JpdGUoJ3NjcmF0Y2gnLCBbcmVjb3JkXSwgW10sIHJlYWRlci5zaWduYWwpO1xuICAgICAgc2NyYXRjaFdyaXRlTXMgKz0gcGVyZm9ybWFuY2Uubm93KCkgLSB3cml0ZVN0YXJ0O1xuICAgICAgdGhpcy5wcm9ncmVzcyh7IHBoYXNlOiAnaW1wb3J0LXBhcnNlJywgY29tcGxldGVkOiBzdGFnZWQgfSk7XG4gICAgfTtcbiAgICB0cnkge1xuICAgICAgaWYgKGlucHV0ICYmIHR5cGVvZiBpbnB1dCA9PT0gJ29iamVjdCcgJiYgJ2JpbmFyeScgaW4gaW5wdXQpIHtcbiAgICAgICAgZm9yIGF3YWl0IChjb25zdCBpdGVtIG9mIHJlYWRCaW5hcnkoXG4gICAgICAgICAgKGlucHV0IGFzIHVua25vd24gYXMgeyBiaW5hcnk6IEJsb2IgfCBVaW50OEFycmF5IHwgUmVhZGFibGVTdHJlYW08VWludDhBcnJheT4gfSkuYmluYXJ5LFxuICAgICAgICAgIHsgc2lnbmFsOiByZWFkZXIuc2lnbmFsIH0sXG4gICAgICAgICkpIHtcbiAgICAgICAgICBpZiAoJ21ldGFkYXRhJyBpbiBpdGVtKSB7XG4gICAgICAgICAgICBmaWxlID0gaXRlbS5tZXRhZGF0YTtcbiAgICAgICAgICAgIGJpbmFyeVNuYXBzaG90ID0gaXRlbS5zbmFwc2hvdDtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgYXdhaXQgc3RhZ2UoaXRlbS5ieXRlcywgYC8ke2l0ZW0uc2hlZXR9LyR7aXRlbS5yb3d9LyR7aXRlbS5jb2x1bW59YCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKFxuICAgICAgICB0eXBlb2YgaW5wdXQgPT09ICdzdHJpbmcnIHx8XG4gICAgICAgIGlucHV0IGluc3RhbmNlb2YgQmxvYiB8fFxuICAgICAgICBpbnB1dCBpbnN0YW5jZW9mIFJlYWRhYmxlU3RyZWFtXG4gICAgICApIHtcbiAgICAgICAgZm9yIGF3YWl0IChjb25zdCBpdGVtIG9mIHBhcnNlV29ya2Jvb2tKU09OKGlucHV0LCB7IHNpZ25hbDogcmVhZGVyLnNpZ25hbCB9KSkge1xuICAgICAgICAgIGlmICgnYmxvY2snIGluIGl0ZW0pIGF3YWl0IHN0YWdlKGl0ZW0pO1xuICAgICAgICAgIGVsc2UgZmlsZSA9IGNvbnZlcnRNZXRhZGF0YSA/IGNvbnZlcnRNZXRhZGF0YShpdGVtLm1ldGFkYXRhKSA6IGl0ZW0ubWV0YWRhdGE7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGFzc2VydChpbnB1dCAmJiBBcnJheS5pc0FycmF5KGlucHV0LnNoZWV0cyksICdJTlZBTElEX0FSR1VNRU5UJywgJ0ludmFsaWQgd29ya2Jvb2sgZmlsZScpO1xuICAgICAgICBmaWxlID0geyAuLi5pbnB1dCwgc2hlZXRzOiBpbnB1dC5zaGVldHMubWFwKChzaCkgPT4gKHsgLi4uc2gsIGJsb2NrczogW10gfSkpIH07XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaW5wdXQuc2hlZXRzLmxlbmd0aDsgaSsrKVxuICAgICAgICAgIGZvciAoY29uc3QgYmxvY2sgb2YgaW5wdXQuc2hlZXRzW2ldLmJsb2NrcykgYXdhaXQgc3RhZ2UoeyBzaGVldDogaSwgYmxvY2sgfSk7XG4gICAgICB9XG4gICAgICB0aGlzLnByb2dyZXNzKHtcbiAgICAgICAgcGhhc2U6ICdpbXBvcnQtc291cmNlLXN0YWdlJyxcbiAgICAgICAgY29tcGxldGVkOiBzdGFnZWQsXG4gICAgICAgIGVsYXBzZWRNczogcGVyZm9ybWFuY2Uubm93KCkgLSBzb3VyY2VTdGFnZVN0YXJ0LFxuICAgICAgfSk7XG4gICAgICB0aGlzLnByb2dyZXNzKHtcbiAgICAgICAgcGhhc2U6ICdpbXBvcnQtc2NyYXRjaC13cml0ZScsXG4gICAgICAgIGNvbXBsZXRlZDogc3RhZ2VkLFxuICAgICAgICBlbGFwc2VkTXM6IHNjcmF0Y2hXcml0ZU1zLFxuICAgICAgfSk7XG4gICAgICB0aGlzLmNoZWNrKCk7XG4gICAgICBhc3NlcnQoZmlsZSwgJ0lOVkFMSURfQVJHVU1FTlQnLCAnTWlzc2luZyB3b3JrYm9vayBtZXRhZGF0YScpO1xuICAgICAgY29uc3Qgc25hcHNob3QgPSBiaW5hcnlTbmFwc2hvdCA/PyBkZWNvZGVGaWxlTWV0YWRhdGEoZmlsZSk7XG4gICAgICBzbmFwc2hvdC53b3JrYm9va0lkID0gdGhpcy5pZDtcbiAgICAgIC8vIEltcG9ydCBpcyBhIGxvZ2ljYWwgY2hhbmdlIGV2ZW4gaWYgdGhlIHNvdXJjZSByZXZpc2lvbiBpcyBvbGRlci5cbiAgICAgIHNuYXBzaG90LnJldmlzaW9uID0gdGhpcy5oZWFkLm1ldGEgPyB0aGlzLmhlYWQucmV2aXNpb24gKyAxIDogZmlsZS5yZXZpc2lvbjtcbiAgICAgIGNvbnN0IG1ldGFkYXRhOiBNZXRhZGF0YSA9IHsgc25hcHNob3QsIGltcG9ydFJldmlzaW9uOiBzbmFwc2hvdC5yZXZpc2lvbiwgZmlsdGVyZWQ6IHt9IH07XG4gICAgICBjb25zdCBuZXh0OiBIZWFkID0ge1xuICAgICAgICBtZXRhOiAnJyxcbiAgICAgICAgYmxvY2tzOiB7fSxcbiAgICAgICAgcmV2aXNpb246IHNuYXBzaG90LnJldmlzaW9uLFxuICAgICAgICBwYXN0OiBbXSxcbiAgICAgICAgZnV0dXJlOiBbXSxcbiAgICAgICAgaGlzdG9yeUJ5dGVzOiAwLFxuICAgICAgICBidWRnZXQsXG4gICAgICB9O1xuICAgICAgY29uc3Qgc3R5bGVzID0gT2JqZWN0LmtleXMoc25hcHNob3Quc3R5bGVzKSxcbiAgICAgICAgc3R5bGVTZXQgPSBiaW5hcnlTbmFwc2hvdCA/IG5ldyBTZXQoc3R5bGVzKSA6IHVuZGVmaW5lZCxcbiAgICAgICAgcm93cyA9IHNuYXBzaG90LnNoZWV0cy5tYXAoKHNoKSA9PiBuZXcgU2V0KHNoLnJvd09yZGVyKSksXG4gICAgICAgIGNvbHVtbnMgPSBzbmFwc2hvdC5zaGVldHMubWFwKChzaCkgPT4gbmV3IFNldChzaC5jb2x1bW5PcmRlcikpO1xuICAgICAgLy8gRmlsdGVycyBtYXkgaW1tZWRpYXRlbHkgcmVhZCBzdGFnZWQgcGFnZXMgKGluY2x1ZGluZyBjcm9zcy1zaGVldCByZWZlcmVuY2VzKS5cbiAgICAgIC8vIE90aGVyd2lzZSBsZXQgdGhlIGZpcnN0IGFjdHVhbCByZWFkIHBvcHVsYXRlIHRoZSBjYWNoZS5cbiAgICAgIGNvbnN0IHdhcm1DYWNoZSA9IHNuYXBzaG90LnNoZWV0cy5zb21lKChzaGVldCkgPT4gISFzaGVldC5maWx0ZXIpO1xuICAgICAgbGV0IGNvbXBsZXRlZCA9IDA7XG4gICAgICBjb25zdCBzZWVuID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gICAgICBjb25zdCB0aW1lcyA9IHtcbiAgICAgICAgJ2ltcG9ydC1zY3JhdGNoLXJlYWQnOiAwLFxuICAgICAgICAnaW1wb3J0LWRlY29kZSc6IDAsXG4gICAgICAgICdpbXBvcnQtcGFnZXMnOiAwLFxuICAgICAgICAnaW1wb3J0LXNjcmF0Y2gtZGVsZXRlJzogMCxcbiAgICAgIH07XG4gICAgICBsZXQgcHJldmlvdXMgPSBwZXJmb3JtYW5jZS5ub3coKTtcbiAgICAgIGZvciBhd2FpdCAoY29uc3QgYmF0Y2ggb2YgdGhpcy5kYi5zY2FuPFxuICAgICAgICB8IFVpbnQ4QXJyYXlcbiAgICAgICAgfCB7XG4gICAgICAgICAgICBzaGVldDogbnVtYmVyO1xuICAgICAgICAgICAgYmxvY2s6IGltcG9ydCgnLi9maWxlLWNvZGVjLmpzJykuRmlsZUJsb2NrO1xuICAgICAgICAgIH1cbiAgICAgID4oJ3NjcmF0Y2gnLCBwcmVmaXhSYW5nZShzY3JhdGNoKSwgMTYsIDEwMjQgKiAxMDI0KSkge1xuICAgICAgICBjb25zdCByZWNlaXZlZCA9IHBlcmZvcm1hbmNlLm5vdygpO1xuICAgICAgICB0aW1lc1snaW1wb3J0LXNjcmF0Y2gtcmVhZCddICs9IHJlY2VpdmVkIC0gcHJldmlvdXM7XG4gICAgICAgIGZvciAoY29uc3QgW2lkLCBpdGVtXSBvZiBiYXRjaCkge1xuICAgICAgICAgIGNvbnN0IGRlY29kaW5nID0gcGVyZm9ybWFuY2Uubm93KCk7XG4gICAgICAgICAgdGhpcy5jaGVjaygpO1xuICAgICAgICAgIGNvbnN0IGJpbmFyeSA9IGl0ZW0gaW5zdGFuY2VvZiBVaW50OEFycmF5O1xuICAgICAgICAgIGNvbnN0IFtzaGVldCwgcm93LCBjb2x1bW5dID0gYmluYXJ5XG4gICAgICAgICAgICA/IFN0cmluZyhpZCkuc3BsaXQoJy8nKS5zbGljZSgtMykubWFwKE51bWJlcilcbiAgICAgICAgICAgIDogW2l0ZW0uc2hlZXQsIGl0ZW0uYmxvY2sucm93LCBpdGVtLmJsb2NrLmNvbHVtbl07XG4gICAgICAgICAgYXNzZXJ0KFxuICAgICAgICAgICAgTnVtYmVyLmlzSW50ZWdlcihzaGVldCkgJiYgISFzbmFwc2hvdC5zaGVldHNbc2hlZXRdICYmIGJpbmFyeSA9PT0gISFiaW5hcnlTbmFwc2hvdCxcbiAgICAgICAgICAgICdJTlZBTElEX0FSR1VNRU5UJyxcbiAgICAgICAgICAgICdVbmtub3duIGltcG9ydGVkIHNoZWV0JyxcbiAgICAgICAgICApO1xuICAgICAgICAgIGNvbnN0IHNoID0gc25hcHNob3Quc2hlZXRzW3NoZWV0XSxcbiAgICAgICAgICAgIGFkZHJlc3MgPSBgJHtzaC5pZH0vJHtyb3d9LyR7Y29sdW1ufWA7XG4gICAgICAgICAgYXNzZXJ0KCFzZWVuLmhhcyhhZGRyZXNzKSwgJ0lOVkFMSURfQVJHVU1FTlQnLCAnRHVwbGljYXRlIGltcG9ydGVkIGJsb2NrJyk7XG4gICAgICAgICAgc2Vlbi5hZGQoYWRkcmVzcyk7XG4gICAgICAgICAgY29uc3QgY2VsbHMgPSBiaW5hcnlcbiAgICAgICAgICAgID8gZGVjb2RlVmVyaWZpZWRCaW5hcnlQYWdlKGl0ZW0sIHJvdywgY29sdW1uLCByb3dzW3NoZWV0XSwgY29sdW1uc1tzaGVldF0sIHN0eWxlU2V0ISlcbiAgICAgICAgICAgIDogZGVjb2RlRmlsZUNlbGxzKGl0ZW0uYmxvY2ssIHN0eWxlcywgcm93c1tzaGVldF0sIGNvbHVtbnNbc2hlZXRdKTtcbiAgICAgICAgICBjb25zdCBkZWNvZGVkID0gcGVyZm9ybWFuY2Uubm93KCk7XG4gICAgICAgICAgdGltZXNbJ2ltcG9ydC1kZWNvZGUnXSArPSBkZWNvZGVkIC0gZGVjb2Rpbmc7XG4gICAgICAgICAgYXdhaXQgdGhpcy5zdG9yZUJsb2NrKGFkZHJlc3MsIGNlbGxzLCBuZXh0LCBtZXRhZGF0YSwgd2FybUNhY2hlKTtcbiAgICAgICAgICBjb25zdCBzdG9yZWQgPSBwZXJmb3JtYW5jZS5ub3coKTtcbiAgICAgICAgICB0aW1lc1snaW1wb3J0LXBhZ2VzJ10gKz0gc3RvcmVkIC0gZGVjb2RlZDtcbiAgICAgICAgICBhd2FpdCB0aGlzLmRiLndyaXRlKCdzY3JhdGNoJywgW10sIFtpZF0pO1xuICAgICAgICAgIHRpbWVzWydpbXBvcnQtc2NyYXRjaC1kZWxldGUnXSArPSBwZXJmb3JtYW5jZS5ub3coKSAtIHN0b3JlZDtcbiAgICAgICAgICB0aGlzLnN0YWdpbmdCeXRlcyAtPSByZWNvcmRCeXRlcyhpZCwgaXRlbSk7XG4gICAgICAgICAgdGhpcy5wcm9ncmVzcyh7IHBoYXNlOiAnaW1wb3J0LXN0b3JlJywgY29tcGxldGVkOiArK2NvbXBsZXRlZCwgdG90YWw6IHN0YWdlZCB9KTtcbiAgICAgICAgfVxuICAgICAgICBwcmV2aW91cyA9IHBlcmZvcm1hbmNlLm5vdygpO1xuICAgICAgfVxuICAgICAgdGltZXNbJ2ltcG9ydC1zY3JhdGNoLXJlYWQnXSArPSBwZXJmb3JtYW5jZS5ub3coKSAtIHByZXZpb3VzO1xuICAgICAgZm9yIChjb25zdCBbcGhhc2UsIGVsYXBzZWRNc10gb2YgT2JqZWN0LmVudHJpZXModGltZXMpKVxuICAgICAgICB0aGlzLnByb2dyZXNzKHsgcGhhc2UsIGVsYXBzZWRNcywgY29tcGxldGVkLCB0b3RhbDogc3RhZ2VkIH0pO1xuICAgICAgYXdhaXQgdGhpcy5maWx0ZXJzKG5leHQsIG1ldGFkYXRhKTtcbiAgICAgIG5leHQubWV0YSA9IGF3YWl0IHRoaXMuYWxsb2NhdGUoZW5jb2RlTWV0YWRhdGEobWV0YWRhdGEpLCBidWRnZXQpO1xuICAgICAgYXdhaXQgdGhpcy5wdWJsaXNoKG5leHQsIG1ldGFkYXRhKTtcbiAgICAgIGF3YWl0IHRoaXMuY2xlYW51cChbLi4ub2xkLCAuLi50aGlzLmFsbG9jYXRpb25zXSk7XG4gICAgICByZXR1cm4gdGhpcy52aWV3KCk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGF3YWl0IHRoaXMuY2xlYW51cCh0aGlzLmFsbG9jYXRpb25zKTtcbiAgICAgIHRocm93IGVycm9yO1xuICAgIH0gZmluYWxseSB7XG4gICAgICB0aGlzLmltcG9ydFJlYWQgPSB1bmRlZmluZWQ7XG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCB0aGlzLmRiLndyaXRlKCdzY3JhdGNoJywgW10sIFtwcmVmaXhSYW5nZShzY3JhdGNoKV0pO1xuICAgICAgICB0aGlzLnN0YWdpbmdCeXRlcyA9IDA7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgLy8gS2VlcCBmYWlsZWQgc3RhZ2luZyBjaGFyZ2VkLiBSZW9wZW4gcmVjbGFpbXMgaXQgYmVmb3JlIGFub3RoZXIgaW1wb3J0XG4gICAgICAgIC8vIGNhbiByZXVzZSB0aGVzZSBrZXlzLiBQcmVzZXJ2ZSB0aGUgb3JpZ2luYWwgb3BlcmF0aW9uIHJlc3VsdC5cbiAgICAgICAgdGhpcy5wb2lzb25lZCA9IHRydWU7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIGltcG9ydEJpbmFyeShpbnB1dDogQmxvYiB8IFVpbnQ4QXJyYXkgfCBSZWFkYWJsZVN0cmVhbTxVaW50OEFycmF5Pikge1xuICAgIHJldHVybiB0aGlzLmltcG9ydEpTT04oeyBiaW5hcnk6IGlucHV0IH0gYXMgdW5rbm93biBhcyBXb3JrYm9va0ZpbGUpO1xuICB9XG4gIGFzeW5jIGdlbmVyYXRlKGNvdW50OiBudW1iZXIsIGJ1ZGdldDogbnVtYmVyKSB7XG4gICAgYXNzZXJ0KHRoaXMud3JpdGVyLCAnUkVBRF9PTkxZJywgJ1dvcmtib29rIGlzIG9wZW4gaW4gYW5vdGhlciB0YWInKTtcbiAgICBhc3NlcnQoXG4gICAgICBOdW1iZXIuaXNTYWZlSW50ZWdlcihjb3VudCkgJiYgY291bnQgPiAwICYmIGNvdW50IDw9IDEwXzAwMF8wMDAsXG4gICAgICAnSU5WQUxJRF9BUkdVTUVOVCcsXG4gICAgICAnQ291bnQgZXhjZWVkcyB0aGUgMTAwLWNvbHVtbiBkaW1lbnNpb24gYm91bmRhcnknLFxuICAgICk7XG4gICAgdGhpcy5jYW5jZWxsZWQgPSBmYWxzZTtcbiAgICB0aGlzLmFsbG9jYXRpb25zID0gW107XG4gICAgdGhpcy5jaGFuZ2VkLmNsZWFyKCk7XG4gICAgdGhpcy5hbGxvY2F0ZWQuY2xlYXIoKTtcbiAgICB0aGlzLnBpbnMuY2xlYXIoKTtcbiAgICBjb25zdCBtZXRhZGF0YTogTWV0YWRhdGEgPSBzdHJ1Y3R1cmVkQ2xvbmUodGhpcy5tZXRhZGF0YSk7XG4gICAgY29uc3Qgc2ggPSBtZXRhZGF0YS5zbmFwc2hvdC5zaGVldHNbMF07XG4gICAgc2gucm93T3JkZXIgPSBBcnJheS5mcm9tKHsgbGVuZ3RoOiBNYXRoLmNlaWwoY291bnQgLyAxMDApIH0sIChfLCBpKSA9PiBpKTtcbiAgICBzaC5jb2x1bW5PcmRlciA9IEFycmF5LmZyb20oeyBsZW5ndGg6IDEwMCB9LCAoXywgaSkgPT4gaSk7XG4gICAgc2gubmV4dFJvd0lkID0gc2gucm93T3JkZXIubGVuZ3RoO1xuICAgIHNoLm5leHRDb2x1bW5JZCA9IHNoLmNvbHVtbk9yZGVyLmxlbmd0aDtcbiAgICBzaC5jZWxscyA9IHt9O1xuICAgIHNoLnJvd3MgPSB7fTtcbiAgICBzaC5jb2x1bW5zID0ge307XG4gICAgc2gubWVyZ2VzID0gW107XG4gICAgc2guZnJlZXplID0geyByb3dzOiAwLCBjb2x1bW5zOiAwIH07XG4gICAgc2guZmlsdGVyID0gbnVsbDtcbiAgICBtZXRhZGF0YS5zbmFwc2hvdC5zaGVldHMgPSBbc2hdO1xuICAgIG1ldGFkYXRhLnNuYXBzaG90LnNoZWV0T3JkZXIgPSBbc2guaWRdO1xuICAgIG1ldGFkYXRhLnNuYXBzaG90LnN0eWxlcyA9IHt9O1xuICAgIG1ldGFkYXRhLmZpbHRlcmVkID0ge307XG4gICAgY29uc3QgbmV4dDogSGVhZCA9IHtcbiAgICAgIG1ldGE6ICcnLFxuICAgICAgYmxvY2tzOiB7fSxcbiAgICAgIHJldmlzaW9uOiB0aGlzLmhlYWQucmV2aXNpb24gKyAxLFxuICAgICAgcGFzdDogW10sXG4gICAgICBmdXR1cmU6IFtdLFxuICAgICAgaGlzdG9yeUJ5dGVzOiAwLFxuICAgICAgYnVkZ2V0LFxuICAgIH07XG4gICAgY29uc3Qgb2xkID0gYXdhaXQgdGhpcy5saXZlSWRzKCk7XG4gICAgZm9yIChjb25zdCBhZGRyZXNzIG9mIE9iamVjdC5rZXlzKHRoaXMuaGVhZC5ibG9ja3MpKSB0aGlzLmNoYW5nZWQuYWRkKGFkZHJlc3MpO1xuICAgIHRyeSB7XG4gICAgICBmb3IgKGxldCByID0gMDsgciA8IHNoLnJvd09yZGVyLmxlbmd0aDsgciArPSBCTE9DS19ST1dTKVxuICAgICAgICBmb3IgKGxldCBjID0gMDsgYyA8IDEwMDsgYyArPSBCTE9DS19DT0xVTU5TKSB7XG4gICAgICAgICAgY29uc3QgY2VsbHM6IFJlY29yZDxzdHJpbmcsIENlbGxSZWNvcmQ+ID0ge307XG4gICAgICAgICAgZm9yIChsZXQgcm93ID0gcjsgcm93IDwgTWF0aC5taW4ociArIEJMT0NLX1JPV1MsIHNoLnJvd09yZGVyLmxlbmd0aCk7IHJvdysrKVxuICAgICAgICAgICAgZm9yIChsZXQgY29sdW1uID0gYzsgY29sdW1uIDwgTWF0aC5taW4oYyArIEJMT0NLX0NPTFVNTlMsIDEwMCk7IGNvbHVtbisrKSB7XG4gICAgICAgICAgICAgIGNvbnN0IG4gPSByb3cgKiAxMDAgKyBjb2x1bW47XG4gICAgICAgICAgICAgIGlmIChuID49IGNvdW50KSBicmVhaztcbiAgICAgICAgICAgICAgY29uc3QgdiA9IGZpeHR1cmVWYWx1ZShuKTtcbiAgICAgICAgICAgICAgY2VsbHNba2V5KHNoLnJvd09yZGVyW3Jvd10sIHNoLmNvbHVtbk9yZGVyW2NvbHVtbl0pXSA9IHtcbiAgICAgICAgICAgICAgICByb3dJZDogc2gucm93T3JkZXJbcm93XSxcbiAgICAgICAgICAgICAgICBjb2x1bW5JZDogc2guY29sdW1uT3JkZXJbY29sdW1uXSxcbiAgICAgICAgICAgICAgICBpbnB1dDpcbiAgICAgICAgICAgICAgICAgIHR5cGVvZiB2ID09PSAnbnVtYmVyJ1xuICAgICAgICAgICAgICAgICAgICA/IHsgdHlwZTogJ251bWJlcicsIHZhbHVlOiB2IH1cbiAgICAgICAgICAgICAgICAgICAgOiB0eXBlb2YgdiA9PT0gJ2Jvb2xlYW4nXG4gICAgICAgICAgICAgICAgICAgICAgPyB7IHR5cGU6ICdib29sZWFuJywgdmFsdWU6IHYgfVxuICAgICAgICAgICAgICAgICAgICAgIDogeyB0eXBlOiAnc3RyaW5nJywgdmFsdWU6IHYgfSxcbiAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICBhd2FpdCB0aGlzLnN0b3JlQmxvY2soYmxvY2tBZGRyZXNzKHNoLmlkLCByLCBjKSwgY2VsbHMsIG5leHQsIG1ldGFkYXRhKTtcbiAgICAgICAgICB0aGlzLnByb2dyZXNzKHtcbiAgICAgICAgICAgIHBoYXNlOiAnZ2VuZXJhdGUnLFxuICAgICAgICAgICAgY29tcGxldGVkOiBNYXRoLm1pbihjb3VudCwgKHIgKyBCTE9DS19ST1dTKSAqIDEwMCksXG4gICAgICAgICAgICB0b3RhbDogY291bnQsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIG5leHQubWV0YSA9IGF3YWl0IHRoaXMuYWxsb2NhdGUoZW5jb2RlTWV0YWRhdGEobWV0YWRhdGEpLCBidWRnZXQpO1xuICAgICAgYXdhaXQgdGhpcy5wdWJsaXNoKG5leHQsIG1ldGFkYXRhKTtcbiAgICAgIGF3YWl0IHRoaXMuY2xlYW51cChbLi4ub2xkLCAuLi50aGlzLmFsbG9jYXRpb25zXSk7XG4gICAgICByZXR1cm4gdGhpcy52aWV3KCk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGF3YWl0IHRoaXMuY2xlYW51cCh0aGlzLmFsbG9jYXRpb25zKTtcbiAgICAgIHRocm93IGVycm9yO1xuICAgIH1cbiAgfVxuICBwcml2YXRlIGFzeW5jIGZpbHRlcnMoaGVhZDogSGVhZCwgbWV0YWRhdGE6IE1ldGFkYXRhKSB7XG4gICAgbWV0YWRhdGEuZmlsdGVyZWQgPSB7fTtcbiAgICBpZiAoIW1ldGFkYXRhLnNuYXBzaG90LnNoZWV0cy5zb21lKChzaGVldCkgPT4gc2hlZXQuZmlsdGVyKSkgcmV0dXJuO1xuICAgIHRoaXMuY2FsY3VsYXRvci5jbGVhcigpO1xuICAgIGNvbnN0IGNhbGN1bGF0b3IgPSBuZXcgQXN5bmNDYWxjdWxhdGlvbihcbiAgICAgIChzaGVldCwgcm93LCBjb2x1bW4pID0+IHRoaXMuc3RhZ2VkQ2VsbChzaGVldCwgcm93LCBjb2x1bW4sIGhlYWQsIG1ldGFkYXRhKSxcbiAgICAgIChuYW1lKSA9PlxuICAgICAgICBtZXRhZGF0YS5zbmFwc2hvdC5zaGVldHMuZmluZCgocykgPT4gcy5uYW1lLnRvTG93ZXJDYXNlKCkgPT09IG5hbWUudG9Mb3dlckNhc2UoKSk/LmlkLFxuICAgICAgdGhpcy5jYWxjdWxhdG9yLmNhY2hlQnVkZ2V0LFxuICAgICAgdW5kZWZpbmVkLFxuICAgICAgKCkgPT4gbWV0YWRhdGEuc25hcHNob3QuZGF0ZVN5c3RlbSxcbiAgICApO1xuICAgIGZvciAoY29uc3Qgc2ggb2YgbWV0YWRhdGEuc25hcHNob3Quc2hlZXRzKVxuICAgICAgaWYgKHNoLmZpbHRlcikge1xuICAgICAgICBjb25zdCBoaWRkZW46IG51bWJlcltdID0gW107XG4gICAgICAgIGNvbnN0IGZpbHRlciA9IHNoLmZpbHRlcjtcbiAgICAgICAgY29uc3QgcXVlcnkgPSAnY29sdW1uJyBpbiBmaWx0ZXIgPyBmaWx0ZXIucXVlcnkudG9Mb3dlckNhc2UoKSA6IHVuZGVmaW5lZDtcbiAgICAgICAgY29uc3QgY3JpdGVyaWEgPVxuICAgICAgICAgICdjcml0ZXJpYScgaW4gZmlsdGVyXG4gICAgICAgICAgICA/IGZpbHRlci5jcml0ZXJpYS5tYXAoKGNyaXRlcmlvbikgPT4gKHtcbiAgICAgICAgICAgICAgICBjcml0ZXJpb24sXG4gICAgICAgICAgICAgICAgZm9sZGVkUXVlcnk6XG4gICAgICAgICAgICAgICAgICAndmFsdWUnIGluIGNyaXRlcmlvbiAmJiB0eXBlb2YgY3JpdGVyaW9uLnZhbHVlID09PSAnc3RyaW5nJ1xuICAgICAgICAgICAgICAgICAgICA/IGNyaXRlcmlvbi52YWx1ZS50b0xvd2VyQ2FzZSgpXG4gICAgICAgICAgICAgICAgICAgIDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICB9KSlcbiAgICAgICAgICAgIDogW107XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgaGVhZGVyUm93cyA9ICdjb2x1bW4nIGluIGZpbHRlciA/IDEgOiBmaWx0ZXIuaGVhZGVyUm93cztcbiAgICAgICAgICBmb3IgKGxldCByb3cgPSBoZWFkZXJSb3dzOyByb3cgPCBzaC5yb3dPcmRlci5sZW5ndGg7IHJvdysrKSB7XG4gICAgICAgICAgICB0aGlzLmNoZWNrKCk7XG4gICAgICAgICAgICBsZXQgbWF0Y2hlczogYm9vbGVhbjtcbiAgICAgICAgICAgIGlmICgnY29sdW1uJyBpbiBmaWx0ZXIpIHtcbiAgICAgICAgICAgICAgY29uc3QgYyA9IGF3YWl0IHRoaXMuc3RhZ2VkQ2VsbChzaC5pZCwgcm93LCBmaWx0ZXIuY29sdW1uLCBoZWFkLCBtZXRhZGF0YSk7XG4gICAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gYXdhaXQgY2FsY3VsYXRvci52YWx1ZShzaC5pZCwgcm93LCBmaWx0ZXIuY29sdW1uKTtcbiAgICAgICAgICAgICAgYXNzZXJ0KFxuICAgICAgICAgICAgICAgICEodmFsdWUgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZS5lcnJvciA9PT0gJyNMSU1JVCEnKSxcbiAgICAgICAgICAgICAgICAnTElNSVRfRVhDRUVERUQnLFxuICAgICAgICAgICAgICAgICdGaWx0ZXIgY2FsY3VsYXRpb24gZXhjZWVkZWQgaXRzIHdvcmsgYnVkZ2V0JyxcbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgbWF0Y2hlcyA9IGZvcm1hdFZhbHVlKFxuICAgICAgICAgICAgICAgIHZhbHVlLFxuICAgICAgICAgICAgICAgIGM/Lm51bWJlckZvcm1hdCA/PyBtZXRhZGF0YS5zbmFwc2hvdC5zdHlsZXNbYz8uc3R5bGVJZCA/PyAnJ10/Lm51bWJlckZvcm1hdCxcbiAgICAgICAgICAgICAgICBtZXRhZGF0YS5zbmFwc2hvdC5kYXRlU3lzdGVtLFxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcbiAgICAgICAgICAgICAgICAuaW5jbHVkZXMocXVlcnkhKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIG1hdGNoZXMgPSBmaWx0ZXIubW9kZSA9PT0gJ2FsbCc7XG4gICAgICAgICAgICAgIGNvbnN0IHZhbHVlcyA9IG5ldyBNYXA8bnVtYmVyLCBDZWxsVmFsdWU+KCk7XG4gICAgICAgICAgICAgIGZvciAoY29uc3QgeyBjcml0ZXJpb24sIGZvbGRlZFF1ZXJ5IH0gb2YgY3JpdGVyaWEpIHtcbiAgICAgICAgICAgICAgICBpZiAoIXZhbHVlcy5oYXMoY3JpdGVyaW9uLmNvbHVtbikpIHtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gYXdhaXQgY2FsY3VsYXRvci52YWx1ZShzaC5pZCwgcm93LCBjcml0ZXJpb24uY29sdW1uKTtcbiAgICAgICAgICAgICAgICAgIGFzc2VydChcbiAgICAgICAgICAgICAgICAgICAgISh2YWx1ZSAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmIHZhbHVlLmVycm9yID09PSAnI0xJTUlUIScpLFxuICAgICAgICAgICAgICAgICAgICAnTElNSVRfRVhDRUVERUQnLFxuICAgICAgICAgICAgICAgICAgICAnRmlsdGVyIGNhbGN1bGF0aW9uIGV4Y2VlZGVkIGl0cyB3b3JrIGJ1ZGdldCcsXG4gICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgdmFsdWVzLnNldChjcml0ZXJpb24uY29sdW1uLCB2YWx1ZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IG1hdGNoID0gbWF0Y2hlc0ZpbHRlcih2YWx1ZXMuZ2V0KGNyaXRlcmlvbi5jb2x1bW4pISwgY3JpdGVyaW9uLCBmb2xkZWRRdWVyeSk7XG4gICAgICAgICAgICAgICAgaWYgKGZpbHRlci5tb2RlID09PSAnYWxsJyA/ICFtYXRjaCA6IG1hdGNoKSB7XG4gICAgICAgICAgICAgICAgICBtYXRjaGVzID0gbWF0Y2g7XG4gICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghbWF0Y2hlcykgaGlkZGVuLnB1c2gocm93KTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgY2FsY3VsYXRvci5jbGVhcigpO1xuICAgICAgICB9XG4gICAgICAgIG1ldGFkYXRhLmZpbHRlcmVkW3NoLmlkXSA9IGhpZGRlbjtcbiAgICAgIH1cbiAgfVxuICBwcml2YXRlIGFkZHJlc3NlcyhzaDogU2hlZXRTbmFwc2hvdCwgcmFuZ2U6IFJlY3QpIHtcbiAgICBjb25zdCByb3dzID0gbmV3IFNldChcbiAgICAgIHNoLnJvd09yZGVyLnNsaWNlKHJhbmdlLnN0YXJ0Um93LCByYW5nZS5lbmRSb3cpLm1hcCgoaWQpID0+IE1hdGguZmxvb3IoaWQgLyBCTE9DS19ST1dTKSksXG4gICAgKTtcbiAgICBjb25zdCBjb2x1bW5zID0gbmV3IFNldChcbiAgICAgIHNoLmNvbHVtbk9yZGVyXG4gICAgICAgIC5zbGljZShyYW5nZS5zdGFydENvbHVtbiwgcmFuZ2UuZW5kQ29sdW1uKVxuICAgICAgICAubWFwKChpZCkgPT4gTWF0aC5mbG9vcihpZCAvIEJMT0NLX0NPTFVNTlMpKSxcbiAgICApO1xuICAgIGNvbnN0IG91dDogc3RyaW5nW10gPSBbXTtcbiAgICBmb3IgKGNvbnN0IHIgb2Ygcm93cykgZm9yIChjb25zdCBjIG9mIGNvbHVtbnMpIG91dC5wdXNoKGAke3NoLmlkfS8ke3J9LyR7Y31gKTtcbiAgICByZXR1cm4gb3V0O1xuICB9XG4gIHByaXZhdGUgYXN5bmMgYXBwbHlMb2NhbChjb21tYW5kOiBDb21tYW5kLCBoZWFkOiBIZWFkLCBtZXRhZGF0YTogTWV0YWRhdGEpIHtcbiAgICBjb25zdCBwID0gY29tbWFuZC5wYXlsb2FkIGFzIGFueSxcbiAgICAgIHNoID0gbWV0YWRhdGEuc25hcHNob3Quc2hlZXRzLmZpbmQoKHMpID0+IHMuaWQgPT09IHAuc2hlZXRJZCk7XG4gICAgY29uc3QgdHJhdmVyc2FsQ2VsbHMgPVxuICAgICAgKHAuY2VsbHM/Lmxlbmd0aCA/PyAwKSArXG4gICAgICBbcC5yYW5nZSwgcC50YXJnZXRdLnJlZHVjZShcbiAgICAgICAgKHRvdGFsLCByYW5nZSkgPT5cbiAgICAgICAgICB0b3RhbCArXG4gICAgICAgICAgKHJhbmdlID8gKHJhbmdlLmVuZFJvdyAtIHJhbmdlLnN0YXJ0Um93KSAqIChyYW5nZS5lbmRDb2x1bW4gLSByYW5nZS5zdGFydENvbHVtbikgOiAwKSxcbiAgICAgICAgMCxcbiAgICAgICk7XG4gICAgbGV0IGV4cGVjdGVkVGV4dEJ5dGVzID0gMDtcbiAgICBpZiAoY29tbWFuZC50eXBlID09PSAnY29yZS5jZWxscy5zZXQnKSB7XG4gICAgICBmb3IgKGNvbnN0IGl0ZW0gb2YgcC5jZWxscykge1xuICAgICAgICBjb25zdCBpbnB1dCA9IGl0ZW0uZXhwZWN0ZWQ/LmlucHV0O1xuICAgICAgICBpZiAoaW5wdXQ/LnR5cGUgPT09ICdzdHJpbmcnKSBleHBlY3RlZFRleHRCeXRlcyArPSBpbnB1dC52YWx1ZS5sZW5ndGggKiAyO1xuICAgICAgICBlbHNlIGlmIChpbnB1dD8udHlwZSA9PT0gJ2Zvcm11bGEnKSBleHBlY3RlZFRleHRCeXRlcyArPSBpbnB1dC5leHByZXNzaW9uLmxlbmd0aCAqIDI7XG4gICAgICAgIGVsc2UgaWYgKGlucHV0Py50eXBlID09PSAnZXJyb3InKSBleHBlY3RlZFRleHRCeXRlcyArPSBpbnB1dC5jb2RlLmxlbmd0aCAqIDI7XG4gICAgICB9XG4gICAgfVxuICAgIGFzc2VydChcbiAgICAgIHRyYXZlcnNhbENlbGxzICogNTEyICsgZXhwZWN0ZWRUZXh0Qnl0ZXMgPD0gMzIgKiAxMDI0ICogMTAyNCxcbiAgICAgICdMSU1JVF9FWENFRURFRCcsXG4gICAgICAnQ29tbWFuZCBleGNlZWRzIHRoZSAzMiBNaUIgdHJhdmVyc2FsIHBsYW5uaW5nIGJ1ZGdldDsgdXNlIGEgc3RyZWFtZWQgb3BlcmF0aW9uJyxcbiAgICApO1xuICAgIGNvbnN0IGFkZHJlc3NlcyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICAgIGlmIChzaCkge1xuICAgICAgaWYgKHAuY2VsbHMpXG4gICAgICAgIGZvciAoY29uc3QgYyBvZiBwLmNlbGxzKVxuICAgICAgICAgIGFkZHJlc3Nlcy5hZGQoYmxvY2tBZGRyZXNzKHNoLmlkLCBzaC5yb3dPcmRlcltjLnJvd10sIHNoLmNvbHVtbk9yZGVyW2MuY29sdW1uXSkpO1xuICAgICAgZm9yIChjb25zdCByYW5nZSBvZiBbcC5yYW5nZSwgcC50YXJnZXRdKVxuICAgICAgICBpZiAocmFuZ2UpIHtcbiAgICAgICAgICBjaGVja0JvdW5kcyhzaCwgcmFuZ2UpO1xuICAgICAgICAgIGZvciAoY29uc3QgYSBvZiB0aGlzLmFkZHJlc3NlcyhzaCwgcmFuZ2UpKSBhZGRyZXNzZXMuYWRkKGEpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGxldCBieXRlcyA9IDA7XG4gICAgY29uc3Qgc25hcHNob3Q6IFdvcmtib29rU25hcHNob3QgPSB7XG4gICAgICAuLi5tZXRhZGF0YS5zbmFwc2hvdCxcbiAgICAgIHNoZWV0T3JkZXI6IFsuLi5tZXRhZGF0YS5zbmFwc2hvdC5zaGVldE9yZGVyXSxcbiAgICAgIHN0eWxlczogY2hhbmdlc1N0eWxlcyhjb21tYW5kKSA/IHsgLi4ubWV0YWRhdGEuc25hcHNob3Quc3R5bGVzIH0gOiBtZXRhZGF0YS5zbmFwc2hvdC5zdHlsZXMsXG4gICAgICBzaGVldHM6IG1ldGFkYXRhLnNuYXBzaG90LnNoZWV0cy5tYXAoKHMpID0+ICh7XG4gICAgICAgIC4uLnMsXG4gICAgICAgIGNlbGxzOiB7fSxcbiAgICAgICAgcm93czpcbiAgICAgICAgICBjb21tYW5kLnR5cGUgPT09ICdjb3JlLmF4aXMubWV0YScgfHxcbiAgICAgICAgICBjb21tYW5kLnR5cGUgPT09ICdjb3JlLmF4aXMudmlzaWJpbGl0eScgfHxcbiAgICAgICAgICBjb21tYW5kLnR5cGUgPT09ICdjb3JlLmF4aXMudmlzaWJpbGl0eUFsbCcgfHxcbiAgICAgICAgICBjb21tYW5kLnR5cGUgPT09ICdjb3JlLmF4aXMucmVzaXplJ1xuICAgICAgICAgICAgPyB7IC4uLnMucm93cyB9XG4gICAgICAgICAgICA6IHMucm93cyxcbiAgICAgICAgY29sdW1uczpcbiAgICAgICAgICBjb21tYW5kLnR5cGUgPT09ICdjb3JlLmF4aXMubWV0YScgfHxcbiAgICAgICAgICBjb21tYW5kLnR5cGUgPT09ICdjb3JlLmF4aXMudmlzaWJpbGl0eScgfHxcbiAgICAgICAgICBjb21tYW5kLnR5cGUgPT09ICdjb3JlLmF4aXMudmlzaWJpbGl0eUFsbCcgfHxcbiAgICAgICAgICBjb21tYW5kLnR5cGUgPT09ICdjb3JlLmF4aXMucmVzaXplJ1xuICAgICAgICAgICAgPyB7IC4uLnMuY29sdW1ucyB9XG4gICAgICAgICAgICA6IHMuY29sdW1ucyxcbiAgICAgICAgbWVyZ2VzOiBjb21tYW5kLnR5cGUgPT09ICdjb3JlLmNlbGxzLm1lcmdlJyA/IHMubWVyZ2VzLm1hcCgobSkgPT4gKHsgLi4ubSB9KSkgOiBzLm1lcmdlcyxcbiAgICAgICAgZnJlZXplOiBzLmZyZWV6ZSxcbiAgICAgICAgZmlsdGVyOiBzLmZpbHRlcixcbiAgICAgIH0pKSxcbiAgICB9O1xuICAgIGNvbnN0IHRhcmdldCA9IHNuYXBzaG90LnNoZWV0cy5maW5kKChzKSA9PiBzLmlkID09PSBwLnNoZWV0SWQpO1xuICAgIC8vIE1lcmdpbmcgY2hhbmdlcyBtZXRhZGF0YSBldmVuIHdoZW4gZXZlcnkgY292ZXJlZCBjZWxsIGlzIGFscmVhZHkgYmxhbmsuXG4gICAgLy8gS2VlcCB1bnRvdWNoZWQgcGFnZSBwb2ludGVycyByYXRoZXIgdGhhbiByZXdyaXRpbmcgdGhvc2UgcGFnZXMuXG4gICAgY29uc3QgbWVyZ2VEaXJ0eSA9IGNvbW1hbmQudHlwZSA9PT0gJ2NvcmUuY2VsbHMubWVyZ2UnID8gbmV3IFNldDxzdHJpbmc+KCkgOiB1bmRlZmluZWQ7XG4gICAgaWYgKG1lcmdlRGlydHkpIGFzc2VydCh0YXJnZXQsICdJTlZBTElEX0FSR1VNRU5UJywgJ1NoZWV0IG5vIGxvbmdlciBleGlzdHMnKTtcbiAgICBjb25zdCBtZXJnZVJvd3MgPVxuICAgICAgbWVyZ2VEaXJ0eSAmJiBuZXcgU2V0KHRhcmdldCEucm93T3JkZXIuc2xpY2UocC5yYW5nZS5zdGFydFJvdywgcC5yYW5nZS5lbmRSb3cpKTtcbiAgICBjb25zdCBtZXJnZUNvbHVtbnMgPVxuICAgICAgbWVyZ2VEaXJ0eSAmJiBuZXcgU2V0KHRhcmdldCEuY29sdW1uT3JkZXIuc2xpY2UocC5yYW5nZS5zdGFydENvbHVtbiwgcC5yYW5nZS5lbmRDb2x1bW4pKTtcbiAgICBjb25zdCBtZXJnZUFuY2hvclJvdyA9IG1lcmdlRGlydHkgJiYgdGFyZ2V0IS5yb3dPcmRlcltwLnJhbmdlLnN0YXJ0Um93XTtcbiAgICBjb25zdCBtZXJnZUFuY2hvckNvbHVtbiA9IG1lcmdlRGlydHkgJiYgdGFyZ2V0IS5jb2x1bW5PcmRlcltwLnJhbmdlLnN0YXJ0Q29sdW1uXTtcbiAgICBmb3IgKGNvbnN0IGFkZHJlc3Mgb2YgYWRkcmVzc2VzKSB7XG4gICAgICBjb25zdCBibG9jayA9IGF3YWl0IHRoaXMuYmxvY2soYWRkcmVzcywgaGVhZCk7XG4gICAgICBieXRlcyArPSBlbmNvZGVkQnl0ZXMoYmxvY2spICogNDtcbiAgICAgIGFzc2VydChcbiAgICAgICAgYnl0ZXMgPD0gMzIgKiAxMDI0ICogMTAyNCxcbiAgICAgICAgJ0xJTUlUX0VYQ0VFREVEJyxcbiAgICAgICAgJ0NvbW1hbmQgd29ya2luZyBzZXQgZXhjZWVkcyAzMiBNaUI7IHVzZSBhIHN0cmVhbWVkIG9wZXJhdGlvbicsXG4gICAgICApO1xuICAgICAgaWYgKG1lcmdlRGlydHkpXG4gICAgICAgIGZvciAoY29uc3QgY2VsbCBvZiBPYmplY3QudmFsdWVzKGJsb2NrLmNlbGxzKSlcbiAgICAgICAgICBpZiAoXG4gICAgICAgICAgICBtZXJnZVJvd3MhLmhhcyhjZWxsLnJvd0lkKSAmJlxuICAgICAgICAgICAgbWVyZ2VDb2x1bW5zIS5oYXMoY2VsbC5jb2x1bW5JZCkgJiZcbiAgICAgICAgICAgIChjZWxsLnJvd0lkICE9PSBtZXJnZUFuY2hvclJvdyB8fCBjZWxsLmNvbHVtbklkICE9PSBtZXJnZUFuY2hvckNvbHVtbikgJiZcbiAgICAgICAgICAgIChjZWxsLmlucHV0LnR5cGUgIT09ICdibGFuaycgfHwgY2VsbC5jYWNoZWQgIT09IHVuZGVmaW5lZClcbiAgICAgICAgICApIHtcbiAgICAgICAgICAgIG1lcmdlRGlydHkuYWRkKGFkZHJlc3MpO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgfVxuICAgICAgT2JqZWN0LmFzc2lnbih0YXJnZXQhLmNlbGxzLCBzdHJ1Y3R1cmVkQ2xvbmUoYmxvY2suY2VsbHMpKTtcbiAgICB9XG4gICAgcmVkdWNlQ29tbWFuZChzbmFwc2hvdCwgY29tbWFuZCk7XG4gICAgY29uc3QgcGFnZXMgPSBuZXcgTWFwPHN0cmluZywgUmVjb3JkPHN0cmluZywgQ2VsbFJlY29yZD4+KCk7XG4gICAgaWYgKHRhcmdldCAmJiAoIW1lcmdlRGlydHkgfHwgbWVyZ2VEaXJ0eS5zaXplKSkge1xuICAgICAgZm9yIChjb25zdCBjZWxsIG9mIE9iamVjdC52YWx1ZXModGFyZ2V0LmNlbGxzKSkge1xuICAgICAgICBjb25zdCBhZGRyZXNzID0gYmxvY2tBZGRyZXNzKHRhcmdldC5pZCwgY2VsbC5yb3dJZCwgY2VsbC5jb2x1bW5JZCk7XG4gICAgICAgIGlmIChtZXJnZURpcnR5ICYmICFtZXJnZURpcnR5LmhhcyhhZGRyZXNzKSkgY29udGludWU7XG4gICAgICAgIGxldCBwYWdlID0gcGFnZXMuZ2V0KGFkZHJlc3MpO1xuICAgICAgICBpZiAoIXBhZ2UpIHBhZ2VzLnNldChhZGRyZXNzLCAocGFnZSA9IHt9KSk7XG4gICAgICAgIHBhZ2Vba2V5KGNlbGwucm93SWQsIGNlbGwuY29sdW1uSWQpXSA9IGNlbGw7XG4gICAgICB9XG4gICAgfVxuICAgIGZvciAoY29uc3QgYWRkcmVzcyBvZiBhZGRyZXNzZXMpIHtcbiAgICAgIGlmIChtZXJnZURpcnR5ICYmICFtZXJnZURpcnR5LmhhcyhhZGRyZXNzKSkgY29udGludWU7XG4gICAgICBhd2FpdCB0aGlzLnN0b3JlQmxvY2soYWRkcmVzcywgcGFnZXMuZ2V0KGFkZHJlc3MpID8/IHt9LCBoZWFkLCBtZXRhZGF0YSk7XG4gICAgfVxuICAgIGZvciAoY29uc3QgcyBvZiBzbmFwc2hvdC5zaGVldHMpIHMuY2VsbHMgPSB7fTtcbiAgICBtZXRhZGF0YS5zbmFwc2hvdCA9IHNuYXBzaG90O1xuICB9XG4gIGFzeW5jIGV4ZWN1dGUoaW5wdXRzOiBBcnJheTxDb21tYW5kIHwgQ29tbWFuZEVudmVsb3BlPiwgbGFiZWwgPSAnZWRpdCcpIHtcbiAgICBhc3NlcnQodGhpcy53cml0ZXIsICdSRUFEX09OTFknLCAnV29ya2Jvb2sgaXMgb3BlbiBpbiBhbm90aGVyIHRhYicpO1xuICAgIHRoaXMuY2FuY2VsbGVkID0gZmFsc2U7XG4gICAgdGhpcy5hbGxvY2F0aW9ucyA9IFtdO1xuICAgIHRoaXMuY2hhbmdlZC5jbGVhcigpO1xuICAgIHRoaXMuYWxsb2NhdGVkLmNsZWFyKCk7XG4gICAgdGhpcy5waW5zLmNsZWFyKCk7XG4gICAgY29uc3QgZW52ZWxvcGUgPVxuICAgICAgaW5wdXRzLmxlbmd0aCA9PT0gMSAmJiAncHJvdG9jb2xWZXJzaW9uJyBpbiBpbnB1dHNbMF1cbiAgICAgICAgPyAoaW5wdXRzWzBdIGFzIENvbW1hbmRFbnZlbG9wZSlcbiAgICAgICAgOiB1bmRlZmluZWQ7XG4gICAgbGV0IHNpZ25hdHVyZSA9ICcnO1xuICAgIGlmIChlbnZlbG9wZSkge1xuICAgICAgYXNzZXJ0KFxuICAgICAgICBlbnZlbG9wZS5wcm90b2NvbFZlcnNpb24gPT09IDEgJiZcbiAgICAgICAgICBlbnZlbG9wZS53b3JrYm9va0lkID09PSB0aGlzLmlkICYmXG4gICAgICAgICAgdHlwZW9mIGVudmVsb3BlLmNvbW1hbmRJZCA9PT0gJ3N0cmluZycgJiZcbiAgICAgICAgICBlbnZlbG9wZS5jb21tYW5kSWQubGVuZ3RoID4gMCAmJlxuICAgICAgICAgIGVudmVsb3BlLmNvbW1hbmRJZC5sZW5ndGggPD0gMTAwLFxuICAgICAgICAnSU5WQUxJRF9BUkdVTUVOVCcsXG4gICAgICAgICdJbnZhbGlkIGNvbW1hbmQgZW52ZWxvcGUnLFxuICAgICAgKTtcbiAgICAgIHNpZ25hdHVyZSA9IEpTT04uc3RyaW5naWZ5KGVudmVsb3BlKTtcbiAgICAgIGNvbnN0IG9sZCA9IHRoaXMuc2Vlbi5nZXQoZW52ZWxvcGUuY29tbWFuZElkKTtcbiAgICAgIGlmIChvbGQpIHtcbiAgICAgICAgYXNzZXJ0KG9sZC5zaWduYXR1cmUgPT09IHNpZ25hdHVyZSwgJ0lOVkFMSURfQVJHVU1FTlQnLCAnQ29tbWFuZCBpZCByZXVzZWQnKTtcbiAgICAgICAgcmV0dXJuIHsgdmlldzogdGhpcy52aWV3KCksIGNvbW1pdDogb2xkLmNvbW1pdCwgZHVwbGljYXRlOiB0cnVlIH07XG4gICAgICB9XG4gICAgICBhc3NlcnQoZW52ZWxvcGUuYmFzZVJldmlzaW9uID09PSB0aGlzLmhlYWQucmV2aXNpb24sICdSRVZJU0lPTl9DT05GTElDVCcsICdXb3JrYm9vayBjaGFuZ2VkJyk7XG4gICAgfVxuICAgIGNvbnN0IGNvbW1hbmRzID0gaW5wdXRzLm1hcCh2YWxpZGF0ZUNvbW1hbmQpLFxuICAgICAgb2xkID0gdGhpcy5oZWFkLFxuICAgICAgbWV0YWRhdGE6IE1ldGFkYXRhID0ge1xuICAgICAgICAuLi50aGlzLm1ldGFkYXRhLFxuICAgICAgICBzbmFwc2hvdDoge1xuICAgICAgICAgIC4uLnRoaXMubWV0YWRhdGEuc25hcHNob3QsXG4gICAgICAgICAgc2hlZXRPcmRlcjogWy4uLnRoaXMubWV0YWRhdGEuc25hcHNob3Quc2hlZXRPcmRlcl0sXG4gICAgICAgICAgc3R5bGVzOiB0aGlzLm1ldGFkYXRhLnNuYXBzaG90LnN0eWxlcyxcbiAgICAgICAgICBzaGVldHM6IHRoaXMubWV0YWRhdGEuc25hcHNob3Quc2hlZXRzLm1hcCgoc2gpID0+ICh7XG4gICAgICAgICAgICAuLi5zaCxcbiAgICAgICAgICAgIGNlbGxzOiB7fSxcbiAgICAgICAgICAgIHJvd3M6IHNoLnJvd3MsXG4gICAgICAgICAgICBjb2x1bW5zOiBzaC5jb2x1bW5zLFxuICAgICAgICAgICAgbWVyZ2VzOiBzaC5tZXJnZXMsXG4gICAgICAgICAgICBmcmVlemU6IHNoLmZyZWV6ZSxcbiAgICAgICAgICAgIGZpbHRlcjogc2guZmlsdGVyLFxuICAgICAgICAgIH0pKSxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICB0cmFuc2FjdGlvbiA9IG92ZXJsYXkob2xkLmJsb2NrcyksXG4gICAgICBuZXh0OiBIZWFkID0ge1xuICAgICAgICAuLi5vbGQsXG4gICAgICAgIGJsb2NrczogdHJhbnNhY3Rpb24ucmVjb3JkLFxuICAgICAgICBwYXN0OiBbLi4ub2xkLnBhc3RdLFxuICAgICAgICBmdXR1cmU6IFsuLi5vbGQuZnV0dXJlXSxcbiAgICAgIH07XG4gICAgLy8gUmVzb2x2ZSBhIHN0YW5kYWxvbmUgdmlzaWJpbGl0eSBjb21tYW5kIGFnYWluc3QgdGhlIHF1ZXVlZCBXb3JrZXIgcmV2aXNpb24uXG4gICAgLy8gQSBuby1vcCBtdXN0IG5vdCBjcmVhdGUgaGlzdG9yeSBvciBkaXNjYXJkIHJlZG8sIGluY2x1ZGluZyBmb3IgZW52ZWxvcGVzLlxuICAgIGlmIChcbiAgICAgIGNvbW1hbmRzLmxlbmd0aCA9PT0gMSAmJlxuICAgICAgKGNvbW1hbmRzWzBdLnR5cGUgPT09ICdjb3JlLmF4aXMudmlzaWJpbGl0eScgfHxcbiAgICAgICAgY29tbWFuZHNbMF0udHlwZSA9PT0gJ2NvcmUuYXhpcy52aXNpYmlsaXR5QWxsJylcbiAgICApIHtcbiAgICAgIGNvbnN0IHAgPSBjb21tYW5kc1swXS5wYXlsb2FkIGFzIHtcbiAgICAgICAgc2hlZXRJZDogc3RyaW5nO1xuICAgICAgICBheGlzOiAncm93JyB8ICdjb2x1bW4nO1xuICAgICAgICBpbmRleDogbnVtYmVyO1xuICAgICAgICBjb3VudDogbnVtYmVyO1xuICAgICAgICBoaWRkZW46IGJvb2xlYW47XG4gICAgICB9O1xuICAgICAgY29uc3Qgc2hlZXQgPSBtZXRhZGF0YS5zbmFwc2hvdC5zaGVldHMuZmluZCgoaXRlbSkgPT4gaXRlbS5pZCA9PT0gcC5zaGVldElkKTtcbiAgICAgIGFzc2VydChzaGVldCwgJ0lOVkFMSURfQVJHVU1FTlQnLCAnU2hlZXQgbm8gbG9uZ2VyIGV4aXN0cycpO1xuICAgICAgY29uc3Qgb3JkZXIgPSBwLmF4aXMgPT09ICdyb3cnID8gc2hlZXQucm93T3JkZXIgOiBzaGVldC5jb2x1bW5PcmRlcjtcbiAgICAgIGNvbnN0IGF4aXNNZXRhZGF0YSA9IHAuYXhpcyA9PT0gJ3JvdycgPyBzaGVldC5yb3dzIDogc2hlZXQuY29sdW1ucztcbiAgICAgIGNvbnN0IHN0YXJ0ID0gY29tbWFuZHNbMF0udHlwZSA9PT0gJ2NvcmUuYXhpcy52aXNpYmlsaXR5QWxsJyA/IDAgOiBwLmluZGV4O1xuICAgICAgY29uc3QgZW5kID0gY29tbWFuZHNbMF0udHlwZSA9PT0gJ2NvcmUuYXhpcy52aXNpYmlsaXR5QWxsJyA/IG9yZGVyLmxlbmd0aCA6IHAuaW5kZXggKyBwLmNvdW50O1xuICAgICAgYXNzZXJ0KGVuZCA8PSBvcmRlci5sZW5ndGgsICdJTlZBTElEX1JBTkdFJywgJ1Vua25vd24gcm93L2NvbHVtbicpO1xuICAgICAgbGV0IGNoYW5nZXMgPSBmYWxzZTtcbiAgICAgIGZvciAobGV0IGkgPSBzdGFydDsgaSA8IGVuZCAmJiAhY2hhbmdlczsgaSsrKVxuICAgICAgICBjaGFuZ2VzID0gISFheGlzTWV0YWRhdGFbb3JkZXJbaV1dPy5oaWRkZW4gIT09IHAuaGlkZGVuO1xuICAgICAgaWYgKCFjaGFuZ2VzKSB7XG4gICAgICAgIGlmIChlbnZlbG9wZSkgdGhpcy5zZWVuLnNldChlbnZlbG9wZS5jb21tYW5kSWQsIHsgc2lnbmF0dXJlIH0pO1xuICAgICAgICByZXR1cm4geyB2aWV3OiB0aGlzLnZpZXcoKSB9O1xuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCBjYW5kaWRhdGVzID0gbmV3IFNldDxzdHJpbmc+KHRoaXMuYWxsb2NhdGlvbnMpO1xuICAgIGxldCBtZXRhZGF0YURpcnR5ID0gZmFsc2U7XG4gICAgY29uc3QgcmFuZ2VzOiBTZWxlY3Rpb25bXSA9IFtdO1xuICAgIHRyeSB7XG4gICAgICBmb3IgKGNvbnN0IGNvbW1hbmQgb2YgY29tbWFuZHMpIHtcbiAgICAgICAgdGhpcy5jaGVjaygpO1xuICAgICAgICBtZXRhZGF0YURpcnR5IHx8PVxuICAgICAgICAgICEoXG4gICAgICAgICAgICBbJ2NvcmUuY2VsbHMucGFzdGUnLCAnY29yZS5jZWxscy5wYXN0ZVRpbGUnXS5pbmNsdWRlcyhjb21tYW5kLnR5cGUpICYmXG4gICAgICAgICAgICAhY2hhbmdlc1N0eWxlcyhjb21tYW5kKVxuICAgICAgICAgICkgJiZcbiAgICAgICAgICAhW1xuICAgICAgICAgICAgJ2NvcmUuY2VsbHMuc2V0JyxcbiAgICAgICAgICAgICdjb3JlLmNlbGxzLmFubm90YXRpb24nLFxuICAgICAgICAgICAgJ2NvcmUuY2VsbHMuY29weScsXG4gICAgICAgICAgICAnY29yZS5jZWxscy5maWxsRG93bicsXG4gICAgICAgICAgICAnY29yZS5jZWxscy5maWxsU2VyaWVzJyxcbiAgICAgICAgICAgICdjb3JlLmNlbGxzLmNsZWFyJyxcbiAgICAgICAgICAgICdjb3JlLmNlbGxzLnJlcGxhY2UnLFxuICAgICAgICAgICAgJ2NvcmUuc2hlZXQuc29ydCcsXG4gICAgICAgICAgXS5pbmNsdWRlcyhjb21tYW5kLnR5cGUpO1xuICAgICAgICBjb25zdCBwID0gY29tbWFuZC5wYXlsb2FkIGFzIGFueTtcbiAgICAgICAgaWYgKHAuc2hlZXRJZCkge1xuICAgICAgICAgIGNvbnN0IHNoID0gbWV0YWRhdGEuc25hcHNob3Quc2hlZXRzLmZpbmQoKHMpID0+IHMuaWQgPT09IHAuc2hlZXRJZCkhO1xuICAgICAgICAgIGlmIChwLnRhcmdldCkgcmFuZ2VzLnB1c2goeyBzaGVldElkOiBwLnNoZWV0SWQsIC4uLnAudGFyZ2V0IH0pO1xuICAgICAgICAgIGlmIChwLnJhbmdlKSByYW5nZXMucHVzaCh7IHNoZWV0SWQ6IHAuc2hlZXRJZCwgLi4ucC5yYW5nZSB9KTtcbiAgICAgICAgICBlbHNlIGlmIChwLmNlbGxzPy5sZW5ndGgpIHtcbiAgICAgICAgICAgIGxldCBzdGFydFJvdyA9IEluZmluaXR5LFxuICAgICAgICAgICAgICBlbmRSb3cgPSAwLFxuICAgICAgICAgICAgICBzdGFydENvbHVtbiA9IEluZmluaXR5LFxuICAgICAgICAgICAgICBlbmRDb2x1bW4gPSAwO1xuICAgICAgICAgICAgZm9yIChjb25zdCBjZWxsIG9mIHAuY2VsbHMpIHtcbiAgICAgICAgICAgICAgc3RhcnRSb3cgPSBNYXRoLm1pbihzdGFydFJvdywgY2VsbC5yb3cpO1xuICAgICAgICAgICAgICBlbmRSb3cgPSBNYXRoLm1heChlbmRSb3csIGNlbGwucm93ICsgMSk7XG4gICAgICAgICAgICAgIHN0YXJ0Q29sdW1uID0gTWF0aC5taW4oc3RhcnRDb2x1bW4sIGNlbGwuY29sdW1uKTtcbiAgICAgICAgICAgICAgZW5kQ29sdW1uID0gTWF0aC5tYXgoZW5kQ29sdW1uLCBjZWxsLmNvbHVtbiArIDEpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmFuZ2VzLnB1c2goe1xuICAgICAgICAgICAgICBzaGVldElkOiBwLnNoZWV0SWQsXG4gICAgICAgICAgICAgIHN0YXJ0Um93LFxuICAgICAgICAgICAgICBlbmRSb3csXG4gICAgICAgICAgICAgIHN0YXJ0Q29sdW1uLFxuICAgICAgICAgICAgICBlbmRDb2x1bW4sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9IGVsc2UgaWYgKHNoKVxuICAgICAgICAgICAgcmFuZ2VzLnB1c2goe1xuICAgICAgICAgICAgICBzaGVldElkOiBzaC5pZCxcbiAgICAgICAgICAgICAgc3RhcnRSb3c6IDAsXG4gICAgICAgICAgICAgIHN0YXJ0Q29sdW1uOiAwLFxuICAgICAgICAgICAgICBlbmRSb3c6IHNoLnJvd09yZGVyLmxlbmd0aCxcbiAgICAgICAgICAgICAgZW5kQ29sdW1uOiBzaC5jb2x1bW5PcmRlci5sZW5ndGgsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoXG4gICAgICAgICAgW1xuICAgICAgICAgICAgJ2NvcmUuYXhpcy5pbnNlcnQnLFxuICAgICAgICAgICAgJ2NvcmUuYXhpcy5kZWxldGUnLFxuICAgICAgICAgICAgJ2NvcmUuc2hlZXQucmVuYW1lJyxcbiAgICAgICAgICAgICdjb3JlLnNoZWV0LnJlbW92ZScsXG4gICAgICAgICAgXS5pbmNsdWRlcyhjb21tYW5kLnR5cGUpXG4gICAgICAgIClcbiAgICAgICAgICBhd2FpdCB0aGlzLnN0cnVjdHVyYWwoY29tbWFuZCwgbmV4dCwgbWV0YWRhdGEpO1xuICAgICAgICBlbHNlIGlmIChjb21tYW5kLnR5cGUgPT09ICdjb3JlLmNlbGxzLnBhc3RlJylcbiAgICAgICAgICBhd2FpdCB0aGlzLnBhc3RlQ2VsbHMoY29tbWFuZCwgbmV4dCwgbWV0YWRhdGEpO1xuICAgICAgICBlbHNlIGlmIChjb21tYW5kLnR5cGUgPT09ICdjb3JlLmNlbGxzLnBhc3RlVGlsZScpXG4gICAgICAgICAgYXdhaXQgdGhpcy5wYXN0ZVRpbGUoY29tbWFuZCwgbmV4dCwgbWV0YWRhdGEpO1xuICAgICAgICBlbHNlIGlmIChjb21tYW5kLnR5cGUgPT09ICdjb3JlLmNlbGxzLmNvcHlTcGVjaWFsJylcbiAgICAgICAgICBhd2FpdCB0aGlzLmNvcHlTcGVjaWFsKGNvbW1hbmQsIG5leHQsIG1ldGFkYXRhKTtcbiAgICAgICAgZWxzZSBpZiAoY29tbWFuZC50eXBlID09PSAnY29yZS5jZWxscy5maWxsRG93bicpXG4gICAgICAgICAgYXdhaXQgdGhpcy5maWxsRG93bihjb21tYW5kLCBuZXh0LCBtZXRhZGF0YSk7XG4gICAgICAgIGVsc2UgaWYgKGNvbW1hbmQudHlwZSA9PT0gJ2NvcmUuY2VsbHMuZmlsbFNlcmllcycpXG4gICAgICAgICAgYXdhaXQgdGhpcy5maWxsU2VyaWVzKGNvbW1hbmQsIG5leHQsIG1ldGFkYXRhKTtcbiAgICAgICAgZWxzZSBpZiAoY29tbWFuZC50eXBlID09PSAnY29yZS5jZWxscy5zdHlsZScpXG4gICAgICAgICAgYXdhaXQgdGhpcy5hcHBseVN0eWxlKGNvbW1hbmQsIG5leHQsIG1ldGFkYXRhKTtcbiAgICAgICAgZWxzZSBpZiAoY29tbWFuZC50eXBlID09PSAnY29yZS5jZWxscy5yZXBsYWNlJylcbiAgICAgICAgICBhd2FpdCB0aGlzLnJlcGxhY2VUZXh0KGNvbW1hbmQsIG5leHQsIG1ldGFkYXRhKTtcbiAgICAgICAgZWxzZSBpZiAoY29tbWFuZC50eXBlID09PSAnY29yZS5zaGVldC5zb3J0JykgYXdhaXQgdGhpcy5zb3J0KGNvbW1hbmQsIG5leHQsIG1ldGFkYXRhKTtcbiAgICAgICAgZWxzZSBhd2FpdCB0aGlzLmFwcGx5TG9jYWwoY29tbWFuZCwgbmV4dCwgbWV0YWRhdGEpO1xuICAgICAgfVxuICAgICAgaWYgKFxuICAgICAgICBjb21tYW5kcy5sZW5ndGggJiZcbiAgICAgICAgY29tbWFuZHMuZXZlcnkoKGNvbW1hbmQpID0+IGNvbW1hbmQudHlwZSA9PT0gJ2NvcmUuY2VsbHMucmVwbGFjZScpICYmXG4gICAgICAgICF0aGlzLmNoYW5nZWQuc2l6ZVxuICAgICAgKSB7XG4gICAgICAgIGlmIChlbnZlbG9wZSkgdGhpcy5zZWVuLnNldChlbnZlbG9wZS5jb21tYW5kSWQsIHsgc2lnbmF0dXJlIH0pO1xuICAgICAgICByZXR1cm4geyB2aWV3OiB0aGlzLnZpZXcoKSB9O1xuICAgICAgfVxuICAgICAgYXdhaXQgdGhpcy5maWx0ZXJzKG5leHQsIG1ldGFkYXRhKTtcbiAgICAgIG5leHQucmV2aXNpb24rKztcbiAgICAgIG5leHQubWV0YSA9ICFtZXRhZGF0YURpcnR5ID8gb2xkLm1ldGEgOiBhd2FpdCB0aGlzLmFsbG9jYXRlKGVuY29kZU1ldGFkYXRhKG1ldGFkYXRhKSk7XG4gICAgICBjb25zdCBjaGFuZ2VzOiBIaXN0b3J5WydjaGFuZ2VzJ10gPSBbXTtcbiAgICAgIGZvciAoY29uc3QgYSBvZiB0aGlzLmNoYW5nZWQpXG4gICAgICAgIGlmIChvbGQuYmxvY2tzW2FdICE9PSBuZXh0LmJsb2Nrc1thXSlcbiAgICAgICAgICBjaGFuZ2VzLnB1c2goW2EsIG9sZC5ibG9ja3NbYV0gPz8gbnVsbCwgbmV4dC5ibG9ja3NbYV0gPz8gbnVsbF0pO1xuICAgICAgY29uc3QgYnl0ZXMgPVxuICAgICAgICBjaGFuZ2VzLnJlZHVjZSgobiwgWywgYSwgYl0pID0+IG4gKyAoYT8uYnl0ZXMgPz8gMCkgKyAoYj8uYnl0ZXMgPz8gMCksIDApICtcbiAgICAgICAgKG5leHQubWV0YSA9PT0gb2xkLm1ldGFcbiAgICAgICAgICA/IDBcbiAgICAgICAgICA6IGVuY29kZWRCeXRlcyhlbmNvZGVNZXRhZGF0YShtZXRhZGF0YSkpICsgZW5jb2RlZEJ5dGVzKGVuY29kZU1ldGFkYXRhKHRoaXMubWV0YWRhdGEpKSk7XG4gICAgICBhc3NlcnQoXG4gICAgICAgIGJ5dGVzIDw9IDMyICogMTAyNCAqIDEwMjQsXG4gICAgICAgICdMSU1JVF9FWENFRURFRCcsXG4gICAgICAgICdDaGFuZ2UgZXhjZWVkcyB0aGUgMzIgTWlCIHVuZG8gYnVkZ2V0OyBpbXBvcnQgYXMgYSBuZXcgd29ya2Jvb2snLFxuICAgICAgKTtcbiAgICAgIGNvbnN0IGhpc3Rvcnk6IEhpc3RvcnkgPSB7IGJlZm9yZTogb2xkLm1ldGEsIGFmdGVyOiBuZXh0Lm1ldGEsIGNoYW5nZXMsIGJ5dGVzLCByYW5nZXMgfTtcbiAgICAgIG5leHQucGFzdC5wdXNoKGF3YWl0IHRoaXMuYWxsb2NhdGUoaGlzdG9yeSkpO1xuICAgICAgZm9yIChjb25zdCBpZCBvZiBvbGQuZnV0dXJlKSB7XG4gICAgICAgIGNvbnN0IGggPSB0aGlzLmhpc3Rvcmllcy5nZXQoaWQpITtcbiAgICAgICAgY2FuZGlkYXRlcy5hZGQoaWQpO1xuICAgICAgICBjYW5kaWRhdGVzLmFkZChoLmJlZm9yZSk7XG4gICAgICAgIGNhbmRpZGF0ZXMuYWRkKGguYWZ0ZXIpO1xuICAgICAgICBmb3IgKGNvbnN0IFssIGEsIGJdIG9mIGguY2hhbmdlcykge1xuICAgICAgICAgIGlmIChhKSBjYW5kaWRhdGVzLmFkZChhLmlkKTtcbiAgICAgICAgICBpZiAoYikgY2FuZGlkYXRlcy5hZGQoYi5pZCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIG5leHQuZnV0dXJlID0gW107XG4gICAgICBuZXh0Lmhpc3RvcnlCeXRlcyA9IG9sZC5oaXN0b3J5Qnl0ZXMgKyBieXRlcztcbiAgICAgIHdoaWxlIChuZXh0LnBhc3QubGVuZ3RoID4gMTAwIHx8IG5leHQuaGlzdG9yeUJ5dGVzID4gMzIgKiAxMDI0ICogMTAyNCkge1xuICAgICAgICBjb25zdCBleHBpcmVkID0gbmV4dC5wYXN0LnNoaWZ0KCkhO1xuICAgICAgICBjb25zdCBoID0gdGhpcy5oaXN0b3JpZXMuZ2V0KGV4cGlyZWQpITtcbiAgICAgICAgbmV4dC5oaXN0b3J5Qnl0ZXMgLT0gaC5ieXRlcztcbiAgICAgICAgY2FuZGlkYXRlcy5hZGQoZXhwaXJlZCk7XG4gICAgICAgIGNhbmRpZGF0ZXMuYWRkKGguYmVmb3JlKTtcbiAgICAgICAgY2FuZGlkYXRlcy5hZGQoaC5hZnRlcik7XG4gICAgICAgIGZvciAoY29uc3QgWywgYSwgYl0gb2YgaC5jaGFuZ2VzKSB7XG4gICAgICAgICAgaWYgKGEpIGNhbmRpZGF0ZXMuYWRkKGEuaWQpO1xuICAgICAgICAgIGlmIChiKSBjYW5kaWRhdGVzLmFkZChiLmlkKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgYXdhaXQgdGhpcy5wdWJsaXNoKG5leHQsIG1ldGFkYXRhLCBtZXRhZGF0YURpcnR5ID8gdW5kZWZpbmVkIDogcmFuZ2VzKTtcbiAgICAgIGF3YWl0IHRoaXMuY2xlYW51cChbLi4uY2FuZGlkYXRlcywgLi4udGhpcy5hbGxvY2F0aW9uc10pO1xuICAgICAgZm9yIChjb25zdCBbYWRkcmVzcywgcG9pbnRlcl0gb2YgdHJhbnNhY3Rpb24uY2hhbmdlZCkge1xuICAgICAgICBpZiAocG9pbnRlcikgb2xkLmJsb2Nrc1thZGRyZXNzXSA9IHBvaW50ZXI7XG4gICAgICAgIGVsc2UgZGVsZXRlIG9sZC5ibG9ja3NbYWRkcmVzc107XG4gICAgICB9XG4gICAgICB0aGlzLmhlYWQuYmxvY2tzID0gb2xkLmJsb2NrcztcbiAgICAgIGNvbnN0IGNvbW1pdDogQ29tbWl0ID0ge1xuICAgICAgICBjb21tYW5kSWQ6IGVudmVsb3BlPy5jb21tYW5kSWQgPz8gdWlkKCdjbWQnKSxcbiAgICAgICAgcHJldmlvdXNSZXZpc2lvbjogb2xkLnJldmlzaW9uLFxuICAgICAgICByZXZpc2lvbjogbmV4dC5yZXZpc2lvbixcbiAgICAgICAgc291cmNlOiBsYWJlbCxcbiAgICAgICAgY29tbWFuZHMsXG4gICAgICAgIGNoYW5nZWRSYW5nZXM6IHJhbmdlcyxcbiAgICAgIH07XG4gICAgICBpZiAoZW52ZWxvcGUpIHRoaXMuc2Vlbi5zZXQoZW52ZWxvcGUuY29tbWFuZElkLCB7IHNpZ25hdHVyZSwgY29tbWl0IH0pO1xuICAgICAgcmV0dXJuIHsgdmlldzogdGhpcy52aWV3KCksIGNvbW1pdCB9O1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBhd2FpdCB0aGlzLmNsZWFudXAodGhpcy5hbGxvY2F0aW9ucyk7XG4gICAgICB0aHJvdyBlcnJvcjtcbiAgICB9XG4gIH1cbiAgcHJpdmF0ZSBhc3luYyBwYXN0ZVRpbGUoY29tbWFuZDogQ29tbWFuZCwgbmV4dDogSGVhZCwgbWV0YWRhdGE6IE1ldGFkYXRhKSB7XG4gICAgY29uc3QgdGlsZSA9IGNvbW1hbmQucGF5bG9hZCBhcyBQYXN0ZVRpbGU7XG4gICAgY29uc3Qgc2ggPSBtZXRhZGF0YS5zbmFwc2hvdC5zaGVldHMuZmluZCgoc2hlZXQpID0+IHNoZWV0LmlkID09PSB0aWxlLnNoZWV0SWQpO1xuICAgIGFzc2VydChzaCwgJ0lOVkFMSURfQVJHVU1FTlQnLCAnU2hlZXQgbm8gbG9uZ2VyIGV4aXN0cycpO1xuICAgIGxldCB1bml0cyA9IHZhbGlkYXRlUGFzdGVUaWxlKHNoLCB0aWxlKTtcbiAgICBjb25zdCBjaGFyZ2UgPSAoZXh0cmE6IG51bWJlcikgPT4ge1xuICAgICAgdW5pdHMgKz0gZXh0cmE7XG4gICAgICBhc3NlcnQoXG4gICAgICAgIHVuaXRzIDw9IDMyICogMTAyNCAqIDEwMjQsXG4gICAgICAgICdMSU1JVF9FWENFRURFRCcsXG4gICAgICAgICdFeHBhbmRlZCBjbGlwYm9hcmQgY29udGVudCBpcyB0b28gbGFyZ2UnLFxuICAgICAgKTtcbiAgICB9O1xuICAgIGlmIChjaGFuZ2VzU3R5bGVzKGNvbW1hbmQpKSBtZXRhZGF0YS5zbmFwc2hvdC5zdHlsZXMgPSB7IC4uLm1ldGFkYXRhLnNuYXBzaG90LnN0eWxlcyB9O1xuICAgIGNvbnN0IG9mZnNldCA9IGNyZWF0ZVRpbGVPZmZzZXR0ZXIoKTtcbiAgICBjb25zdCByb3dHcm91cHMgPSBncm91cEF4aXMoc2gucm93T3JkZXIsIHRpbGUucmFuZ2Uuc3RhcnRSb3csIHRpbGUucmFuZ2UuZW5kUm93LCBCTE9DS19ST1dTKTtcbiAgICBjb25zdCBjb2x1bW5Hcm91cHMgPSBncm91cEF4aXMoXG4gICAgICBzaC5jb2x1bW5PcmRlcixcbiAgICAgIHRpbGUucmFuZ2Uuc3RhcnRDb2x1bW4sXG4gICAgICB0aWxlLnJhbmdlLmVuZENvbHVtbixcbiAgICAgIEJMT0NLX0NPTFVNTlMsXG4gICAgKTtcbiAgICBmb3IgKGNvbnN0IHJvd3Mgb2Ygcm93R3JvdXBzLnZhbHVlcygpKVxuICAgICAgZm9yIChjb25zdCBjb2x1bW5zIG9mIGNvbHVtbkdyb3Vwcy52YWx1ZXMoKSkge1xuICAgICAgICB0aGlzLmNoZWNrKCk7XG4gICAgICAgIGNvbnN0IGFkZHJlc3MgPSBibG9ja0FkZHJlc3ModGlsZS5zaGVldElkLCByb3dzWzBdLmlkLCBjb2x1bW5zWzBdLmlkKTtcbiAgICAgICAgY29uc3QgY2VsbHMgPSBzdHJ1Y3R1cmVkQ2xvbmUoKGF3YWl0IHRoaXMuYmxvY2soYWRkcmVzcywgbmV4dCkpLmNlbGxzKTtcbiAgICAgICAgZm9yIChjb25zdCByb3cgb2Ygcm93cylcbiAgICAgICAgICBmb3IgKGNvbnN0IGNvbHVtbiBvZiBjb2x1bW5zKSB7XG4gICAgICAgICAgICBjb25zdCBwb3NpdGlvbiA9IGtleShyb3cuaWQsIGNvbHVtbi5pZCk7XG4gICAgICAgICAgICBjb25zdCB0YXJnZXQgPVxuICAgICAgICAgICAgICBjZWxsc1twb3NpdGlvbl0gPz9cbiAgICAgICAgICAgICAgKGNlbGxzW3Bvc2l0aW9uXSA9IHsgcm93SWQ6IHJvdy5pZCwgY29sdW1uSWQ6IGNvbHVtbi5pZCwgaW5wdXQ6IHsgdHlwZTogJ2JsYW5rJyB9IH0pO1xuICAgICAgICAgICAgYXBwbHlQYXN0ZWRDZWxsKFxuICAgICAgICAgICAgICBtZXRhZGF0YS5zbmFwc2hvdCxcbiAgICAgICAgICAgICAgdGFyZ2V0LFxuICAgICAgICAgICAgICB0aWxlQ2VsbCh0aWxlLCByb3cuaW5kZXgsIGNvbHVtbi5pbmRleCwgY2hhcmdlLCBvZmZzZXQpLFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG4gICAgICAgIGF3YWl0IHRoaXMuc3RvcmVCbG9jayhhZGRyZXNzLCBjZWxscywgbmV4dCwgbWV0YWRhdGEpO1xuICAgICAgfVxuICB9XG4gIHByaXZhdGUgYXN5bmMgY29weVNwZWNpYWwoY29tbWFuZDogQ29tbWFuZCwgbmV4dDogSGVhZCwgbWV0YWRhdGE6IE1ldGFkYXRhKSB7XG4gICAgY29uc3QgeyBzaGVldElkLCByYW5nZSwgdGFyZ2V0LCBtb2RlIH0gPSBjb21tYW5kLnBheWxvYWQgYXMge1xuICAgICAgc2hlZXRJZDogc3RyaW5nO1xuICAgICAgcmFuZ2U6IFJlY3Q7XG4gICAgICB0YXJnZXQ6IFJlY3Q7XG4gICAgICBtb2RlOiAndmFsdWVzJyB8ICdmb3JtdWxhcycgfCAnZm9ybWF0cyc7XG4gICAgfTtcbiAgICBjb25zdCBzaGVldCA9IG1ldGFkYXRhLnNuYXBzaG90LnNoZWV0cy5maW5kKChpdGVtKSA9PiBpdGVtLmlkID09PSBzaGVldElkKTtcbiAgICBhc3NlcnQoc2hlZXQsICdJTlZBTElEX0FSR1VNRU5UJywgJ1NoZWV0IG5vIGxvbmdlciBleGlzdHMnKTtcbiAgICBjaGVja0JvdW5kcyhzaGVldCwgcmFuZ2UpO1xuICAgIGNoZWNrQm91bmRzKHNoZWV0LCB0YXJnZXQpO1xuICAgIGNvbnN0IHJvd3MgPSByYW5nZS5lbmRSb3cgLSByYW5nZS5zdGFydFJvdztcbiAgICBjb25zdCBjb2x1bW5zID0gcmFuZ2UuZW5kQ29sdW1uIC0gcmFuZ2Uuc3RhcnRDb2x1bW47XG4gICAgYXNzZXJ0KFxuICAgICAgcm93cyA9PT0gdGFyZ2V0LmVuZFJvdyAtIHRhcmdldC5zdGFydFJvdyAmJiBjb2x1bW5zID09PSB0YXJnZXQuZW5kQ29sdW1uIC0gdGFyZ2V0LnN0YXJ0Q29sdW1uLFxuICAgICAgJ0lOVkFMSURfUkFOR0UnLFxuICAgICAgJ0NvcHkgcmFuZ2VzIG11c3QgaGF2ZSBlcXVhbCBkaW1lbnNpb25zJyxcbiAgICApO1xuICAgIGFzc2VydChyb3dzICogY29sdW1ucyA8PSBMSU1JVFMucmFuZ2VDZWxscywgJ0xJTUlUX0VYQ0VFREVEJywgJ0NvcHkgZXhjZWVkcyB0aGUgY2VsbCBsaW1pdCcpO1xuICAgIGFzc2VydChcbiAgICAgICFzaGVldC5tZXJnZXMuc29tZSgobWVyZ2UpID0+IGludGVyc2VjdHMobWVyZ2UsIHJhbmdlKSB8fCBpbnRlcnNlY3RzKG1lcmdlLCB0YXJnZXQpKSxcbiAgICAgICdJTlZBTElEX1JBTkdFJyxcbiAgICAgICdVbm1lcmdlIGJlZm9yZSBjb3B5aW5nJyxcbiAgICApO1xuICAgIGNvbnN0IGNhbGN1bGF0ZSA9XG4gICAgICBtb2RlID09PSAndmFsdWVzJ1xuICAgICAgICA/IG5ldyBBc3luY0NhbGN1bGF0aW9uKFxuICAgICAgICAgICAgKGlkLCByb3csIGNvbHVtbikgPT4gdGhpcy5zdGFnZWRDZWxsKGlkLCByb3csIGNvbHVtbiwgbmV4dCwgbWV0YWRhdGEpLFxuICAgICAgICAgICAgKG5hbWUpID0+XG4gICAgICAgICAgICAgIG1ldGFkYXRhLnNuYXBzaG90LnNoZWV0cy5maW5kKChzKSA9PiBzLm5hbWUudG9Mb3dlckNhc2UoKSA9PT0gbmFtZS50b0xvd2VyQ2FzZSgpKT8uaWQsXG4gICAgICAgICAgICB0aGlzLmNhbGN1bGF0b3IuY2FjaGVCdWRnZXQsXG4gICAgICAgICAgICB1bmRlZmluZWQsXG4gICAgICAgICAgICAoKSA9PiBtZXRhZGF0YS5zbmFwc2hvdC5kYXRlU3lzdGVtLFxuICAgICAgICAgICkucmVhZFNlc3Npb24oKVxuICAgICAgICA6IHVuZGVmaW5lZDtcbiAgICBjb25zdCBwYWdlOiBTdGFnZWRSZWFkUGFnZSA9IHt9O1xuICAgIGNvbnN0IGNlbGxzOiBQYXN0ZUNlbGxbXSA9IFtdO1xuICAgIGxldCBieXRlcyA9IDA7XG4gICAgbGV0IHZpc2l0ZWQgPSAwO1xuICAgIGZvciAobGV0IHJvdyA9IHJhbmdlLnN0YXJ0Um93OyByb3cgPCByYW5nZS5lbmRSb3c7IHJvdysrKSB7XG4gICAgICBmb3IgKGxldCBjb2x1bW4gPSByYW5nZS5zdGFydENvbHVtbjsgY29sdW1uIDwgcmFuZ2UuZW5kQ29sdW1uOyBjb2x1bW4rKykge1xuICAgICAgICB0aGlzLmNoZWNrKCk7XG4gICAgICAgIGlmICgrK3Zpc2l0ZWQgJSAxMDI0ID09PSAwKSB7XG4gICAgICAgICAgYXdhaXQgeWllbGRUb1Rhc2soKTtcbiAgICAgICAgICB0aGlzLmNoZWNrKCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgY2VsbCA9IGF3YWl0IHRoaXMuc3RhZ2VkQ2VsbChzaGVldElkLCByb3csIGNvbHVtbiwgbmV4dCwgbWV0YWRhdGEsIHBhZ2UpO1xuICAgICAgICBjb25zdCBzdHlsZSA9IGNlbGw/LnN0eWxlSWQgPyBtZXRhZGF0YS5zbmFwc2hvdC5zdHlsZXNbY2VsbC5zdHlsZUlkXSA6IHt9O1xuICAgICAgICBjb25zdCBpdGVtID0gc2VsZWN0aXZlQ29weUNlbGwoXG4gICAgICAgICAge1xuICAgICAgICAgICAgcm93LFxuICAgICAgICAgICAgY29sdW1uLFxuICAgICAgICAgICAgLi4uKG1vZGUgPT09ICd2YWx1ZXMnXG4gICAgICAgICAgICAgID8ge1xuICAgICAgICAgICAgICAgICAgdmFsdWU6XG4gICAgICAgICAgICAgICAgICAgIGNlbGw/LmlucHV0LnR5cGUgPT09ICdmb3JtdWxhJ1xuICAgICAgICAgICAgICAgICAgICAgID8gYXdhaXQgY2FsY3VsYXRlIShzaGVldElkLCByb3csIGNvbHVtbilcbiAgICAgICAgICAgICAgICAgICAgICA6IGNlbGxcbiAgICAgICAgICAgICAgICAgICAgICAgID8gc2NhbGFyVmFsdWUoY2VsbC5pbnB1dClcbiAgICAgICAgICAgICAgICAgICAgICAgIDogbnVsbCxcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIDoge30pLFxuICAgICAgICAgICAgLi4uKG1vZGUgPT09ICdmb3JtdWxhcycgPyB7IGlucHV0OiBjZWxsPy5pbnB1dCB9IDoge30pLFxuICAgICAgICAgICAgLi4uKG1vZGUgPT09ICdmb3JtYXRzJ1xuICAgICAgICAgICAgICA/IHsgc3R5bGUsIG51bWJlckZvcm1hdDogY2VsbD8ubnVtYmVyRm9ybWF0ID8/IHN0eWxlPy5udW1iZXJGb3JtYXQgfVxuICAgICAgICAgICAgICA6IHt9KSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIG1vZGUsXG4gICAgICAgICAgdGFyZ2V0LnN0YXJ0Um93IC0gcmFuZ2Uuc3RhcnRSb3csXG4gICAgICAgICAgdGFyZ2V0LnN0YXJ0Q29sdW1uIC0gcmFuZ2Uuc3RhcnRDb2x1bW4sXG4gICAgICAgICk7XG4gICAgICAgIGJ5dGVzICs9IEpTT04uc3RyaW5naWZ5KGl0ZW0pLmxlbmd0aCAqIDI7XG4gICAgICAgIGFzc2VydChieXRlcyA8PSAzMiAqIDEwMjQgKiAxMDI0LCAnTElNSVRfRVhDRUVERUQnLCAnQ29weSB3b3JraW5nIHNldCBpcyB0b28gbGFyZ2UnKTtcbiAgICAgICAgY2VsbHMucHVzaChpdGVtKTtcbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgcGFzdGUgPSB2YWxpZGF0ZUNvbW1hbmQoeyB0eXBlOiAnY29yZS5jZWxscy5wYXN0ZScsIHBheWxvYWQ6IHsgc2hlZXRJZCwgY2VsbHMgfSB9KTtcbiAgICBhd2FpdCB0aGlzLnBhc3RlQ2VsbHMocGFzdGUsIG5leHQsIG1ldGFkYXRhKTtcbiAgfVxuICBwcml2YXRlIGFzeW5jIHBhc3RlQ2VsbHMoY29tbWFuZDogQ29tbWFuZCwgbmV4dDogSGVhZCwgbWV0YWRhdGE6IE1ldGFkYXRhKSB7XG4gICAgY29uc3QgeyBzaGVldElkLCBjZWxsczogaW5jb21pbmcgfSA9IGNvbW1hbmQucGF5bG9hZCBhcyB7IHNoZWV0SWQ6IHN0cmluZzsgY2VsbHM6IFBhc3RlQ2VsbFtdIH07XG4gICAgY29uc3Qgc2ggPSBtZXRhZGF0YS5zbmFwc2hvdC5zaGVldHMuZmluZCgoc2hlZXQpID0+IHNoZWV0LmlkID09PSBzaGVldElkKTtcbiAgICBhc3NlcnQoc2gsICdJTlZBTElEX0FSR1VNRU5UJywgJ1NoZWV0IG5vIGxvbmdlciBleGlzdHMnKTtcbiAgICBjb25zdCBwYWdlcyA9IG5ldyBNYXA8c3RyaW5nLCBQYXN0ZUNlbGxbXT4oKTtcbiAgICBsZXQgc3RhcnRSb3cgPSBJbmZpbml0eSxcbiAgICAgIGVuZFJvdyA9IDAsXG4gICAgICBzdGFydENvbHVtbiA9IEluZmluaXR5LFxuICAgICAgZW5kQ29sdW1uID0gMDtcbiAgICBmb3IgKGNvbnN0IGl0ZW0gb2YgaW5jb21pbmcpIHtcbiAgICAgIGFzc2VydChcbiAgICAgICAgaXRlbS5yb3cgPCBzaC5yb3dPcmRlci5sZW5ndGggJiYgaXRlbS5jb2x1bW4gPCBzaC5jb2x1bW5PcmRlci5sZW5ndGgsXG4gICAgICAgICdJTlZBTElEX1JBTkdFJyxcbiAgICAgICAgJ1JhbmdlIGV4Y2VlZHMgc2hlZXQgZGltZW5zaW9ucycsXG4gICAgICApO1xuICAgICAgc3RhcnRSb3cgPSBNYXRoLm1pbihzdGFydFJvdywgaXRlbS5yb3cpO1xuICAgICAgZW5kUm93ID0gTWF0aC5tYXgoZW5kUm93LCBpdGVtLnJvdyArIDEpO1xuICAgICAgc3RhcnRDb2x1bW4gPSBNYXRoLm1pbihzdGFydENvbHVtbiwgaXRlbS5jb2x1bW4pO1xuICAgICAgZW5kQ29sdW1uID0gTWF0aC5tYXgoZW5kQ29sdW1uLCBpdGVtLmNvbHVtbiArIDEpO1xuICAgICAgY29uc3QgYWRkcmVzcyA9IGJsb2NrQWRkcmVzcyhzaGVldElkLCBzaC5yb3dPcmRlcltpdGVtLnJvd10sIHNoLmNvbHVtbk9yZGVyW2l0ZW0uY29sdW1uXSk7XG4gICAgICBsZXQgcGFnZSA9IHBhZ2VzLmdldChhZGRyZXNzKTtcbiAgICAgIGlmICghcGFnZSkgcGFnZXMuc2V0KGFkZHJlc3MsIChwYWdlID0gW10pKTtcbiAgICAgIHBhZ2UucHVzaChpdGVtKTtcbiAgICB9XG4gICAgY29uc3QgbWVyZ2VzID0gc2gubWVyZ2VzLmZpbHRlcigobWVyZ2UpID0+XG4gICAgICBpbnRlcnNlY3RzKG1lcmdlLCB7IHN0YXJ0Um93LCBlbmRSb3csIHN0YXJ0Q29sdW1uLCBlbmRDb2x1bW4gfSksXG4gICAgKTtcbiAgICBsZXQgY2hlY2tzID0gMDtcbiAgICBmb3IgKGNvbnN0IGl0ZW0gb2YgaW5jb21pbmcpXG4gICAgICBmb3IgKGNvbnN0IG1lcmdlIG9mIG1lcmdlcykge1xuICAgICAgICBhc3NlcnQoKytjaGVja3MgPD0gMl8wMDBfMDAwLCAnTElNSVRfRVhDRUVERUQnLCAnUGFzdGUgbWVyZ2UtY2hlY2sgYnVkZ2V0IGV4Y2VlZGVkJyk7XG4gICAgICAgIGFzc2VydChcbiAgICAgICAgICAhKFxuICAgICAgICAgICAgaXRlbS5yb3cgPj0gbWVyZ2Uuc3RhcnRSb3cgJiZcbiAgICAgICAgICAgIGl0ZW0ucm93IDwgbWVyZ2UuZW5kUm93ICYmXG4gICAgICAgICAgICBpdGVtLmNvbHVtbiA+PSBtZXJnZS5zdGFydENvbHVtbiAmJlxuICAgICAgICAgICAgaXRlbS5jb2x1bW4gPCBtZXJnZS5lbmRDb2x1bW5cbiAgICAgICAgICApLFxuICAgICAgICAgICdJTlZBTElEX1JBTkdFJyxcbiAgICAgICAgICAnVW5tZXJnZSBiZWZvcmUgcGFzdGluZyBjZWxsIGlucHV0cyBvciBmb3JtYXRzJyxcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICBpZiAoY2hhbmdlc1N0eWxlcyhjb21tYW5kKSkgbWV0YWRhdGEuc25hcHNob3Quc3R5bGVzID0geyAuLi5tZXRhZGF0YS5zbmFwc2hvdC5zdHlsZXMgfTtcbiAgICBmb3IgKGNvbnN0IFthZGRyZXNzLCBwYWdlXSBvZiBwYWdlcykge1xuICAgICAgdGhpcy5jaGVjaygpO1xuICAgICAgY29uc3QgY2VsbHMgPSBzdHJ1Y3R1cmVkQ2xvbmUoKGF3YWl0IHRoaXMuYmxvY2soYWRkcmVzcywgbmV4dCkpLmNlbGxzKTtcbiAgICAgIGZvciAoY29uc3QgaXRlbSBvZiBwYWdlKSB7XG4gICAgICAgIGNvbnN0IHJvd0lkID0gc2gucm93T3JkZXJbaXRlbS5yb3ddLFxuICAgICAgICAgIGNvbHVtbklkID0gc2guY29sdW1uT3JkZXJbaXRlbS5jb2x1bW5dO1xuICAgICAgICBjb25zdCBwb3NpdGlvbiA9IGtleShyb3dJZCwgY29sdW1uSWQpO1xuICAgICAgICBjb25zdCB0YXJnZXQgPVxuICAgICAgICAgIGNlbGxzW3Bvc2l0aW9uXSA/PyAoY2VsbHNbcG9zaXRpb25dID0geyByb3dJZCwgY29sdW1uSWQsIGlucHV0OiB7IHR5cGU6ICdibGFuaycgfSB9KTtcbiAgICAgICAgYXBwbHlQYXN0ZWRDZWxsKG1ldGFkYXRhLnNuYXBzaG90LCB0YXJnZXQsIGl0ZW0pO1xuICAgICAgfVxuICAgICAgYXdhaXQgdGhpcy5zdG9yZUJsb2NrKGFkZHJlc3MsIGNlbGxzLCBuZXh0LCBtZXRhZGF0YSk7XG4gICAgfVxuICB9XG4gIHByaXZhdGUgYXN5bmMgZmlsbFNlcmllcyhjb21tYW5kOiBDb21tYW5kLCBuZXh0OiBIZWFkLCBtZXRhZGF0YTogTWV0YWRhdGEpIHtcbiAgICBjb25zdCB7IHNoZWV0SWQsIHJhbmdlLCBzdGFydCwgc3RlcCwgYXhpcywgY2FsZW5kYXIgfSA9IGNvbW1hbmQucGF5bG9hZCBhcyB7XG4gICAgICBzaGVldElkOiBzdHJpbmc7XG4gICAgICByYW5nZTogUmVjdDtcbiAgICAgIHN0YXJ0OiBudW1iZXI7XG4gICAgICBzdGVwOiBudW1iZXI7XG4gICAgICBheGlzOiAncm93JyB8ICdjb2x1bW4nO1xuICAgICAgY2FsZW5kYXI/OiAnbW9udGgnIHwgJ3llYXInO1xuICAgIH07XG4gICAgY29uc3Qgc2ggPSBtZXRhZGF0YS5zbmFwc2hvdC5zaGVldHMuZmluZCgoc2hlZXQpID0+IHNoZWV0LmlkID09PSBzaGVldElkKTtcbiAgICBhc3NlcnQoc2gsICdJTlZBTElEX0FSR1VNRU5UJywgJ1NoZWV0IG5vIGxvbmdlciBleGlzdHMnKTtcbiAgICBjaGVja0JvdW5kcyhzaCwgcmFuZ2UpO1xuICAgIGFzc2VydChcbiAgICAgIChyYW5nZS5lbmRSb3cgLSByYW5nZS5zdGFydFJvdykgKiAocmFuZ2UuZW5kQ29sdW1uIC0gcmFuZ2Uuc3RhcnRDb2x1bW4pIDw9IExJTUlUUy5yYW5nZUNlbGxzLFxuICAgICAgJ0xJTUlUX0VYQ0VFREVEJyxcbiAgICAgICdTZXJpZXMgZXhjZWVkcyB0aGUgY2VsbCBsaW1pdCcsXG4gICAgKTtcbiAgICBhc3NlcnQoXG4gICAgICAhc2gubWVyZ2VzLnNvbWUoKG1lcmdlKSA9PiBpbnRlcnNlY3RzKG1lcmdlLCByYW5nZSkpLFxuICAgICAgJ0lOVkFMSURfUkFOR0UnLFxuICAgICAgJ1VubWVyZ2UgYmVmb3JlIGZpbGxpbmcgYSBzZXJpZXMnLFxuICAgICk7XG4gICAgY29uc3QgY291bnQgPVxuICAgICAgYXhpcyA9PT0gJ3JvdycgPyByYW5nZS5lbmRSb3cgLSByYW5nZS5zdGFydFJvdyA6IHJhbmdlLmVuZENvbHVtbiAtIHJhbmdlLnN0YXJ0Q29sdW1uO1xuICAgIGNvbnN0IHZhbHVlcyA9IGNhbGVuZGFyXG4gICAgICA/IGNhbGVuZGFyU2VyaWVzKHN0YXJ0LCBzdGVwLCBjb3VudCwgY2FsZW5kYXIsIG1ldGFkYXRhLnNuYXBzaG90LmRhdGVTeXN0ZW0pXG4gICAgICA6IG51bWVyaWNTZXJpZXMoc3RhcnQsIHN0ZXAsIGNvdW50KTtcbiAgICBjb25zdCByb3dHcm91cHMgPSBncm91cEF4aXMoc2gucm93T3JkZXIsIHJhbmdlLnN0YXJ0Um93LCByYW5nZS5lbmRSb3csIEJMT0NLX1JPV1MpO1xuICAgIGNvbnN0IGNvbHVtbkdyb3VwcyA9IGdyb3VwQXhpcyhcbiAgICAgIHNoLmNvbHVtbk9yZGVyLFxuICAgICAgcmFuZ2Uuc3RhcnRDb2x1bW4sXG4gICAgICByYW5nZS5lbmRDb2x1bW4sXG4gICAgICBCTE9DS19DT0xVTU5TLFxuICAgICk7XG4gICAgZm9yIChjb25zdCByb3dzIG9mIHJvd0dyb3Vwcy52YWx1ZXMoKSkge1xuICAgICAgZm9yIChjb25zdCBjb2x1bW5zIG9mIGNvbHVtbkdyb3Vwcy52YWx1ZXMoKSkge1xuICAgICAgICB0aGlzLmNoZWNrKCk7XG4gICAgICAgIGNvbnN0IGFkZHJlc3MgPSBibG9ja0FkZHJlc3Moc2hlZXRJZCwgcm93c1swXS5pZCwgY29sdW1uc1swXS5pZCk7XG4gICAgICAgIGNvbnN0IGNlbGxzID0gc3RydWN0dXJlZENsb25lKChhd2FpdCB0aGlzLmJsb2NrKGFkZHJlc3MsIG5leHQpKS5jZWxscyk7XG4gICAgICAgIGZvciAoY29uc3Qgcm93IG9mIHJvd3MpXG4gICAgICAgICAgZm9yIChjb25zdCBjb2x1bW4gb2YgY29sdW1ucykge1xuICAgICAgICAgICAgY29uc3QgcG9zaXRpb24gPSBrZXkocm93LmlkLCBjb2x1bW4uaWQpO1xuICAgICAgICAgICAgY29uc3QgdGFyZ2V0ID1cbiAgICAgICAgICAgICAgY2VsbHNbcG9zaXRpb25dID8/XG4gICAgICAgICAgICAgIChjZWxsc1twb3NpdGlvbl0gPSB7XG4gICAgICAgICAgICAgICAgcm93SWQ6IHJvdy5pZCxcbiAgICAgICAgICAgICAgICBjb2x1bW5JZDogY29sdW1uLmlkLFxuICAgICAgICAgICAgICAgIGlucHV0OiB7IHR5cGU6ICdibGFuaycgfSxcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB0YXJnZXQuaW5wdXQgPSB7XG4gICAgICAgICAgICAgIHR5cGU6ICdudW1iZXInLFxuICAgICAgICAgICAgICB2YWx1ZTpcbiAgICAgICAgICAgICAgICB2YWx1ZXNbXG4gICAgICAgICAgICAgICAgICBheGlzID09PSAncm93JyA/IHJvdy5pbmRleCAtIHJhbmdlLnN0YXJ0Um93IDogY29sdW1uLmluZGV4IC0gcmFuZ2Uuc3RhcnRDb2x1bW5cbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIGRlbGV0ZSB0YXJnZXQuY2FjaGVkO1xuICAgICAgICAgIH1cbiAgICAgICAgYXdhaXQgdGhpcy5zdG9yZUJsb2NrKGFkZHJlc3MsIGNlbGxzLCBuZXh0LCBtZXRhZGF0YSk7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHByaXZhdGUgYXN5bmMgYXBwbHlTdHlsZShjb21tYW5kOiBDb21tYW5kLCBuZXh0OiBIZWFkLCBtZXRhZGF0YTogTWV0YWRhdGEpIHtcbiAgICBjb25zdCB7IHNoZWV0SWQsIHJhbmdlLCBzdHlsZSB9ID0gY29tbWFuZC5wYXlsb2FkIGFzIHtcbiAgICAgIHNoZWV0SWQ6IHN0cmluZztcbiAgICAgIHJhbmdlOiBSZWN0O1xuICAgICAgc3R5bGU6IENlbGxTdHlsZTtcbiAgICB9O1xuICAgIGNvbnN0IHNoID0gbWV0YWRhdGEuc25hcHNob3Quc2hlZXRzLmZpbmQoKHNoZWV0KSA9PiBzaGVldC5pZCA9PT0gc2hlZXRJZCk7XG4gICAgYXNzZXJ0KHNoLCAnSU5WQUxJRF9BUkdVTUVOVCcsICdTaGVldCBubyBsb25nZXIgZXhpc3RzJyk7XG4gICAgY2hlY2tCb3VuZHMoc2gsIHJhbmdlKTtcbiAgICBhc3NlcnQoXG4gICAgICAocmFuZ2UuZW5kUm93IC0gcmFuZ2Uuc3RhcnRSb3cpICogKHJhbmdlLmVuZENvbHVtbiAtIHJhbmdlLnN0YXJ0Q29sdW1uKSA8PSBMSU1JVFMucmFuZ2VDZWxscyxcbiAgICAgICdMSU1JVF9FWENFRURFRCcsXG4gICAgICAnU3R5bGUgcmFuZ2UgZXhjZWVkcyB0aGUgY2VsbCBsaW1pdCcsXG4gICAgKTtcbiAgICBhc3NlcnQoXG4gICAgICBzaC5tZXJnZXMuZXZlcnkoKG1lcmdlKSA9PiAhaW50ZXJzZWN0cyhtZXJnZSwgcmFuZ2UpIHx8IGNvbnRhaW5zKHJhbmdlLCBtZXJnZSkpLFxuICAgICAgJ0lOVkFMSURfUkFOR0UnLFxuICAgICAgJ09wZXJhdGlvbiBjdXRzIHRocm91Z2ggYSBtZXJnZWQgY2VsbCcsXG4gICAgKTtcbiAgICBtZXRhZGF0YS5zbmFwc2hvdC5zdHlsZXMgPSB7IC4uLm1ldGFkYXRhLnNuYXBzaG90LnN0eWxlcyB9O1xuICAgIGNvbnN0IHN0eWxlcyA9IG5ldyBNYXA8c3RyaW5nLCBzdHJpbmc+KCk7XG4gICAgY29uc3Qgcm93R3JvdXBzID0gZ3JvdXBBeGlzKHNoLnJvd09yZGVyLCByYW5nZS5zdGFydFJvdywgcmFuZ2UuZW5kUm93LCBCTE9DS19ST1dTKTtcbiAgICBjb25zdCBjb2x1bW5Hcm91cHMgPSBncm91cEF4aXMoXG4gICAgICBzaC5jb2x1bW5PcmRlcixcbiAgICAgIHJhbmdlLnN0YXJ0Q29sdW1uLFxuICAgICAgcmFuZ2UuZW5kQ29sdW1uLFxuICAgICAgQkxPQ0tfQ09MVU1OUyxcbiAgICApO1xuICAgIGZvciAoY29uc3Qgcm93cyBvZiByb3dHcm91cHMudmFsdWVzKCkpIHtcbiAgICAgIGZvciAoY29uc3QgY29sdW1ucyBvZiBjb2x1bW5Hcm91cHMudmFsdWVzKCkpIHtcbiAgICAgICAgdGhpcy5jaGVjaygpO1xuICAgICAgICBjb25zdCBhZGRyZXNzID0gYmxvY2tBZGRyZXNzKHNoZWV0SWQsIHJvd3NbMF0uaWQsIGNvbHVtbnNbMF0uaWQpO1xuICAgICAgICBjb25zdCBjZWxscyA9IHN0cnVjdHVyZWRDbG9uZSgoYXdhaXQgdGhpcy5ibG9jayhhZGRyZXNzLCBuZXh0KSkuY2VsbHMpO1xuICAgICAgICBmb3IgKGNvbnN0IHJvdyBvZiByb3dzKVxuICAgICAgICAgIGZvciAoY29uc3QgY29sdW1uIG9mIGNvbHVtbnMpIHtcbiAgICAgICAgICAgIGNvbnN0IHBvc2l0aW9uID0ga2V5KHJvdy5pZCwgY29sdW1uLmlkKTtcbiAgICAgICAgICAgIGNvbnN0IHRhcmdldCA9XG4gICAgICAgICAgICAgIGNlbGxzW3Bvc2l0aW9uXSA/P1xuICAgICAgICAgICAgICAoY2VsbHNbcG9zaXRpb25dID0ge1xuICAgICAgICAgICAgICAgIHJvd0lkOiByb3cuaWQsXG4gICAgICAgICAgICAgICAgY29sdW1uSWQ6IGNvbHVtbi5pZCxcbiAgICAgICAgICAgICAgICBpbnB1dDogeyB0eXBlOiAnYmxhbmsnIH0sXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgY29uc3QgcHJpb3IgPSB0YXJnZXQuc3R5bGVJZCA/PyAnJztcbiAgICAgICAgICAgIGxldCBuZXh0U3R5bGUgPSBzdHlsZXMuZ2V0KHByaW9yKTtcbiAgICAgICAgICAgIGlmICghbmV4dFN0eWxlKSB7XG4gICAgICAgICAgICAgIG5leHRTdHlsZSA9IHN0eWxlSWQobWV0YWRhdGEuc25hcHNob3QsIHtcbiAgICAgICAgICAgICAgICAuLi4odGFyZ2V0LnN0eWxlSWQgPyBtZXRhZGF0YS5zbmFwc2hvdC5zdHlsZXNbdGFyZ2V0LnN0eWxlSWRdIDoge30pLFxuICAgICAgICAgICAgICAgIC4uLnN0eWxlLFxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgc3R5bGVzLnNldChwcmlvciwgbmV4dFN0eWxlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRhcmdldC5zdHlsZUlkID0gbmV4dFN0eWxlO1xuICAgICAgICAgICAgaWYgKHN0eWxlLm51bWJlckZvcm1hdCAhPT0gdW5kZWZpbmVkKSBkZWxldGUgdGFyZ2V0Lm51bWJlckZvcm1hdDtcbiAgICAgICAgICB9XG4gICAgICAgIGF3YWl0IHRoaXMuc3RvcmVCbG9jayhhZGRyZXNzLCBjZWxscywgbmV4dCwgbWV0YWRhdGEpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBwcml2YXRlIGFzeW5jIGZpbGxEb3duKGNvbW1hbmQ6IENvbW1hbmQsIG5leHQ6IEhlYWQsIG1ldGFkYXRhOiBNZXRhZGF0YSkge1xuICAgIGNvbnN0IHsgc2hlZXRJZCwgcmFuZ2UgfSA9IGNvbW1hbmQucGF5bG9hZCBhcyB7IHNoZWV0SWQ6IHN0cmluZzsgcmFuZ2U6IFJlY3QgfTtcbiAgICBjb25zdCBzaCA9IG1ldGFkYXRhLnNuYXBzaG90LnNoZWV0cy5maW5kKChzaGVldCkgPT4gc2hlZXQuaWQgPT09IHNoZWV0SWQpO1xuICAgIGFzc2VydChzaCwgJ0lOVkFMSURfQVJHVU1FTlQnLCAnU2hlZXQgbm8gbG9uZ2VyIGV4aXN0cycpO1xuICAgIGNoZWNrQm91bmRzKHNoLCByYW5nZSk7XG4gICAgYXNzZXJ0KFxuICAgICAgIXNoLm1lcmdlcy5zb21lKChtZXJnZSkgPT4gaW50ZXJzZWN0cyhtZXJnZSwgcmFuZ2UpKSxcbiAgICAgICdJTlZBTElEX1JBTkdFJyxcbiAgICAgICdVbm1lcmdlIGJlZm9yZSBjb3B5aW5nIG9yIGZpbGxpbmcnLFxuICAgICk7XG4gICAgY29uc3Qgcm93R3JvdXBzID0gbmV3IE1hcDxudW1iZXIsIHsgaW5kZXg6IG51bWJlcjsgaWQ6IG51bWJlciB9W10+KCk7XG4gICAgY29uc3QgY29sdW1uR3JvdXBzID0gbmV3IE1hcDxudW1iZXIsIHsgaW5kZXg6IG51bWJlcjsgaWQ6IG51bWJlciB9W10+KCk7XG4gICAgZm9yIChsZXQgaW5kZXggPSByYW5nZS5zdGFydFJvdyArIDE7IGluZGV4IDwgcmFuZ2UuZW5kUm93OyBpbmRleCsrKSB7XG4gICAgICBjb25zdCBpZCA9IHNoLnJvd09yZGVyW2luZGV4XSxcbiAgICAgICAgZ3JvdXAgPSBNYXRoLmZsb29yKGlkIC8gQkxPQ0tfUk9XUyk7XG4gICAgICBsZXQgdmFsdWVzID0gcm93R3JvdXBzLmdldChncm91cCk7XG4gICAgICBpZiAoIXZhbHVlcykgcm93R3JvdXBzLnNldChncm91cCwgKHZhbHVlcyA9IFtdKSk7XG4gICAgICB2YWx1ZXMucHVzaCh7IGluZGV4LCBpZCB9KTtcbiAgICB9XG4gICAgZm9yIChsZXQgaW5kZXggPSByYW5nZS5zdGFydENvbHVtbjsgaW5kZXggPCByYW5nZS5lbmRDb2x1bW47IGluZGV4KyspIHtcbiAgICAgIGNvbnN0IGlkID0gc2guY29sdW1uT3JkZXJbaW5kZXhdLFxuICAgICAgICBncm91cCA9IE1hdGguZmxvb3IoaWQgLyBCTE9DS19DT0xVTU5TKTtcbiAgICAgIGxldCB2YWx1ZXMgPSBjb2x1bW5Hcm91cHMuZ2V0KGdyb3VwKTtcbiAgICAgIGlmICghdmFsdWVzKSBjb2x1bW5Hcm91cHMuc2V0KGdyb3VwLCAodmFsdWVzID0gW10pKTtcbiAgICAgIHZhbHVlcy5wdXNoKHsgaW5kZXgsIGlkIH0pO1xuICAgIH1cbiAgICBjb25zdCBzb3VyY2UgPSBuZXcgTWFwPG51bWJlciwgQ2VsbFJlY29yZD4oKTtcbiAgICBjb25zdCBzb3VyY2VJZCA9IHNoLnJvd09yZGVyW3JhbmdlLnN0YXJ0Um93XTtcbiAgICBmb3IgKGNvbnN0IGNvbHVtbnMgb2YgY29sdW1uR3JvdXBzLnZhbHVlcygpKSB7XG4gICAgICB0aGlzLmNoZWNrKCk7XG4gICAgICBjb25zdCBibG9jayA9IGF3YWl0IHRoaXMuYmxvY2soYmxvY2tBZGRyZXNzKHNoZWV0SWQsIHNvdXJjZUlkLCBjb2x1bW5zWzBdLmlkKSwgbmV4dCk7XG4gICAgICBjb25zdCBjZWxscyA9IGJsb2NrLmNlbGxzO1xuICAgICAgZm9yIChjb25zdCBjb2x1bW4gb2YgY29sdW1ucykge1xuICAgICAgICBjb25zdCB2YWx1ZSA9IGNlbGxzW2tleShzb3VyY2VJZCwgY29sdW1uLmlkKV07XG4gICAgICAgIGlmICh2YWx1ZSkgc291cmNlLnNldChjb2x1bW4uaWQsIHN0cnVjdHVyZWRDbG9uZSh2YWx1ZSkpO1xuICAgICAgfVxuICAgIH1cbiAgICBmb3IgKGNvbnN0IHJvd3Mgb2Ygcm93R3JvdXBzLnZhbHVlcygpKSB7XG4gICAgICBmb3IgKGNvbnN0IGNvbHVtbnMgb2YgY29sdW1uR3JvdXBzLnZhbHVlcygpKSB7XG4gICAgICAgIHRoaXMuY2hlY2soKTtcbiAgICAgICAgY29uc3QgYWRkcmVzcyA9IGJsb2NrQWRkcmVzcyhzaGVldElkLCByb3dzWzBdLmlkLCBjb2x1bW5zWzBdLmlkKTtcbiAgICAgICAgY29uc3QgY2VsbHMgPSBzdHJ1Y3R1cmVkQ2xvbmUoKGF3YWl0IHRoaXMuYmxvY2soYWRkcmVzcywgbmV4dCkpLmNlbGxzKTtcbiAgICAgICAgZm9yIChjb25zdCByb3cgb2Ygcm93cylcbiAgICAgICAgICBmb3IgKGNvbnN0IGNvbHVtbiBvZiBjb2x1bW5zKSB7XG4gICAgICAgICAgICBjb25zdCBwb3NpdGlvbiA9IGtleShyb3cuaWQsIGNvbHVtbi5pZCk7XG4gICAgICAgICAgICBjb25zdCBvcmlnaW5hbCA9IHNvdXJjZS5nZXQoY29sdW1uLmlkKTtcbiAgICAgICAgICAgIGlmICghb3JpZ2luYWwpIHtcbiAgICAgICAgICAgICAgZGVsZXRlIGNlbGxzW3Bvc2l0aW9uXTtcbiAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCB2YWx1ZSA9IHN0cnVjdHVyZWRDbG9uZShvcmlnaW5hbCk7XG4gICAgICAgICAgICB2YWx1ZS5yb3dJZCA9IHJvdy5pZDtcbiAgICAgICAgICAgIHZhbHVlLmNvbHVtbklkID0gY29sdW1uLmlkO1xuICAgICAgICAgICAgaWYgKHZhbHVlLmlucHV0LnR5cGUgPT09ICdmb3JtdWxhJylcbiAgICAgICAgICAgICAgdmFsdWUuaW5wdXQuZXhwcmVzc2lvbiA9IG9mZnNldENlbGxGb3JtdWxhKFxuICAgICAgICAgICAgICAgIHZhbHVlLmlucHV0LmV4cHJlc3Npb24sXG4gICAgICAgICAgICAgICAgcm93LmluZGV4IC0gcmFuZ2Uuc3RhcnRSb3csXG4gICAgICAgICAgICAgICAgMCxcbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIGRlbGV0ZSB2YWx1ZS5jYWNoZWQ7XG4gICAgICAgICAgICBjZWxsc1twb3NpdGlvbl0gPSB2YWx1ZTtcbiAgICAgICAgICB9XG4gICAgICAgIGF3YWl0IHRoaXMuc3RvcmVCbG9jayhhZGRyZXNzLCBjZWxscywgbmV4dCwgbWV0YWRhdGEpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBwcml2YXRlIGFzeW5jIHJlcGxhY2VUZXh0KGNvbW1hbmQ6IENvbW1hbmQsIG5leHQ6IEhlYWQsIG1ldGFkYXRhOiBNZXRhZGF0YSkge1xuICAgIGNvbnN0IGlkID0gU3RyaW5nKGNvbW1hbmQucGF5bG9hZC5zaGVldElkKTtcbiAgICBhc3NlcnQoXG4gICAgICBtZXRhZGF0YS5zbmFwc2hvdC5zaGVldHMuc29tZSgoc2hlZXQpID0+IHNoZWV0LmlkID09PSBpZCksXG4gICAgICAnSU5WQUxJRF9BUkdVTUVOVCcsXG4gICAgICAnVW5rbm93biBzaGVldCcsXG4gICAgKTtcbiAgICBjb25zdCBxdWVyeSA9IFN0cmluZyhjb21tYW5kLnBheWxvYWQucXVlcnkpO1xuICAgIGlmIChxdWVyeSA9PT0gY29tbWFuZC5wYXlsb2FkLnJlcGxhY2VtZW50KSByZXR1cm47XG4gICAgZm9yIChjb25zdCBhIG9mIE9iamVjdC5rZXlzKG5leHQuYmxvY2tzKSlcbiAgICAgIGlmIChhLnN0YXJ0c1dpdGgoYCR7aWR9L2ApKSB7XG4gICAgICAgIHRoaXMuY2hlY2soKTtcbiAgICAgICAgY29uc3QgZXhpc3RpbmcgPSAoYXdhaXQgdGhpcy5ibG9jayhhLCBuZXh0KSkuY2VsbHM7XG4gICAgICAgIGlmIChcbiAgICAgICAgICAhT2JqZWN0LnZhbHVlcyhleGlzdGluZykuc29tZShcbiAgICAgICAgICAgIChjZWxsKSA9PiBjZWxsLmlucHV0LnR5cGUgPT09ICdzdHJpbmcnICYmIGNlbGwuaW5wdXQudmFsdWUuaW5jbHVkZXMocXVlcnkpLFxuICAgICAgICAgIClcbiAgICAgICAgKVxuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICBjb25zdCBjZWxscyA9IHN0cnVjdHVyZWRDbG9uZShleGlzdGluZyk7XG4gICAgICAgIGNvbnN0IHNuYXBzaG90ID0ge1xuICAgICAgICAgIC4uLm1ldGFkYXRhLnNuYXBzaG90LFxuICAgICAgICAgIHNoZWV0czogbWV0YWRhdGEuc25hcHNob3Quc2hlZXRzLm1hcCgocykgPT4gKHMuaWQgPT09IGlkID8geyAuLi5zLCBjZWxscyB9IDogcykpLFxuICAgICAgICB9O1xuICAgICAgICByZWR1Y2VDb21tYW5kKHNuYXBzaG90LCBjb21tYW5kKTtcbiAgICAgICAgYXdhaXQgdGhpcy5zdG9yZUJsb2NrKGEsIGNlbGxzLCBuZXh0LCBtZXRhZGF0YSk7XG4gICAgICB9XG4gIH1cbiAgcHJpdmF0ZSBhc3luYyBzdHJ1Y3R1cmFsKGNvbW1hbmQ6IENvbW1hbmQsIG5leHQ6IEhlYWQsIG1ldGFkYXRhOiBNZXRhZGF0YSkge1xuICAgIGNvbnN0IG9yaWdpbmFsID0gbWV0YWRhdGEuc25hcHNob3Q7XG4gICAgY29uc3QgdHJhbnNmb3JtZWQgPSBzdHJ1Y3R1cmVkQ2xvbmUob3JpZ2luYWwpO1xuICAgIC8vIEF4ZXMgYXJlIGNvcGllZCBvbmx5IGZvciBhIHN0cnVjdHVyYWwgb3BlcmF0aW9uLiBTdGFibGUgaWRlbnRpdHkgcGFnZXMgc3RheSBpbiBwbGFjZS5cbiAgICByZWR1Y2VDb21tYW5kKHRyYW5zZm9ybWVkLCBjb21tYW5kKTtcbiAgICBjb25zdCBheGlzUGF5bG9hZCA9IGNvbW1hbmQucGF5bG9hZCBhcyBhbnk7XG4gICAgaWYgKGNvbW1hbmQudHlwZSA9PT0gJ2NvcmUuYXhpcy5pbnNlcnQnIHx8IGNvbW1hbmQudHlwZSA9PT0gJ2NvcmUuYXhpcy5kZWxldGUnKSB7XG4gICAgICBjb25zdCBiZWZvcmUgPSBvcmlnaW5hbC5zaGVldHMuZmluZCgocykgPT4gcy5pZCA9PT0gYXhpc1BheWxvYWQuc2hlZXRJZCkhLFxuICAgICAgICBhZnRlciA9IHRyYW5zZm9ybWVkLnNoZWV0cy5maW5kKChzKSA9PiBzLmlkID09PSBheGlzUGF5bG9hZC5zaGVldElkKSE7XG4gICAgICBjb25zdCBmaWVsZCA9IGF4aXNQYXlsb2FkLmF4aXMgPT09ICdyb3cnID8gJ3Jvd09yZGVyJyA6ICdjb2x1bW5PcmRlcicsXG4gICAgICAgIGluZGV4ID0gdGhpcy5heGlzKGJlZm9yZVtmaWVsZF0pLmNsb25lKCk7XG4gICAgICBpbmRleC5zcGxpY2UoXG4gICAgICAgIGF4aXNQYXlsb2FkLmluZGV4LFxuICAgICAgICBjb21tYW5kLnR5cGUgPT09ICdjb3JlLmF4aXMuZGVsZXRlJyA/IGF4aXNQYXlsb2FkLmNvdW50IDogMCxcbiAgICAgICAgY29tbWFuZC50eXBlID09PSAnY29yZS5heGlzLmluc2VydCcgPyBheGlzUGF5bG9hZC5pZHMgOiBbXSxcbiAgICAgICk7XG4gICAgICBhc3NlcnQoXG4gICAgICAgIGluZGV4LnRvQXJyYXkoKS5ldmVyeSgoaWQsIGkpID0+IGlkID09PSBhZnRlcltmaWVsZF1baV0pLFxuICAgICAgICAnQ09SUlVQVF9TVE9SQUdFJyxcbiAgICAgICAgJ0F4aXMgc2VxdWVuY2UgZGlmZmVycycsXG4gICAgICApO1xuICAgICAgdGhpcy5heGVzLnNldChhZnRlcltmaWVsZF0sIGluZGV4KTtcbiAgICB9XG4gICAgY29uc3QgcGF5bG9hZCA9IGNvbW1hbmQucGF5bG9hZCBhcyBhbnksXG4gICAgICBzb3VyY2VTaGVldCA9IG9yaWdpbmFsLnNoZWV0cy5maW5kKChzKSA9PiBzLmlkID09PSBwYXlsb2FkLnNoZWV0SWQpITtcbiAgICBjb25zdCBzb3VyY2VOYW1lID0gc291cmNlU2hlZXQubmFtZS50b0xvd2VyQ2FzZSgpO1xuICAgIGNvbnN0IG5hbWVzID0gbmV3IE1hcChvcmlnaW5hbC5zaGVldHMubWFwKChzaGVldCkgPT4gW3NoZWV0LmlkLCBzaGVldC5uYW1lXSkpO1xuICAgIGNvbnN0IHJld3JpdGUgPSBjcmVhdGVDZWxsRm9ybXVsYVRyYW5zZm9ybWVyKFxuICAgICAgc3RydWN0dXJhbFJlZmVyZW5jZXMoY29tbWFuZCwgc291cmNlU2hlZXQubmFtZSksXG4gICAgICBzdHJ1Y3R1cmFsUmFuZ2VSZWZlcmVuY2VzKGNvbW1hbmQsIHNvdXJjZVNoZWV0Lm5hbWUpLFxuICAgICk7XG4gICAgY29uc3QgYXhpc0VkaXQgPSBjb21tYW5kLnR5cGUgPT09ICdjb3JlLmF4aXMuaW5zZXJ0JyB8fCBjb21tYW5kLnR5cGUgPT09ICdjb3JlLmF4aXMuZGVsZXRlJztcbiAgICBjb25zdCBkZWxldGVkID1cbiAgICAgIGNvbW1hbmQudHlwZSA9PT0gJ2NvcmUuYXhpcy5kZWxldGUnXG4gICAgICAgID8gbmV3IFNldChcbiAgICAgICAgICAgIChwYXlsb2FkLmF4aXMgPT09ICdyb3cnID8gc291cmNlU2hlZXQucm93T3JkZXIgOiBzb3VyY2VTaGVldC5jb2x1bW5PcmRlcikuc2xpY2UoXG4gICAgICAgICAgICAgIHBheWxvYWQuaW5kZXgsXG4gICAgICAgICAgICAgIHBheWxvYWQuaW5kZXggKyBwYXlsb2FkLmNvdW50LFxuICAgICAgICAgICAgKSxcbiAgICAgICAgICApXG4gICAgICAgIDogbmV3IFNldDxudW1iZXI+KCk7XG4gICAgY29uc3QgZGVsZXRlZEJ1Y2tldHMgPSBuZXcgU2V0KFxuICAgICAgWy4uLmRlbGV0ZWRdLm1hcCgoaWQpID0+IE1hdGguZmxvb3IoaWQgLyAocGF5bG9hZC5heGlzID09PSAncm93JyA/IDY0IDogMzIpKSksXG4gICAgKTtcbiAgICBjb25zdCByZW1haW5pbmdCdWNrZXRzID0gbmV3IFNldDxudW1iZXI+KCk7XG4gICAgaWYgKGNvbW1hbmQudHlwZSA9PT0gJ2NvcmUuYXhpcy5kZWxldGUnKSB7XG4gICAgICBjb25zdCBzaGVldCA9IHRyYW5zZm9ybWVkLnNoZWV0cy5maW5kKChpdGVtKSA9PiBpdGVtLmlkID09PSBwYXlsb2FkLnNoZWV0SWQpITtcbiAgICAgIGNvbnN0IG9yZGVyID0gcGF5bG9hZC5heGlzID09PSAncm93JyA/IHNoZWV0LnJvd09yZGVyIDogc2hlZXQuY29sdW1uT3JkZXI7XG4gICAgICBjb25zdCBzaXplID0gcGF5bG9hZC5heGlzID09PSAncm93JyA/IEJMT0NLX1JPV1MgOiBCTE9DS19DT0xVTU5TO1xuICAgICAgZm9yIChjb25zdCBpZCBvZiBvcmRlcikge1xuICAgICAgICBjb25zdCBidWNrZXQgPSBNYXRoLmZsb29yKGlkIC8gc2l6ZSk7XG4gICAgICAgIGlmIChkZWxldGVkQnVja2V0cy5oYXMoYnVja2V0KSkgcmVtYWluaW5nQnVja2V0cy5hZGQoYnVja2V0KTtcbiAgICAgICAgaWYgKHJlbWFpbmluZ0J1Y2tldHMuc2l6ZSA9PT0gZGVsZXRlZEJ1Y2tldHMuc2l6ZSkgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuICAgIG1ldGFkYXRhLnNuYXBzaG90ID0gdHJhbnNmb3JtZWQ7XG4gICAgZm9yIChjb25zdCBbYWRkcmVzcywgcG9pbnRlcl0gb2YgT2JqZWN0LmVudHJpZXMobmV4dC5ibG9ja3MpKSB7XG4gICAgICB0aGlzLmNoZWNrKCk7XG4gICAgICBjb25zdCBbc2hlZXRJZCwgYnIsIGJjXSA9IGFkZHJlc3Muc3BsaXQoJy8nKTtcbiAgICAgIGNvbnN0IHJlbW92ZWRTaGVldCA9IGNvbW1hbmQudHlwZSA9PT0gJ2NvcmUuc2hlZXQucmVtb3ZlJyAmJiBzaGVldElkID09PSBzb3VyY2VTaGVldC5pZDtcbiAgICAgIGNvbnN0IGRlbGV0aW9uID1cbiAgICAgICAgc2hlZXRJZCA9PT0gc291cmNlU2hlZXQuaWQgJiYgZGVsZXRlZEJ1Y2tldHMuaGFzKHBheWxvYWQuYXhpcyA9PT0gJ3JvdycgPyArYnIgOiArYmMpO1xuICAgICAgY29uc3QgZm9ybXVsYSA9IHBvaW50ZXIuZm9ybXVsYXM/LnNvbWUoXG4gICAgICAgIChuYW1lKSA9PiBuYW1lID09PSAnKicgfHwgbmFtZS50b0xvd2VyQ2FzZSgpID09PSBzb3VyY2VOYW1lLFxuICAgICAgKTtcbiAgICAgIGlmIChyZW1vdmVkU2hlZXQpIHtcbiAgICAgICAgdGhpcy5jaGFuZ2VkLmFkZChhZGRyZXNzKTtcbiAgICAgICAgZGVsZXRlIG5leHQuYmxvY2tzW2FkZHJlc3NdO1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cbiAgICAgIGlmIChkZWxldGlvbiAmJiAhcmVtYWluaW5nQnVja2V0cy5oYXMocGF5bG9hZC5heGlzID09PSAncm93JyA/ICticiA6ICtiYykpIHtcbiAgICAgICAgdGhpcy5jaGFuZ2VkLmFkZChhZGRyZXNzKTtcbiAgICAgICAgZGVsZXRlIG5leHQuYmxvY2tzW2FkZHJlc3NdO1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cbiAgICAgIGlmICghZGVsZXRpb24gJiYgIWZvcm11bGEpIGNvbnRpbnVlO1xuICAgICAgY29uc3QgY2VsbHMgPSBzdHJ1Y3R1cmVkQ2xvbmUoKGF3YWl0IHRoaXMuYmxvY2soYWRkcmVzcywgbmV4dCkpLmNlbGxzKTtcbiAgICAgIGlmIChkZWxldGlvbikge1xuICAgICAgICBjb25zdCBmaWVsZCA9IHBheWxvYWQuYXhpcyA9PT0gJ3JvdycgPyAncm93SWQnIDogJ2NvbHVtbklkJztcbiAgICAgICAgZm9yIChjb25zdCBba2V5LCBjZWxsXSBvZiBPYmplY3QuZW50cmllcyhjZWxscykpXG4gICAgICAgICAgaWYgKGRlbGV0ZWQuaGFzKGNlbGxbZmllbGRdKSkgZGVsZXRlIGNlbGxzW2tleV07XG4gICAgICB9XG4gICAgICByZXdyaXRlKGNlbGxzLCBheGlzRWRpdCA/IG5hbWVzLmdldChzaGVldElkKSA6IHVuZGVmaW5lZCk7XG4gICAgICBhd2FpdCB0aGlzLnN0b3JlQmxvY2soYWRkcmVzcywgY2VsbHMsIG5leHQsIG1ldGFkYXRhKTtcbiAgICB9XG4gIH1cbiAgcHJpdmF0ZSBhc3luYyBzb3J0KGNvbW1hbmQ6IENvbW1hbmQsIG5leHQ6IEhlYWQsIG1ldGFkYXRhOiBNZXRhZGF0YSkge1xuICAgIGNvbnN0IHAgPSBjb21tYW5kLnBheWxvYWQgYXMgYW55LFxuICAgICAgc2ggPSBtZXRhZGF0YS5zbmFwc2hvdC5zaGVldHMuZmluZCgocykgPT4gcy5pZCA9PT0gcC5zaGVldElkKSE7XG4gICAgY2hlY2tCb3VuZHMoc2gsIHAucmFuZ2UpO1xuICAgIC8vIFZhbGlkYXRlIHJhbmdlL21lcmdlIGNvbnN0cmFpbnRzIHVzaW5nIHRoZSBleGlzdGluZyBzZW1hbnRpYyByZWR1Y2VyLlxuICAgIGNvbnN0IGtleXMgPSBzb3J0Q29sdW1ucyhwLCBwLnJhbmdlKTtcbiAgICBhc3NlcnQoXG4gICAgICAhc2gubWVyZ2VzLnNvbWUoKG0pID0+IGludGVyc2VjdHMobSwgcC5yYW5nZSkpLFxuICAgICAgJ0lOVkFMSURfUkFOR0UnLFxuICAgICAgJ1VubWVyZ2UgYmVmb3JlIHNvcnRpbmcnLFxuICAgICk7XG4gICAgY29uc3Qgc291cmNlID0geyAuLi5uZXh0LCBibG9ja3M6IHsgLi4ubmV4dC5ibG9ja3MgfSB9O1xuICAgIGZvciAoY29uc3QgYmxvY2sgb2YgT2JqZWN0LnZhbHVlcyhzb3VyY2UuYmxvY2tzKSkgdGhpcy5waW5zLmFkZChibG9jay5pZCk7XG4gICAgbGV0IHJ1bnM6IEFycmF5PHsgaWQ6IHN0cmluZzsgY291bnQ6IG51bWJlcjsgYnl0ZXM6IG51bWJlcjsgbWF4Um93Qnl0ZXM6IG51bWJlciB9PiA9IFtdO1xuICAgIGxldCBzY3JhdGNoQnl0ZXMgPSAwO1xuICAgIGxldCBvdXRwdXRDb21wbGV0ZSA9IGZhbHNlO1xuICAgIHR5cGUgU29ydFJvdyA9IHsgcm93OiBudW1iZXI7IGNlbGxzOiBBcnJheTxDZWxsUmVjb3JkIHwgbnVsbD47IHZhbHVlczogQ2VsbFZhbHVlW10gfTtcbiAgICBjb25zdCBjb21wYXJlID0gKGE6IFNvcnRSb3csIGI6IFNvcnRSb3cpID0+XG4gICAgICBjb21wYXJlU29ydEtleXMoYS52YWx1ZXMsIGIudmFsdWVzLCBrZXlzKSB8fCBhLnJvdyAtIGIucm93O1xuICAgIGNvbnN0IGNhbGN1bGF0aW9uQnl0ZXMgPSBNYXRoLm1pbig0ICogMTAyNCAqIDEwMjQsIHRoaXMuY2FjaGUuYnVkZ2V0KTtcbiAgICBjb25zdCB3b3JraW5nQnVkZ2V0ID0gMzIgKiAxMDI0ICogMTAyNCAtIGNhbGN1bGF0aW9uQnl0ZXM7XG4gICAgY29uc3QgY2FsY3VsYXRvciA9IG5ldyBBc3luY0NhbGN1bGF0aW9uKFxuICAgICAgKHNoZWV0LCByb3csIGNvbHVtbikgPT4gdGhpcy5zdGFnZWRDZWxsKHNoZWV0LCByb3csIGNvbHVtbiwgc291cmNlLCBtZXRhZGF0YSksXG4gICAgICAobmFtZSkgPT5cbiAgICAgICAgbWV0YWRhdGEuc25hcHNob3Quc2hlZXRzLmZpbmQoKHMpID0+IHMubmFtZS50b0xvd2VyQ2FzZSgpID09PSBuYW1lLnRvTG93ZXJDYXNlKCkpPy5pZCxcbiAgICAgIGNhbGN1bGF0aW9uQnl0ZXMsXG4gICAgICB1bmRlZmluZWQsXG4gICAgICAoKSA9PiBtZXRhZGF0YS5zbmFwc2hvdC5kYXRlU3lzdGVtLFxuICAgICk7XG4gICAgdHJ5IHtcbiAgICAgIGxldCBzdGFnZVN0YXJ0ID0gcGVyZm9ybWFuY2Uubm93KCk7XG4gICAgICBjb25zdCB0b3RhbFJvd3MgPSBwLnJhbmdlLmVuZFJvdyAtIHAucmFuZ2Uuc3RhcnRSb3c7XG4gICAgICBjb25zdCBydW5Sb3dzID0gTWF0aC5tYXgoXG4gICAgICAgIDEsXG4gICAgICAgIE1hdGgubWluKDI1NiwgTWF0aC5mbG9vcig4MTkyIC8gKHAucmFuZ2UuZW5kQ29sdW1uIC0gcC5yYW5nZS5zdGFydENvbHVtbikpKSxcbiAgICAgICk7XG4gICAgICBmb3IgKGxldCByb3cgPSBwLnJhbmdlLnN0YXJ0Um93OyByb3cgPCBwLnJhbmdlLmVuZFJvdzsgcm93ICs9IHJ1blJvd3MpIHtcbiAgICAgICAgY29uc3QgYmF0Y2g6IFNvcnRSb3dbXSA9IFtdO1xuICAgICAgICBsZXQgd29ya2luZ0J5dGVzID0gMDtcbiAgICAgICAgZm9yIChsZXQgciA9IHJvdzsgciA8IE1hdGgubWluKHJvdyArIHJ1blJvd3MsIHAucmFuZ2UuZW5kUm93KTsgcisrKSB7XG4gICAgICAgICAgdGhpcy5jaGVjaygpO1xuICAgICAgICAgIGNvbnN0IGNlbGxzOiBBcnJheTxDZWxsUmVjb3JkIHwgbnVsbD4gPSBbXTtcbiAgICAgICAgICBmb3IgKGxldCBjID0gcC5yYW5nZS5zdGFydENvbHVtbjsgYyA8IHAucmFuZ2UuZW5kQ29sdW1uOyBjKyspIHtcbiAgICAgICAgICAgIGNvbnN0IGNlbGwgPVxuICAgICAgICAgICAgICAoXG4gICAgICAgICAgICAgICAgYXdhaXQgdGhpcy5ibG9jayhibG9ja0FkZHJlc3Moc2guaWQsIHNoLnJvd09yZGVyW3JdLCBzaC5jb2x1bW5PcmRlcltjXSksIHNvdXJjZSlcbiAgICAgICAgICAgICAgKS5jZWxsKChzaC5yb3dPcmRlcltyXSAlIDY0KSAqIDMyICsgKHNoLmNvbHVtbk9yZGVyW2NdICUgMzIpKSA/PyBudWxsO1xuICAgICAgICAgICAgd29ya2luZ0J5dGVzICs9IGVuY29kZWRCeXRlcyhjZWxsKSAqIDQ7XG4gICAgICAgICAgICBhc3NlcnQoXG4gICAgICAgICAgICAgIHdvcmtpbmdCeXRlcyA8PSB3b3JraW5nQnVkZ2V0LFxuICAgICAgICAgICAgICAnTElNSVRfRVhDRUVERUQnLFxuICAgICAgICAgICAgICAnU29ydCBydW4gZXhjZWVkcyB0aGUgb3BlcmF0aW9uIHdvcmtpbmctc2V0IGJ1ZGdldCcsXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgY2VsbHMucHVzaChjZWxsKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgY29uc3QgdmFsdWVzOiBDZWxsVmFsdWVbXSA9IFtdO1xuICAgICAgICAgIGZvciAoY29uc3Qga2V5IG9mIGtleXMpIHtcbiAgICAgICAgICAgIGNvbnN0IGlucHV0ID0gY2VsbHNba2V5LmNvbHVtbiAtIHAucmFuZ2Uuc3RhcnRDb2x1bW5dPy5pbnB1dDtcbiAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gc29ydEtleShcbiAgICAgICAgICAgICAgaW5wdXQ/LnR5cGUgPT09ICdmb3JtdWxhJ1xuICAgICAgICAgICAgICAgID8gYXdhaXQgY2FsY3VsYXRvci52YWx1ZShzaC5pZCwgciwga2V5LmNvbHVtbilcbiAgICAgICAgICAgICAgICA6IGlucHV0XG4gICAgICAgICAgICAgICAgICA/IHNjYWxhclZhbHVlKGlucHV0KVxuICAgICAgICAgICAgICAgICAgOiBudWxsLFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIHdvcmtpbmdCeXRlcyArPSBlbmNvZGVkQnl0ZXModmFsdWUpICogNDtcbiAgICAgICAgICAgIGFzc2VydChcbiAgICAgICAgICAgICAgd29ya2luZ0J5dGVzIDw9IHdvcmtpbmdCdWRnZXQsXG4gICAgICAgICAgICAgICdMSU1JVF9FWENFRURFRCcsXG4gICAgICAgICAgICAgICdTb3J0IGtleXMgZXhjZWVkIHRoZSBvcGVyYXRpb24gd29ya2luZy1zZXQgYnVkZ2V0JyxcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICB2YWx1ZXMucHVzaCh2YWx1ZSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGJhdGNoLnB1c2goeyByb3c6IHIsIGNlbGxzLCB2YWx1ZXMgfSk7XG4gICAgICAgIH1cbiAgICAgICAgYXNzZXJ0KFxuICAgICAgICAgIGVuY29kZWRCeXRlcyhiYXRjaCkgKiA0IDw9IHdvcmtpbmdCdWRnZXQsXG4gICAgICAgICAgJ0xJTUlUX0VYQ0VFREVEJyxcbiAgICAgICAgICAnU29ydCBydW4gZXhjZWVkcyB0aGUgMzIgTWlCIG9wZXJhdGlvbiBidWRnZXQnLFxuICAgICAgICApO1xuICAgICAgICBiYXRjaC5zb3J0KGNvbXBhcmUpO1xuICAgICAgICBjb25zdCBydW4gPSBgJHt0aGlzLmlkfS9zb3J0LzAvJHtydW5zLmxlbmd0aH1gO1xuICAgICAgICBjb25zdCBwdXRzOiBBcnJheTxbSURCVmFsaWRLZXksIHVua25vd25dPiA9IGJhdGNoLm1hcCgodiwgaSkgPT4gW1xuICAgICAgICAgIGAke3J1bn0vJHtTdHJpbmcoaSkucGFkU3RhcnQoOCwgJzAnKX1gLFxuICAgICAgICAgIHYsXG4gICAgICAgIF0pO1xuICAgICAgICBjb25zdCBydW5CeXRlcyA9IHB1dHMucmVkdWNlKCh0b3RhbCwgcmVjb3JkKSA9PiB0b3RhbCArIGVuY29kZWRCeXRlcyhyZWNvcmQpLCAwKTtcbiAgICAgICAgc2NyYXRjaEJ5dGVzICs9IHJ1bkJ5dGVzO1xuICAgICAgICB0aGlzLnN0YWdpbmdCeXRlcyA9IHNjcmF0Y2hCeXRlcztcbiAgICAgICAgYXNzZXJ0KFxuICAgICAgICAgIHRoaXMudXNlZEJ5dGVzICsgc2NyYXRjaEJ5dGVzIDw9IG5leHQuYnVkZ2V0LFxuICAgICAgICAgICdTVE9SQUdFX0JVREdFVCcsXG4gICAgICAgICAgJ1NvcnQgc3RhZ2luZyBleGNlZWRzIHRoZSBzdG9yYWdlIGJ1ZGdldCcsXG4gICAgICAgICk7XG4gICAgICAgIGF3YWl0IHRoaXMuZGIud3JpdGUoJ3NjcmF0Y2gnLCBwdXRzKTtcbiAgICAgICAgcnVucy5wdXNoKHtcbiAgICAgICAgICBpZDogcnVuLFxuICAgICAgICAgIGNvdW50OiBiYXRjaC5sZW5ndGgsXG4gICAgICAgICAgYnl0ZXM6IHJ1bkJ5dGVzLFxuICAgICAgICAgIG1heFJvd0J5dGVzOiBNYXRoLm1heCguLi5iYXRjaC5tYXAoKHJvdykgPT4gZW5jb2RlZEJ5dGVzKHJvdykgKiA0ICsgMTAyNCkpLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIHRoaXMucHJvZ3Jlc3Moe1xuICAgICAgICBwaGFzZTogJ3NvcnQtcnVucycsXG4gICAgICAgIGNvbXBsZXRlZDogdG90YWxSb3dzLFxuICAgICAgICB0b3RhbDogdG90YWxSb3dzLFxuICAgICAgICBlbGFwc2VkTXM6IHBlcmZvcm1hbmNlLm5vdygpIC0gc3RhZ2VTdGFydCxcbiAgICAgIH0pO1xuICAgICAgc3RhZ2VTdGFydCA9IHBlcmZvcm1hbmNlLm5vdygpO1xuICAgICAgLy8gUGFpcndpc2UgbWVyZ2UgYnVmZmVycyBhcmUgc2l6ZWQgYnkgdGhlIGxhcmdlc3QgcGVyc2lzdGVkIHJvdywgbm90IGp1c3Qgcm93IGNvdW50LlxuICAgICAgbGV0IHBhc3MgPSAxO1xuICAgICAgd2hpbGUgKHJ1bnMubGVuZ3RoID4gMSkge1xuICAgICAgICBjb25zdCBtZXJnZWQ6IHR5cGVvZiBydW5zID0gW107XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcnVucy5sZW5ndGg7IGkgKz0gMikge1xuICAgICAgICAgIGlmICghcnVuc1tpICsgMV0pIHtcbiAgICAgICAgICAgIG1lcmdlZC5wdXNoKHJ1bnNbaV0pO1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgfVxuICAgICAgICAgIGNvbnN0IGxlZnQgPSBydW5zW2ldLFxuICAgICAgICAgICAgcmlnaHQgPSBydW5zW2kgKyAxXSxcbiAgICAgICAgICAgIGlkID0gYCR7dGhpcy5pZH0vc29ydC8ke3Bhc3N9LyR7aX1gO1xuICAgICAgICAgIGNvbnN0IG1heFJvd0J5dGVzID0gTWF0aC5tYXgobGVmdC5tYXhSb3dCeXRlcywgcmlnaHQubWF4Um93Qnl0ZXMpO1xuICAgICAgICAgIGFzc2VydChcbiAgICAgICAgICAgIGxlZnQubWF4Um93Qnl0ZXMgKyByaWdodC5tYXhSb3dCeXRlcyA8PSB3b3JraW5nQnVkZ2V0LFxuICAgICAgICAgICAgJ0xJTUlUX0VYQ0VFREVEJyxcbiAgICAgICAgICAgICdTb3J0IG1lcmdlIHJvd3MgZXhjZWVkIHRoZSBvcGVyYXRpb24gd29ya2luZy1zZXQgYnVkZ2V0JyxcbiAgICAgICAgICApO1xuICAgICAgICAgIC8vIFJlc2VydmUgc2l4IGJ1ZmZlciBzaGFyZXMgZm9yIGJvdGggcmVhZGVycywgcGVuZGluZyBvdXRwdXQgYW5kIHRyYW5zaWVudFxuICAgICAgICAgIC8vIGN1cnNvci9lbmNvZGluZyBjb3BpZXMuIE92ZXJzaXplZCByb3dzIHJldGFpbiB0aGUgdHdvLXJvdyBtZXJnZSBwYXRoLlxuICAgICAgICAgIGNvbnN0IGJ1ZmZlcmVkID0gbWF4Um93Qnl0ZXMgPD0gd29ya2luZ0J1ZGdldCAvIDY7XG4gICAgICAgICAgY29uc3QgYmF0Y2hTaXplID0gYnVmZmVyZWRcbiAgICAgICAgICAgID8gTWF0aC5taW4oNjQsIE1hdGguZmxvb3Iod29ya2luZ0J1ZGdldCAvIDYgLyBtYXhSb3dCeXRlcykpXG4gICAgICAgICAgICA6IDE7XG4gICAgICAgICAgY29uc3QgZGIgPSB0aGlzLmRiO1xuICAgICAgICAgIGFzeW5jIGZ1bmN0aW9uKiByb3dzKHJ1bjogKHR5cGVvZiBydW5zKVtudW1iZXJdKSB7XG4gICAgICAgICAgICBpZiAoYmF0Y2hTaXplID09PSAxKSB7XG4gICAgICAgICAgICAgIGZvciAobGV0IGluZGV4ID0gMDsgaW5kZXggPCBydW4uY291bnQ7IGluZGV4KyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCB2YWx1ZSA9IGF3YWl0IGRiLmdldDxTb3J0Um93PihcbiAgICAgICAgICAgICAgICAgICdzY3JhdGNoJyxcbiAgICAgICAgICAgICAgICAgIGAke3J1bi5pZH0vJHtTdHJpbmcoaW5kZXgpLnBhZFN0YXJ0KDgsICcwJyl9YCxcbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIGFzc2VydCh2YWx1ZSwgJ0NPUlJVUFRfU1RPUkFHRScsICdNaXNzaW5nIHNvcnQgcm93Jyk7XG4gICAgICAgICAgICAgICAgeWllbGQgdmFsdWU7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIGZvciBhd2FpdCAoY29uc3QgZW50cmllcyBvZiBkYi5zY2FuPFNvcnRSb3c+KFxuICAgICAgICAgICAgICAgICdzY3JhdGNoJyxcbiAgICAgICAgICAgICAgICBwcmVmaXhSYW5nZShydW4uaWQpLFxuICAgICAgICAgICAgICAgIGJhdGNoU2l6ZSxcbiAgICAgICAgICAgICAgKSlcbiAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IFssIHZhbHVlXSBvZiBlbnRyaWVzKSB5aWVsZCB2YWx1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgY29uc3QgbGVmdFJvd3MgPSByb3dzKGxlZnQpLFxuICAgICAgICAgICAgcmlnaHRSb3dzID0gcm93cyhyaWdodCk7XG4gICAgICAgICAgbGV0IHggPSBhd2FpdCBsZWZ0Um93cy5uZXh0KCksXG4gICAgICAgICAgICB5ID0gYXdhaXQgcmlnaHRSb3dzLm5leHQoKTtcbiAgICAgICAgICBsZXQgb3V0cHV0ID0gMCxcbiAgICAgICAgICAgIGJ5dGVzID0gMDtcbiAgICAgICAgICBsZXQgcGVuZGluZzogQXJyYXk8W0lEQlZhbGlkS2V5LCB1bmtub3duXT4gPSBbXTtcbiAgICAgICAgICBjb25zdCBmbHVzaE1lcmdlID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgaWYgKHBlbmRpbmcubGVuZ3RoKSBhd2FpdCB0aGlzLmRiLndyaXRlKCdzY3JhdGNoJywgcGVuZGluZyk7XG4gICAgICAgICAgICBwZW5kaW5nID0gW107XG4gICAgICAgICAgfTtcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgd2hpbGUgKCF4LmRvbmUgfHwgIXkuZG9uZSkge1xuICAgICAgICAgICAgICB0aGlzLmNoZWNrKCk7XG4gICAgICAgICAgICAgIGNvbnN0IHRha2VMZWZ0ID0gIXguZG9uZSAmJiAoeS5kb25lIHx8IGNvbXBhcmUoeC52YWx1ZSwgeS52YWx1ZSkgPD0gMCk7XG4gICAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gdGFrZUxlZnQgPyB4LnZhbHVlISA6IHkudmFsdWUhO1xuICAgICAgICAgICAgICBjb25zdCByZWNvcmQ6IFtJREJWYWxpZEtleSwgdW5rbm93bl0gPSBbXG4gICAgICAgICAgICAgICAgYCR7aWR9LyR7U3RyaW5nKG91dHB1dCsrKS5wYWRTdGFydCg4LCAnMCcpfWAsXG4gICAgICAgICAgICAgICAgdmFsdWUsXG4gICAgICAgICAgICAgIF07XG4gICAgICAgICAgICAgIGNvbnN0IHNpemUgPSBlbmNvZGVkQnl0ZXMocmVjb3JkKTtcbiAgICAgICAgICAgICAgc2NyYXRjaEJ5dGVzICs9IHNpemU7XG4gICAgICAgICAgICAgIGJ5dGVzICs9IHNpemU7XG4gICAgICAgICAgICAgIHRoaXMuc3RhZ2luZ0J5dGVzID0gc2NyYXRjaEJ5dGVzO1xuICAgICAgICAgICAgICBhc3NlcnQoXG4gICAgICAgICAgICAgICAgdGhpcy51c2VkQnl0ZXMgKyBzY3JhdGNoQnl0ZXMgPD0gbmV4dC5idWRnZXQsXG4gICAgICAgICAgICAgICAgJ1NUT1JBR0VfQlVER0VUJyxcbiAgICAgICAgICAgICAgICAnU29ydCBtZXJnZSBleGNlZWRzIHRoZSBzdG9yYWdlIGJ1ZGdldCcsXG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgIHBlbmRpbmcucHVzaChyZWNvcmQpO1xuICAgICAgICAgICAgICBpZiAocGVuZGluZy5sZW5ndGggPj0gYmF0Y2hTaXplKSBhd2FpdCBmbHVzaE1lcmdlKCk7XG4gICAgICAgICAgICAgIGlmICh0YWtlTGVmdCkgeCA9IGF3YWl0IGxlZnRSb3dzLm5leHQoKTtcbiAgICAgICAgICAgICAgZWxzZSB5ID0gYXdhaXQgcmlnaHRSb3dzLm5leHQoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGF3YWl0IGZsdXNoTWVyZ2UoKTtcbiAgICAgICAgICAgIGFzc2VydChvdXRwdXQgPT09IGxlZnQuY291bnQgKyByaWdodC5jb3VudCwgJ0NPUlJVUFRfU1RPUkFHRScsICdJbmNvbXBsZXRlIHNvcnQgcnVuJyk7XG4gICAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIGF3YWl0IGxlZnRSb3dzLnJldHVybih1bmRlZmluZWQpO1xuICAgICAgICAgICAgYXdhaXQgcmlnaHRSb3dzLnJldHVybih1bmRlZmluZWQpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBhd2FpdCB0aGlzLmRiLndyaXRlKCdzY3JhdGNoJywgW10sIFtwcmVmaXhSYW5nZShsZWZ0LmlkKSwgcHJlZml4UmFuZ2UocmlnaHQuaWQpXSk7XG4gICAgICAgICAgc2NyYXRjaEJ5dGVzIC09IGxlZnQuYnl0ZXMgKyByaWdodC5ieXRlcztcbiAgICAgICAgICB0aGlzLnN0YWdpbmdCeXRlcyA9IHNjcmF0Y2hCeXRlcztcbiAgICAgICAgICBtZXJnZWQucHVzaCh7IGlkLCBjb3VudDogb3V0cHV0LCBieXRlcywgbWF4Um93Qnl0ZXMgfSk7XG4gICAgICAgIH1cbiAgICAgICAgcnVucyA9IG1lcmdlZDtcbiAgICAgICAgcGFzcysrO1xuICAgICAgfVxuICAgICAgdGhpcy5wcm9ncmVzcyh7XG4gICAgICAgIHBoYXNlOiAnc29ydC1tZXJnZScsXG4gICAgICAgIGNvbXBsZXRlZDogdG90YWxSb3dzLFxuICAgICAgICB0b3RhbDogdG90YWxSb3dzLFxuICAgICAgICBlbGFwc2VkTXM6IHBlcmZvcm1hbmNlLm5vdygpIC0gc3RhZ2VTdGFydCxcbiAgICAgIH0pO1xuICAgICAgc3RhZ2VTdGFydCA9IHBlcmZvcm1hbmNlLm5vdygpO1xuICAgICAgbGV0IHBvc2l0aW9uID0gMDtcbiAgICAgIGNvbnN0IGdyb3VwZWQgPSBuZXcgTWFwPHN0cmluZywgUmVjb3JkPHN0cmluZywgQ2VsbFJlY29yZD4+KCk7XG4gICAgICBsZXQgZ3JvdXBlZEJ5dGVzID0gMCxcbiAgICAgICAgcm93QmFuZCA9IC0xO1xuICAgICAgY29uc3QgZmx1c2ggPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIGZvciAoY29uc3QgW2FkZHJlc3MsIGNlbGxzXSBvZiBncm91cGVkKSB7XG4gICAgICAgICAgdGhpcy5jaGVjaygpO1xuICAgICAgICAgIGF3YWl0IHRoaXMuc3RvcmVCbG9jayhhZGRyZXNzLCBjZWxscywgbmV4dCwgbWV0YWRhdGEpO1xuICAgICAgICB9XG4gICAgICAgIGdyb3VwZWQuY2xlYXIoKTtcbiAgICAgICAgZ3JvdXBlZEJ5dGVzID0gMDtcbiAgICAgIH07XG4gICAgICBmb3IgKGxldCByb3cgPSBwLnJhbmdlLnN0YXJ0Um93OyByb3cgPCBwLnJhbmdlLmVuZFJvdzsgcm93KyspIHtcbiAgICAgICAgdGhpcy5jaGVjaygpO1xuICAgICAgICBjb25zdCBlbnRyeSA9IChhd2FpdCB0aGlzLmRiLmdldDxTb3J0Um93PihcbiAgICAgICAgICAnc2NyYXRjaCcsXG4gICAgICAgICAgYCR7cnVuc1swXS5pZH0vJHtTdHJpbmcocG9zaXRpb24rKykucGFkU3RhcnQoOCwgJzAnKX1gLFxuICAgICAgICApKSE7XG4gICAgICAgIGNvbnN0IGVudHJ5Qnl0ZXMgPSBlbmNvZGVkQnl0ZXMoZW50cnkpICogNDtcbiAgICAgICAgYXNzZXJ0KFxuICAgICAgICAgIGVudHJ5Qnl0ZXMgPD0gd29ya2luZ0J1ZGdldCxcbiAgICAgICAgICAnTElNSVRfRVhDRUVERUQnLFxuICAgICAgICAgICdTb3J0IG91dHB1dCByb3cgZXhjZWVkcyB0aGUgb3BlcmF0aW9uIGJ1ZGdldCcsXG4gICAgICAgICk7XG4gICAgICAgIGNvbnN0IGJhbmQgPSBNYXRoLmZsb29yKHNoLnJvd09yZGVyW3Jvd10gLyA2NCk7XG4gICAgICAgIGlmIChyb3dCYW5kICE9PSBiYW5kIHx8IGdyb3VwZWRCeXRlcyArIGVudHJ5Qnl0ZXMgPiB3b3JraW5nQnVkZ2V0KSBhd2FpdCBmbHVzaCgpO1xuICAgICAgICByb3dCYW5kID0gYmFuZDtcbiAgICAgICAgY29uc3QgcGFnZUZvciA9IGFzeW5jIChhZGRyZXNzOiBzdHJpbmcsIGV4dHJhID0gMCkgPT4ge1xuICAgICAgICAgIGlmIChncm91cGVkLmhhcyhhZGRyZXNzKSAmJiBncm91cGVkQnl0ZXMgKyBlbnRyeUJ5dGVzICsgZXh0cmEgPiB3b3JraW5nQnVkZ2V0KVxuICAgICAgICAgICAgYXdhaXQgZmx1c2goKTtcbiAgICAgICAgICBpZiAoIWdyb3VwZWQuaGFzKGFkZHJlc3MpKSB7XG4gICAgICAgICAgICBjb25zdCBjZWxscyA9IChhd2FpdCB0aGlzLmJsb2NrKGFkZHJlc3MsIG5leHQpKS5jZWxscztcbiAgICAgICAgICAgIGNvbnN0IGJ5dGVzID0gZW5jb2RlZEJ5dGVzKGNlbGxzKSAqIDQ7XG4gICAgICAgICAgICBpZiAoZ3JvdXBlZEJ5dGVzICsgYnl0ZXMgKyBlbnRyeUJ5dGVzICsgZXh0cmEgPiB3b3JraW5nQnVkZ2V0KSBhd2FpdCBmbHVzaCgpO1xuICAgICAgICAgICAgYXNzZXJ0KFxuICAgICAgICAgICAgICBieXRlcyArIGVudHJ5Qnl0ZXMgKyBleHRyYSA8PSB3b3JraW5nQnVkZ2V0LFxuICAgICAgICAgICAgICAnTElNSVRfRVhDRUVERUQnLFxuICAgICAgICAgICAgICAnU29ydCBvdXRwdXQgcGFnZSBleGNlZWRzIHRoZSBvcGVyYXRpb24gYnVkZ2V0JyxcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICBncm91cGVkLnNldChhZGRyZXNzLCBzdHJ1Y3R1cmVkQ2xvbmUoY2VsbHMpKTtcbiAgICAgICAgICAgIGdyb3VwZWRCeXRlcyArPSBieXRlcztcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIGdyb3VwZWQuZ2V0KGFkZHJlc3MpITtcbiAgICAgICAgfTtcbiAgICAgICAgZm9yIChsZXQgYyA9IHAucmFuZ2Uuc3RhcnRDb2x1bW47IGMgPCBwLnJhbmdlLmVuZENvbHVtbjsgYysrKSB7XG4gICAgICAgICAgY29uc3QgYSA9IGJsb2NrQWRkcmVzcyhzaC5pZCwgc2gucm93T3JkZXJbcm93XSwgc2guY29sdW1uT3JkZXJbY10pO1xuICAgICAgICAgIGxldCBjZWxscyA9IGF3YWl0IHBhZ2VGb3IoYSk7XG4gICAgICAgICAgY29uc3QgayA9IGtleShzaC5yb3dPcmRlcltyb3ddLCBzaC5jb2x1bW5PcmRlcltjXSk7XG4gICAgICAgICAgY29uc3QgY2VsbCA9IGVudHJ5LmNlbGxzW2MgLSBwLnJhbmdlLnN0YXJ0Q29sdW1uXTtcbiAgICAgICAgICBpZiAoIWNlbGwpIHtcbiAgICAgICAgICAgIGlmIChjZWxsc1trXSkgZ3JvdXBlZEJ5dGVzIC09IGVuY29kZWRCeXRlcyhjZWxsc1trXSkgKiA0O1xuICAgICAgICAgICAgZGVsZXRlIGNlbGxzW2tdO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb25zdCBjb3BpZWQgPSBzdHJ1Y3R1cmVkQ2xvbmUoY2VsbCk7XG4gICAgICAgICAgICBjb3BpZWQucm93SWQgPSBzaC5yb3dPcmRlcltyb3ddO1xuICAgICAgICAgICAgY29waWVkLmNvbHVtbklkID0gc2guY29sdW1uT3JkZXJbY107XG4gICAgICAgICAgICBkZWxldGUgY29waWVkLmNhY2hlZDtcbiAgICAgICAgICAgIGlmIChjb3BpZWQuaW5wdXQudHlwZSA9PT0gJ2Zvcm11bGEnKVxuICAgICAgICAgICAgICBjb3BpZWQuaW5wdXQuZXhwcmVzc2lvbiA9IG9mZnNldENlbGxGb3JtdWxhKFxuICAgICAgICAgICAgICAgIGNvcGllZC5pbnB1dC5leHByZXNzaW9uLFxuICAgICAgICAgICAgICAgIHJvdyAtIGVudHJ5LnJvdyxcbiAgICAgICAgICAgICAgICAwLFxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgY29uc3QgZ3Jvd3RoID1cbiAgICAgICAgICAgICAgKGVuY29kZWRCeXRlcyhjb3BpZWQpIC1cbiAgICAgICAgICAgICAgICAoY2VsbHNba10gPyBlbmNvZGVkQnl0ZXMoY2VsbHNba10pIDogMCkgK1xuICAgICAgICAgICAgICAgIChjZWxsc1trXSA/IDAgOiBrLmxlbmd0aCArIDQpKSAqXG4gICAgICAgICAgICAgIDQ7XG4gICAgICAgICAgICBjZWxscyA9IGF3YWl0IHBhZ2VGb3IoYSwgTWF0aC5tYXgoMCwgZ3Jvd3RoKSk7XG4gICAgICAgICAgICBjZWxsc1trXSA9IGNvcGllZDtcbiAgICAgICAgICAgIGdyb3VwZWRCeXRlcyArPSBncm93dGg7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICBhd2FpdCBmbHVzaCgpO1xuICAgICAgdGhpcy5wcm9ncmVzcyh7XG4gICAgICAgIHBoYXNlOiAnc29ydC1vdXRwdXQnLFxuICAgICAgICBjb21wbGV0ZWQ6IHRvdGFsUm93cyxcbiAgICAgICAgdG90YWw6IHRvdGFsUm93cyxcbiAgICAgICAgZWxhcHNlZE1zOiBwZXJmb3JtYW5jZS5ub3coKSAtIHN0YWdlU3RhcnQsXG4gICAgICB9KTtcbiAgICAgIG91dHB1dENvbXBsZXRlID0gdHJ1ZTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgY2FsY3VsYXRvci5jbGVhcigpO1xuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgdGhpcy5kYi53cml0ZSgnc2NyYXRjaCcsIFtdLCBbcHJlZml4UmFuZ2UoYCR7dGhpcy5pZH0vc29ydGApXSk7XG4gICAgICAgIHRoaXMuc3RhZ2luZ0J5dGVzID0gMDtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICB0aGlzLnBvaXNvbmVkID0gdHJ1ZTtcbiAgICAgICAgaWYgKG91dHB1dENvbXBsZXRlKVxuICAgICAgICAgIHRocm93IG5ldyBPcGVuU2hlZXRFcnJvcignV09SS0VSX0ZBSUxFRCcsICdSZW9wZW4gdGhlIHdvcmtib29rIHRvIHJlY292ZXIgc29ydCBzdGFnaW5nJyk7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIGFzeW5jIGhpc3RvcnkocmVkbzogYm9vbGVhbikge1xuICAgIGFzc2VydCh0aGlzLndyaXRlciwgJ1JFQURfT05MWScsICdXb3JrYm9vayBpcyBvcGVuIGluIGFub3RoZXIgdGFiJyk7XG4gICAgdGhpcy5jYW5jZWxsZWQgPSBmYWxzZTtcbiAgICB0aGlzLmNoYW5nZWQuY2xlYXIoKTtcbiAgICBjb25zdCBuZXh0ID0ge1xuICAgICAgICAuLi50aGlzLmhlYWQsXG4gICAgICAgIGJsb2NrczogeyAuLi50aGlzLmhlYWQuYmxvY2tzIH0sXG4gICAgICAgIHBhc3Q6IFsuLi50aGlzLmhlYWQucGFzdF0sXG4gICAgICAgIGZ1dHVyZTogWy4uLnRoaXMuaGVhZC5mdXR1cmVdLFxuICAgICAgfSxcbiAgICAgIGZyb20gPSByZWRvID8gbmV4dC5mdXR1cmUgOiBuZXh0LnBhc3QsXG4gICAgICB0byA9IHJlZG8gPyBuZXh0LnBhc3QgOiBuZXh0LmZ1dHVyZTtcbiAgICBjb25zdCBpZCA9IGZyb20ucG9wKCk7XG4gICAgaWYgKCFpZCkgcmV0dXJuIHsgdmlldzogdGhpcy52aWV3KCksIGNvbW1pdDogdW5kZWZpbmVkIH07XG4gICAgY29uc3QgaCA9IHRoaXMuaGlzdG9yaWVzLmdldChpZCkgPz8gKGF3YWl0IHRoaXMucmVhZEhpc3RvcnkoaWQpKTtcbiAgICBhc3NlcnQoaCwgJ0NPUlJVUFRfU1RPUkFHRScsICdNaXNzaW5nIGhpc3RvcnknKTtcbiAgICBmb3IgKGNvbnN0IFthLCBiZWZvcmUsIGFmdGVyXSBvZiBoLmNoYW5nZXMpIHtcbiAgICAgIHRoaXMuY2hhbmdlZC5hZGQoYSk7XG4gICAgICBjb25zdCBwID0gcmVkbyA/IGFmdGVyIDogYmVmb3JlO1xuICAgICAgaWYgKHApIG5leHQuYmxvY2tzW2FdID0gcDtcbiAgICAgIGVsc2UgZGVsZXRlIG5leHQuYmxvY2tzW2FdO1xuICAgIH1cbiAgICBuZXh0Lm1ldGEgPSByZWRvID8gaC5hZnRlciA6IGguYmVmb3JlO1xuICAgIG5leHQucmV2aXNpb24rKztcbiAgICB0by5wdXNoKGlkKTtcbiAgICBuZXh0Lmhpc3RvcnlCeXRlcyArPSByZWRvID8gaC5ieXRlcyA6IC1oLmJ5dGVzO1xuICAgIGNvbnN0IG1ldGFkYXRhID0ge1xuICAgICAgLi4uKG5leHQubWV0YSA9PT0gdGhpcy5oZWFkLm1ldGEgPyB0aGlzLm1ldGFkYXRhIDogYXdhaXQgdGhpcy5yZWFkTWV0YWRhdGEobmV4dC5tZXRhKSksXG4gICAgfTtcbiAgICBhd2FpdCB0aGlzLmZpbHRlcnMobmV4dCwgbWV0YWRhdGEpO1xuICAgIGF3YWl0IHRoaXMucHVibGlzaChuZXh0LCBtZXRhZGF0YSwgbmV4dC5tZXRhID09PSB0aGlzLmhlYWQubWV0YSA/IGgucmFuZ2VzIDogdW5kZWZpbmVkKTtcbiAgICByZXR1cm4ge1xuICAgICAgdmlldzogdGhpcy52aWV3KCksXG4gICAgICBjb21taXQ6IHtcbiAgICAgICAgY29tbWFuZElkOiB1aWQoJ2NtZCcpLFxuICAgICAgICBwcmV2aW91c1JldmlzaW9uOiBuZXh0LnJldmlzaW9uIC0gMSxcbiAgICAgICAgcmV2aXNpb246IG5leHQucmV2aXNpb24sXG4gICAgICAgIHNvdXJjZTogcmVkbyA/ICdyZWRvJyA6ICd1bmRvJyxcbiAgICAgICAgY29tbWFuZHM6IFtdLFxuICAgICAgICBjaGFuZ2VkUmFuZ2VzOiBoLnJhbmdlcyxcbiAgICAgIH0gYXMgQ29tbWl0LFxuICAgIH07XG4gIH1cbiAgYXN5bmMgc2VhcmNoKFxuICAgIHNoZWV0SWQ6IHN0cmluZyxcbiAgICBxdWVyeTogc3RyaW5nLFxuICAgIGFmdGVyID0gLTEsXG4gICAgY29vcGVyYXRpdmUgPSBmYWxzZSxcbiAgICBkaXJlY3Rpb246ICduZXh0JyB8ICdwcmV2aW91cycgPSAnbmV4dCcsXG4gICkge1xuICAgIHRoaXMuY2hlY2soKTtcbiAgICB2YWxpZGF0ZVNlYXJjaEFyZ3VtZW50cyhzaGVldElkLCBxdWVyeSwgYWZ0ZXIsIGRpcmVjdGlvbik7XG4gICAgYXNzZXJ0KFxuICAgICAgdHlwZW9mIGNvb3BlcmF0aXZlID09PSAnYm9vbGVhbicsXG4gICAgICAnSU5WQUxJRF9BUkdVTUVOVCcsXG4gICAgICAnSW52YWxpZCBzZWFyY2ggY2FuY2VsbGF0aW9uIG1vZGUnLFxuICAgICk7XG4gICAgY29uc3Qgc2ggPSB0aGlzLm1ldGFkYXRhLnNuYXBzaG90LnNoZWV0cy5maW5kKChzKSA9PiBzLmlkID09PSBzaGVldElkKTtcbiAgICBhc3NlcnQoc2gsICdJTlZBTElEX0FSR1VNRU5UJywgJ1Vua25vd24gc2VhcmNoIHNoZWV0Jyk7XG4gICAgY29uc3QgcSA9IHF1ZXJ5LnRvTG93ZXJDYXNlKCk7XG4gICAgY29uc3QgcmV2ZXJzZSA9IGRpcmVjdGlvbiA9PT0gJ3ByZXZpb3VzJztcbiAgICBjb25zdCBwcmVjZWRlcyA9IChhOiBudW1iZXIsIGI6IG51bWJlcikgPT4gKHJldmVyc2UgPyBhID4gYiA6IGEgPCBiKTtcbiAgICBjb25zdCB3aWR0aCA9IHNoLmNvbHVtbk9yZGVyLmxlbmd0aDtcbiAgICBjb25zdCB0b1Jlc3VsdCA9IChwb3NpdGlvbjogbnVtYmVyIHwgdW5kZWZpbmVkLCBjb3VudDogbnVtYmVyKSA9PiAoe1xuICAgICAgbWF0Y2g6XG4gICAgICAgIHBvc2l0aW9uID09PSB1bmRlZmluZWRcbiAgICAgICAgICA/IHVuZGVmaW5lZFxuICAgICAgICAgIDogeyByb3c6IE1hdGguZmxvb3IocG9zaXRpb24gLyB3aWR0aCksIGNvbHVtbjogcG9zaXRpb24gJSB3aWR0aCB9LFxuICAgICAgY291bnQsXG4gICAgfSk7XG4gICAgY29uc3QgaGVhZCA9IHRoaXMuaGVhZDtcbiAgICBjb25zdCBjYWNoZWQgPSB0aGlzLnNlYXJjaFJlc3VsdHMuZ2V0KGhlYWQpO1xuICAgIGlmIChjYWNoZWQ/LnNoZWV0SWQgPT09IHNoZWV0SWQgJiYgY2FjaGVkLnF1ZXJ5ID09PSBxKSB7XG4gICAgICBjb25zdCB7IHBvc2l0aW9ucyB9ID0gY2FjaGVkO1xuICAgICAgbGV0IGxvdyA9IDAsXG4gICAgICAgIGhpZ2ggPSBwb3NpdGlvbnMubGVuZ3RoO1xuICAgICAgd2hpbGUgKGxvdyA8IGhpZ2gpIHtcbiAgICAgICAgY29uc3QgbWlkID0gKGxvdyArIGhpZ2gpID4+PiAxO1xuICAgICAgICBpZiAocmV2ZXJzZSA/IHBvc2l0aW9uc1ttaWRdIDwgYWZ0ZXIgOiBwb3NpdGlvbnNbbWlkXSA8PSBhZnRlcikgbG93ID0gbWlkICsgMTtcbiAgICAgICAgZWxzZSBoaWdoID0gbWlkO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHRvUmVzdWx0KFxuICAgICAgICByZXZlcnNlID8gKHBvc2l0aW9uc1tsb3cgLSAxXSA/PyBwb3NpdGlvbnMuYXQoLTEpKSA6IChwb3NpdGlvbnNbbG93XSA/PyBwb3NpdGlvbnNbMF0pLFxuICAgICAgICBwb3NpdGlvbnMubGVuZ3RoLFxuICAgICAgKTtcbiAgICB9XG4gICAgbGV0IHBvc2l0aW9uczogbnVtYmVyW10gfCB1bmRlZmluZWQgPSBxLmxlbmd0aCA8PSAxMDI0ID8gW10gOiB1bmRlZmluZWQ7XG4gICAgbGV0IHdyYXA6IG51bWJlciB8IHVuZGVmaW5lZCxcbiAgICAgIG5leHQ6IG51bWJlciB8IHVuZGVmaW5lZCxcbiAgICAgIGNvdW50ID0gMDtcbiAgICBjb25zdCByb3dzID0gdGhpcy5heGlzKHNoLnJvd09yZGVyKSxcbiAgICAgIGNvbHMgPSB0aGlzLmF4aXMoc2guY29sdW1uT3JkZXIpO1xuICAgIGxldCB2aXNpdGVkID0gMCxcbiAgICAgIHRleHRVbml0cyA9IDA7XG4gICAgZm9yIChjb25zdCBbYV0gb2YgT2JqZWN0LmVudHJpZXModGhpcy5oZWFkLmJsb2NrcykpXG4gICAgICBpZiAoYS5zdGFydHNXaXRoKGAke3NoZWV0SWR9L2ApKVxuICAgICAgICBmb3IgKGNvbnN0IGNlbGwgb2YgKGF3YWl0IHRoaXMuYmxvY2soYSkpLnJlY29yZHMoKSkge1xuICAgICAgICAgIGlmIChjb29wZXJhdGl2ZSAmJiArK3Zpc2l0ZWQgJSAxNjM4NCA9PT0gMCkge1xuICAgICAgICAgICAgYXdhaXQgbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUpID0+IHNldFRpbWVvdXQocmVzb2x2ZSwgMCkpO1xuICAgICAgICAgICAgdGV4dFVuaXRzID0gMDtcbiAgICAgICAgICB9XG4gICAgICAgICAgdGhpcy5jaGVjaygpO1xuICAgICAgICAgIGNvbnN0IHJvdyA9IHJvd3MuZ2V0KGNlbGwucm93SWQpISxcbiAgICAgICAgICAgIGNvbHVtbiA9IGNvbHMuZ2V0KGNlbGwuY29sdW1uSWQpITtcbiAgICAgICAgICBjb25zdCB2YWx1ZSA9XG4gICAgICAgICAgICBjZWxsLmlucHV0LnR5cGUgPT09ICdmb3JtdWxhJ1xuICAgICAgICAgICAgICA/IGF3YWl0IHRoaXMuY2FsY3VsYXRvci52YWx1ZShzaGVldElkLCByb3csIGNvbHVtbilcbiAgICAgICAgICAgICAgOiBzY2FsYXJWYWx1ZShjZWxsLmlucHV0KTtcbiAgICAgICAgICBhc3NlcnQoXG4gICAgICAgICAgICAhKHZhbHVlICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgdmFsdWUuZXJyb3IgPT09ICcjTElNSVQhJyksXG4gICAgICAgICAgICAnTElNSVRfRVhDRUVERUQnLFxuICAgICAgICAgICAgJ1NlYXJjaCBjYWxjdWxhdGlvbiBleGNlZWRlZCBpdHMgd29yayBidWRnZXQnLFxuICAgICAgICAgICk7XG4gICAgICAgICAgY29uc3QgZGlzcGxheSA9XG4gICAgICAgICAgICB2YWx1ZSAmJlxuICAgICAgICAgICAgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJlxuICAgICAgICAgICAgY2VsbC5jYWNoZWQgJiZcbiAgICAgICAgICAgIHRoaXMuaGVhZC5yZXZpc2lvbiA9PT0gdGhpcy5tZXRhZGF0YS5pbXBvcnRSZXZpc2lvblxuICAgICAgICAgICAgICA/IGZvcm1hdFZhbHVlKFxuICAgICAgICAgICAgICAgICAgc2NhbGFyVmFsdWUoY2VsbC5jYWNoZWQpLFxuICAgICAgICAgICAgICAgICAgY2VsbC5udW1iZXJGb3JtYXQsXG4gICAgICAgICAgICAgICAgICB0aGlzLm1ldGFkYXRhLnNuYXBzaG90LmRhdGVTeXN0ZW0sXG4gICAgICAgICAgICAgICAgKSArICcg4oCgJ1xuICAgICAgICAgICAgICA6IGZvcm1hdFZhbHVlKFxuICAgICAgICAgICAgICAgICAgdmFsdWUsXG4gICAgICAgICAgICAgICAgICBjZWxsLm51bWJlckZvcm1hdCA/P1xuICAgICAgICAgICAgICAgICAgICB0aGlzLm1ldGFkYXRhLnNuYXBzaG90LnN0eWxlc1tjZWxsLnN0eWxlSWQgPz8gJyddPy5udW1iZXJGb3JtYXQsXG4gICAgICAgICAgICAgICAgICB0aGlzLm1ldGFkYXRhLnNuYXBzaG90LmRhdGVTeXN0ZW0sXG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAvLyBMb25nIHN0cmluZ3MgY2FuIG1vbm9wb2xpemUgYSBXb3JrZXIgZXZlbiB3aGVuIGZld2VyIHRoYW4gMTYsMzg0XG4gICAgICAgICAgLy8gcmVjb3JkcyBhcmUgc2Nhbm5lZC4gWWllbGQgYmVmb3JlIG5vcm1hbGl6aW5nIHRoZSBuZXh0IGxhcmdlIGJhdGNoLlxuICAgICAgICAgIGlmIChjb29wZXJhdGl2ZSkge1xuICAgICAgICAgICAgdGV4dFVuaXRzICs9IGRpc3BsYXkubGVuZ3RoO1xuICAgICAgICAgICAgaWYgKHRleHRVbml0cyA+PSBTRUFSQ0hfWUlFTERfVEVYVF9VTklUUykge1xuICAgICAgICAgICAgICB0ZXh0VW5pdHMgPSAwO1xuICAgICAgICAgICAgICBhd2FpdCBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSkgPT4gc2V0VGltZW91dChyZXNvbHZlLCAwKSk7XG4gICAgICAgICAgICAgIHRoaXMuY2hlY2soKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKCFkaXNwbGF5LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocSkpIGNvbnRpbnVlO1xuICAgICAgICAgIGNvdW50Kys7XG4gICAgICAgICAgY29uc3QgcG9zaXRpb24gPSByb3cgKiB3aWR0aCArIGNvbHVtbjtcbiAgICAgICAgICBpZiAocG9zaXRpb25zKSB7XG4gICAgICAgICAgICBpZiAocG9zaXRpb25zLmxlbmd0aCA9PT0gMTYzODQpIHBvc2l0aW9ucyA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIGVsc2UgcG9zaXRpb25zLnB1c2gocG9zaXRpb24pO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAod3JhcCA9PT0gdW5kZWZpbmVkIHx8IHByZWNlZGVzKHBvc2l0aW9uLCB3cmFwKSkgd3JhcCA9IHBvc2l0aW9uO1xuICAgICAgICAgIGlmIChwcmVjZWRlcyhhZnRlciwgcG9zaXRpb24pICYmIChuZXh0ID09PSB1bmRlZmluZWQgfHwgcHJlY2VkZXMocG9zaXRpb24sIG5leHQpKSlcbiAgICAgICAgICAgIG5leHQgPSBwb3NpdGlvbjtcbiAgICAgICAgfVxuICAgIHRoaXMuY2hlY2soKTtcbiAgICAvLyBSb3ctbWFqb3IgcG9zaXRpb25zIGZpdCB1aW50MzIgdW5kZXIgdGhlIHdvcmtib29rIGRpbWVuc2lvbiBsaW1pdHMuXG4gICAgaWYgKHBvc2l0aW9ucyAmJiB0aGlzLmhlYWQgPT09IGhlYWQpXG4gICAgICB0aGlzLnNlYXJjaFJlc3VsdHMuc2V0KGhlYWQsIHtcbiAgICAgICAgc2hlZXRJZCxcbiAgICAgICAgcXVlcnk6IHEsXG4gICAgICAgIHBvc2l0aW9uczogVWludDMyQXJyYXkuZnJvbShwb3NpdGlvbnMpLnNvcnQoKSxcbiAgICAgIH0pO1xuICAgIHJldHVybiB0b1Jlc3VsdChuZXh0ID8/IHdyYXAsIGNvdW50KTtcbiAgfVxuICBhc3luYyBjbGVhcigpIHtcbiAgICBhc3NlcnQodGhpcy53cml0ZXIsICdSRUFEX09OTFknLCAnV29ya2Jvb2sgaXMgb3BlbiBpbiBhbm90aGVyIHRhYicpO1xuICAgIGF3YWl0IHRoaXMuZGIuZGVsZXRlV29ya2Jvb2sodGhpcy5pZCwgcHJlZml4UmFuZ2UodGhpcy5pZCkpO1xuICAgIHRoaXMuY2FjaGUuY2xlYXIoKTtcbiAgfVxuICBjbG9zZSgpIHtcbiAgICB0aGlzLndyaXRlciA9IGZhbHNlO1xuICAgIHRoaXMucmVsZWFzZT8uKCk7XG4gICAgdGhpcy5yZWxlYXNlID0gdW5kZWZpbmVkO1xuICAgIHRoaXMuZGIuY2xvc2UoKTtcbiAgICB0aGlzLmNhY2hlLmNsZWFyKCk7XG4gICAgdGhpcy5zZWVuLmNsZWFyKCk7XG4gIH1cbn1cbi8vIFN0YXRlbGVzcyBmaXhlZC1zZWVkIGdlbmVyYXRpb24gYWxsb3dzIGV4YWN0IHZhbGlkYXRpb24gd2l0aG91dCByZXRhaW5pbmcgdGhlIGZpeHR1cmUuXG5leHBvcnQgZnVuY3Rpb24gZml4dHVyZVZhbHVlKG46IG51bWJlcik6IG51bWJlciB8IHN0cmluZyB8IGJvb2xlYW4ge1xuICBsZXQgeCA9IChNYXRoLmltdWwobiArIDEsIDE2NjQ1MjUpICsgMTAxMzkwNDIyMykgPj4+IDA7XG4gIGlmIChuICUgMTAgPCA2KSByZXR1cm4gbiA9PT0gMCA/IDAgOiB4IC8gMTAwMDtcbiAgaWYgKG4gJSAxMCA9PT0gOSkgcmV0dXJuICgobiAvIDEwKSB8IDApICUgMiA9PT0gMTtcbiAgbGV0IHRleHQgPSAnJztcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCAzMjsgaSsrKSB7XG4gICAgeCA9IChNYXRoLmltdWwoeCwgMTY2NDUyNSkgKyAxMDEzOTA0MjIzKSA+Pj4gMDtcbiAgICB0ZXh0ICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoMzMgKyAoeCAlIDk0KSk7XG4gIH1cbiAgcmV0dXJuIHRleHQ7XG59XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMscUJBQXFCO0FBQzlCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsK0JBQStCO0FBQ3hDLFNBQVMsbUNBQW1DO0FBQzVDLFNBQVMscUJBQXFCO0FBQzlCLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMscUJBQXFCLFVBQVUseUJBQXlDO0FBQ2pGLFNBQVMsaUJBQWlCLGFBQWEsZUFBZTtBQUN0RCxTQUFTLGlCQUFpQjtBQUMxQixTQUFTLGVBQWU7QUFDeEIsU0FBUyxVQUFVLGtCQUFrQjtBQUNyQyxTQUFTLG9CQUE4QjtBQUN2QyxTQUFTLGFBQWEsbUJBQWtEO0FBQ3hFO0FBQUEsRUFDRTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLE9BRUs7QUFDUCxTQUFTLE9BQU8sVUFBVSxZQUFZLGtCQUFrQjtBQUN4RCxTQUFTLGdDQUFnQztBQUN6QyxTQUFTLHlCQUEwQztBQUNuRCxTQUFTLG1DQUFtQztBQUM1QyxTQUFTLDZCQUE2QjtBQUN0QyxTQUFTLDRCQUE0QjtBQUVyQztBQUFBLEVBQ0U7QUFBQSxFQUNBO0FBQUEsT0FFSztBQUNQLFNBQVMsaUJBQWlCO0FBQzFCLFNBQVMsd0JBQXdCO0FBQ2pDLFNBQVMseUJBQXlCO0FBQ2xDLFNBQVMsZUFBZSx1QkFBdUI7QUFDL0M7QUFBQSxFQUNFO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxPQUVLO0FBQ1AsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxhQUFhLG1CQUFtQix3QkFBd0I7QUFDakU7QUFBQSxFQUNFO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUVBO0FBQUEsRUFDQTtBQUFBLE9BQ0s7QUFDUDtBQUFBLEVBQ0U7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLE9BV0s7QUFDUCxTQUFTLFVBQVUsT0FBaUIsT0FBZSxLQUFhLE1BQWM7QUFDNUUsUUFBTSxTQUFTLG9CQUFJLElBQTZDO0FBQ2hFLFdBQVMsUUFBUSxPQUFPLFFBQVEsS0FBSyxTQUFTO0FBQzVDLFVBQU0sS0FBSyxNQUFNLEtBQUssR0FDcEIsUUFBUSxLQUFLLE1BQU0sS0FBSyxJQUFJO0FBQzlCLFFBQUksVUFBVSxPQUFPLElBQUksS0FBSztBQUM5QixRQUFJLENBQUMsUUFBUyxRQUFPLElBQUksT0FBUSxVQUFVLENBQUMsQ0FBRTtBQUM5QyxZQUFRLEtBQUssRUFBRSxPQUFPLEdBQUcsQ0FBQztBQUFBLEVBQzVCO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUyxjQUFjLFNBQTJCO0FBQ2hELFNBQ0UsUUFBUSxTQUFTLHVCQUNmLFFBQVEsU0FBUyxzQkFBc0IsUUFBUSxTQUFTLDJCQUN2RCxRQUFRLFFBQTZDLE1BQU07QUFBQSxJQUMxRCxDQUFDLFNBQVMsS0FBSyxVQUFVO0FBQUEsRUFDM0I7QUFFTjtBQUdBLE1BQU0sK0JBQStCLE9BQU87QUFDNUMsTUFBTSwwQkFBMEIsT0FBTztBQTZCdkMsTUFBTSxpQkFBaUIsQ0FBQyxjQUF3QztBQUFBLEVBQzlELEdBQUc7QUFBQSxFQUNILFVBQVUsbUJBQW1CLFNBQVMsUUFBUTtBQUFBLEVBQzlDLFVBQVUsT0FBTyxLQUFLLFNBQVMsU0FBUyxNQUFNO0FBQ2hEO0FBK0JPLGFBQU0sZUFBZSxDQUFDLE9BQWUsS0FBYSxXQUN2RCxHQUFHLEtBQUssSUFBSSxLQUFLLE1BQU0sTUFBTSxVQUFVLENBQUMsSUFBSSxLQUFLLE1BQU0sU0FBUyxhQUFhLENBQUM7QUFDaEYsTUFBTSxjQUFjLENBQUMsT0FBZSxZQUFZLE1BQU0sR0FBRyxFQUFFLEtBQUssR0FBRyxFQUFFLElBQUk7QUFDbEUsYUFBTSxPQUFPO0FBQUEsRUF1Q2xCLFlBQ1UsSUFDQyxJQUNULGFBQWEsS0FBSyxPQUFPLE1BQ2pCLFdBQWtDLE1BQU07QUFBQSxFQUFDLEdBQ2pEO0FBSlE7QUFDQztBQUVEO0FBRVIsVUFBTSxhQUFhLEtBQUssSUFBSSxJQUFJLE9BQU8sTUFBTSxLQUFLLE1BQU0sYUFBYSxFQUFFLENBQUM7QUFDeEUsU0FBSyxPQUFPLElBQUksVUFBVSxVQUFVO0FBQ3BDLFVBQU0sbUJBQW1CLEtBQUssSUFBSSxJQUFJLE9BQU8sTUFBTSxLQUFLLE1BQU0sYUFBYSxDQUFDLENBQUM7QUFDN0UsU0FBSyxRQUFRLElBQUksVUFBVSxLQUFLLElBQUksR0FBRyxhQUFhLG1CQUFtQixVQUFVLENBQUM7QUFDbEYsU0FBSyxhQUFhLElBQUk7QUFBQSxNQUNwQixDQUFDLEdBQUcsR0FBRyxNQUFNLEtBQUssS0FBSyxHQUFHLEdBQUcsQ0FBQztBQUFBLE1BQzlCLENBQUMsU0FDQyxLQUFLLFNBQVMsU0FBUyxPQUFPLEtBQUssQ0FBQyxNQUFNLEVBQUUsS0FBSyxZQUFZLE1BQU0sS0FBSyxZQUFZLENBQUMsR0FBRztBQUFBLE1BQzFGO0FBQUEsTUFDQSxPQUFPLE9BQU8sS0FBSyxXQUFXO0FBQzVCLGNBQU0sS0FBSyxLQUFLLFNBQVMsU0FBUyxPQUFPLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxLQUFLO0FBQ25FLGdCQUNFLE1BQU0sS0FBSztBQUFBLFVBQ1Q7QUFBQSxZQUNFO0FBQUEsWUFDQSxLQUFLLFNBQVMsU0FBUyxPQUFPLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxLQUFLLEVBQUcsU0FBUyxHQUFHO0FBQUEsWUFDdkUsS0FBSyxTQUFTLFNBQVMsT0FBTyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sS0FBSyxFQUFHLFlBQVksTUFBTTtBQUFBLFVBQy9FO0FBQUEsUUFDRixHQUNBLGFBQWEsSUFBSSxHQUFHLFNBQVMsR0FBRyxHQUFHLEdBQUcsWUFBWSxNQUFNLENBQUMsQ0FBQztBQUFBLE1BQzlEO0FBQUEsTUFDQSxNQUFNLEtBQUssU0FBUyxTQUFTO0FBQUEsSUFDL0I7QUFBQSxFQUNGO0FBQUEsRUE1QlU7QUFBQSxFQUNDO0FBQUEsRUFFRDtBQUFBLEVBMUNGO0FBQUEsRUFDQTtBQUFBLEVBQ0EsWUFBWTtBQUFBLEVBQ1osY0FBd0IsQ0FBQztBQUFBLEVBQ3pCLFlBQVksb0JBQUksSUFBWTtBQUFBLEVBQzVCLGVBQWU7QUFBQSxFQUNmLE9BQU8sb0JBQUksSUFBWTtBQUFBLEVBQ3ZCLE9BQU8sb0JBQUksUUFBNkI7QUFBQSxFQUN4QyxLQUFLLEtBQWU7QUFDMUIsUUFBSSxRQUFRLEtBQUssS0FBSyxJQUFJLEdBQUc7QUFDN0IsUUFBSSxDQUFDLE9BQU87QUFDVixjQUFRLElBQUksVUFBVSxHQUFHO0FBQ3pCLFdBQUssS0FBSyxJQUFJLEtBQUssS0FBSztBQUFBLElBQzFCO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNRLFVBQVUsb0JBQUksUUFBc0Q7QUFBQSxFQUNwRTtBQUFBLEVBQ0EsZ0JBQWdCLG9CQUFJLFFBRzFCO0FBQUEsRUFDTSxtQkFBbUIsb0JBQUksSUFBWTtBQUFBLEVBQ25DLG1CQUFtQixvQkFBSSxJQUFxQztBQUFBLEVBQzVEO0FBQUEsRUFDQSxVQUFVLG9CQUFJLElBQVk7QUFBQSxFQUMxQixhQUFhLG9CQUFJLElBQW9CO0FBQUEsRUFDckMsWUFBWSxvQkFBSSxJQUFxQjtBQUFBLEVBQ3JDLE9BQTZCLENBQUM7QUFBQSxFQUM5QixRQUFRLG9CQUFJLElBQW9CO0FBQUEsRUFDaEM7QUFBQSxFQUNBLFlBQVk7QUFBQSxFQUNaO0FBQUEsRUFDQSxXQUFXO0FBQUEsRUFDWCxTQUFTO0FBQUEsRUFDVDtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUErQlIsSUFBSSxXQUFXO0FBQ2IsV0FBTyxLQUFLO0FBQUEsRUFDZDtBQUFBLEVBQ0EsTUFBTSxPQUFPO0FBQ1gsUUFBSTtBQUNGLFVBQUksT0FBTyxjQUFjLGVBQWUsVUFBVSxPQUFPLFNBQVM7QUFDaEUsY0FBTSxJQUFJLFFBQWMsQ0FBQyxTQUFTLFdBQVc7QUFDM0MsZUFBSyxVQUFVLE1BQ1o7QUFBQSxZQUNDLGFBQWEsS0FBSyxHQUFHLEdBQUcsSUFBSSxJQUFJLEtBQUssRUFBRTtBQUFBLFlBQ3ZDLEVBQUUsYUFBYSxLQUFLO0FBQUEsWUFDcEIsT0FBTyxTQUFTO0FBQ2QsbUJBQUssU0FBUyxDQUFDLENBQUM7QUFDaEIsc0JBQVE7QUFDUixrQkFBSTtBQUNGLHNCQUFNLElBQUksUUFBYyxDQUFDLFlBQVk7QUFDbkMsdUJBQUssVUFBVTtBQUFBLGdCQUNqQixDQUFDO0FBQUEsWUFDTDtBQUFBLFVBQ0YsRUFDQyxNQUFNLE1BQU07QUFBQSxRQUNqQixDQUFDO0FBQUEsTUFDSCxXQUFXLE9BQU8sV0FBVyxlQUFlLE9BQU8sU0FBUyxZQUFhLE1BQUssU0FBUztBQUFBO0FBRXJGLGNBQU0sSUFBSTtBQUFBLFVBQ1I7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUFBLElBQ0osU0FBUyxPQUFPO0FBQ2QsVUFBSyxPQUE4QixTQUFTO0FBQzFDLGNBQU0sSUFBSTtBQUFBLFVBQ1I7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUNGLFlBQU07QUFBQSxJQUNSO0FBQUEsRUFDRjtBQUFBLEVBQ0EsTUFBTSxzQkFBc0I7QUFDMUIsUUFBSSxLQUFLLE9BQVEsUUFBTyxFQUFFLFFBQVEsTUFBTSxNQUFNLEtBQUssS0FBSyxFQUFFO0FBQzFELFVBQU0sS0FBSyxLQUFLO0FBQ2hCLFFBQUksQ0FBQyxLQUFLLE9BQVEsUUFBTyxFQUFFLFFBQVEsTUFBTTtBQUN6QyxRQUFJO0FBQ0YsWUFBTSxLQUFLLE9BQU87QUFDbEIsWUFBTSxLQUFLLFFBQVE7QUFDbkIsYUFBTyxFQUFFLFFBQVEsTUFBTSxNQUFNLEtBQUssS0FBSyxFQUFFO0FBQUEsSUFDM0MsU0FBUyxPQUFPO0FBQ2QsV0FBSyxVQUFVO0FBQ2YsV0FBSyxVQUFVO0FBQ2YsV0FBSyxTQUFTO0FBQ2QsWUFBTTtBQUFBLElBQ1I7QUFBQSxFQUNGO0FBQUEsRUFDUSxRQUFRO0FBQ2QsV0FBTyxDQUFDLEtBQUssV0FBVyxXQUFXLHFCQUFxQjtBQUFBLEVBQzFEO0FBQUEsRUFDQSxRQUFRO0FBQ04sV0FBTyxDQUFDLEtBQUssVUFBVSxpQkFBaUIsK0NBQStDO0FBQ3ZGLFNBQUssWUFBWTtBQUFBLEVBQ25CO0FBQUEsRUFDQSxTQUFTO0FBQ1AsU0FBSyxZQUFZO0FBQ2pCLFNBQUssWUFBWSxNQUFNLElBQUksZUFBZSxXQUFXLHFCQUFxQixDQUFDO0FBQUEsRUFDN0U7QUFBQSxFQUNBLE1BQU0sS0FDSixPQUNBLFNBQVMsTUFBTSxPQUFPLE1BQ3RCLGtCQUFrQixNQUNsQjtBQUNBO0FBQUEsTUFDRSxPQUFPLGNBQWMsTUFBTSxLQUFLLFNBQVM7QUFBQSxNQUN6QztBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsVUFBTSxXQUNKLFVBQ0MsZ0JBQWdCLFFBQ2IsUUFDQSxtQkFBbUI7QUFBQSxNQUNqQixHQUFHO0FBQUEsTUFDSCxRQUFRLE1BQU0sT0FBTyxJQUFJLENBQUMsT0FBTyxFQUFFLEdBQUcsR0FBRyxRQUFRLENBQUMsRUFBRSxFQUFFO0FBQUEsSUFDeEQsQ0FBQztBQUNQLFVBQU0sS0FBSyxLQUFLO0FBQ2hCLFFBQUksQ0FBQyxLQUFLLFFBQVE7QUFDaEIsWUFBTSxLQUFLLGFBQWEsSUFBSTtBQUM1QixhQUFPLEtBQUssS0FBSztBQUFBLElBQ25CO0FBQ0EsVUFBTSxhQUFhLE1BQU0sS0FBSyxHQUFHLElBQVUsU0FBUyxLQUFLLEVBQUU7QUFDM0QsVUFBTSxXQUFXLGFBQWEsTUFBTSxLQUFLLFlBQVksVUFBVSxJQUFJO0FBQ25FLFFBQUksVUFBVTtBQUNaLFdBQUssT0FBTztBQUNaLFdBQUssV0FBVyxNQUFNLEtBQUssYUFBYSxLQUFLLEtBQUssSUFBSTtBQUN0RCxhQUFPLEtBQUssVUFBVSxtQkFBbUIsOEJBQThCO0FBQ3ZFLFdBQUsscUJBQXFCO0FBRTFCLFlBQU0sS0FBSyxRQUFRLEtBQUssTUFBTSxLQUFLLFFBQVE7QUFDM0MsWUFBTSxLQUFLLFFBQVE7QUFBQSxJQUNyQixPQUFPO0FBQ0wsYUFBTyxZQUFZLEtBQUssUUFBUSxvQkFBb0Isc0NBQXNDO0FBRTFGLFVBQUksaUJBQWlCO0FBQ25CLGNBQU0sUUFBUSxZQUFZLEtBQUssRUFBRTtBQUNqQyxjQUFNLENBQUMsU0FBUyxPQUFPLE9BQU8sSUFBSSxNQUFNLFFBQVEsSUFBSTtBQUFBLFVBQ2xELEtBQUssR0FBRyxPQUFPLFdBQVcsS0FBSztBQUFBLFVBQy9CLEtBQUssR0FBRyxPQUFPLFNBQVMsS0FBSztBQUFBLFVBQzdCLEtBQUssR0FBRyxPQUFPLFdBQVcsS0FBSztBQUFBLFFBQ2pDLENBQUM7QUFDRDtBQUFBLFVBQ0UsQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDO0FBQUEsVUFDdkI7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxZQUFNLEtBQUssR0FBRyxNQUFNLFdBQVcsQ0FBQyxHQUFHLENBQUMsWUFBWSxLQUFLLEVBQUUsQ0FBQyxDQUFDO0FBQ3pELFlBQU0sS0FBSyxHQUFHLE1BQU0sV0FBVyxDQUFDLEdBQUcsQ0FBQyxZQUFZLEtBQUssRUFBRSxDQUFDLENBQUM7QUFDekQsV0FBSyxPQUFPO0FBQUEsUUFDVixNQUFNO0FBQUEsUUFDTixRQUFRLENBQUM7QUFBQSxRQUNULFVBQVUsU0FBUztBQUFBLFFBQ25CLE1BQU0sQ0FBQztBQUFBLFFBQ1AsUUFBUSxDQUFDO0FBQUEsUUFDVCxjQUFjO0FBQUEsUUFDZDtBQUFBLE1BQ0Y7QUFDQSxXQUFLLFlBQVksWUFBWSxLQUFLLElBQUksS0FBSyxXQUFXLEtBQUssSUFBSSxDQUFDO0FBQ2hFLFdBQUssV0FBVztBQUFBLFFBQ2QsVUFBVSxFQUFFLEdBQUcsVUFBVSxRQUFRLFNBQVMsT0FBTyxJQUFJLENBQUMsT0FBTyxFQUFFLEdBQUcsR0FBRyxPQUFPLENBQUMsRUFBRSxFQUFFLEVBQUU7QUFBQSxRQUNuRixVQUFVLENBQUM7QUFBQSxNQUNiO0FBQ0EsVUFBSSxTQUFTLEVBQUUsZ0JBQWdCLE9BQVEsT0FBTSxLQUFLLFdBQVcsT0FBTyxNQUFNO0FBQUEsVUFDckUsT0FBTSxLQUFLLFFBQVEsVUFBVSxNQUFNO0FBQUEsSUFDMUM7QUFDQSxXQUFPLEtBQUssS0FBSztBQUFBLEVBQ25CO0FBQUEsRUFDQSxNQUFjLFFBQVEsT0FBTyxLQUFLLE1BQU07QUFDdEMsVUFBTSxNQUFNLG9CQUFJLElBQUk7QUFBQSxNQUNsQixLQUFLO0FBQUEsTUFDTCxHQUFHLE9BQU8sT0FBTyxLQUFLLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLEVBQUU7QUFBQSxNQUM3QyxHQUFHLE9BQU8sT0FBTyxLQUFLLGFBQWEsQ0FBQyxDQUFDO0FBQUEsTUFDckMsR0FBRyxLQUFLO0FBQUEsTUFDUixHQUFHLEtBQUs7QUFBQSxJQUNWLENBQUM7QUFDRCxlQUFXLE1BQU0sQ0FBQyxHQUFHLEtBQUssTUFBTSxHQUFHLEtBQUssTUFBTSxHQUFHO0FBQy9DLFlBQU0sSUFBSSxNQUFNLEtBQUssWUFBWSxFQUFFO0FBQ25DLFVBQUksSUFBSSxFQUFFLE1BQU07QUFDaEIsVUFBSSxJQUFJLEVBQUUsS0FBSztBQUNmLGlCQUFXLENBQUMsRUFBRSxHQUFHLENBQUMsS0FBSyxFQUFFLFNBQVM7QUFDaEMsWUFBSSxFQUFHLEtBQUksSUFBSSxFQUFFLEVBQUU7QUFDbkIsWUFBSSxFQUFHLEtBQUksSUFBSSxFQUFFLEVBQUU7QUFBQSxNQUNyQjtBQUFBLElBQ0Y7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0EsTUFBYyxZQUFZO0FBQ3hCLFFBQUksUUFBUSxZQUFZLEtBQUssSUFBSSxLQUFLLFdBQVcsS0FBSyxJQUFJLENBQUM7QUFDM0QsVUFBTSxNQUFNLENBQUMsR0FBSSxNQUFNLEtBQUssUUFBUSxDQUFFO0FBQ3RDLFVBQU0sUUFBUSxNQUFNLEtBQUssR0FBRyxZQUFZLEdBQUc7QUFDM0MsUUFBSSxRQUFRLENBQUMsSUFBSSxNQUFNO0FBQ3JCLGVBQVMsTUFBTSxDQUFDLElBQUksWUFBWSxJQUFJLE1BQU0sQ0FBQyxDQUFDO0FBQUEsSUFDOUMsQ0FBQztBQUNELFdBQU87QUFBQSxFQUNUO0FBQUEsRUFDUSxPQUFPLElBQVksT0FBZTtBQUN4QyxRQUFJLENBQUMsR0FBSTtBQUNULFVBQU0sU0FBUyxLQUFLLFdBQVcsSUFBSSxFQUFFLEtBQUssS0FBSztBQUMvQyxXQUFPLFNBQVMsR0FBRyxtQkFBbUIsaUNBQWlDO0FBQ3ZFLFFBQUksTUFBTyxNQUFLLFdBQVcsSUFBSSxJQUFJLEtBQUs7QUFBQSxRQUNuQyxNQUFLLFdBQVcsT0FBTyxFQUFFO0FBQUEsRUFDaEM7QUFBQSxFQUNRLGNBQWMsSUFBWSxHQUFZLE9BQWU7QUFDM0QsU0FBSyxPQUFPLElBQUksS0FBSztBQUNyQixTQUFLLE9BQU8sRUFBRSxRQUFRLEtBQUs7QUFDM0IsU0FBSyxPQUFPLEVBQUUsT0FBTyxLQUFLO0FBQzFCLGVBQVcsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxLQUFLLEVBQUUsU0FBUztBQUNoQyxVQUFJLEVBQUcsTUFBSyxPQUFPLEVBQUUsSUFBSSxLQUFLO0FBQzlCLFVBQUksRUFBRyxNQUFLLE9BQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxJQUNoQztBQUFBLEVBQ0Y7QUFBQSxFQUNRLGFBQWEsT0FBa0M7QUFDckQsUUFBSSxDQUFDLFNBQVMsT0FBTyxVQUFVLFlBQVksTUFBTSxRQUFRLEtBQUssRUFBRyxRQUFPO0FBQ3hFLFVBQU0sVUFBVTtBQUNoQixXQUNFLE9BQU8sS0FBSyxPQUFPLEVBQUU7QUFBQSxNQUFNLENBQUNBLFNBQzFCO0FBQUEsUUFDRTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRixFQUFFLFNBQVNBLElBQUc7QUFBQSxJQUNoQixLQUNBLE9BQU8sUUFBUSxPQUFPLFlBQ3RCLFFBQVEsR0FBRyxXQUFXLEdBQUcsS0FBSyxFQUFFLEdBQUcsS0FDbkMsT0FBTyxjQUFjLFFBQVEsS0FBSyxLQUNsQyxRQUFRLFFBQVEsS0FDaEIsT0FBTyxVQUFVLFFBQVEsS0FBSyxLQUM5QixRQUFRLFNBQVMsS0FDakIsUUFBUSxTQUFTLGFBQWEsaUJBQzlCLE9BQU8sVUFBVSxRQUFRLE1BQU0sS0FDL0IsUUFBUSxTQUFTLEtBQ2pCLFFBQVEsVUFBVSxPQUFPLFFBQ3pCLE9BQU8sVUFBVSxRQUFRLFNBQVMsS0FDbEMsUUFBUSxZQUFZLEtBQ3BCLFFBQVEsYUFBYSxPQUFPLFlBQzNCLFFBQVEsWUFBWSxVQUNsQixPQUFPLFFBQVEsWUFBWSxZQUFZLG1CQUFtQixLQUFLLFFBQVEsT0FBTyxPQUNoRixRQUFRLGVBQWUsVUFDckIsT0FBTyxVQUFVLFFBQVEsVUFBVSxLQUNsQyxRQUFRLGNBQWMsS0FDdEIsUUFBUSxjQUFjLGdCQUN6QixRQUFRLGFBQWEsVUFDbkIsTUFBTSxRQUFRLFFBQVEsUUFBUSxLQUM3QixRQUFRLFNBQVMsTUFBTSxDQUFDLFNBQVMsT0FBTyxTQUFTLFFBQVEsT0FDNUQsUUFBUSxXQUFXLFVBQ2pCLE1BQU0sUUFBUSxRQUFRLE1BQU0sS0FDM0IsUUFBUSxPQUFPLE1BQU0sQ0FBQyxVQUFVLE9BQU8sVUFBVSxRQUFRO0FBQUEsRUFFakU7QUFBQSxFQUNBLE1BQWMsWUFBWSxJQUE4QjtBQUN0RCxVQUFNLFVBQVUsTUFBTSxLQUFLLEdBQUcsSUFBYSxXQUFXLEVBQUU7QUFDeEQsVUFBTSxRQUFRLENBQUMsVUFBbUIsT0FBTyxVQUFVLFlBQVksTUFBTSxXQUFXLEdBQUcsS0FBSyxFQUFFLEdBQUc7QUFDN0YsVUFBTSxVQUFVLENBQUMsVUFBbUIsVUFBVSxRQUFRLEtBQUssYUFBYSxLQUFLO0FBQzdFLFVBQU0sVUFBVSxDQUFDLFVBQW1CO0FBQ2xDLFVBQUksT0FBTyxVQUFVLFNBQVUsUUFBTztBQUN0QyxZQUFNLFFBQVEsdUNBQXVDLEtBQUssS0FBSztBQUMvRCxhQUNFLENBQUMsQ0FBQyxTQUNGLE9BQU8sTUFBTSxDQUFDLENBQUMsS0FBSyxLQUFLLE1BQU0sYUFBYSxVQUFVLEtBQ3RELE9BQU8sTUFBTSxDQUFDLENBQUMsS0FBSyxLQUFLLE1BQU0sYUFBYSxhQUFhO0FBQUEsSUFFN0Q7QUFDQTtBQUFBLE1BQ0UsV0FDRSxPQUFPLFlBQVksWUFDbkIsQ0FBQyxNQUFNLFFBQVEsT0FBTyxLQUN0QixPQUFPLEtBQUssT0FBTyxFQUFFO0FBQUEsUUFBTSxDQUFDQSxTQUMxQixDQUFDLFVBQVUsU0FBUyxXQUFXLFNBQVMsUUFBUSxFQUFFLFNBQVNBLElBQUc7QUFBQSxNQUNoRSxLQUNBLE1BQU0sUUFBUSxNQUFNLEtBQ3BCLE1BQU0sUUFBUSxLQUFLLEtBQ25CLE9BQU8sY0FBYyxRQUFRLEtBQUssS0FDbEMsUUFBUSxTQUFTLEtBQ2pCLFFBQVEsU0FBUyxLQUFLLE9BQU8sUUFDN0IsTUFBTSxRQUFRLFFBQVEsT0FBTyxLQUM3QixRQUFRLFFBQVE7QUFBQSxRQUNkLENBQUMsV0FDQyxNQUFNLFFBQVEsTUFBTSxLQUNwQixPQUFPLFdBQVcsS0FDbEIsUUFBUSxPQUFPLENBQUMsQ0FBQyxNQUNoQixPQUFPLENBQUMsTUFBTSxRQUFRLE9BQU8sQ0FBQyxNQUFNLFNBQ3JDLFFBQVEsT0FBTyxDQUFDLENBQUMsS0FDakIsUUFBUSxPQUFPLENBQUMsQ0FBQztBQUFBLE1BQ3JCLEtBQ0EsSUFBSSxJQUFJLFFBQVEsUUFBUSxJQUFJLENBQUMsV0FBVyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsU0FBUyxRQUFRLFFBQVEsVUFDN0UsTUFBTSxRQUFRLFFBQVEsTUFBTSxLQUM1QixRQUFRLE9BQU87QUFBQSxRQUNiLENBQUMsVUFDQyxTQUNBLE9BQU8sVUFBVSxZQUNqQixDQUFDLE1BQU0sUUFBUSxLQUFLLEtBQ3BCLE9BQU8sS0FBSyxLQUFLLEVBQUU7QUFBQSxVQUFNLENBQUNBLFNBQ3hCLENBQUMsV0FBVyxZQUFZLFVBQVUsZUFBZSxXQUFXLEVBQUUsU0FBU0EsSUFBRztBQUFBLFFBQzVFLEtBQ0EsT0FBTyxNQUFNLFlBQVksWUFDekIsT0FBTyxVQUFVLE1BQU0sUUFBUSxLQUMvQixNQUFNLFlBQVksS0FDbEIsT0FBTyxVQUFVLE1BQU0sTUFBTSxLQUM3QixNQUFNLFNBQVMsTUFBTSxZQUNyQixNQUFNLFVBQVUsT0FBTyxRQUN2QixPQUFPLFVBQVUsTUFBTSxXQUFXLEtBQ2xDLE1BQU0sZUFBZSxLQUNyQixPQUFPLFVBQVUsTUFBTSxTQUFTLEtBQ2hDLE1BQU0sWUFBWSxNQUFNLGVBQ3hCLE1BQU0sYUFBYSxPQUFPO0FBQUEsTUFDOUI7QUFBQSxNQUNGO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0EsTUFBYyx1QkFBdUI7QUFDbkMsU0FBSyxXQUFXLE1BQU07QUFDdEIsU0FBSyxVQUFVLE1BQU07QUFDckIsU0FBSyxPQUFPLEtBQUssS0FBSyxNQUFNLENBQUM7QUFDN0IsZUFBVyxNQUFNLE9BQU8sT0FBTyxLQUFLLEtBQUssYUFBYSxDQUFDLENBQUMsRUFBRyxNQUFLLE9BQU8sSUFBSSxDQUFDO0FBQzVFLGVBQVcsS0FBSyxPQUFPLE9BQU8sS0FBSyxLQUFLLE1BQU0sRUFBRyxNQUFLLE9BQU8sRUFBRSxJQUFJLENBQUM7QUFDcEUsUUFBSSxZQUFZO0FBQ2hCLFVBQU0sa0JBQWtCLG9CQUFJLElBQUksQ0FBQyxLQUFLLEtBQUssSUFBSSxDQUFDO0FBQ2hELGVBQVcsQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLEdBQUcsS0FBSyxLQUFLLE1BQU0sR0FBRyxLQUFLLEtBQUssTUFBTSxFQUFFLFFBQVEsR0FBRztBQUM1RSxZQUFNLElBQUksTUFBTSxLQUFLLFlBQVksRUFBRTtBQUNuQyxpQkFBVyxjQUFjLENBQUMsRUFBRSxRQUFRLEVBQUUsS0FBSyxHQUFHO0FBQzVDLFlBQUksZ0JBQWdCLElBQUksVUFBVSxFQUFHO0FBRXJDLGNBQU0sRUFBRSxTQUFTLElBQUksTUFBTSxLQUFLLHFCQUFxQixVQUFVO0FBRy9EO0FBQUEsVUFDRSxNQUFNLFFBQVEsU0FBUyxNQUFNLEtBQzNCLFNBQVMsT0FBTztBQUFBLFlBQ2QsQ0FBQyxVQUFVLE1BQU0sUUFBUSxPQUFPLE1BQU0sS0FBSyxNQUFNLE9BQU8sV0FBVztBQUFBLFVBQ3JFO0FBQUEsVUFDRjtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQ0EsMEJBQWtCLFFBQVE7QUFDMUI7QUFBQSxVQUNFLG1CQUFtQixVQUFVLFFBQVEsRUFBRTtBQUFBLFVBQ3ZDO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFDQSx3QkFBZ0IsSUFBSSxVQUFVO0FBQUEsTUFDaEM7QUFDQSxVQUFJLFFBQVEsS0FBSyxLQUFLLEtBQUssT0FBUSxjQUFhLEVBQUU7QUFDbEQsV0FBSyxVQUFVLElBQUksSUFBSSxDQUFDO0FBQ3hCLFdBQUssY0FBYyxJQUFJLEdBQUcsQ0FBQztBQUFBLElBQzdCO0FBQ0E7QUFBQSxNQUNFLGNBQWMsS0FBSyxLQUFLO0FBQUEsTUFDeEI7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLE1BQWMsVUFBVTtBQUN0QixVQUFNLEtBQUsscUJBQXFCO0FBQ2hDLGVBQVcsTUFBTSxLQUFLLFdBQVcsS0FBSyxFQUFHLE1BQUssaUJBQWlCLElBQUksRUFBRTtBQUNyRSxVQUFNLE9BQU8sTUFBTSxLQUFLLFFBQVE7QUFDaEMsVUFBTSxXQUFXLENBQUMsR0FBRyxJQUFJO0FBQ3pCLFVBQU0sU0FBUyxNQUFNLEtBQUssR0FBRyxZQUFZLFFBQVE7QUFDakQsU0FBSyxZQUFZLFlBQVksS0FBSyxJQUFJLEtBQUssV0FBVyxLQUFLLElBQUksQ0FBQztBQUNoRSxTQUFLLE1BQU0sTUFBTTtBQUNqQixhQUFTLFFBQVEsQ0FBQyxJQUFJLE1BQU07QUFDMUIsWUFBTSxRQUFRLE9BQU8sQ0FBQyxJQUFJLFlBQVksSUFBSSxPQUFPLENBQUMsQ0FBQztBQUNuRCxXQUFLLGFBQWE7QUFDbEIsV0FBSyxNQUFNLElBQUksSUFBSSxLQUFLO0FBQUEsSUFDMUIsQ0FBQztBQUdELHFCQUFpQixTQUFTLEtBQUssR0FBRyxLQUFhLFNBQVMsWUFBWSxLQUFLLEVBQUUsQ0FBQyxHQUFHO0FBQzdFLGlCQUFXLENBQUMsRUFBRSxLQUFLLEtBQUs7QUFDdEI7QUFBQSxVQUNFLE9BQU8sY0FBYyxLQUFLLEtBQUssUUFBUTtBQUFBLFVBQ3ZDO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFBQSxJQUNKO0FBQ0EscUJBQWlCLFNBQVMsS0FBSyxHQUFHLFNBQVMsU0FBUyxZQUFZLEtBQUssRUFBRSxDQUFDLEdBQUc7QUFDekUsWUFBTSxPQUFpQixDQUFDO0FBQ3hCLGlCQUFXLEtBQUssT0FBTztBQUNyQixjQUFNLEtBQUssT0FBTyxDQUFDO0FBQ25CLFlBQUksQ0FBQyxLQUFLLElBQUksRUFBRSxFQUFHLE1BQUssS0FBSyxFQUFFO0FBQUEsTUFDakM7QUFDQSxVQUFJLEtBQUssT0FBUSxPQUFNLEtBQUssR0FBRyxNQUFNLFdBQVcsQ0FBQyxHQUFHLElBQUk7QUFBQSxJQUMxRDtBQUNBLFVBQU0sS0FBSyxHQUFHLE1BQU0sV0FBVyxDQUFDLEdBQUcsQ0FBQyxZQUFZLEtBQUssRUFBRSxDQUFDLENBQUM7QUFBQSxFQUMzRDtBQUFBLEVBQ0EsTUFBTSxTQUFTO0FBQ2IsUUFBSSxDQUFDLEtBQUssUUFBUTtBQUNoQixZQUFNLEtBQUssYUFBYSxLQUFLO0FBQzdCLGFBQU8sS0FBSyxLQUFLO0FBQUEsSUFDbkI7QUFDQSxVQUFNLGFBQWEsTUFBTSxLQUFLLEdBQUcsSUFBVSxTQUFTLEtBQUssRUFBRTtBQUMzRCxXQUFPLFlBQVksbUJBQW1CLDRDQUE0QztBQUNsRixTQUFLLE9BQU8sTUFBTSxLQUFLLFlBQVksVUFBVTtBQUM3QyxTQUFLLFdBQVcsTUFBTSxLQUFLLGFBQWEsS0FBSyxLQUFLLElBQUk7QUFDdEQsU0FBSyxxQkFBcUI7QUFDMUIsU0FBSyxrQkFBa0I7QUFDdkIsU0FBSyxNQUFNLE1BQU07QUFDakIsU0FBSyxXQUFXLE1BQU07QUFDdEIsU0FBSyxZQUFZLE1BQU0sS0FBSyxVQUFVO0FBQ3RDLFVBQU0sS0FBSyxxQkFBcUI7QUFDaEMsU0FBSyxPQUFPLENBQUM7QUFDYixXQUFPLEtBQUssS0FBSztBQUFBLEVBQ25CO0FBQUEsRUFDQSxNQUFNLGtCQUFrQjtBQUN0QixVQUFNLFVBQVUsTUFBTSxLQUFLLEdBQUcsSUFBVSxTQUFTLEtBQUssRUFBRTtBQUN4RCxXQUFPLFNBQVMsbUJBQW1CLDRDQUE0QztBQUMvRSxRQUFJLEtBQUssVUFBVSxPQUFPLE1BQU0sS0FBSyxzQkFBdUIsUUFBTztBQUNuRSxXQUFPLEtBQUssT0FBTztBQUFBLEVBQ3JCO0FBQUEsRUFDQSxNQUFNLGFBQWE7QUFDakIsV0FBUSxNQUFNLEtBQUssR0FBRyxJQUFVLFNBQVMsS0FBSyxFQUFFLE1BQU87QUFBQSxFQUN6RDtBQUFBLEVBQ0EsTUFBYyxhQUFhLGVBQXdCO0FBQ2pELFVBQU0sVUFBVSxLQUFLLElBQUk7QUFDekIsYUFBUyxVQUFVLEdBQUcsVUFBVSxJQUFJLFdBQVc7QUFDN0MsWUFBTSxTQUFTLE1BQU0sS0FBSyxHQUFHLElBQVUsU0FBUyxLQUFLLEVBQUU7QUFDdkQsYUFBTyxRQUFRLG1CQUFtQiw0Q0FBNEM7QUFDOUUsWUFBTSxZQUFZLEtBQUssVUFBVSxNQUFNO0FBQ3ZDLFVBQUksU0FBUyxPQUNYO0FBQ0YsVUFBSTtBQUNGLGFBQUssT0FBTyxNQUFNLEtBQUssWUFBWSxNQUFNO0FBQ3pDLGFBQUssV0FBVyxNQUFNLEtBQUssYUFBYSxLQUFLLEtBQUssSUFBSTtBQUN0RCxhQUFLLHFCQUFxQjtBQUMxQixhQUFLLGtCQUFrQjtBQUN2QixhQUFLLE1BQU0sTUFBTTtBQUNqQixhQUFLLFdBQVcsTUFBTTtBQUN0QixhQUFLLE9BQU8sQ0FBQztBQUNiLFlBQUksY0FBZSxPQUFNLEtBQUssUUFBUSxLQUFLLE1BQU0sS0FBSyxRQUFRO0FBQzlELGFBQUssWUFBWSxNQUFNLEtBQUssVUFBVTtBQUN0QyxjQUFNLEtBQUsscUJBQXFCO0FBQUEsTUFDbEMsU0FBUyxPQUFPO0FBQ2QsaUJBQVM7QUFDVCxrQkFBVTtBQUFBLE1BQ1o7QUFDQSxZQUFNLFVBQVUsTUFBTSxLQUFLLEdBQUcsSUFBVSxTQUFTLEtBQUssRUFBRTtBQUN4RCxVQUFJLEtBQUssVUFBVSxPQUFPLE1BQU0sV0FBVztBQUN6QyxZQUFJLFlBQVksTUFBTSxLQUFLLElBQUksSUFBSSxXQUFXO0FBQzVDLGdCQUFNLElBQUk7QUFBQSxZQUNSO0FBQUEsWUFDQTtBQUFBLFVBQ0Y7QUFDRixjQUFNLElBQUksUUFBYyxDQUFDLFlBQVksV0FBVyxTQUFTLEVBQUUsQ0FBQztBQUM1RDtBQUFBLE1BQ0Y7QUFDQSxVQUFJLE9BQVEsT0FBTTtBQUNsQixXQUFLLHdCQUF3QjtBQUM3QjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUEsRUFDQSxNQUFjLFNBQVMsT0FBZ0IsU0FBUyxLQUFLLEtBQUssUUFBUTtBQUNoRSxTQUFLLE1BQU07QUFDWCxVQUFNLEtBQUssR0FBRyxLQUFLLEVBQUUsSUFBSSxJQUFJLFFBQVEsQ0FBQztBQUN0QyxVQUFNLFdBQVcsWUFBWSxJQUFJLEtBQUs7QUFDdEMsVUFBTSxRQUFRLFdBQVcsWUFBWSxJQUFJLFFBQVE7QUFDakQ7QUFBQSxNQUNFLEtBQUssWUFBWSxLQUFLLGVBQWUsU0FBUztBQUFBLE1BQzlDO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFDQSxVQUFNLEtBQUssR0FBRyxNQUFNLFdBQVcsQ0FBQyxDQUFDLElBQUksS0FBSyxDQUFDLENBQUM7QUFDNUMsU0FBSyxhQUFhO0FBQ2xCLFNBQUssTUFBTSxJQUFJLElBQUksS0FBSztBQUN4QixTQUFLLFlBQVksS0FBSyxFQUFFO0FBQ3hCLFNBQUssVUFBVSxJQUFJLEVBQUU7QUFDckIsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBLE1BQWMscUJBQXFCLElBQXFDO0FBQ3RFLFVBQU0sU0FBUyxNQUFNLEtBQUssR0FBRyxJQUFvQixXQUFXLEVBQUU7QUFDOUQsV0FBTyxRQUFRLG1CQUFtQiw4QkFBOEI7QUFDaEU7QUFBQSxNQUNFLE9BQU8sV0FBVyxZQUNoQixDQUFDLE1BQU0sUUFBUSxNQUFNLEtBQ3JCLE9BQU8sS0FBSyxNQUFNLEVBQUU7QUFBQSxRQUFNLENBQUNBLFNBQ3pCLENBQUMsWUFBWSxZQUFZLFlBQVksZ0JBQWdCLEVBQUUsU0FBU0EsSUFBRztBQUFBLE1BQ3JFO0FBQUEsTUFDRjtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsVUFBTSxVQUFVLE9BQU8sVUFBVTtBQUNqQztBQUFBLE1BQ0UsT0FBTyxjQUFjLE9BQU8sS0FBSyxVQUFVO0FBQUEsTUFDM0M7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBO0FBQUEsTUFDRSxZQUFZO0FBQUEsTUFDWjtBQUFBLE1BQ0EsMEJBQTBCLE9BQU87QUFBQSxJQUNuQztBQUNBLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFDQSxNQUFjLGFBQWEsSUFBK0I7QUFDeEQsVUFBTSxTQUFTLE1BQU0sS0FBSyxxQkFBcUIsRUFBRTtBQUNqRCxVQUFNLFdBQVcsbUJBQW1CLE9BQU8sUUFBUTtBQUNuRDtBQUFBLE1BQ0UsTUFBTSxRQUFRLE9BQU8sUUFBUSxLQUMzQixPQUFPLFNBQVMsV0FBVyxPQUFPLFNBQVMsT0FBTyxVQUNsRCxJQUFJLElBQUksT0FBTyxRQUFRLEVBQUUsU0FBUyxPQUFPLFNBQVMsVUFDbEQsT0FBTyxTQUFTO0FBQUEsUUFDZCxDQUFDQyxRQUFPLFdBQVcsS0FBS0EsR0FBRSxLQUFLLENBQUMsQ0FBQyxhQUFhLGFBQWEsYUFBYSxFQUFFLFNBQVNBLEdBQUU7QUFBQSxNQUN2RjtBQUFBLE1BQ0Y7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLGFBQVMsU0FBUyxPQUFPO0FBQUEsTUFDdkIsT0FBTyxTQUFTLElBQUksQ0FBQ0EsS0FBSSxNQUFNLENBQUNBLEtBQUksT0FBTyxTQUFTLE9BQU8sQ0FBQyxDQUFDLENBQUM7QUFBQSxJQUNoRTtBQUNBLFVBQU0sRUFBRSxVQUFVLEdBQUcsU0FBUyxJQUFJO0FBQ2xDLFdBQU8sRUFBRSxHQUFHLFVBQVUsU0FBUztBQUFBLEVBQ2pDO0FBQUEsRUFDUSxlQUFlLEdBQVcsR0FBVztBQUMzQyxVQUFNLENBQUMsSUFBSSxJQUFJLEVBQUUsSUFBSSxFQUFFLE1BQU0sR0FBRyxHQUM5QixDQUFDLElBQUksSUFBSSxFQUFFLElBQUksRUFBRSxNQUFNLEdBQUc7QUFDNUIsV0FBTyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO0FBQUEsRUFDMUQ7QUFBQSxFQUNBLFlBQVksVUFBa0IsT0FBZ0IsUUFBUSxJQUFJLFNBQTRCO0FBQ3BGLFdBQU8sYUFBYSxLQUFLLEtBQUssVUFBVSxxQkFBcUIsZ0NBQWdDO0FBQzdGO0FBQUEsTUFDRSxPQUFPLFVBQVUsS0FBSyxLQUFLLFFBQVEsS0FBSyxTQUFTO0FBQUEsTUFDakQ7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLFVBQU0sWUFBYSxLQUFLLG9CQUFvQixPQUFPLEtBQUssS0FBSyxLQUFLLE1BQU0sRUFBRTtBQUFBLE1BQUssQ0FBQyxHQUFHLE1BQ2pGLEtBQUssZUFBZSxHQUFHLENBQUM7QUFBQSxJQUMxQjtBQUNBLFFBQUksTUFBTSxHQUNSLE9BQU8sVUFBVTtBQUNuQixVQUFNLFNBQVMsQ0FBQyxZQUNkLFFBQ0ksS0FBSyxlQUFlLFNBQVMsS0FBSyxLQUFLLElBQ3ZDLFVBQ0UsUUFBUSxNQUFNLEdBQUcsRUFBRSxDQUFDLElBQUksVUFDeEI7QUFDUixXQUFPLE1BQU0sTUFBTTtBQUNqQixZQUFNLE1BQU8sTUFBTSxTQUFVO0FBQzdCLFVBQUksT0FBTyxVQUFVLEdBQUcsQ0FBQyxFQUFHLE9BQU0sTUFBTTtBQUFBLFVBQ25DLFFBQU87QUFBQSxJQUNkO0FBQ0EsVUFBTSxTQUFtQixDQUFDO0FBQzFCLGFBQVMsSUFBSSxLQUFLLElBQUksVUFBVSxVQUFVLE9BQU8sU0FBUyxPQUFPLEtBQUs7QUFDcEUsWUFBTSxVQUFVLFVBQVUsQ0FBQztBQUMzQixVQUFJLFdBQVcsQ0FBQyxRQUFRLFdBQVcsR0FBRyxPQUFPLEdBQUcsRUFBRztBQUNuRCxhQUFPLEtBQUssT0FBTztBQUFBLElBQ3JCO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBLGFBQWEsVUFBa0I7QUFDN0IsV0FBTyxhQUFhLEtBQUssS0FBSyxVQUFVLHFCQUFxQixnQ0FBZ0M7QUFDN0YsVUFBTSxPQUFPLElBQUk7QUFBQSxNQUNmLE9BQU8sT0FBTyxLQUFLLEtBQUssTUFBTSxFQUFFLFFBQVEsQ0FBQyxZQUFZLFFBQVEsVUFBVSxDQUFDLENBQUM7QUFBQSxJQUMzRTtBQUNBLFdBQU8sT0FBTyxLQUFLLEtBQUssU0FBUyxTQUFTLE1BQU0sRUFBRSxPQUFPLENBQUMsT0FBTyxLQUFLLElBQUksRUFBRSxDQUFDO0FBQUEsRUFDL0U7QUFBQSxFQUNBLE1BQU0sWUFBWSxTQUFpQixVQUF5QztBQUMxRSxXQUFPLGFBQWEsS0FBSyxLQUFLLFVBQVUscUJBQXFCLGdDQUFnQztBQUM3RixVQUFNLFVBQVUsS0FBSyxLQUFLLE9BQU8sT0FBTztBQUN4QyxXQUFPLFNBQVMsb0JBQW9CLHNCQUFzQjtBQUMxRCxVQUFNLFVBQVUsTUFBTSxLQUFLLEdBQUcsSUFBa0IsV0FBVyxRQUFRLEVBQUU7QUFDckUsU0FBSyxNQUFNO0FBQ1gsV0FBTyxTQUFTLG1CQUFtQix5QkFBeUI7QUFDNUQsV0FBTyxhQUFhLEtBQUssS0FBSyxVQUFVLHFCQUFxQixnQ0FBZ0M7QUFDN0YsV0FBTyxLQUFLLFFBQVEsT0FBTztBQUFBLEVBQzdCO0FBQUEsRUFDQSxNQUFjLFFBQVEsT0FBbUI7QUFDdkMsUUFBSSxNQUFNLENBQUMsTUFBTSxNQUFNLE1BQU0sQ0FBQyxNQUFNLE1BQU0sTUFBTSxDQUFDLE1BQU0sR0FBSSxRQUFPO0FBQ2xFLFdBQU8sTUFBTSxVQUFVLE1BQU0sTUFBTSxDQUFDLE1BQU0sR0FBRyxtQkFBbUIseUJBQXlCO0FBQ3pGLFVBQU0sT0FBTyxJQUFJLFNBQVMsTUFBTSxRQUFRLE1BQU0sWUFBWSxNQUFNLFVBQVU7QUFDMUUsVUFBTSxPQUFPLE1BQU0sV0FBVyxNQUFNLFNBQVMsRUFBRSxHQUFHLEdBQUcsS0FBSyxVQUFVLEdBQUcsSUFBSSxDQUFDO0FBQzVFO0FBQUEsTUFDRSxNQUFNLElBQUksTUFBTSxLQUFLLFVBQVUsR0FBRyxJQUFJO0FBQUEsTUFDdEM7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFDQSxJQUFJLHVCQUF1QjtBQUN6QixXQUFPLEtBQUssaUJBQWlCLE9BQU87QUFBQSxFQUN0QztBQUFBLEVBQ0EsTUFBTSxRQUFRLFFBQVEsR0FBRztBQUN2QixRQUFJLENBQUMsS0FBSyxPQUFRO0FBQ2xCLGVBQVcsTUFBTSxDQUFDLEdBQUcsS0FBSyxnQkFBZ0IsRUFBRSxNQUFNLEdBQUcsS0FBSyxHQUFHO0FBQzNELFdBQUssaUJBQWlCLE9BQU8sRUFBRTtBQUMvQixVQUFJLENBQUMsS0FBSyxXQUFXLElBQUksRUFBRSxFQUFHO0FBQzlCLFlBQU0sUUFBUSxNQUFNLEtBQUssR0FBRyxJQUFhLFdBQVcsRUFBRTtBQUN0RCxVQUFJLEVBQUUsaUJBQWlCLGVBQWUsTUFBTSxTQUFTLE9BQU8sTUFBTSxDQUFDLE1BQU0sR0FBSTtBQUM3RSxZQUFNLGFBQWEsTUFBTSxTQUFTLEtBQUs7QUFDdkMsVUFBSSxXQUFXLFVBQVUsS0FBSyxXQUFXLE1BQU0sU0FBUyxLQUFLLE1BQU0sU0FBUyxJQUFLO0FBQ2pGLFlBQU0sU0FBUyxJQUFJLFdBQVcsV0FBVyxNQUFNLFNBQVMsRUFBRSxHQUN4RCxPQUFPLElBQUksU0FBUyxPQUFPLE1BQU07QUFDbkMsYUFBTyxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxDQUFDO0FBQzFCLFdBQUssVUFBVSxHQUFHLE1BQU0sUUFBUSxJQUFJO0FBQ3BDLFdBQUssVUFBVSxHQUFHLE1BQU0sS0FBSyxHQUFHLElBQUk7QUFDcEMsYUFBTyxJQUFJLFdBQVcsT0FBTyxFQUFFO0FBQy9CLFlBQU0sTUFBTSxZQUFZLElBQUksTUFBTSxHQUNoQyxPQUFPLE1BQU0sWUFBWSxJQUFJLEdBQUcsR0FDaEMsTUFBTSxLQUFLLE1BQU0sSUFBSSxFQUFFO0FBRXpCLFVBQUksS0FBSyxZQUFZLE9BQU8sS0FBSyxLQUFLLE9BQVE7QUFDOUMsWUFBTSxLQUFLLEdBQUcsTUFBTSxXQUFXLENBQUMsQ0FBQyxJQUFJLE1BQU0sQ0FBQyxDQUFDO0FBQzdDLFdBQUssTUFBTSxJQUFJLElBQUksSUFBSTtBQUN2QixXQUFLLGFBQWEsT0FBTztBQUFBLElBQzNCO0FBQ0EsV0FBTztBQUFBLE1BQ0wsT0FBTyxLQUFLO0FBQUEsTUFDWixZQUFZLEtBQUssTUFBTSxRQUFRLEtBQUssV0FBVyxhQUFhLEtBQUssS0FBSztBQUFBLElBQ3hFO0FBQUEsRUFDRjtBQUFBLEVBQ0EsTUFBYyxRQUFRLFlBQThCO0FBQ2xELFFBQUksS0FBSyxTQUFVO0FBQ25CLFVBQU0sT0FBTyxDQUFDLEdBQUcsSUFBSSxJQUFJLFVBQVUsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxPQUFPLENBQUMsS0FBSyxXQUFXLElBQUksRUFBRSxDQUFDO0FBQzdFLFFBQUksS0FBSyxPQUFRLE9BQU0sS0FBSyxHQUFHLE1BQU0sV0FBVyxDQUFDLEdBQUcsSUFBSTtBQUN4RCxlQUFXLE1BQU0sTUFBTTtBQUNyQixXQUFLLGFBQWEsS0FBSyxNQUFNLElBQUksRUFBRSxLQUFLO0FBQ3hDLFdBQUssTUFBTSxPQUFPLEVBQUU7QUFDcEIsV0FBSyxNQUFNLE9BQU8sRUFBRTtBQUFBLElBQ3RCO0FBQUEsRUFDRjtBQUFBLEVBQ0EsTUFBYyxRQUFRLFlBQThCO0FBR2xELFFBQUk7QUFDRixZQUFNLEtBQUssUUFBUSxVQUFVO0FBQUEsSUFDL0IsUUFBUTtBQUFBLElBRVI7QUFBQSxFQUNGO0FBQUEsRUFDUSxPQUFPLFNBQWlCO0FBQzlCLFFBQUksT0FBTztBQUNYLGVBQVcsS0FBSyxRQUFTLFFBQU8sS0FBSyxLQUFLLE9BQU8sRUFBRSxXQUFXLENBQUMsR0FBRyxRQUFRO0FBQzFFLFdBQU8sUUFBUSxTQUFTLEtBQUssR0FBRztBQUFBLEVBQ2xDO0FBQUEsRUFDUSxXQUFXLE1BQVk7QUFDN0IsVUFBTSxFQUFFLFFBQVEsR0FBRyxLQUFLLElBQUk7QUFDNUIsV0FBTyxFQUFFLEdBQUcsTUFBTSxXQUFXLEtBQUssYUFBYSxDQUFDLEVBQUU7QUFBQSxFQUNwRDtBQUFBLEVBQ1EsdUJBQXVCO0FBQzdCLFVBQU0sV0FBVyxJQUFJLElBQUksS0FBSyxTQUFTLFNBQVMsT0FBTyxJQUFJLENBQUMsVUFBVSxNQUFNLEVBQUUsQ0FBQztBQUMvRTtBQUFBLE1BQ0UsT0FBTyxLQUFLLEtBQUssS0FBSyxNQUFNLEVBQUUsTUFBTSxDQUFDLFlBQVksU0FBUyxJQUFJLFFBQVEsTUFBTSxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFBQSxNQUNwRjtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBQ0EsTUFBYyxZQUFZLE1BQVk7QUFDcEM7QUFBQSxNQUNFLFFBQVEsT0FBTyxTQUFTLFlBQVksQ0FBQyxNQUFNLFFBQVEsSUFBSTtBQUFBLE1BQ3ZEO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFDQSxRQUFJLE9BQU8sT0FBTyxNQUFNLHFCQUFxQixHQUFHO0FBQzlDO0FBQUEsUUFDRSxPQUFPLGNBQWMsS0FBSyxtQkFBbUIsS0FBSyxLQUFLLHNCQUF1QjtBQUFBLFFBQzlFO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFDQTtBQUFBLFFBQ0UsS0FBSyx3QkFBd0I7QUFBQSxRQUM3QjtBQUFBLFFBQ0EsMEJBQTBCLEtBQUssbUJBQW1CO0FBQUEsTUFDcEQ7QUFBQSxJQUNGO0FBQ0E7QUFBQSxNQUNFLE9BQU8sS0FBSyxJQUFJLEVBQUU7QUFBQSxRQUFNLENBQUNELFNBQ3ZCO0FBQUEsVUFDRTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxRQUNGLEVBQUUsU0FBU0EsSUFBRztBQUFBLE1BQ2hCO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsVUFBTSxRQUFRLENBQUMsVUFBbUIsT0FBTyxVQUFVLFlBQVksTUFBTSxXQUFXLEdBQUcsS0FBSyxFQUFFLEdBQUc7QUFDN0Y7QUFBQSxNQUNFLE1BQU0sS0FBSyxJQUFJLEtBQ2IsT0FBTyxjQUFjLEtBQUssUUFBUSxLQUNsQyxLQUFLLFlBQVksS0FDakIsT0FBTyxjQUFjLEtBQUssTUFBTSxLQUNoQyxLQUFLLFNBQVMsS0FDZCxPQUFPLGNBQWMsS0FBSyxZQUFZLEtBQ3RDLEtBQUssZ0JBQWdCLEtBQ3JCLEtBQUssZ0JBQWdCLEtBQUssT0FBTyxRQUNqQyxNQUFNLFFBQVEsS0FBSyxJQUFJLEtBQ3ZCLE1BQU0sUUFBUSxLQUFLLE1BQU0sS0FDekIsS0FBSyxLQUFLLFNBQVMsS0FBSyxPQUFPLFVBQVUsT0FDekMsQ0FBQyxHQUFHLEtBQUssTUFBTSxHQUFHLEtBQUssTUFBTSxFQUFFLE1BQU0sS0FBSyxNQUMxQyxvQkFBSSxJQUFJLENBQUMsR0FBRyxLQUFLLE1BQU0sR0FBRyxLQUFLLE1BQU0sQ0FBQyxHQUFFLFNBQVMsS0FBSyxLQUFLLFNBQVMsS0FBSyxPQUFPO0FBQUEsTUFDbEY7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBO0FBQUEsTUFDRSxLQUFLLGFBQ0gsT0FBTyxLQUFLLGNBQWMsWUFDMUIsQ0FBQyxNQUFNLFFBQVEsS0FBSyxTQUFTLEtBQzdCLENBQUMsT0FBTyxPQUFPLE1BQU0sUUFBUSxLQUM3QixPQUFPLFFBQVEsS0FBSyxTQUFTLEVBQUU7QUFBQSxRQUM3QixDQUFDLENBQUMsUUFBUSxFQUFFLE1BQ1YsaUJBQWlCLEtBQUssTUFBTSxLQUM1QixPQUFPLE1BQU0sSUFBSSxPQUNqQixPQUFPLE9BQU8sWUFDZCxHQUFHLFdBQVcsR0FBRyxLQUFLLEVBQUUsR0FBRztBQUFBLE1BQy9CO0FBQUEsTUFDRjtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsVUFBTSxTQUFrQyxDQUFDO0FBQ3pDLFNBQUssaUJBQWlCLE1BQU07QUFDNUIsZUFBVyxDQUFDLFFBQVEsRUFBRSxLQUFLLE9BQU8sUUFBUSxLQUFLLFNBQVMsR0FBRztBQUN6RCxZQUFNLFVBQVUsTUFBTSxLQUFLLEdBQUcsSUFBNkIsV0FBVyxFQUFFO0FBQ3hFO0FBQUEsUUFDRSxXQUFXLE9BQU8sWUFBWSxZQUFZLENBQUMsTUFBTSxRQUFRLE9BQU87QUFBQSxRQUNoRTtBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBQ0EsaUJBQVcsQ0FBQyxTQUFTLE9BQU8sS0FBSyxPQUFPLFFBQVEsT0FBTyxHQUFHO0FBQ3hELGNBQU0sUUFBUSx5Q0FBeUMsS0FBSyxPQUFPO0FBQ25FO0FBQUEsVUFDRSxTQUNFLE9BQU8sTUFBTSxDQUFDLENBQUMsS0FBSyxLQUFLLE1BQU0sYUFBYSxVQUFVLEtBQ3RELE9BQU8sTUFBTSxDQUFDLENBQUMsS0FBSyxLQUFLLE1BQU0sYUFBYSxhQUFhLEtBQ3pELEtBQUssT0FBTyxPQUFPLE1BQU0sVUFDekIsQ0FBQyxPQUFPLE9BQU8sUUFBUSxPQUFPLEtBQzlCLEtBQUssYUFBYSxPQUFPO0FBQUEsVUFDM0I7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxXQUFLLGlCQUFpQixJQUFJLFFBQVEsT0FBTztBQUN6QyxhQUFPLE9BQU8sUUFBUSxPQUFPO0FBQUEsSUFDL0I7QUFDQSxXQUFPLEVBQUUsR0FBRyxNQUFNLE9BQU87QUFBQSxFQUMzQjtBQUFBLEVBQ0EsTUFBYyxRQUFRLE1BQVksVUFBb0IsUUFBc0I7QUFDMUUsU0FBSyxNQUFNO0FBQ1gsVUFBTSxvQkFBb0IsS0FBSyxLQUFLLGFBQWEsQ0FBQztBQUNsRCxVQUFNLFlBQVksRUFBRSxHQUFHLGtCQUFrQixHQUN2QyxRQUFRLG9CQUFJLElBQXFDO0FBQ25ELGVBQVcsV0FBVyxLQUFLLFNBQVM7QUFDbEMsWUFBTSxTQUFTLEtBQUssT0FBTyxPQUFPO0FBQ2xDLFVBQUksQ0FBQyxNQUFNLElBQUksTUFBTSxFQUFHLE9BQU0sSUFBSSxRQUFRLEVBQUUsR0FBRyxLQUFLLGlCQUFpQixJQUFJLE1BQU0sRUFBRSxDQUFDO0FBQ2xGLFlBQU0sVUFBVSxNQUFNLElBQUksTUFBTTtBQUNoQyxVQUFJLEtBQUssT0FBTyxPQUFPLEVBQUcsU0FBUSxPQUFPLElBQUksS0FBSyxPQUFPLE9BQU87QUFBQSxVQUMzRCxRQUFPLFFBQVEsT0FBTztBQUFBLElBQzdCO0FBQ0EsVUFBTSxrQkFBNEIsQ0FBQztBQUNuQyxlQUFXLENBQUMsUUFBUSxPQUFPLEtBQUssT0FBTztBQUNyQyxVQUFJLFVBQVUsTUFBTSxFQUFHLGlCQUFnQixLQUFLLFVBQVUsTUFBTSxDQUFDO0FBQzdELFVBQUksT0FBTyxLQUFLLE9BQU8sRUFBRTtBQUN2QixrQkFBVSxNQUFNLElBQUksTUFBTSxLQUFLLFNBQVMsU0FBUyxLQUFLLE1BQU07QUFBQSxVQUN6RCxRQUFPLFVBQVUsTUFBTTtBQUFBLElBQzlCO0FBQ0EsU0FBSyxZQUFZO0FBQ2pCLFNBQUssc0JBQXNCO0FBQzNCLFVBQU0sUUFDSixLQUFLLFlBQ0wsWUFBWSxLQUFLLElBQUksS0FBSyxXQUFXLEtBQUssSUFBSSxDQUFDLElBQy9DLFlBQVksS0FBSyxJQUFJLEtBQUssV0FBVyxJQUFJLENBQUM7QUFDNUMsV0FBTyxTQUFTLEtBQUssUUFBUSxrQkFBa0IscUNBQXFDO0FBQ3BGLFNBQUssTUFBTTtBQUNYLFVBQU0sS0FBSyxHQUFHLE1BQU0sU0FBUyxDQUFDLENBQUMsS0FBSyxJQUFJLEtBQUssV0FBVyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQy9ELFFBQUk7QUFDRixZQUFNLE1BQU0sS0FBSztBQUNqQixVQUFJLENBQUMsR0FBRyxLQUFLLE9BQU8sRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxPQUFPLENBQUMsQ0FBQztBQUNwRSxhQUFLLGtCQUFrQjtBQUN6QixpQkFBVyxNQUFNLE9BQU8sT0FBTyxTQUFTO0FBQ3RDLFlBQUksQ0FBQyxPQUFPLE9BQU8saUJBQWlCLEVBQUUsU0FBUyxFQUFFLEVBQUcsTUFBSyxPQUFPLElBQUksQ0FBQztBQUN2RSxpQkFBVyxNQUFNLGdCQUFpQixNQUFLLE9BQU8sSUFBSSxFQUFFO0FBQ3BELGlCQUFXLENBQUMsUUFBUSxPQUFPLEtBQUssT0FBTztBQUNyQyxZQUFJLE9BQU8sS0FBSyxPQUFPLEVBQUUsT0FBUSxNQUFLLGlCQUFpQixJQUFJLFFBQVEsT0FBTztBQUFBLFlBQ3JFLE1BQUssaUJBQWlCLE9BQU8sTUFBTTtBQUFBLE1BQzFDO0FBQ0EsWUFBTSxPQUFPLEtBQUssV0FBVyxJQUFJLFVBQVUsQ0FBQyxLQUFLLFFBQVE7QUFDekQsVUFBSSxNQUFNO0FBQ1IsbUJBQVcsS0FBSyxPQUFPLE9BQU8sS0FBSyxNQUFNLEVBQUcsTUFBSyxPQUFPLEVBQUUsSUFBSSxDQUFDO0FBQy9ELG1CQUFXLEtBQUssT0FBTyxPQUFPLElBQUksTUFBTSxFQUFHLE1BQUssT0FBTyxFQUFFLElBQUksRUFBRTtBQUFBLE1BQ2pFO0FBQ0UsbUJBQVcsV0FBVyxLQUFLLFNBQVM7QUFDbEMsZ0JBQU0sSUFBSSxJQUFJLE9BQU8sT0FBTyxHQUMxQixJQUFJLEtBQUssT0FBTyxPQUFPO0FBQ3pCLGNBQUksR0FBRyxPQUFPLEdBQUcsR0FBSTtBQUNyQixjQUFJLEVBQUcsTUFBSyxPQUFPLEVBQUUsSUFBSSxDQUFDO0FBQzFCLGNBQUksRUFBRyxNQUFLLE9BQU8sRUFBRSxJQUFJLEVBQUU7QUFBQSxRQUM3QjtBQUNGLFVBQUksS0FBSyxTQUFTLElBQUksTUFBTTtBQUMxQixhQUFLLE9BQU8sS0FBSyxNQUFNLENBQUM7QUFDeEIsYUFBSyxPQUFPLElBQUksTUFBTSxFQUFFO0FBQUEsTUFDMUI7QUFDQSxZQUFNLGFBQWEsb0JBQUksSUFBSSxDQUFDLEdBQUcsSUFBSSxNQUFNLEdBQUcsSUFBSSxNQUFNLENBQUMsR0FDckQsYUFBYSxvQkFBSSxJQUFJLENBQUMsR0FBRyxLQUFLLE1BQU0sR0FBRyxLQUFLLE1BQU0sQ0FBQztBQUNyRCxpQkFBVyxNQUFNO0FBQ2YsWUFBSSxDQUFDLFdBQVcsSUFBSSxFQUFFLEdBQUc7QUFDdkIsZ0JBQU0sSUFBSSxLQUFLLFVBQVUsSUFBSSxFQUFFLEtBQU0sTUFBTSxLQUFLLFlBQVksRUFBRTtBQUM5RCxpQkFBTyxHQUFHLG1CQUFtQixxQkFBcUI7QUFDbEQsZUFBSyxVQUFVLElBQUksSUFBSSxDQUFDO0FBQ3hCLGVBQUssY0FBYyxJQUFJLEdBQUcsQ0FBQztBQUFBLFFBQzdCO0FBQ0YsaUJBQVcsTUFBTTtBQUNmLFlBQUksQ0FBQyxXQUFXLElBQUksRUFBRSxHQUFHO0FBQ3ZCLGdCQUFNLElBQUksS0FBSyxVQUFVLElBQUksRUFBRTtBQUMvQixlQUFLLGNBQWMsSUFBSSxHQUFHLEVBQUU7QUFDNUIsZUFBSyxVQUFVLE9BQU8sRUFBRTtBQUFBLFFBQzFCO0FBQ0YsWUFBTSxjQUFjLElBQUksSUFBSSxLQUFLLFNBQVMsU0FBUyxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJLEVBQUUsQ0FBQyxDQUFDO0FBQ2xGLFdBQUssT0FBTztBQUNaLFdBQUssV0FBVztBQUNoQixVQUFJLElBQUksU0FBUyxLQUFLLE1BQU07QUFDMUIsbUJBQVcsTUFBTSxTQUFTLFNBQVMsUUFBUTtBQUN6QyxnQkFBTSxRQUFRLFlBQVksSUFBSSxHQUFHLEVBQUU7QUFFbkMsY0FDRSxDQUFDLFNBQ0QsTUFBTSxXQUFXLEdBQUcsVUFDcEIsTUFBTSxTQUFTLFdBQVcsR0FBRyxTQUFTLFVBQ3RDLE1BQU0sWUFBWSxXQUFXLEdBQUcsWUFBWSxVQUM1QyxNQUFNLFNBQVMsS0FBSyxDQUFDLElBQUksTUFBTSxPQUFPLEdBQUcsU0FBUyxDQUFDLENBQUMsS0FDcEQsTUFBTSxZQUFZLEtBQUssQ0FBQyxJQUFJLE1BQU0sT0FBTyxHQUFHLFlBQVksQ0FBQyxDQUFDO0FBRTFELG1CQUFPLEtBQUssS0FBSyxHQUFHLEVBQUU7QUFBQSxRQUMxQjtBQUFBLE1BQ0Y7QUFDQSxpQkFBVyxLQUFLLEtBQUs7QUFDbkIsWUFDRSxJQUFJLE9BQU8sQ0FBQyxHQUFHLFlBQVksS0FBSyxPQUFPLENBQUMsR0FBRyxXQUMzQyxJQUFJLE9BQU8sQ0FBQyxHQUFHLGVBQWUsS0FBSyxPQUFPLENBQUMsR0FBRztBQUU5QyxpQkFBTyxLQUFLLEtBQUssRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDcEMsV0FBSyxZQUFZO0FBQ2pCLFVBQUksT0FBUSxNQUFLLFdBQVcsV0FBVyxNQUFNO0FBQUEsVUFDeEMsTUFBSyxXQUFXLE1BQU07QUFDM0IsWUFBTSxLQUFLLFFBQVEsZUFBZTtBQUFBLElBQ3BDLFFBQVE7QUFDTixXQUFLLFdBQVc7QUFDaEIsWUFBTSxJQUFJLGVBQWUsaUJBQWlCLGdEQUFnRDtBQUFBLElBQzVGO0FBQUEsRUFDRjtBQUFBLEVBQ0EsT0FBbUI7QUFDakIsVUFBTSxPQUFPLEtBQUs7QUFDbEIsZUFBVyxLQUFLLEtBQUssU0FBUyxTQUFTLFFBQVE7QUFDN0MsVUFBSSxLQUFLLEVBQUUsRUFBRSxFQUFHO0FBQ2hCLFVBQUksU0FBUyxHQUNYLFlBQVk7QUFDZCxZQUFNLE9BQU8sS0FBSyxLQUFLLEVBQUUsUUFBUSxHQUMvQixPQUFPLEtBQUssS0FBSyxFQUFFLFdBQVc7QUFDaEMsaUJBQVcsQ0FBQyxTQUFTLENBQUMsS0FBSyxPQUFPLFFBQVEsS0FBSyxLQUFLLE1BQU07QUFDeEQsWUFBSSxRQUFRLFdBQVcsR0FBRyxFQUFFLEVBQUUsR0FBRyxHQUFHO0FBQ2xDLGdCQUFNLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxRQUFRLE1BQU0sR0FBRyxHQUNsQyxPQUFPLE9BQU8sUUFBUSxFQUFFLFdBQVcsSUFBSTtBQUN6QyxtQkFBUyxJQUFJLEdBQUcsSUFBSSxJQUFJO0FBQ3RCLGdCQUFJLE9BQVEsTUFBTSxPQUFPLENBQUM7QUFDeEIsdUJBQVMsS0FBSyxJQUFJLFNBQVMsS0FBSyxJQUFJLENBQUMsS0FBSyxLQUFLLENBQUMsS0FBSyxNQUFNLENBQUM7QUFDaEUsbUJBQVMsSUFBSSxHQUFHLElBQUksSUFBSTtBQUN0QixpQkFBSyxFQUFFLGNBQWMsS0FBTSxLQUFLO0FBQzlCLDBCQUFZLEtBQUssSUFBSSxZQUFZLEtBQUssSUFBSSxDQUFDLEtBQUssS0FBSyxDQUFDLEtBQUssTUFBTSxDQUFDO0FBQUEsUUFDeEU7QUFDRixpQkFBVyxLQUFLLEVBQUUsUUFBUTtBQUN4QixpQkFBUyxLQUFLLElBQUksUUFBUSxFQUFFLE1BQU07QUFDbEMsb0JBQVksS0FBSyxJQUFJLFdBQVcsRUFBRSxTQUFTO0FBQUEsTUFDN0M7QUFDQSxXQUFLLEVBQUUsRUFBRSxJQUFJLEVBQUUsVUFBVSxHQUFHLGFBQWEsR0FBRyxRQUFRLFVBQVU7QUFBQSxJQUNoRTtBQUNBLFdBQU87QUFBQSxNQUNMLFVBQVUsRUFBRSxHQUFHLEtBQUssU0FBUyxVQUFVLFVBQVUsS0FBSyxLQUFLLFNBQVM7QUFBQSxNQUNwRSxZQUFZLEtBQUssS0FBSztBQUFBLE1BQ3RCLFVBQVUsS0FBSyxLQUFLO0FBQUEsTUFDcEIsZ0JBQWdCLEtBQUssU0FBUztBQUFBLE1BQzlCLFVBQVUsS0FBSyxTQUFTO0FBQUEsTUFDeEI7QUFBQSxNQUNBLFNBQVMsQ0FBQyxDQUFDLEtBQUssS0FBSyxLQUFLO0FBQUEsTUFDMUIsU0FBUyxDQUFDLENBQUMsS0FBSyxLQUFLLE9BQU87QUFBQSxNQUM1QixPQUFPLEtBQUs7QUFBQSxNQUNaLFlBQVksS0FBSyxNQUFNLFFBQVEsS0FBSyxXQUFXLGFBQWEsS0FBSyxLQUFLO0FBQUEsTUFDdEUsUUFBUSxLQUFLLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLE1BQWMsTUFBTSxTQUFpQixPQUFPLEtBQUssTUFBTSxRQUEwQztBQUMvRixVQUFNLElBQUksS0FBSyxPQUFPLE9BQU87QUFDN0IsUUFBSSxDQUFDLEdBQUc7QUFDTixVQUFJLE9BQVEsUUFBTztBQUNuQixhQUFPLFlBQVksWUFBWSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUFBLElBQ2hEO0FBQ0EsVUFBTSxTQUFTLEtBQUssTUFBTSxJQUFJLEVBQUUsRUFBRTtBQUNsQyxRQUFJLFFBQVE7QUFDVixVQUFJLE9BQVEsUUFBTztBQUNuQixhQUFPO0FBQUEsSUFDVDtBQUNBLFFBQUksT0FBUSxRQUFPO0FBQ25CLFFBQUksVUFBVSxTQUFTLFlBQVksSUFBSSxJQUFJO0FBQzNDLFVBQU0sVUFBVSxNQUFNLEtBQUssR0FBRyxJQUFrQixXQUFXLEVBQUUsRUFBRTtBQUMvRCxRQUFJLFFBQVE7QUFDVixhQUFPLGFBQWEsWUFBWSxJQUFJLElBQUk7QUFDeEMsZ0JBQVUsWUFBWSxJQUFJO0FBQUEsSUFDNUI7QUFDQSxXQUFPLFNBQVMsbUJBQW1CLHVCQUF1QjtBQUMxRCxVQUFNLFdBQVcsTUFBTSxLQUFLLFFBQVEsT0FBTztBQUMzQyxRQUFJLFFBQVE7QUFDVixZQUFNLE1BQU0sWUFBWSxJQUFJO0FBQzVCLGFBQU8sYUFBYSxNQUFNO0FBQzFCLGdCQUFVO0FBQUEsSUFDWjtBQUNBLFVBQU0sUUFBUSxZQUFZLFFBQVE7QUFDbEMsUUFBSSxRQUFRO0FBQ1YsWUFBTSxXQUFXLFlBQVksSUFBSSxJQUFJO0FBQ3JDLGFBQU8sZ0JBQWdCO0FBQ3ZCLGFBQU8sV0FBVyxPQUFPLFlBQVksT0FBTztBQUFBLElBQzlDO0FBQ0EsU0FBSyxNQUFNLElBQUksRUFBRSxJQUFJLE9BQU8sTUFBTSxLQUFLO0FBQ3ZDLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFDQSxNQUFNLEtBQUssT0FBZSxLQUFhLFFBQWlEO0FBQ3RGLFdBQU8sS0FBSyxXQUFXLE9BQU8sS0FBSyxRQUFRLEtBQUssTUFBTSxLQUFLLFFBQVE7QUFBQSxFQUNyRTtBQUFBLEVBQ0EsTUFBYyxXQUNaLE9BQ0EsS0FDQSxRQUNBLE1BQ0EsVUFDQSxPQUNpQztBQUNqQyxTQUFLLE1BQU07QUFDWCxVQUFNLEtBQUssU0FBUyxTQUFTLE9BQU8sS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLEtBQUs7QUFDOUQsUUFDRSxDQUFDLE1BQ0QsTUFBTSxLQUNOLFNBQVMsS0FDVCxPQUFPLEdBQUcsU0FBUyxVQUNuQixVQUFVLEdBQUcsWUFBWTtBQUV6QixhQUFPLEVBQUUsT0FBTyxHQUFHLFVBQVUsR0FBRyxPQUFPLEVBQUUsTUFBTSxTQUFTLE1BQU0sUUFBUSxFQUFFO0FBQzFFLFVBQU0sVUFBVSxhQUFhLE9BQU8sR0FBRyxTQUFTLEdBQUcsR0FBRyxHQUFHLFlBQVksTUFBTSxDQUFDO0FBQzVFLFFBQUksT0FBTyxPQUFPLFlBQVksVUFBVSxNQUFNLE9BQU87QUFDckQsUUFBSSxDQUFDLE1BQU07QUFDVCxhQUFPLE1BQU0sS0FBSyxNQUFNLFNBQVMsSUFBSTtBQUNyQyxVQUFJLE9BQU87QUFDVCxjQUFNLFVBQVUsS0FBSyxTQUFTLCtCQUErQixVQUFVO0FBQ3ZFLGNBQU0sT0FBTyxLQUFLLFNBQVMsK0JBQStCLE9BQU87QUFBQSxNQUNuRTtBQUFBLElBQ0Y7QUFDQSxXQUFPLEtBQUssS0FBTSxHQUFHLFNBQVMsR0FBRyxJQUFJLEtBQU0sS0FBTSxHQUFHLFlBQVksTUFBTSxJQUFJLEVBQUc7QUFBQSxFQUMvRTtBQUFBO0FBQUEsRUFFQSxNQUFjLG9CQUNaLE1BQ0EsVUFDQSxTQUNBLE9BQ0EsV0FDQSxRQUNBO0FBQ0EsU0FBSyxNQUFNO0FBQ1gsWUFBUSxlQUFlO0FBQ3ZCLFVBQU0sUUFBUSxTQUFTLFNBQVMsT0FBTyxLQUFLLENBQUMsY0FBYyxVQUFVLE9BQU8sT0FBTztBQUNuRixXQUFPLE9BQU8sb0JBQW9CLDBCQUEwQjtBQUM1RCxVQUFNLGFBQWEsSUFBSTtBQUFBLE1BQ3JCLENBQUMsSUFBSSxLQUFLLFdBQVcsS0FBSyxXQUFXLElBQUksS0FBSyxRQUFRLE1BQU0sUUFBUTtBQUFBLE1BQ3BFLENBQUMsU0FDQyxTQUFTLFNBQVMsT0FBTztBQUFBLFFBQ3ZCLENBQUMsY0FBYyxVQUFVLEtBQUssWUFBWSxNQUFNLEtBQUssWUFBWTtBQUFBLE1BQ25FLEdBQUc7QUFBQSxNQUNMLEtBQUssV0FBVztBQUFBLE1BQ2hCO0FBQUEsTUFDQSxNQUFNLFNBQVMsU0FBUztBQUFBLElBQzFCO0FBQ0EsVUFBTSxTQUFTLFdBQVcsa0JBQWtCLE1BQU0sRUFBRSxTQUFTLE9BQU87QUFDcEUsVUFBTSxTQUFTLE1BQU07QUFBQSxNQUNuQjtBQUFBLE1BQ0E7QUFBQSxNQUNBLE9BQU87QUFBQSxNQUNQO0FBQUEsTUFDQSxPQUFPO0FBQUEsTUFDUCxFQUFFLE1BQU0sTUFBTSxTQUFTLFFBQVEsU0FBUyxNQUFNLFlBQVksT0FBTztBQUFBLElBQ25FO0FBQ0EsU0FBSyxNQUFNO0FBQ1gsWUFBUSxlQUFlO0FBQ3ZCLFdBQU87QUFBQSxFQUNUO0FBQUE7QUFBQSxFQUVBLE1BQWMscUJBQ1osTUFDQSxVQUNBLFNBQ0EsT0FDQSxRQUNBLFFBQ0E7QUFDQSxTQUFLLE1BQU07QUFDWCxVQUFNLFFBQVEsU0FBUyxTQUFTLE9BQU8sS0FBSyxDQUFDLGNBQWMsVUFBVSxPQUFPLE9BQU87QUFDbkYsV0FBTyxPQUFPLG9CQUFvQiwwQkFBMEI7QUFDNUQsVUFBTSxXQUFXLE1BQU07QUFBQSxNQUNyQjtBQUFBLE1BQ0E7QUFBQSxNQUNBLEVBQUUsTUFBTSxNQUFNLFNBQVMsUUFBUSxTQUFTLE1BQU0sWUFBWSxPQUFPO0FBQUEsTUFDakU7QUFBQSxJQUNGO0FBQ0EsU0FBSyxNQUFNO0FBQ1gsV0FBTyxLQUFLO0FBQUEsTUFDVjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQSxTQUFTO0FBQUEsTUFDVCxTQUFTO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUE7QUFBQSxFQUVBLE1BQWMsMEJBQ1osTUFDQSxVQUNBLFNBQ0EsT0FDQSxXQUNBLFFBQ3NCO0FBQ3RCLFNBQUssTUFBTTtBQUNYLFlBQVEsZUFBZTtBQUN2QixVQUFNLFFBQVEsU0FBUyxTQUFTLE9BQU8sS0FBSyxDQUFDLGNBQWMsVUFBVSxPQUFPLE9BQU87QUFDbkYsV0FBTyxPQUFPLG9CQUFvQixzQ0FBc0M7QUFDeEUsVUFBTSxVQUFVO0FBQUEsTUFDZDtBQUFBLE1BQ0EsTUFBTSxTQUFTO0FBQUEsTUFDZixNQUFNLFlBQVk7QUFBQSxJQUNwQjtBQUNBO0FBQUEsTUFDRSxNQUFNLFFBQVEsU0FBUyxLQUNyQixVQUFVLFVBQVUsT0FDcEIsVUFBVSxTQUFTLFFBQVEsVUFBVTtBQUFBLE1BQ3ZDO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFDQSxVQUFNLFdBQVcsVUFBVSxJQUFJLENBQUMsRUFBRSxLQUFLLE9BQU8sTUFBTTtBQUNsRDtBQUFBLFFBQ0UsT0FBTyxVQUFVLEdBQUcsS0FDbEIsT0FBTyxLQUNQLE1BQU0sTUFBTSxTQUFTLFVBQ3JCLE9BQU8sVUFBVSxNQUFNLEtBQ3ZCLFVBQVUsS0FDVixTQUFTLE1BQU0sWUFBWTtBQUFBLFFBQzdCO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFDQSxhQUFPLEVBQUUsS0FBSyxPQUFPO0FBQUEsSUFDdkIsQ0FBQztBQUNELFFBQUk7QUFHSixVQUFNLGFBQWEsUUFBUSxLQUFLLENBQUMsU0FBUyxLQUFLLFVBQVUsU0FBUyxTQUFTLElBQ3ZFLG9CQUFJLElBQW9DLElBQ3hDO0FBQ0osUUFBSSxlQUFlO0FBQ25CLFVBQU0sYUFBYSxJQUFJO0FBQUEsTUFDckIsQ0FBQyxJQUFJLEtBQUssV0FBVztBQUNuQixZQUFJLE9BQU8sV0FBVyxTQUFTLFFBQVEsT0FBTyxRQUFRLFdBQVc7QUFDL0QsaUJBQU8sUUFBUSxRQUFRLFFBQVEsSUFBSTtBQUNyQyxjQUFNLFVBQVUsTUFBTSxPQUFPLFVBQVU7QUFDdkMsWUFBSSxPQUFPLFdBQVcsZ0JBQWdCLFlBQVksSUFBSSxPQUFPO0FBQzNELGlCQUFPLFFBQVEsUUFBUSxXQUFXLElBQUksT0FBTyxDQUFDO0FBQ2hELGVBQU8sS0FBSyxXQUFXLElBQUksS0FBSyxRQUFRLE1BQU0sUUFBUTtBQUFBLE1BQ3hEO0FBQUEsTUFDQSxDQUFDLFNBQ0MsU0FBUyxTQUFTLE9BQU87QUFBQSxRQUN2QixDQUFDLGNBQWMsVUFBVSxLQUFLLFlBQVksTUFBTSxLQUFLLFlBQVk7QUFBQSxNQUNuRSxHQUFHO0FBQUEsTUFDTCxLQUFLLFdBQVc7QUFBQSxNQUNoQjtBQUFBLE1BQ0EsTUFBTSxTQUFTLFNBQVM7QUFBQSxJQUMxQjtBQUNBLFVBQU0sU0FBUyxXQUFXLGtCQUFrQixNQUFNLEVBQUUsU0FBUyxPQUFPO0FBQ3BFLFVBQU0sUUFBbUYsQ0FBQztBQUMxRixVQUFNLGVBQStCLENBQUM7QUFDdEMsUUFBSSxZQUFZO0FBQ2hCLGVBQVcsRUFBRSxLQUFLLE9BQU8sS0FBSyxVQUFVO0FBQ3RDLFdBQUssTUFBTTtBQUNYLGNBQVEsZUFBZTtBQUN2QixZQUFNLE9BQU8sTUFBTTtBQUFBLFFBQ2pCLEtBQUssV0FBVyxTQUFTLEtBQUssUUFBUSxNQUFNLFVBQVUsWUFBWTtBQUFBLFFBQ2xFO0FBQUEsTUFDRjtBQUNBLGdCQUFVLEVBQUUsS0FBSyxRQUFRLEtBQUs7QUFDOUIsVUFBSTtBQUNKLFVBQUk7QUFDRixnQkFBUSxNQUFNLFVBQVUsT0FBTyxLQUFLLEtBQUssTUFBTSxHQUFHLE1BQU07QUFBQSxNQUMxRCxVQUFFO0FBQ0Esa0JBQVU7QUFBQSxNQUNaO0FBQ0EsY0FBUSxlQUFlO0FBQ3ZCO0FBQUEsUUFDRSxFQUFFLFNBQVMsT0FBTyxVQUFVLFlBQVksTUFBTSxVQUFVO0FBQUEsUUFDeEQ7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUNBLFVBQUksT0FBTyxVQUFVLFVBQVU7QUFDN0IscUJBQWEsTUFBTTtBQUNuQjtBQUFBLFVBQ0UsYUFBYTtBQUFBLFVBQ2I7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxVQUFJLGVBQWUsQ0FBQyxRQUFRLEtBQUssTUFBTSxTQUFTO0FBQzlDLG1CQUFXO0FBQUEsVUFDVCxNQUFNLE9BQU8sVUFBVTtBQUFBLFVBQ3ZCLE9BQU8sRUFBRSxPQUFPLEtBQUssT0FBTyxVQUFVLEtBQUssVUFBVSxPQUFPLEtBQUssTUFBTSxJQUFJO0FBQUEsUUFDN0U7QUFDRixZQUFNLEtBQUs7QUFBQSxRQUNUO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBLE1BQU0sTUFBTSxVQUFXLFNBQVMsU0FBUyxPQUFPLEtBQUssT0FBTyxLQUFLLENBQUMsSUFBSyxDQUFDO0FBQUEsTUFDMUUsQ0FBQztBQUFBLElBQ0g7QUFDQSxtQkFBZTtBQUNmLFVBQU0sU0FBUyxNQUFNO0FBQUEsTUFDbkI7QUFBQSxNQUNBO0FBQUEsTUFDQSxPQUFPO0FBQUEsTUFDUDtBQUFBLElBQ0Y7QUFDQSxTQUFLLE1BQU07QUFDWCxZQUFRLGVBQWU7QUFDdkIsV0FBTztBQUFBLEVBQ1Q7QUFBQTtBQUFBLEVBRUEsTUFBTSxhQUNKLFNBQ0EsS0FDQSxRQUNBLE1BQ0EsV0FDQTtBQUNBLGdDQUE0QixTQUFTLEtBQUssUUFBUSxNQUFNLFNBQVM7QUFDakUsVUFBTSxLQUFLLEtBQUssU0FBUyxTQUFTLE9BQU8sS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDckUsV0FBTyxJQUFJLG9CQUFvQixlQUFlO0FBQzlDO0FBQUEsTUFDRSxNQUFNLEdBQUcsU0FBUyxVQUFVLFNBQVMsR0FBRyxZQUFZO0FBQUEsTUFDcEQ7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLFVBQU0sT0FBTyxLQUFLLE1BQ2hCLFdBQVcsS0FBSztBQUNsQixVQUFNLFdBQVcsU0FBUyxPQUN4QixRQUFRLFdBQVcsTUFBTTtBQUMzQixVQUFNLFFBQVEsV0FBVyxHQUFHLFdBQVcsR0FBRztBQUMxQyxVQUFNLFdBQVcsV0FBVyxHQUFHLE9BQU8sR0FBRztBQUN6QyxVQUFNLFdBQVcsV0FBVyxJQUFJLElBQUksS0FBSyxTQUFTLFNBQVMsT0FBTyxLQUFLLENBQUMsQ0FBQyxJQUFJO0FBQzdFLFVBQU0sWUFBWSxHQUFHLE9BQ2xCO0FBQUEsTUFBTyxDQUFDLE1BQ1AsV0FDSSxVQUFVLEVBQUUsZUFBZSxTQUFTLEVBQUUsWUFDdEMsT0FBTyxFQUFFLFlBQVksTUFBTSxFQUFFO0FBQUEsSUFDbkMsRUFDQyxJQUFJLENBQUMsT0FBTztBQUFBLE1BQ1gsT0FBTyxXQUFXLEVBQUUsV0FBVyxFQUFFO0FBQUEsTUFDakMsS0FBSyxXQUFXLEVBQUUsU0FBUyxFQUFFO0FBQUEsTUFDN0IsS0FBSyxFQUFFO0FBQUEsTUFDUCxRQUFRLEVBQUU7QUFBQSxJQUNaLEVBQUUsRUFDRCxLQUFLLENBQUMsR0FBRyxNQUFNLEVBQUUsUUFBUSxFQUFFLEtBQUs7QUFDbkMsVUFBTSxVQUFVLENBQUNFLFdBQWtCO0FBQ2pDLFVBQUksS0FBSyxHQUNQLEtBQUssVUFBVTtBQUNqQixhQUFPLEtBQUssSUFBSTtBQUNkLGNBQU0sTUFBTyxLQUFLLE9BQVE7QUFDMUIsWUFBSSxVQUFVLEdBQUcsRUFBRSxTQUFTQSxPQUFPLE1BQUssTUFBTTtBQUFBLFlBQ3pDLE1BQUs7QUFBQSxNQUNaO0FBQ0EsWUFBTSxRQUFRLFVBQVUsS0FBSyxDQUFDO0FBQzlCLGFBQU8sU0FBU0EsU0FBUSxNQUFNLE1BQU0sUUFBUTtBQUFBLElBQzlDO0FBQ0EsVUFBTSxVQUFVLENBQUNBLFdBQ2YsQ0FBQyxVQUFVLElBQUlBLE1BQUssS0FDcEIsQ0FBQyxTQUFTLE1BQU1BLE1BQUssQ0FBQyxHQUFHLFVBQ3pCLFNBQVMsTUFBTUEsTUFBSyxDQUFDLEdBQUcsU0FBUztBQUNuQyxRQUFJLGdCQUFnQixJQUNsQjtBQUNGLFVBQU0sV0FBVyxDQUFDQSxXQUE4QztBQUM5RCxZQUFNLFFBQVEsUUFBUUEsTUFBSyxHQUN6QixJQUFJLE9BQU8sUUFBUSxXQUFXQSxTQUFRLE1BQ3RDLElBQUksT0FBTyxXQUFXLFdBQVcsU0FBU0E7QUFDNUMsWUFBTSxRQUFRLEdBQUcsU0FBUyxDQUFDLEdBQ3pCLFdBQVcsR0FBRyxZQUFZLENBQUMsR0FDM0IsVUFBVSxhQUFhLFNBQVMsT0FBTyxRQUFRO0FBQ2pELFVBQUksQ0FBQyxLQUFLLE9BQU8sT0FBTyxFQUFHLFFBQU87QUFDbEMsWUFBTSxXQUFXLENBQUMsVUFDZixLQUFLLEtBQU0sUUFBUSxLQUFNLEtBQU0sV0FBVyxFQUFHLEdBQUcsTUFBTSxRQUFRLGFBQWE7QUFDOUUsVUFBSSxZQUFZLGNBQWUsUUFBTyxTQUFTLFVBQVc7QUFDMUQsYUFBTyxLQUFLLE1BQU0sU0FBUyxJQUFJLEVBQUUsS0FBSyxDQUFDLFNBQVM7QUFDOUMscUJBQWE7QUFDYix3QkFBZ0I7QUFDaEIsZUFBTyxTQUFTLElBQUk7QUFBQSxNQUN0QixDQUFDO0FBQUEsSUFDSDtBQUNBLFVBQU0sUUFBUSxTQUFTLEtBQUssR0FDMUIsVUFBVSxPQUFPLFVBQVUsWUFBWSxRQUFRLE1BQU0sT0FDckQsYUFBYSxRQUFRLEtBQUs7QUFDNUIsU0FBSyxNQUFNO0FBQ1gsUUFBSSxRQUFRLGFBQ1IsWUFBWSxJQUNWLFdBQVcsTUFDWCxXQUFXLFFBQVEsSUFDckIsUUFBUTtBQUNaLFFBQUksT0FBTyxPQUNULFFBQXlDLFNBQ3pDLFVBQVU7QUFDWixXQUFPLFNBQVMsS0FBSyxRQUFRLE1BQU0sUUFBUTtBQUN6QyxXQUFLLE1BQU07QUFDWCxVQUFJLEVBQUUsVUFBVSxTQUFTLEdBQUc7QUFDMUIsY0FBTSxZQUFZO0FBQ2xCLGFBQUssTUFBTTtBQUFBLE1BQ2I7QUFDQSxVQUFJLENBQUMsUUFBUSxLQUFLLEdBQUc7QUFDbkIsaUJBQVM7QUFDVDtBQUFBLE1BQ0Y7QUFDQSxZQUFNLFVBQVUsU0FBUyxLQUFLO0FBQzlCLFlBQU0sU0FBUyxPQUFPLFlBQVksWUFBWSxVQUFVLE1BQU07QUFDOUQsV0FBSyxNQUFNO0FBQ1gsVUFBSSxVQUFVLFFBQVMsU0FBUSxXQUFXLFNBQVMsYUFBYTtBQUNoRSxVQUFJLFVBQVUsY0FBYyxDQUFDLE9BQVE7QUFDckMsYUFBTztBQUNQLFVBQUksVUFBVSxZQUFZLE9BQVE7QUFDbEMsZUFBUztBQUFBLElBQ1g7QUFDQSxXQUFPLEVBQUUsVUFBVSxLQUFLLFdBQVcsT0FBTyxLQUFLLFFBQVEsV0FBVyxTQUFTLEtBQUs7QUFBQSxFQUNsRjtBQUFBLEVBQ0EsTUFBTSxLQUFLLFNBQWlCLE9BQWEsU0FBUyxNQUFNLFNBQVMsTUFBTSxRQUFxQjtBQUMxRixVQUFNLEtBQUssS0FBSyxTQUFTLFNBQVMsT0FBTyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUNyRSxXQUFPLElBQUksb0JBQW9CLGVBQWU7QUFDOUMsZ0JBQVksSUFBSSxLQUFLO0FBQ3JCO0FBQUEsT0FDRyxNQUFNLFNBQVMsTUFBTSxhQUFhLE1BQU0sWUFBWSxNQUFNLGdCQUFnQjtBQUFBLE1BQzNFO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFDQSxVQUFNLFFBQW9DLENBQUMsR0FDekMsYUFBd0MsQ0FBQyxHQUN6QyxVQUFrQyxDQUFDO0FBQ3JDLFFBQUk7QUFDSixRQUFJO0FBQ0osUUFBSTtBQUNKLFFBQUksVUFBVTtBQUNkLGFBQVMsTUFBTSxNQUFNLFVBQVUsTUFBTSxNQUFNLFFBQVE7QUFDakQsZUFBUyxTQUFTLE1BQU0sYUFBYSxTQUFTLE1BQU0sV0FBVyxVQUFVO0FBQ3ZFLGFBQUssTUFBTTtBQUNYLFlBQUksRUFBRSxVQUFVLFNBQVMsR0FBRztBQUMxQixnQkFBTSxJQUFJLFFBQWMsQ0FBQyxZQUFZLFdBQVcsU0FBUyxDQUFDLENBQUM7QUFDM0QsZUFBSyxNQUFNO0FBQUEsUUFDYjtBQUNBLGNBQU0sUUFBUSxHQUFHLFNBQVMsR0FBRyxHQUMzQixXQUFXLEdBQUcsWUFBWSxNQUFNLEdBQ2hDLElBQUksSUFBSSxPQUFPLFFBQVEsR0FDdkIsVUFBVSxhQUFhLFNBQVMsT0FBTyxRQUFRO0FBQ2pELFlBQUksWUFBWSxlQUFlO0FBQzdCLHVCQUFhLE1BQU0sS0FBSyxNQUFNLFNBQVMsS0FBSyxNQUFNLE1BQU07QUFDeEQsMEJBQWdCO0FBQUEsUUFDbEI7QUFDQSxjQUFNLE9BQU8sV0FBWSxLQUFNLFFBQVEsS0FBTSxLQUFNLFdBQVcsRUFBRztBQUNqRSxZQUFJLE1BQU07QUFDUixnQkFBTSxDQUFDLElBQUk7QUFDWCxjQUFJLEtBQUssS0FBSyxhQUFhLEtBQUssU0FBUyxrQkFBa0IsS0FBSyxRQUFRO0FBQ3RFLGtCQUFNLENBQUMsSUFBSSxFQUFFLEdBQUcsS0FBSztBQUNyQixtQkFBTyxNQUFNLENBQUMsRUFBRTtBQUFBLFVBQ2xCO0FBQUEsUUFDRjtBQUNBLFlBQUksUUFBUTtBQUNWLGdCQUFNLElBQ0osTUFBTSxNQUFNLFNBQVMsWUFDakIsT0FBTyxjQUFjLEtBQUssV0FBVyxZQUFZLEtBQUssSUFBSSxHQUFHLFNBQVMsS0FBSyxNQUFNLElBQ2pGLE9BQ0UsWUFBWSxLQUFLLEtBQUssSUFDdEI7QUFDUixxQkFBVyxDQUFDLElBQUk7QUFDaEIsY0FBSTtBQUNGLG9CQUFRLENBQUMsSUFDUCxLQUNBLE9BQU8sTUFBTSxZQUNiLE1BQU0sVUFDTixLQUFLLEtBQUssYUFBYSxLQUFLLFNBQVMsaUJBQ2pDO0FBQUEsY0FDRSxZQUFZLEtBQUssTUFBTTtBQUFBLGNBQ3ZCLEtBQUs7QUFBQSxjQUNMLEtBQUssU0FBUyxTQUFTO0FBQUEsWUFDekIsSUFBSSxPQUNKO0FBQUEsY0FDRTtBQUFBLGNBQ0EsTUFBTSxnQkFDSixLQUFLLFNBQVMsU0FBUyxPQUFPLE1BQU0sV0FBVyxFQUFFLEdBQUc7QUFBQSxjQUN0RCxLQUFLLFNBQVMsU0FBUztBQUFBLFlBQ3pCO0FBQUEsUUFDVjtBQUFBLE1BQ0Y7QUFDRixXQUFPLEVBQUUsU0FBUyxPQUFPLE9BQU8sWUFBWSxTQUFTLFVBQVUsS0FBSyxLQUFLLFNBQVM7QUFBQSxFQUNwRjtBQUFBLEVBQ0EsTUFBTSxVQUFVLFNBQWlCLE9BQWEsUUFBNkM7QUFDekYsVUFBTSxTQUFTLE9BQU8sU0FBUyxPQUFPLEtBQUssT0FBTyxTQUFTLFNBQVM7QUFDcEUsVUFBTSxPQUFPLE1BQU0sS0FBSyxLQUFLLFNBQVMsT0FBTyxRQUFRLE9BQU8sU0FBUyxTQUFTLENBQUM7QUFDL0UsVUFBTSxLQUFLLEtBQUssU0FBUyxTQUFTLE9BQU8sS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDckUsVUFBTSxRQUE0QyxDQUFDO0FBQ25ELGFBQVMsTUFBTSxNQUFNLFVBQVUsTUFBTSxNQUFNLFFBQVE7QUFDakQsZUFBUyxTQUFTLE1BQU0sYUFBYSxTQUFTLE1BQU0sV0FBVyxVQUFVO0FBQ3ZFLGNBQU0sSUFBSSxJQUFJLEdBQUcsU0FBUyxHQUFHLEdBQUcsR0FBRyxZQUFZLE1BQU0sQ0FBQyxHQUNwRCxPQUFPLEtBQUssTUFBTSxDQUFDO0FBQ3JCLGNBQU0sS0FBSyxLQUFLLFdBQVcsS0FBSyxRQUFRLE1BQU0sUUFBUSxLQUFLLFdBQVcsQ0FBQyxHQUFHLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQztBQUFBLE1BQzVGO0FBQ0YsV0FBTyxFQUFFLFVBQVUsS0FBSyxLQUFLLFVBQVUsU0FBUyxPQUFPLE1BQU07QUFBQSxFQUMvRDtBQUFBLEVBQ1EsV0FDTixLQUNBLFFBQ0EsTUFDQSxRQUNBLE9BQ0EsU0FDQTtBQUNBLFVBQU0sU0FBMkMsRUFBRSxLQUFLLE9BQU87QUFDL0QsZUFBVyxTQUFTLFFBQVE7QUFDMUIsVUFBSSxVQUFVLFFBQVMsUUFBTyxRQUFRLE1BQU0sU0FBUyxFQUFFLE1BQU0sUUFBUTtBQUFBLGVBQzVELFVBQVUsUUFBUyxRQUFPLFFBQVEsU0FBUztBQUFBLGVBQzNDLFVBQVUsVUFBVyxRQUFPLFVBQVUsV0FBVztBQUFBLGVBQ2pELFVBQVU7QUFDakIsZUFBTyxRQUFRLE1BQU0sVUFBVSxLQUFLLFNBQVMsU0FBUyxPQUFPLEtBQUssT0FBTyxJQUFJLENBQUM7QUFBQSxlQUN2RSxVQUFVO0FBQ2pCLGVBQU8sZUFDTCxNQUFNLGdCQUFnQixLQUFLLFNBQVMsU0FBUyxPQUFPLE1BQU0sV0FBVyxFQUFFLEdBQUc7QUFBQSxlQUNyRSxVQUFVLE9BQVEsUUFBTyxPQUFPLE1BQU07QUFBQSxlQUN0QyxVQUFVLE9BQVEsUUFBTyxPQUFPLE1BQU07QUFBQSxJQUNqRDtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFDQSxNQUFNLFVBQ0osU0FDQSxTQUtBO0FBQ0EsVUFBTSxLQUFLLEtBQUssU0FBUyxTQUFTLE9BQU8sS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDckUsV0FBTyxJQUFJLG9CQUFvQixlQUFlO0FBQzlDLFVBQU0sV0FBVyxLQUFLLEtBQUssVUFDekIsUUFBUSxRQUFRLFNBQVMsTUFDekIsU0FBUyxRQUFRLFVBQVUsQ0FBQyxPQUFPO0FBQ3JDO0FBQUEsTUFDRSxPQUFPLFVBQVUsS0FBSyxLQUFLLFFBQVEsS0FBSyxTQUFTO0FBQUEsTUFDakQ7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLFVBQU0sU0FBUyxRQUFRO0FBQ3ZCLFFBQUk7QUFDRjtBQUFBLFFBQ0UsT0FBTyxhQUFhLFlBQVksT0FBTyxZQUFZO0FBQUEsUUFDbkQ7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUNGLFFBQUk7QUFDRjtBQUFBLFFBQ0UsT0FBTyxVQUFVLE9BQU8sTUFBTSxLQUM1QixPQUFPLFVBQVUsS0FDakIsQ0FBQyxDQUFDLEtBQUssS0FBSyxPQUFPLE9BQU8sT0FBTyxLQUNqQyxPQUFPLFFBQVEsV0FBVyxHQUFHLE9BQU8sR0FBRztBQUFBLFFBQ3pDO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFDRixVQUFNLFVBQVUsUUFBUSxXQUFXLEtBQUssWUFBWSxVQUFVLFFBQVcsR0FBRyxPQUFPLEVBQUUsQ0FBQztBQUN0RixRQUFJLENBQUMsUUFBUyxRQUFPLEVBQUUsVUFBVSxPQUFPLENBQUMsRUFBRTtBQUMzQyxVQUFNLE9BQU8sTUFBTSxLQUFLLE1BQU0sT0FBTyxHQUNuQyxTQUFTLE9BQU8sT0FBTyxLQUFLLEtBQUssRUFBRTtBQUFBLE1BQ2pDLENBQUMsR0FBRyxNQUFNLEVBQUUsUUFBUSxFQUFFLFNBQVMsRUFBRSxXQUFXLEVBQUU7QUFBQSxJQUNoRCxHQUNBLFFBQVEsUUFBUSxVQUFVO0FBQzVCLFdBQU8sU0FBUyxPQUFPLFFBQVEsb0JBQW9CLDRCQUE0QjtBQUMvRSxVQUFNLFFBQTRDLENBQUM7QUFDbkQsZUFBVyxRQUFRLE9BQU8sTUFBTSxPQUFPLFFBQVEsS0FBSyxHQUFHO0FBQ3JELFdBQUssTUFBTTtBQUNYLFlBQU0sTUFBTSxLQUFLLEtBQUssR0FBRyxRQUFRLEVBQUUsSUFBSSxLQUFLLEtBQUssR0FDL0MsU0FBUyxLQUFLLEtBQUssR0FBRyxXQUFXLEVBQUUsSUFBSSxLQUFLLFFBQVE7QUFDdEQsWUFBTSxRQUNKLE9BQU8sU0FBUyxPQUFPLEtBQUssT0FBTyxTQUFTLFNBQVMsSUFDakQsTUFBTSxLQUFLLFdBQVcsTUFBTSxTQUFTLEtBQUssTUFBTSxJQUNoRDtBQUNOLFlBQU07QUFBQSxRQUNKLEtBQUs7QUFBQSxVQUNIO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0EsT0FBTyxTQUFTLFNBQVMsSUFDckI7QUFBQSxZQUNFLFNBQ0UsT0FBTyxVQUFVLFlBQ2pCLEtBQUssVUFDTCxLQUFLLEtBQUssYUFBYSxLQUFLLFNBQVMsaUJBQ25DLFlBQVksS0FBSyxNQUFNLElBQ3RCLFNBQVM7QUFBQSxZQUNkLEtBQUssZ0JBQ0gsS0FBSyxTQUFTLFNBQVMsT0FBTyxLQUFLLFdBQVcsRUFBRSxHQUFHO0FBQUEsWUFDckQsS0FBSyxTQUFTLFNBQVM7QUFBQSxVQUN6QixLQUNHLFNBQ0QsT0FBTyxVQUFVLFlBQ2pCLEtBQUssVUFDTCxLQUFLLEtBQUssYUFBYSxLQUFLLFNBQVMsaUJBQ2pDLE9BQ0EsTUFDTjtBQUFBLFFBQ047QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFVBQU0sU0FBUyxRQUFRLE1BQU0sUUFDM0IsY0FDRSxTQUFTLE9BQU8sU0FBUyxVQUFVLEtBQUssWUFBWSxVQUFVLFNBQVMsR0FBRyxPQUFPLEVBQUUsQ0FBQztBQUN4RixXQUFPO0FBQUEsTUFDTDtBQUFBLE1BQ0E7QUFBQSxNQUNBLEdBQUksY0FDQTtBQUFBLFFBQ0UsUUFBUTtBQUFBLFVBQ047QUFBQSxVQUNBO0FBQUEsVUFDQSxTQUFTO0FBQUEsVUFDVCxRQUFRLGdCQUFnQixVQUFVLFNBQVM7QUFBQSxRQUM3QztBQUFBLE1BQ0YsSUFDQSxDQUFDO0FBQUEsSUFDUDtBQUFBLEVBQ0Y7QUFBQSxFQUNBLE1BQWMsV0FDWixTQUNBLE9BQ0EsTUFDQSxVQUNBLFlBQVksTUFDWjtBQUNBLFVBQU0sVUFBVSxRQUFRLE1BQU0sR0FBRyxFQUFFLENBQUMsR0FDbEMsS0FBSyxTQUFTLFNBQVMsT0FBTyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUM1RCxRQUFJLFFBQVEsS0FBSyxRQUFRLElBQUksRUFBRTtBQUMvQixRQUFJLENBQUMsT0FBTztBQUNWLGNBQVE7QUFBQSxRQUNOLE1BQU0sS0FBSyxLQUFLLEdBQUcsUUFBUTtBQUFBLFFBQzNCLE1BQU0sS0FBSyxLQUFLLEdBQUcsV0FBVztBQUFBLE1BQ2hDO0FBQ0EsV0FBSyxRQUFRLElBQUksSUFBSSxLQUFLO0FBQUEsSUFDNUI7QUFDQSxVQUFNLEVBQUUsTUFBTSxLQUFLLElBQUk7QUFDdkIsU0FBSyxRQUFRLElBQUksT0FBTztBQUN4QixVQUFNLFdBQVcsS0FBSyxPQUFPLE9BQU87QUFDcEMsVUFBTSxrQkFBa0IsWUFBWTtBQUNsQyxVQUFJLFlBQVksS0FBSyxVQUFVLElBQUksU0FBUyxFQUFFLEtBQUssQ0FBQyxLQUFLLEtBQUssSUFBSSxTQUFTLEVBQUUsR0FBRztBQUM5RSxjQUFNLEtBQUssR0FBRyxNQUFNLFdBQVcsQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDaEQsYUFBSyxhQUFhLEtBQUssTUFBTSxJQUFJLFNBQVMsRUFBRSxLQUFLO0FBQ2pELGFBQUssTUFBTSxPQUFPLFNBQVMsRUFBRTtBQUM3QixhQUFLLE1BQU0sT0FBTyxTQUFTLEVBQUU7QUFDN0IsYUFBSyxVQUFVLE9BQU8sU0FBUyxFQUFFO0FBQUEsTUFDbkM7QUFBQSxJQUNGO0FBQ0EsVUFBTSxXQUFXLG9CQUFJLElBQVk7QUFDakMsVUFBTSxTQUFTLG9CQUFJLElBQVk7QUFDL0IsVUFBTSxRQUFRLENBQUMsU0FBYztBQUMzQixVQUFJLEtBQUssU0FBUyxNQUFPLFVBQVMsSUFBSSxLQUFLLFNBQVMsR0FBRyxJQUFJO0FBQUEsZUFDbEQsS0FBSyxTQUFTLFNBQVM7QUFDOUIsaUJBQVMsSUFBSSxLQUFLLE1BQU0sU0FBUyxHQUFHLElBQUk7QUFDeEMsaUJBQVMsSUFBSSxLQUFLLElBQUksU0FBUyxHQUFHLElBQUk7QUFBQSxNQUN4QyxXQUFXLEtBQUssU0FBUyxRQUFTLE9BQU0sS0FBSyxLQUFLO0FBQUEsZUFDekMsS0FBSyxTQUFTLFVBQVU7QUFDL0IsY0FBTSxLQUFLLElBQUk7QUFDZixjQUFNLEtBQUssS0FBSztBQUFBLE1BQ2xCLFdBQVcsS0FBSyxTQUFTLE9BQVEsTUFBSyxLQUFLLFFBQVEsS0FBSztBQUFBLElBQzFEO0FBQ0EsUUFBSSxXQUFXLEdBQ2IsU0FBUyxHQUNULFVBQVUsR0FDVixhQUFhLEdBQ2IsUUFBUSxHQUNSLFNBQVMsR0FDVCxZQUFZO0FBQ2QsZUFBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLE9BQU8sUUFBUSxLQUFLLEdBQUc7QUFDMUMsVUFDRSxFQUFFLE1BQU0sU0FBUyxXQUNqQixFQUFFLFlBQVksVUFDZCxFQUFFLGlCQUFpQixVQUNuQixFQUFFLFNBQVMsVUFDWCxFQUFFLFNBQVMsUUFDWDtBQUNBLGVBQU8sTUFBTSxDQUFDO0FBQ2Q7QUFBQSxNQUNGO0FBQ0E7QUFDQSxZQUFNLFNBQVMsRUFBRSxRQUFRO0FBQ3pCLFVBQUksU0FBUyxHQUFJLFdBQVUsS0FBSztBQUFBLFVBQzNCLFlBQVcsS0FBTSxTQUFTO0FBQy9CLG9CQUFjLEtBQUssRUFBRSxXQUFXO0FBQ2hDLFVBQUksRUFBRSxZQUFZLE9BQVcsUUFBTyxJQUFJLEVBQUUsT0FBTztBQUNqRCxVQUFJLEVBQUUsTUFBTSxTQUFTLFFBQVM7QUFDOUIsZUFBUyxLQUFLLElBQUksUUFBUSxLQUFLLElBQUksRUFBRSxLQUFLLElBQUssQ0FBQztBQUNoRCxrQkFBWSxLQUFLLElBQUksV0FBVyxLQUFLLElBQUksRUFBRSxRQUFRLElBQUssQ0FBQztBQUN6RCxVQUFJLEVBQUUsTUFBTSxTQUFTLFdBQVc7QUFDOUIsWUFBSTtBQUNGLGdCQUFNLGFBQWEsRUFBRSxNQUFNLFVBQVUsQ0FBQztBQUFBLFFBQ3hDLFFBQVE7QUFDTixtQkFBUyxJQUFJLEdBQUc7QUFBQSxRQUNsQjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsUUFBSSxDQUFDLFVBQVU7QUFDYixhQUFPLEtBQUssT0FBTyxPQUFPO0FBQzFCLFlBQU0sZ0JBQWdCO0FBQ3RCO0FBQUEsSUFDRjtBQUNBLFVBQU0sVUFBVSxZQUFZLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDN0MsVUFBTSxLQUFLLE1BQU0sS0FBSyxTQUFTLFNBQVMsS0FBSyxNQUFNO0FBQ25ELFNBQUssaUJBQWlCLElBQUksRUFBRTtBQUM1QixVQUFNLE9BQU8sV0FBVyxHQUFHLFNBQVMsRUFBRTtBQUN0QyxTQUFLLE9BQU8sT0FBTyxJQUFJO0FBQUEsTUFDckI7QUFBQSxNQUNBLE9BQU8sS0FBSyxNQUFNLElBQUksRUFBRTtBQUFBLE1BQ3hCO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBLFNBQVMsV0FBVyxZQUFZLEdBQUcsU0FBUyxFQUFFLElBQUksSUFBSSxTQUFTLEdBQUcsR0FBRyxJQUFJO0FBQUEsTUFDekUsWUFBWSxlQUFlO0FBQUEsTUFDM0IsR0FBSSxTQUFTLE9BQU8sRUFBRSxVQUFVLENBQUMsR0FBRyxRQUFRLEVBQUUsSUFBSSxDQUFDO0FBQUEsTUFDbkQsR0FBSSxPQUFPLE9BQU8sRUFBRSxRQUFRLENBQUMsR0FBRyxNQUFNLEVBQUUsSUFBSSxDQUFDO0FBQUEsSUFDL0M7QUFDQSxRQUFJLFdBQVc7QUFDYixZQUFNLE9BQU8sWUFBWSxPQUFPO0FBQ2hDLFdBQUssTUFBTSxJQUFJLElBQUksTUFBTSxLQUFLLEtBQUs7QUFBQSxJQUNyQztBQUNBLFVBQU0sZ0JBQWdCO0FBQUEsRUFDeEI7QUFBQSxFQUNBLE1BQU0sUUFBUSxVQUE0QixTQUFTLEtBQUssS0FBSyxRQUFRO0FBQ25FLFdBQU8sS0FBSyxRQUFRLGFBQWEsaUNBQWlDO0FBQ2xFLFNBQUssWUFBWTtBQUNqQixTQUFLLGNBQWMsQ0FBQztBQUNwQixTQUFLLFFBQVEsTUFBTTtBQUNuQixTQUFLLFVBQVUsTUFBTTtBQUNyQixTQUFLLEtBQUssTUFBTTtBQUVoQixVQUFNLFdBQXFCO0FBQUEsTUFDekIsZ0JBQWdCLFNBQVM7QUFBQSxNQUN6QixVQUFVLGlCQUFpQjtBQUFBLFFBQ3pCLEdBQUc7QUFBQSxRQUNILFFBQVEsU0FBUyxPQUFPLElBQUksQ0FBQyxPQUFPLEVBQUUsR0FBRyxHQUFHLE9BQU8sQ0FBQyxFQUFFLEVBQUU7QUFBQSxNQUMxRCxDQUFDO0FBQUEsTUFDRCxVQUFVLENBQUM7QUFBQSxJQUNiO0FBQ0EsVUFBTSxPQUFhO0FBQUEsTUFDakIsTUFBTTtBQUFBLE1BQ04sUUFBUSxDQUFDO0FBQUEsTUFDVCxVQUFVLFNBQVM7QUFBQSxNQUNuQixNQUFNLENBQUM7QUFBQSxNQUNQLFFBQVEsQ0FBQztBQUFBLE1BQ1QsY0FBYztBQUFBLE1BQ2Q7QUFBQSxJQUNGO0FBQ0EsVUFBTSxNQUFNLE1BQU0sS0FBSyxRQUFRO0FBQy9CLGVBQVcsV0FBVyxPQUFPLEtBQUssS0FBSyxLQUFLLE1BQU0sRUFBRyxNQUFLLFFBQVEsSUFBSSxPQUFPO0FBQzdFLFFBQUk7QUFDRixpQkFBVyxNQUFNLFNBQVMsUUFBUTtBQUNoQyxjQUFNLE9BQU8sSUFBSSxJQUFJLEdBQUcsU0FBUyxJQUFJLENBQUMsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUN0RCxPQUFPLElBQUksSUFBSSxHQUFHLFlBQVksSUFBSSxDQUFDLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDdkQsY0FBTSxVQUFVLG9CQUFJLElBQXdDO0FBRTVELG1CQUFXLENBQUMsR0FBRyxDQUFDLEtBQUssT0FBTyxRQUFRLEdBQUcsS0FBSyxHQUFHO0FBQzdDLGdCQUFNLElBQUksS0FBSyxJQUFJLEVBQUUsS0FBSyxHQUN4QixNQUFNLEtBQUssSUFBSSxFQUFFLFFBQVE7QUFDM0I7QUFBQSxZQUNFLE1BQU0sVUFBYSxRQUFRLFVBQWEsTUFBTSxJQUFJLEVBQUUsT0FBTyxFQUFFLFFBQVE7QUFBQSxZQUNyRTtBQUFBLFlBQ0E7QUFBQSxVQUNGO0FBQ0EsZ0JBQU0sSUFBSSxhQUFhLEdBQUcsSUFBSSxFQUFFLE9BQU8sRUFBRSxRQUFRO0FBQ2pELGNBQUksQ0FBQyxRQUFRLElBQUksQ0FBQyxFQUFHLFNBQVEsSUFBSSxHQUFHLENBQUMsQ0FBQztBQUN0QyxrQkFBUSxJQUFJLENBQUMsRUFBRyxDQUFDLElBQUk7QUFBQSxRQUN2QjtBQUNBLFlBQUksSUFBSTtBQUNSLG1CQUFXLENBQUMsU0FBUyxLQUFLLEtBQUssU0FBUztBQUN0QywyQkFBaUI7QUFBQSxZQUNmLEdBQUcsU0FBUztBQUFBLFlBQ1osUUFBUSxTQUFTLFNBQVMsT0FBTyxJQUFJLENBQUMsTUFBTyxFQUFFLE9BQU8sR0FBRyxLQUFLLEVBQUUsR0FBRyxHQUFHLE1BQU0sSUFBSSxDQUFFO0FBQUEsVUFDcEYsQ0FBQztBQUNELGdCQUFNLEtBQUssV0FBVyxTQUFTLE9BQU8sTUFBTSxRQUFRO0FBQ3BELGVBQUssU0FBUyxFQUFFLE9BQU8sVUFBVSxXQUFXLEVBQUUsR0FBRyxPQUFPLFFBQVEsS0FBSyxDQUFDO0FBQUEsUUFDeEU7QUFBQSxNQUNGO0FBQ0EsWUFBTSxLQUFLLFFBQVEsTUFBTSxRQUFRO0FBQ2pDLFdBQUssT0FBTyxNQUFNLEtBQUssU0FBUyxlQUFlLFFBQVEsR0FBRyxNQUFNO0FBQ2hFLFlBQU0sS0FBSyxRQUFRLE1BQU0sUUFBUTtBQUNqQyxZQUFNLEtBQUssUUFBUSxDQUFDLEdBQUcsS0FBSyxHQUFHLEtBQUssV0FBVyxDQUFDO0FBQ2hELGFBQU8sS0FBSyxLQUFLO0FBQUEsSUFDbkIsU0FBUyxPQUFPO0FBQ2QsWUFBTSxLQUFLLFFBQVEsS0FBSyxXQUFXO0FBQ25DLFlBQU07QUFBQSxJQUNSO0FBQUEsRUFDRjtBQUFBLEVBQ0EsTUFBTSxXQUFXLE9BQWtDLFNBQVMsS0FBSyxLQUFLLFFBQVE7QUFDNUUsV0FBTyxLQUFLLGFBQWEsT0FBTyxNQUFNO0FBQUEsRUFDeEM7QUFBQTtBQUFBLEVBRUEsTUFBTSwrQkFBK0IsT0FBbUIsU0FBUyxLQUFLLEtBQUssUUFBUTtBQUNqRjtBQUFBLE1BQ0UsT0FBTyxVQUFVLFlBQVksaUJBQWlCLFFBQVEsaUJBQWlCO0FBQUEsTUFDdkU7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLFdBQU8sS0FBSyxhQUFhLE9BQU8sUUFBUSwyQkFBMkI7QUFBQSxFQUNyRTtBQUFBLEVBQ0EsTUFBYyxhQUNaLE9BQ0EsUUFDQSxpQkFDQTtBQUNBLFdBQU8sS0FBSyxRQUFRLGFBQWEsaUNBQWlDO0FBQ2xFLFNBQUssTUFBTTtBQUNYLFNBQUssY0FBYyxDQUFDO0FBQ3BCLFNBQUssUUFBUSxNQUFNO0FBQ25CLFNBQUssVUFBVSxNQUFNO0FBQ3JCLFNBQUssS0FBSyxNQUFNO0FBQ2hCLFVBQU0sTUFBTSxNQUFNLEtBQUssUUFBUTtBQUMvQixTQUFLLE1BQU07QUFDWCxlQUFXLFdBQVcsT0FBTyxLQUFLLEtBQUssS0FBSyxNQUFNLEVBQUcsTUFBSyxRQUFRLElBQUksT0FBTztBQUM3RSxRQUFJLE1BQ0YsZ0JBQ0EsU0FBUztBQUNYLFVBQU0sVUFBVSxHQUFHLEtBQUssRUFBRTtBQUMxQixRQUFJLGlCQUFpQjtBQUNyQixVQUFNLG1CQUFtQixZQUFZLElBQUk7QUFDekMsVUFBTSxTQUFTLElBQUksZ0JBQWdCO0FBQ25DLFNBQUssYUFBYTtBQUNsQixVQUFNLFFBQVEsT0FBTyxPQUFnQixTQUFTLE9BQU87QUFDbkQsV0FBSyxNQUFNO0FBQ1gsWUFBTSxTQUFpQztBQUFBLFFBQ3JDLEdBQUcsT0FBTyxJQUFJLE9BQU8sUUFBUSxFQUFFLFNBQVMsSUFBSSxHQUFHLENBQUMsR0FBRyxNQUFNO0FBQUEsUUFDekQ7QUFBQSxNQUNGO0FBQ0EsV0FBSyxnQkFBZ0IsWUFBWSxPQUFPLENBQUMsR0FBRyxPQUFPLENBQUMsQ0FBQztBQUNyRDtBQUFBLFFBQ0UsS0FBSyxZQUFZLEtBQUssZ0JBQWdCO0FBQUEsUUFDdEM7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUNBLFlBQU0sYUFBYSxZQUFZLElBQUk7QUFDbkMsWUFBTSxLQUFLLEdBQUcsTUFBTSxXQUFXLENBQUMsTUFBTSxHQUFHLENBQUMsR0FBRyxPQUFPLE1BQU07QUFDMUQsd0JBQWtCLFlBQVksSUFBSSxJQUFJO0FBQ3RDLFdBQUssU0FBUyxFQUFFLE9BQU8sZ0JBQWdCLFdBQVcsT0FBTyxDQUFDO0FBQUEsSUFDNUQ7QUFDQSxRQUFJO0FBQ0YsVUFBSSxTQUFTLE9BQU8sVUFBVSxZQUFZLFlBQVksT0FBTztBQUMzRCx5QkFBaUIsUUFBUTtBQUFBLFVBQ3RCLE1BQWdGO0FBQUEsVUFDakYsRUFBRSxRQUFRLE9BQU8sT0FBTztBQUFBLFFBQzFCLEdBQUc7QUFDRCxjQUFJLGNBQWMsTUFBTTtBQUN0QixtQkFBTyxLQUFLO0FBQ1osNkJBQWlCLEtBQUs7QUFBQSxVQUN4QixPQUFPO0FBQ0wsa0JBQU0sTUFBTSxLQUFLLE9BQU8sSUFBSSxLQUFLLEtBQUssSUFBSSxLQUFLLEdBQUcsSUFBSSxLQUFLLE1BQU0sRUFBRTtBQUFBLFVBQ3JFO0FBQUEsUUFDRjtBQUFBLE1BQ0YsV0FDRSxPQUFPLFVBQVUsWUFDakIsaUJBQWlCLFFBQ2pCLGlCQUFpQixnQkFDakI7QUFDQSx5QkFBaUIsUUFBUSxrQkFBa0IsT0FBTyxFQUFFLFFBQVEsT0FBTyxPQUFPLENBQUMsR0FBRztBQUM1RSxjQUFJLFdBQVcsS0FBTSxPQUFNLE1BQU0sSUFBSTtBQUFBLGNBQ2hDLFFBQU8sa0JBQWtCLGdCQUFnQixLQUFLLFFBQVEsSUFBSSxLQUFLO0FBQUEsUUFDdEU7QUFBQSxNQUNGLE9BQU87QUFDTCxlQUFPLFNBQVMsTUFBTSxRQUFRLE1BQU0sTUFBTSxHQUFHLG9CQUFvQix1QkFBdUI7QUFDeEYsZUFBTyxFQUFFLEdBQUcsT0FBTyxRQUFRLE1BQU0sT0FBTyxJQUFJLENBQUMsUUFBUSxFQUFFLEdBQUcsSUFBSSxRQUFRLENBQUMsRUFBRSxFQUFFLEVBQUU7QUFDN0UsaUJBQVMsSUFBSSxHQUFHLElBQUksTUFBTSxPQUFPLFFBQVE7QUFDdkMscUJBQVcsU0FBUyxNQUFNLE9BQU8sQ0FBQyxFQUFFLE9BQVEsT0FBTSxNQUFNLEVBQUUsT0FBTyxHQUFHLE1BQU0sQ0FBQztBQUFBLE1BQy9FO0FBQ0EsV0FBSyxTQUFTO0FBQUEsUUFDWixPQUFPO0FBQUEsUUFDUCxXQUFXO0FBQUEsUUFDWCxXQUFXLFlBQVksSUFBSSxJQUFJO0FBQUEsTUFDakMsQ0FBQztBQUNELFdBQUssU0FBUztBQUFBLFFBQ1osT0FBTztBQUFBLFFBQ1AsV0FBVztBQUFBLFFBQ1gsV0FBVztBQUFBLE1BQ2IsQ0FBQztBQUNELFdBQUssTUFBTTtBQUNYLGFBQU8sTUFBTSxvQkFBb0IsMkJBQTJCO0FBQzVELFlBQU0sV0FBVyxrQkFBa0IsbUJBQW1CLElBQUk7QUFDMUQsZUFBUyxhQUFhLEtBQUs7QUFFM0IsZUFBUyxXQUFXLEtBQUssS0FBSyxPQUFPLEtBQUssS0FBSyxXQUFXLElBQUksS0FBSztBQUNuRSxZQUFNLFdBQXFCLEVBQUUsVUFBVSxnQkFBZ0IsU0FBUyxVQUFVLFVBQVUsQ0FBQyxFQUFFO0FBQ3ZGLFlBQU0sT0FBYTtBQUFBLFFBQ2pCLE1BQU07QUFBQSxRQUNOLFFBQVEsQ0FBQztBQUFBLFFBQ1QsVUFBVSxTQUFTO0FBQUEsUUFDbkIsTUFBTSxDQUFDO0FBQUEsUUFDUCxRQUFRLENBQUM7QUFBQSxRQUNULGNBQWM7QUFBQSxRQUNkO0FBQUEsTUFDRjtBQUNBLFlBQU0sU0FBUyxPQUFPLEtBQUssU0FBUyxNQUFNLEdBQ3hDLFdBQVcsaUJBQWlCLElBQUksSUFBSSxNQUFNLElBQUksUUFDOUMsT0FBTyxTQUFTLE9BQU8sSUFBSSxDQUFDLE9BQU8sSUFBSSxJQUFJLEdBQUcsUUFBUSxDQUFDLEdBQ3ZELFVBQVUsU0FBUyxPQUFPLElBQUksQ0FBQyxPQUFPLElBQUksSUFBSSxHQUFHLFdBQVcsQ0FBQztBQUcvRCxZQUFNLFlBQVksU0FBUyxPQUFPLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxNQUFNLE1BQU07QUFDaEUsVUFBSSxZQUFZO0FBQ2hCLFlBQU0sT0FBTyxvQkFBSSxJQUFZO0FBQzdCLFlBQU0sUUFBUTtBQUFBLFFBQ1osdUJBQXVCO0FBQUEsUUFDdkIsaUJBQWlCO0FBQUEsUUFDakIsZ0JBQWdCO0FBQUEsUUFDaEIseUJBQXlCO0FBQUEsTUFDM0I7QUFDQSxVQUFJLFdBQVcsWUFBWSxJQUFJO0FBQy9CLHVCQUFpQixTQUFTLEtBQUssR0FBRyxLQU1oQyxXQUFXLFlBQVksT0FBTyxHQUFHLElBQUksT0FBTyxJQUFJLEdBQUc7QUFDbkQsY0FBTSxXQUFXLFlBQVksSUFBSTtBQUNqQyxjQUFNLHFCQUFxQixLQUFLLFdBQVc7QUFDM0MsbUJBQVcsQ0FBQyxJQUFJLElBQUksS0FBSyxPQUFPO0FBQzlCLGdCQUFNLFdBQVcsWUFBWSxJQUFJO0FBQ2pDLGVBQUssTUFBTTtBQUNYLGdCQUFNLFNBQVMsZ0JBQWdCO0FBQy9CLGdCQUFNLENBQUMsT0FBTyxLQUFLLE1BQU0sSUFBSSxTQUN6QixPQUFPLEVBQUUsRUFBRSxNQUFNLEdBQUcsRUFBRSxNQUFNLEVBQUUsRUFBRSxJQUFJLE1BQU0sSUFDMUMsQ0FBQyxLQUFLLE9BQU8sS0FBSyxNQUFNLEtBQUssS0FBSyxNQUFNLE1BQU07QUFDbEQ7QUFBQSxZQUNFLE9BQU8sVUFBVSxLQUFLLEtBQUssQ0FBQyxDQUFDLFNBQVMsT0FBTyxLQUFLLEtBQUssV0FBVyxDQUFDLENBQUM7QUFBQSxZQUNwRTtBQUFBLFlBQ0E7QUFBQSxVQUNGO0FBQ0EsZ0JBQU0sS0FBSyxTQUFTLE9BQU8sS0FBSyxHQUM5QixVQUFVLEdBQUcsR0FBRyxFQUFFLElBQUksR0FBRyxJQUFJLE1BQU07QUFDckMsaUJBQU8sQ0FBQyxLQUFLLElBQUksT0FBTyxHQUFHLG9CQUFvQiwwQkFBMEI7QUFDekUsZUFBSyxJQUFJLE9BQU87QUFDaEIsZ0JBQU0sUUFBUSxTQUNWLHlCQUF5QixNQUFNLEtBQUssUUFBUSxLQUFLLEtBQUssR0FBRyxRQUFRLEtBQUssR0FBRyxRQUFTLElBQ2xGLGdCQUFnQixLQUFLLE9BQU8sUUFBUSxLQUFLLEtBQUssR0FBRyxRQUFRLEtBQUssQ0FBQztBQUNuRSxnQkFBTSxVQUFVLFlBQVksSUFBSTtBQUNoQyxnQkFBTSxlQUFlLEtBQUssVUFBVTtBQUNwQyxnQkFBTSxLQUFLLFdBQVcsU0FBUyxPQUFPLE1BQU0sVUFBVSxTQUFTO0FBQy9ELGdCQUFNLFNBQVMsWUFBWSxJQUFJO0FBQy9CLGdCQUFNLGNBQWMsS0FBSyxTQUFTO0FBQ2xDLGdCQUFNLEtBQUssR0FBRyxNQUFNLFdBQVcsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO0FBQ3ZDLGdCQUFNLHVCQUF1QixLQUFLLFlBQVksSUFBSSxJQUFJO0FBQ3RELGVBQUssZ0JBQWdCLFlBQVksSUFBSSxJQUFJO0FBQ3pDLGVBQUssU0FBUyxFQUFFLE9BQU8sZ0JBQWdCLFdBQVcsRUFBRSxXQUFXLE9BQU8sT0FBTyxDQUFDO0FBQUEsUUFDaEY7QUFDQSxtQkFBVyxZQUFZLElBQUk7QUFBQSxNQUM3QjtBQUNBLFlBQU0scUJBQXFCLEtBQUssWUFBWSxJQUFJLElBQUk7QUFDcEQsaUJBQVcsQ0FBQyxPQUFPLFNBQVMsS0FBSyxPQUFPLFFBQVEsS0FBSztBQUNuRCxhQUFLLFNBQVMsRUFBRSxPQUFPLFdBQVcsV0FBVyxPQUFPLE9BQU8sQ0FBQztBQUM5RCxZQUFNLEtBQUssUUFBUSxNQUFNLFFBQVE7QUFDakMsV0FBSyxPQUFPLE1BQU0sS0FBSyxTQUFTLGVBQWUsUUFBUSxHQUFHLE1BQU07QUFDaEUsWUFBTSxLQUFLLFFBQVEsTUFBTSxRQUFRO0FBQ2pDLFlBQU0sS0FBSyxRQUFRLENBQUMsR0FBRyxLQUFLLEdBQUcsS0FBSyxXQUFXLENBQUM7QUFDaEQsYUFBTyxLQUFLLEtBQUs7QUFBQSxJQUNuQixTQUFTLE9BQU87QUFDZCxZQUFNLEtBQUssUUFBUSxLQUFLLFdBQVc7QUFDbkMsWUFBTTtBQUFBLElBQ1IsVUFBRTtBQUNBLFdBQUssYUFBYTtBQUNsQixVQUFJO0FBQ0YsY0FBTSxLQUFLLEdBQUcsTUFBTSxXQUFXLENBQUMsR0FBRyxDQUFDLFlBQVksT0FBTyxDQUFDLENBQUM7QUFDekQsYUFBSyxlQUFlO0FBQUEsTUFDdEIsUUFBUTtBQUdOLGFBQUssV0FBVztBQUFBLE1BQ2xCO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLGFBQWEsT0FBdUQ7QUFDbEUsV0FBTyxLQUFLLFdBQVcsRUFBRSxRQUFRLE1BQU0sQ0FBNEI7QUFBQSxFQUNyRTtBQUFBLEVBQ0EsTUFBTSxTQUFTLE9BQWUsUUFBZ0I7QUFDNUMsV0FBTyxLQUFLLFFBQVEsYUFBYSxpQ0FBaUM7QUFDbEU7QUFBQSxNQUNFLE9BQU8sY0FBYyxLQUFLLEtBQUssUUFBUSxLQUFLLFNBQVM7QUFBQSxNQUNyRDtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsU0FBSyxZQUFZO0FBQ2pCLFNBQUssY0FBYyxDQUFDO0FBQ3BCLFNBQUssUUFBUSxNQUFNO0FBQ25CLFNBQUssVUFBVSxNQUFNO0FBQ3JCLFNBQUssS0FBSyxNQUFNO0FBQ2hCLFVBQU0sV0FBcUIsZ0JBQWdCLEtBQUssUUFBUTtBQUN4RCxVQUFNLEtBQUssU0FBUyxTQUFTLE9BQU8sQ0FBQztBQUNyQyxPQUFHLFdBQVcsTUFBTSxLQUFLLEVBQUUsUUFBUSxLQUFLLEtBQUssUUFBUSxHQUFHLEVBQUUsR0FBRyxDQUFDLEdBQUcsTUFBTSxDQUFDO0FBQ3hFLE9BQUcsY0FBYyxNQUFNLEtBQUssRUFBRSxRQUFRLElBQUksR0FBRyxDQUFDLEdBQUcsTUFBTSxDQUFDO0FBQ3hELE9BQUcsWUFBWSxHQUFHLFNBQVM7QUFDM0IsT0FBRyxlQUFlLEdBQUcsWUFBWTtBQUNqQyxPQUFHLFFBQVEsQ0FBQztBQUNaLE9BQUcsT0FBTyxDQUFDO0FBQ1gsT0FBRyxVQUFVLENBQUM7QUFDZCxPQUFHLFNBQVMsQ0FBQztBQUNiLE9BQUcsU0FBUyxFQUFFLE1BQU0sR0FBRyxTQUFTLEVBQUU7QUFDbEMsT0FBRyxTQUFTO0FBQ1osYUFBUyxTQUFTLFNBQVMsQ0FBQyxFQUFFO0FBQzlCLGFBQVMsU0FBUyxhQUFhLENBQUMsR0FBRyxFQUFFO0FBQ3JDLGFBQVMsU0FBUyxTQUFTLENBQUM7QUFDNUIsYUFBUyxXQUFXLENBQUM7QUFDckIsVUFBTSxPQUFhO0FBQUEsTUFDakIsTUFBTTtBQUFBLE1BQ04sUUFBUSxDQUFDO0FBQUEsTUFDVCxVQUFVLEtBQUssS0FBSyxXQUFXO0FBQUEsTUFDL0IsTUFBTSxDQUFDO0FBQUEsTUFDUCxRQUFRLENBQUM7QUFBQSxNQUNULGNBQWM7QUFBQSxNQUNkO0FBQUEsSUFDRjtBQUNBLFVBQU0sTUFBTSxNQUFNLEtBQUssUUFBUTtBQUMvQixlQUFXLFdBQVcsT0FBTyxLQUFLLEtBQUssS0FBSyxNQUFNLEVBQUcsTUFBSyxRQUFRLElBQUksT0FBTztBQUM3RSxRQUFJO0FBQ0YsZUFBUyxJQUFJLEdBQUcsSUFBSSxHQUFHLFNBQVMsUUFBUSxLQUFLO0FBQzNDLGlCQUFTLElBQUksR0FBRyxJQUFJLEtBQUssS0FBSyxlQUFlO0FBQzNDLGdCQUFNLFFBQW9DLENBQUM7QUFDM0MsbUJBQVMsTUFBTSxHQUFHLE1BQU0sS0FBSyxJQUFJLElBQUksWUFBWSxHQUFHLFNBQVMsTUFBTSxHQUFHO0FBQ3BFLHFCQUFTLFNBQVMsR0FBRyxTQUFTLEtBQUssSUFBSSxJQUFJLGVBQWUsR0FBRyxHQUFHLFVBQVU7QUFDeEUsb0JBQU0sSUFBSSxNQUFNLE1BQU07QUFDdEIsa0JBQUksS0FBSyxNQUFPO0FBQ2hCLG9CQUFNLElBQUksYUFBYSxDQUFDO0FBQ3hCLG9CQUFNLElBQUksR0FBRyxTQUFTLEdBQUcsR0FBRyxHQUFHLFlBQVksTUFBTSxDQUFDLENBQUMsSUFBSTtBQUFBLGdCQUNyRCxPQUFPLEdBQUcsU0FBUyxHQUFHO0FBQUEsZ0JBQ3RCLFVBQVUsR0FBRyxZQUFZLE1BQU07QUFBQSxnQkFDL0IsT0FDRSxPQUFPLE1BQU0sV0FDVCxFQUFFLE1BQU0sVUFBVSxPQUFPLEVBQUUsSUFDM0IsT0FBTyxNQUFNLFlBQ1gsRUFBRSxNQUFNLFdBQVcsT0FBTyxFQUFFLElBQzVCLEVBQUUsTUFBTSxVQUFVLE9BQU8sRUFBRTtBQUFBLGNBQ3JDO0FBQUEsWUFDRjtBQUNGLGdCQUFNLEtBQUssV0FBVyxhQUFhLEdBQUcsSUFBSSxHQUFHLENBQUMsR0FBRyxPQUFPLE1BQU0sUUFBUTtBQUN0RSxlQUFLLFNBQVM7QUFBQSxZQUNaLE9BQU87QUFBQSxZQUNQLFdBQVcsS0FBSyxJQUFJLFFBQVEsSUFBSSxjQUFjLEdBQUc7QUFBQSxZQUNqRCxPQUFPO0FBQUEsVUFDVCxDQUFDO0FBQUEsUUFDSDtBQUNGLFdBQUssT0FBTyxNQUFNLEtBQUssU0FBUyxlQUFlLFFBQVEsR0FBRyxNQUFNO0FBQ2hFLFlBQU0sS0FBSyxRQUFRLE1BQU0sUUFBUTtBQUNqQyxZQUFNLEtBQUssUUFBUSxDQUFDLEdBQUcsS0FBSyxHQUFHLEtBQUssV0FBVyxDQUFDO0FBQ2hELGFBQU8sS0FBSyxLQUFLO0FBQUEsSUFDbkIsU0FBUyxPQUFPO0FBQ2QsWUFBTSxLQUFLLFFBQVEsS0FBSyxXQUFXO0FBQ25DLFlBQU07QUFBQSxJQUNSO0FBQUEsRUFDRjtBQUFBLEVBQ0EsTUFBYyxRQUFRLE1BQVksVUFBb0I7QUFDcEQsYUFBUyxXQUFXLENBQUM7QUFDckIsUUFBSSxDQUFDLFNBQVMsU0FBUyxPQUFPLEtBQUssQ0FBQyxVQUFVLE1BQU0sTUFBTSxFQUFHO0FBQzdELFNBQUssV0FBVyxNQUFNO0FBQ3RCLFVBQU0sYUFBYSxJQUFJO0FBQUEsTUFDckIsQ0FBQyxPQUFPLEtBQUssV0FBVyxLQUFLLFdBQVcsT0FBTyxLQUFLLFFBQVEsTUFBTSxRQUFRO0FBQUEsTUFDMUUsQ0FBQyxTQUNDLFNBQVMsU0FBUyxPQUFPLEtBQUssQ0FBQyxNQUFNLEVBQUUsS0FBSyxZQUFZLE1BQU0sS0FBSyxZQUFZLENBQUMsR0FBRztBQUFBLE1BQ3JGLEtBQUssV0FBVztBQUFBLE1BQ2hCO0FBQUEsTUFDQSxNQUFNLFNBQVMsU0FBUztBQUFBLElBQzFCO0FBQ0EsZUFBVyxNQUFNLFNBQVMsU0FBUztBQUNqQyxVQUFJLEdBQUcsUUFBUTtBQUNiLGNBQU0sU0FBbUIsQ0FBQztBQUMxQixjQUFNLFNBQVMsR0FBRztBQUNsQixjQUFNLFFBQVEsWUFBWSxTQUFTLE9BQU8sTUFBTSxZQUFZLElBQUk7QUFDaEUsY0FBTSxXQUNKLGNBQWMsU0FDVixPQUFPLFNBQVMsSUFBSSxDQUFDLGVBQWU7QUFBQSxVQUNsQztBQUFBLFVBQ0EsYUFDRSxXQUFXLGFBQWEsT0FBTyxVQUFVLFVBQVUsV0FDL0MsVUFBVSxNQUFNLFlBQVksSUFDNUI7QUFBQSxRQUNSLEVBQUUsSUFDRixDQUFDO0FBQ1AsWUFBSTtBQUNGLGdCQUFNLGFBQWEsWUFBWSxTQUFTLElBQUksT0FBTztBQUNuRCxtQkFBUyxNQUFNLFlBQVksTUFBTSxHQUFHLFNBQVMsUUFBUSxPQUFPO0FBQzFELGlCQUFLLE1BQU07QUFDWCxnQkFBSTtBQUNKLGdCQUFJLFlBQVksUUFBUTtBQUN0QixvQkFBTSxJQUFJLE1BQU0sS0FBSyxXQUFXLEdBQUcsSUFBSSxLQUFLLE9BQU8sUUFBUSxNQUFNLFFBQVE7QUFDekUsb0JBQU0sUUFBUSxNQUFNLFdBQVcsTUFBTSxHQUFHLElBQUksS0FBSyxPQUFPLE1BQU07QUFDOUQ7QUFBQSxnQkFDRSxFQUFFLFNBQVMsT0FBTyxVQUFVLFlBQVksTUFBTSxVQUFVO0FBQUEsZ0JBQ3hEO0FBQUEsZ0JBQ0E7QUFBQSxjQUNGO0FBQ0Esd0JBQVU7QUFBQSxnQkFDUjtBQUFBLGdCQUNBLEdBQUcsZ0JBQWdCLFNBQVMsU0FBUyxPQUFPLEdBQUcsV0FBVyxFQUFFLEdBQUc7QUFBQSxnQkFDL0QsU0FBUyxTQUFTO0FBQUEsY0FDcEIsRUFDRyxZQUFZLEVBQ1osU0FBUyxLQUFNO0FBQUEsWUFDcEIsT0FBTztBQUNMLHdCQUFVLE9BQU8sU0FBUztBQUMxQixvQkFBTSxTQUFTLG9CQUFJLElBQXVCO0FBQzFDLHlCQUFXLEVBQUUsV0FBVyxZQUFZLEtBQUssVUFBVTtBQUNqRCxvQkFBSSxDQUFDLE9BQU8sSUFBSSxVQUFVLE1BQU0sR0FBRztBQUNqQyx3QkFBTSxRQUFRLE1BQU0sV0FBVyxNQUFNLEdBQUcsSUFBSSxLQUFLLFVBQVUsTUFBTTtBQUNqRTtBQUFBLG9CQUNFLEVBQUUsU0FBUyxPQUFPLFVBQVUsWUFBWSxNQUFNLFVBQVU7QUFBQSxvQkFDeEQ7QUFBQSxvQkFDQTtBQUFBLGtCQUNGO0FBQ0EseUJBQU8sSUFBSSxVQUFVLFFBQVEsS0FBSztBQUFBLGdCQUNwQztBQUNBLHNCQUFNLFFBQVEsY0FBYyxPQUFPLElBQUksVUFBVSxNQUFNLEdBQUksV0FBVyxXQUFXO0FBQ2pGLG9CQUFJLE9BQU8sU0FBUyxRQUFRLENBQUMsUUFBUSxPQUFPO0FBQzFDLDRCQUFVO0FBQ1Y7QUFBQSxnQkFDRjtBQUFBLGNBQ0Y7QUFBQSxZQUNGO0FBQ0EsZ0JBQUksQ0FBQyxRQUFTLFFBQU8sS0FBSyxHQUFHO0FBQUEsVUFDL0I7QUFBQSxRQUNGLFVBQUU7QUFDQSxxQkFBVyxNQUFNO0FBQUEsUUFDbkI7QUFDQSxpQkFBUyxTQUFTLEdBQUcsRUFBRSxJQUFJO0FBQUEsTUFDN0I7QUFBQSxFQUNKO0FBQUEsRUFDUSxVQUFVLElBQW1CLE9BQWE7QUFDaEQsVUFBTSxPQUFPLElBQUk7QUFBQSxNQUNmLEdBQUcsU0FBUyxNQUFNLE1BQU0sVUFBVSxNQUFNLE1BQU0sRUFBRSxJQUFJLENBQUMsT0FBTyxLQUFLLE1BQU0sS0FBSyxVQUFVLENBQUM7QUFBQSxJQUN6RjtBQUNBLFVBQU0sVUFBVSxJQUFJO0FBQUEsTUFDbEIsR0FBRyxZQUNBLE1BQU0sTUFBTSxhQUFhLE1BQU0sU0FBUyxFQUN4QyxJQUFJLENBQUMsT0FBTyxLQUFLLE1BQU0sS0FBSyxhQUFhLENBQUM7QUFBQSxJQUMvQztBQUNBLFVBQU0sTUFBZ0IsQ0FBQztBQUN2QixlQUFXLEtBQUssS0FBTSxZQUFXLEtBQUssUUFBUyxLQUFJLEtBQUssR0FBRyxHQUFHLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQzVFLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFDQSxNQUFjLFdBQVcsU0FBa0IsTUFBWSxVQUFvQjtBQUN6RSxVQUFNLElBQUksUUFBUSxTQUNoQixLQUFLLFNBQVMsU0FBUyxPQUFPLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLE9BQU87QUFDOUQsVUFBTSxrQkFDSCxFQUFFLE9BQU8sVUFBVSxLQUNwQixDQUFDLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRTtBQUFBLE1BQ2xCLENBQUMsT0FBTyxVQUNOLFNBQ0MsU0FBUyxNQUFNLFNBQVMsTUFBTSxhQUFhLE1BQU0sWUFBWSxNQUFNLGVBQWU7QUFBQSxNQUNyRjtBQUFBLElBQ0Y7QUFDRixRQUFJLG9CQUFvQjtBQUN4QixRQUFJLFFBQVEsU0FBUyxrQkFBa0I7QUFDckMsaUJBQVcsUUFBUSxFQUFFLE9BQU87QUFDMUIsY0FBTSxRQUFRLEtBQUssVUFBVTtBQUM3QixZQUFJLE9BQU8sU0FBUyxTQUFVLHNCQUFxQixNQUFNLE1BQU0sU0FBUztBQUFBLGlCQUMvRCxPQUFPLFNBQVMsVUFBVyxzQkFBcUIsTUFBTSxXQUFXLFNBQVM7QUFBQSxpQkFDMUUsT0FBTyxTQUFTLFFBQVMsc0JBQXFCLE1BQU0sS0FBSyxTQUFTO0FBQUEsTUFDN0U7QUFBQSxJQUNGO0FBQ0E7QUFBQSxNQUNFLGlCQUFpQixNQUFNLHFCQUFxQixLQUFLLE9BQU87QUFBQSxNQUN4RDtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsVUFBTSxZQUFZLG9CQUFJLElBQVk7QUFDbEMsUUFBSSxJQUFJO0FBQ04sVUFBSSxFQUFFO0FBQ0osbUJBQVcsS0FBSyxFQUFFO0FBQ2hCLG9CQUFVLElBQUksYUFBYSxHQUFHLElBQUksR0FBRyxTQUFTLEVBQUUsR0FBRyxHQUFHLEdBQUcsWUFBWSxFQUFFLE1BQU0sQ0FBQyxDQUFDO0FBQ25GLGlCQUFXLFNBQVMsQ0FBQyxFQUFFLE9BQU8sRUFBRSxNQUFNO0FBQ3BDLFlBQUksT0FBTztBQUNULHNCQUFZLElBQUksS0FBSztBQUNyQixxQkFBVyxLQUFLLEtBQUssVUFBVSxJQUFJLEtBQUssRUFBRyxXQUFVLElBQUksQ0FBQztBQUFBLFFBQzVEO0FBQUEsSUFDSjtBQUNBLFFBQUksUUFBUTtBQUNaLFVBQU0sV0FBNkI7QUFBQSxNQUNqQyxHQUFHLFNBQVM7QUFBQSxNQUNaLFlBQVksQ0FBQyxHQUFHLFNBQVMsU0FBUyxVQUFVO0FBQUEsTUFDNUMsUUFBUSxjQUFjLE9BQU8sSUFBSSxFQUFFLEdBQUcsU0FBUyxTQUFTLE9BQU8sSUFBSSxTQUFTLFNBQVM7QUFBQSxNQUNyRixRQUFRLFNBQVMsU0FBUyxPQUFPLElBQUksQ0FBQyxPQUFPO0FBQUEsUUFDM0MsR0FBRztBQUFBLFFBQ0gsT0FBTyxDQUFDO0FBQUEsUUFDUixNQUNFLFFBQVEsU0FBUyxvQkFDakIsUUFBUSxTQUFTLDBCQUNqQixRQUFRLFNBQVMsNkJBQ2pCLFFBQVEsU0FBUyxxQkFDYixFQUFFLEdBQUcsRUFBRSxLQUFLLElBQ1osRUFBRTtBQUFBLFFBQ1IsU0FDRSxRQUFRLFNBQVMsb0JBQ2pCLFFBQVEsU0FBUywwQkFDakIsUUFBUSxTQUFTLDZCQUNqQixRQUFRLFNBQVMscUJBQ2IsRUFBRSxHQUFHLEVBQUUsUUFBUSxJQUNmLEVBQUU7QUFBQSxRQUNSLFFBQVEsUUFBUSxTQUFTLHFCQUFxQixFQUFFLE9BQU8sSUFBSSxDQUFDLE9BQU8sRUFBRSxHQUFHLEVBQUUsRUFBRSxJQUFJLEVBQUU7QUFBQSxRQUNsRixRQUFRLEVBQUU7QUFBQSxRQUNWLFFBQVEsRUFBRTtBQUFBLE1BQ1osRUFBRTtBQUFBLElBQ0o7QUFDQSxVQUFNLFNBQVMsU0FBUyxPQUFPLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLE9BQU87QUFHN0QsVUFBTSxhQUFhLFFBQVEsU0FBUyxxQkFBcUIsb0JBQUksSUFBWSxJQUFJO0FBQzdFLFFBQUksV0FBWSxRQUFPLFFBQVEsb0JBQW9CLHdCQUF3QjtBQUMzRSxVQUFNLFlBQ0osY0FBYyxJQUFJLElBQUksT0FBUSxTQUFTLE1BQU0sRUFBRSxNQUFNLFVBQVUsRUFBRSxNQUFNLE1BQU0sQ0FBQztBQUNoRixVQUFNLGVBQ0osY0FBYyxJQUFJLElBQUksT0FBUSxZQUFZLE1BQU0sRUFBRSxNQUFNLGFBQWEsRUFBRSxNQUFNLFNBQVMsQ0FBQztBQUN6RixVQUFNLGlCQUFpQixjQUFjLE9BQVEsU0FBUyxFQUFFLE1BQU0sUUFBUTtBQUN0RSxVQUFNLG9CQUFvQixjQUFjLE9BQVEsWUFBWSxFQUFFLE1BQU0sV0FBVztBQUMvRSxlQUFXLFdBQVcsV0FBVztBQUMvQixZQUFNLFFBQVEsTUFBTSxLQUFLLE1BQU0sU0FBUyxJQUFJO0FBQzVDLGVBQVMsYUFBYSxLQUFLLElBQUk7QUFDL0I7QUFBQSxRQUNFLFNBQVMsS0FBSyxPQUFPO0FBQUEsUUFDckI7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUNBLFVBQUk7QUFDRixtQkFBVyxRQUFRLE9BQU8sT0FBTyxNQUFNLEtBQUs7QUFDMUMsY0FDRSxVQUFXLElBQUksS0FBSyxLQUFLLEtBQ3pCLGFBQWMsSUFBSSxLQUFLLFFBQVEsTUFDOUIsS0FBSyxVQUFVLGtCQUFrQixLQUFLLGFBQWEsdUJBQ25ELEtBQUssTUFBTSxTQUFTLFdBQVcsS0FBSyxXQUFXLFNBQ2hEO0FBQ0EsdUJBQVcsSUFBSSxPQUFPO0FBQ3RCO0FBQUEsVUFDRjtBQUFBO0FBQ0osYUFBTyxPQUFPLE9BQVEsT0FBTyxnQkFBZ0IsTUFBTSxLQUFLLENBQUM7QUFBQSxJQUMzRDtBQUNBLGtCQUFjLFVBQVUsT0FBTztBQUMvQixVQUFNLFFBQVEsb0JBQUksSUFBd0M7QUFDMUQsUUFBSSxXQUFXLENBQUMsY0FBYyxXQUFXLE9BQU87QUFDOUMsaUJBQVcsUUFBUSxPQUFPLE9BQU8sT0FBTyxLQUFLLEdBQUc7QUFDOUMsY0FBTSxVQUFVLGFBQWEsT0FBTyxJQUFJLEtBQUssT0FBTyxLQUFLLFFBQVE7QUFDakUsWUFBSSxjQUFjLENBQUMsV0FBVyxJQUFJLE9BQU8sRUFBRztBQUM1QyxZQUFJLE9BQU8sTUFBTSxJQUFJLE9BQU87QUFDNUIsWUFBSSxDQUFDLEtBQU0sT0FBTSxJQUFJLFNBQVUsT0FBTyxDQUFDLENBQUU7QUFDekMsYUFBSyxJQUFJLEtBQUssT0FBTyxLQUFLLFFBQVEsQ0FBQyxJQUFJO0FBQUEsTUFDekM7QUFBQSxJQUNGO0FBQ0EsZUFBVyxXQUFXLFdBQVc7QUFDL0IsVUFBSSxjQUFjLENBQUMsV0FBVyxJQUFJLE9BQU8sRUFBRztBQUM1QyxZQUFNLEtBQUssV0FBVyxTQUFTLE1BQU0sSUFBSSxPQUFPLEtBQUssQ0FBQyxHQUFHLE1BQU0sUUFBUTtBQUFBLElBQ3pFO0FBQ0EsZUFBVyxLQUFLLFNBQVMsT0FBUSxHQUFFLFFBQVEsQ0FBQztBQUM1QyxhQUFTLFdBQVc7QUFBQSxFQUN0QjtBQUFBLEVBQ0EsTUFBTSxRQUFRLFFBQTBDLFFBQVEsUUFBUTtBQUN0RSxXQUFPLEtBQUssUUFBUSxhQUFhLGlDQUFpQztBQUNsRSxTQUFLLFlBQVk7QUFDakIsU0FBSyxjQUFjLENBQUM7QUFDcEIsU0FBSyxRQUFRLE1BQU07QUFDbkIsU0FBSyxVQUFVLE1BQU07QUFDckIsU0FBSyxLQUFLLE1BQU07QUFDaEIsVUFBTSxXQUNKLE9BQU8sV0FBVyxLQUFLLHFCQUFxQixPQUFPLENBQUMsSUFDL0MsT0FBTyxDQUFDLElBQ1Q7QUFDTixRQUFJLFlBQVk7QUFDaEIsUUFBSSxVQUFVO0FBQ1o7QUFBQSxRQUNFLFNBQVMsb0JBQW9CLEtBQzNCLFNBQVMsZUFBZSxLQUFLLE1BQzdCLE9BQU8sU0FBUyxjQUFjLFlBQzlCLFNBQVMsVUFBVSxTQUFTLEtBQzVCLFNBQVMsVUFBVSxVQUFVO0FBQUEsUUFDL0I7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUNBLGtCQUFZLEtBQUssVUFBVSxRQUFRO0FBQ25DLFlBQU1DLE9BQU0sS0FBSyxLQUFLLElBQUksU0FBUyxTQUFTO0FBQzVDLFVBQUlBLE1BQUs7QUFDUCxlQUFPQSxLQUFJLGNBQWMsV0FBVyxvQkFBb0IsbUJBQW1CO0FBQzNFLGVBQU8sRUFBRSxNQUFNLEtBQUssS0FBSyxHQUFHLFFBQVFBLEtBQUksUUFBUSxXQUFXLEtBQUs7QUFBQSxNQUNsRTtBQUNBLGFBQU8sU0FBUyxpQkFBaUIsS0FBSyxLQUFLLFVBQVUscUJBQXFCLGtCQUFrQjtBQUFBLElBQzlGO0FBQ0EsVUFBTSxXQUFXLE9BQU8sSUFBSSxlQUFlLEdBQ3pDLE1BQU0sS0FBSyxNQUNYLFdBQXFCO0FBQUEsTUFDbkIsR0FBRyxLQUFLO0FBQUEsTUFDUixVQUFVO0FBQUEsUUFDUixHQUFHLEtBQUssU0FBUztBQUFBLFFBQ2pCLFlBQVksQ0FBQyxHQUFHLEtBQUssU0FBUyxTQUFTLFVBQVU7QUFBQSxRQUNqRCxRQUFRLEtBQUssU0FBUyxTQUFTO0FBQUEsUUFDL0IsUUFBUSxLQUFLLFNBQVMsU0FBUyxPQUFPLElBQUksQ0FBQyxRQUFRO0FBQUEsVUFDakQsR0FBRztBQUFBLFVBQ0gsT0FBTyxDQUFDO0FBQUEsVUFDUixNQUFNLEdBQUc7QUFBQSxVQUNULFNBQVMsR0FBRztBQUFBLFVBQ1osUUFBUSxHQUFHO0FBQUEsVUFDWCxRQUFRLEdBQUc7QUFBQSxVQUNYLFFBQVEsR0FBRztBQUFBLFFBQ2IsRUFBRTtBQUFBLE1BQ0o7QUFBQSxJQUNGLEdBQ0EsY0FBYyxRQUFRLElBQUksTUFBTSxHQUNoQyxPQUFhO0FBQUEsTUFDWCxHQUFHO0FBQUEsTUFDSCxRQUFRLFlBQVk7QUFBQSxNQUNwQixNQUFNLENBQUMsR0FBRyxJQUFJLElBQUk7QUFBQSxNQUNsQixRQUFRLENBQUMsR0FBRyxJQUFJLE1BQU07QUFBQSxJQUN4QjtBQUdGLFFBQ0UsU0FBUyxXQUFXLE1BQ25CLFNBQVMsQ0FBQyxFQUFFLFNBQVMsMEJBQ3BCLFNBQVMsQ0FBQyxFQUFFLFNBQVMsNEJBQ3ZCO0FBQ0EsWUFBTSxJQUFJLFNBQVMsQ0FBQyxFQUFFO0FBT3RCLFlBQU0sUUFBUSxTQUFTLFNBQVMsT0FBTyxLQUFLLENBQUMsU0FBUyxLQUFLLE9BQU8sRUFBRSxPQUFPO0FBQzNFLGFBQU8sT0FBTyxvQkFBb0Isd0JBQXdCO0FBQzFELFlBQU0sUUFBUSxFQUFFLFNBQVMsUUFBUSxNQUFNLFdBQVcsTUFBTTtBQUN4RCxZQUFNLGVBQWUsRUFBRSxTQUFTLFFBQVEsTUFBTSxPQUFPLE1BQU07QUFDM0QsWUFBTSxRQUFRLFNBQVMsQ0FBQyxFQUFFLFNBQVMsNEJBQTRCLElBQUksRUFBRTtBQUNyRSxZQUFNLE1BQU0sU0FBUyxDQUFDLEVBQUUsU0FBUyw0QkFBNEIsTUFBTSxTQUFTLEVBQUUsUUFBUSxFQUFFO0FBQ3hGLGFBQU8sT0FBTyxNQUFNLFFBQVEsaUJBQWlCLG9CQUFvQjtBQUNqRSxVQUFJLFVBQVU7QUFDZCxlQUFTLElBQUksT0FBTyxJQUFJLE9BQU8sQ0FBQyxTQUFTO0FBQ3ZDLGtCQUFVLENBQUMsQ0FBQyxhQUFhLE1BQU0sQ0FBQyxDQUFDLEdBQUcsV0FBVyxFQUFFO0FBQ25ELFVBQUksQ0FBQyxTQUFTO0FBQ1osWUFBSSxTQUFVLE1BQUssS0FBSyxJQUFJLFNBQVMsV0FBVyxFQUFFLFVBQVUsQ0FBQztBQUM3RCxlQUFPLEVBQUUsTUFBTSxLQUFLLEtBQUssRUFBRTtBQUFBLE1BQzdCO0FBQUEsSUFDRjtBQUNBLFVBQU0sYUFBYSxJQUFJLElBQVksS0FBSyxXQUFXO0FBQ25ELFFBQUksZ0JBQWdCO0FBQ3BCLFVBQU0sU0FBc0IsQ0FBQztBQUM3QixRQUFJO0FBQ0YsaUJBQVcsV0FBVyxVQUFVO0FBQzlCLGFBQUssTUFBTTtBQUNYLDBCQUNFLEVBQ0UsQ0FBQyxvQkFBb0Isc0JBQXNCLEVBQUUsU0FBUyxRQUFRLElBQUksS0FDbEUsQ0FBQyxjQUFjLE9BQU8sTUFFeEIsQ0FBQztBQUFBLFVBQ0M7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsUUFDRixFQUFFLFNBQVMsUUFBUSxJQUFJO0FBQ3pCLGNBQU0sSUFBSSxRQUFRO0FBQ2xCLFlBQUksRUFBRSxTQUFTO0FBQ2IsZ0JBQU0sS0FBSyxTQUFTLFNBQVMsT0FBTyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxPQUFPO0FBQ2xFLGNBQUksRUFBRSxPQUFRLFFBQU8sS0FBSyxFQUFFLFNBQVMsRUFBRSxTQUFTLEdBQUcsRUFBRSxPQUFPLENBQUM7QUFDN0QsY0FBSSxFQUFFLE1BQU8sUUFBTyxLQUFLLEVBQUUsU0FBUyxFQUFFLFNBQVMsR0FBRyxFQUFFLE1BQU0sQ0FBQztBQUFBLG1CQUNsRCxFQUFFLE9BQU8sUUFBUTtBQUN4QixnQkFBSSxXQUFXLFVBQ2IsU0FBUyxHQUNULGNBQWMsVUFDZCxZQUFZO0FBQ2QsdUJBQVcsUUFBUSxFQUFFLE9BQU87QUFDMUIseUJBQVcsS0FBSyxJQUFJLFVBQVUsS0FBSyxHQUFHO0FBQ3RDLHVCQUFTLEtBQUssSUFBSSxRQUFRLEtBQUssTUFBTSxDQUFDO0FBQ3RDLDRCQUFjLEtBQUssSUFBSSxhQUFhLEtBQUssTUFBTTtBQUMvQywwQkFBWSxLQUFLLElBQUksV0FBVyxLQUFLLFNBQVMsQ0FBQztBQUFBLFlBQ2pEO0FBQ0EsbUJBQU8sS0FBSztBQUFBLGNBQ1YsU0FBUyxFQUFFO0FBQUEsY0FDWDtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLFlBQ0YsQ0FBQztBQUFBLFVBQ0gsV0FBVztBQUNULG1CQUFPLEtBQUs7QUFBQSxjQUNWLFNBQVMsR0FBRztBQUFBLGNBQ1osVUFBVTtBQUFBLGNBQ1YsYUFBYTtBQUFBLGNBQ2IsUUFBUSxHQUFHLFNBQVM7QUFBQSxjQUNwQixXQUFXLEdBQUcsWUFBWTtBQUFBLFlBQzVCLENBQUM7QUFBQSxRQUNMO0FBQ0EsWUFDRTtBQUFBLFVBQ0U7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxRQUNGLEVBQUUsU0FBUyxRQUFRLElBQUk7QUFFdkIsZ0JBQU0sS0FBSyxXQUFXLFNBQVMsTUFBTSxRQUFRO0FBQUEsaUJBQ3RDLFFBQVEsU0FBUztBQUN4QixnQkFBTSxLQUFLLFdBQVcsU0FBUyxNQUFNLFFBQVE7QUFBQSxpQkFDdEMsUUFBUSxTQUFTO0FBQ3hCLGdCQUFNLEtBQUssVUFBVSxTQUFTLE1BQU0sUUFBUTtBQUFBLGlCQUNyQyxRQUFRLFNBQVM7QUFDeEIsZ0JBQU0sS0FBSyxZQUFZLFNBQVMsTUFBTSxRQUFRO0FBQUEsaUJBQ3ZDLFFBQVEsU0FBUztBQUN4QixnQkFBTSxLQUFLLFNBQVMsU0FBUyxNQUFNLFFBQVE7QUFBQSxpQkFDcEMsUUFBUSxTQUFTO0FBQ3hCLGdCQUFNLEtBQUssV0FBVyxTQUFTLE1BQU0sUUFBUTtBQUFBLGlCQUN0QyxRQUFRLFNBQVM7QUFDeEIsZ0JBQU0sS0FBSyxXQUFXLFNBQVMsTUFBTSxRQUFRO0FBQUEsaUJBQ3RDLFFBQVEsU0FBUztBQUN4QixnQkFBTSxLQUFLLFlBQVksU0FBUyxNQUFNLFFBQVE7QUFBQSxpQkFDdkMsUUFBUSxTQUFTLGtCQUFtQixPQUFNLEtBQUssS0FBSyxTQUFTLE1BQU0sUUFBUTtBQUFBLFlBQy9FLE9BQU0sS0FBSyxXQUFXLFNBQVMsTUFBTSxRQUFRO0FBQUEsTUFDcEQ7QUFDQSxVQUNFLFNBQVMsVUFDVCxTQUFTLE1BQU0sQ0FBQyxZQUFZLFFBQVEsU0FBUyxvQkFBb0IsS0FDakUsQ0FBQyxLQUFLLFFBQVEsTUFDZDtBQUNBLFlBQUksU0FBVSxNQUFLLEtBQUssSUFBSSxTQUFTLFdBQVcsRUFBRSxVQUFVLENBQUM7QUFDN0QsZUFBTyxFQUFFLE1BQU0sS0FBSyxLQUFLLEVBQUU7QUFBQSxNQUM3QjtBQUNBLFlBQU0sS0FBSyxRQUFRLE1BQU0sUUFBUTtBQUNqQyxXQUFLO0FBQ0wsV0FBSyxPQUFPLENBQUMsZ0JBQWdCLElBQUksT0FBTyxNQUFNLEtBQUssU0FBUyxlQUFlLFFBQVEsQ0FBQztBQUNwRixZQUFNLFVBQThCLENBQUM7QUFDckMsaUJBQVcsS0FBSyxLQUFLO0FBQ25CLFlBQUksSUFBSSxPQUFPLENBQUMsTUFBTSxLQUFLLE9BQU8sQ0FBQztBQUNqQyxrQkFBUSxLQUFLLENBQUMsR0FBRyxJQUFJLE9BQU8sQ0FBQyxLQUFLLE1BQU0sS0FBSyxPQUFPLENBQUMsS0FBSyxJQUFJLENBQUM7QUFDbkUsWUFBTSxRQUNKLFFBQVEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxNQUFNLEtBQUssR0FBRyxTQUFTLE1BQU0sR0FBRyxTQUFTLElBQUksQ0FBQyxLQUN2RSxLQUFLLFNBQVMsSUFBSSxPQUNmLElBQ0EsYUFBYSxlQUFlLFFBQVEsQ0FBQyxJQUFJLGFBQWEsZUFBZSxLQUFLLFFBQVEsQ0FBQztBQUN6RjtBQUFBLFFBQ0UsU0FBUyxLQUFLLE9BQU87QUFBQSxRQUNyQjtBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBQ0EsWUFBTSxVQUFtQixFQUFFLFFBQVEsSUFBSSxNQUFNLE9BQU8sS0FBSyxNQUFNLFNBQVMsT0FBTyxPQUFPO0FBQ3RGLFdBQUssS0FBSyxLQUFLLE1BQU0sS0FBSyxTQUFTLE9BQU8sQ0FBQztBQUMzQyxpQkFBVyxNQUFNLElBQUksUUFBUTtBQUMzQixjQUFNLElBQUksS0FBSyxVQUFVLElBQUksRUFBRTtBQUMvQixtQkFBVyxJQUFJLEVBQUU7QUFDakIsbUJBQVcsSUFBSSxFQUFFLE1BQU07QUFDdkIsbUJBQVcsSUFBSSxFQUFFLEtBQUs7QUFDdEIsbUJBQVcsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxLQUFLLEVBQUUsU0FBUztBQUNoQyxjQUFJLEVBQUcsWUFBVyxJQUFJLEVBQUUsRUFBRTtBQUMxQixjQUFJLEVBQUcsWUFBVyxJQUFJLEVBQUUsRUFBRTtBQUFBLFFBQzVCO0FBQUEsTUFDRjtBQUNBLFdBQUssU0FBUyxDQUFDO0FBQ2YsV0FBSyxlQUFlLElBQUksZUFBZTtBQUN2QyxhQUFPLEtBQUssS0FBSyxTQUFTLE9BQU8sS0FBSyxlQUFlLEtBQUssT0FBTyxNQUFNO0FBQ3JFLGNBQU0sVUFBVSxLQUFLLEtBQUssTUFBTTtBQUNoQyxjQUFNLElBQUksS0FBSyxVQUFVLElBQUksT0FBTztBQUNwQyxhQUFLLGdCQUFnQixFQUFFO0FBQ3ZCLG1CQUFXLElBQUksT0FBTztBQUN0QixtQkFBVyxJQUFJLEVBQUUsTUFBTTtBQUN2QixtQkFBVyxJQUFJLEVBQUUsS0FBSztBQUN0QixtQkFBVyxDQUFDLEVBQUUsR0FBRyxDQUFDLEtBQUssRUFBRSxTQUFTO0FBQ2hDLGNBQUksRUFBRyxZQUFXLElBQUksRUFBRSxFQUFFO0FBQzFCLGNBQUksRUFBRyxZQUFXLElBQUksRUFBRSxFQUFFO0FBQUEsUUFDNUI7QUFBQSxNQUNGO0FBQ0EsWUFBTSxLQUFLLFFBQVEsTUFBTSxVQUFVLGdCQUFnQixTQUFZLE1BQU07QUFDckUsWUFBTSxLQUFLLFFBQVEsQ0FBQyxHQUFHLFlBQVksR0FBRyxLQUFLLFdBQVcsQ0FBQztBQUN2RCxpQkFBVyxDQUFDLFNBQVMsT0FBTyxLQUFLLFlBQVksU0FBUztBQUNwRCxZQUFJLFFBQVMsS0FBSSxPQUFPLE9BQU8sSUFBSTtBQUFBLFlBQzlCLFFBQU8sSUFBSSxPQUFPLE9BQU87QUFBQSxNQUNoQztBQUNBLFdBQUssS0FBSyxTQUFTLElBQUk7QUFDdkIsWUFBTSxTQUFpQjtBQUFBLFFBQ3JCLFdBQVcsVUFBVSxhQUFhLElBQUksS0FBSztBQUFBLFFBQzNDLGtCQUFrQixJQUFJO0FBQUEsUUFDdEIsVUFBVSxLQUFLO0FBQUEsUUFDZixRQUFRO0FBQUEsUUFDUjtBQUFBLFFBQ0EsZUFBZTtBQUFBLE1BQ2pCO0FBQ0EsVUFBSSxTQUFVLE1BQUssS0FBSyxJQUFJLFNBQVMsV0FBVyxFQUFFLFdBQVcsT0FBTyxDQUFDO0FBQ3JFLGFBQU8sRUFBRSxNQUFNLEtBQUssS0FBSyxHQUFHLE9BQU87QUFBQSxJQUNyQyxTQUFTLE9BQU87QUFDZCxZQUFNLEtBQUssUUFBUSxLQUFLLFdBQVc7QUFDbkMsWUFBTTtBQUFBLElBQ1I7QUFBQSxFQUNGO0FBQUEsRUFDQSxNQUFjLFVBQVUsU0FBa0IsTUFBWSxVQUFvQjtBQUN4RSxVQUFNLE9BQU8sUUFBUTtBQUNyQixVQUFNLEtBQUssU0FBUyxTQUFTLE9BQU8sS0FBSyxDQUFDLFVBQVUsTUFBTSxPQUFPLEtBQUssT0FBTztBQUM3RSxXQUFPLElBQUksb0JBQW9CLHdCQUF3QjtBQUN2RCxRQUFJLFFBQVEsa0JBQWtCLElBQUksSUFBSTtBQUN0QyxVQUFNLFNBQVMsQ0FBQyxVQUFrQjtBQUNoQyxlQUFTO0FBQ1Q7QUFBQSxRQUNFLFNBQVMsS0FBSyxPQUFPO0FBQUEsUUFDckI7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxRQUFJLGNBQWMsT0FBTyxFQUFHLFVBQVMsU0FBUyxTQUFTLEVBQUUsR0FBRyxTQUFTLFNBQVMsT0FBTztBQUNyRixVQUFNLFNBQVMsb0JBQW9CO0FBQ25DLFVBQU0sWUFBWSxVQUFVLEdBQUcsVUFBVSxLQUFLLE1BQU0sVUFBVSxLQUFLLE1BQU0sUUFBUSxVQUFVO0FBQzNGLFVBQU0sZUFBZTtBQUFBLE1BQ25CLEdBQUc7QUFBQSxNQUNILEtBQUssTUFBTTtBQUFBLE1BQ1gsS0FBSyxNQUFNO0FBQUEsTUFDWDtBQUFBLElBQ0Y7QUFDQSxlQUFXLFFBQVEsVUFBVSxPQUFPO0FBQ2xDLGlCQUFXLFdBQVcsYUFBYSxPQUFPLEdBQUc7QUFDM0MsYUFBSyxNQUFNO0FBQ1gsY0FBTSxVQUFVLGFBQWEsS0FBSyxTQUFTLEtBQUssQ0FBQyxFQUFFLElBQUksUUFBUSxDQUFDLEVBQUUsRUFBRTtBQUNwRSxjQUFNLFFBQVEsaUJBQWlCLE1BQU0sS0FBSyxNQUFNLFNBQVMsSUFBSSxHQUFHLEtBQUs7QUFDckUsbUJBQVcsT0FBTztBQUNoQixxQkFBVyxVQUFVLFNBQVM7QUFDNUIsa0JBQU0sV0FBVyxJQUFJLElBQUksSUFBSSxPQUFPLEVBQUU7QUFDdEMsa0JBQU0sU0FDSixNQUFNLFFBQVEsTUFDYixNQUFNLFFBQVEsSUFBSSxFQUFFLE9BQU8sSUFBSSxJQUFJLFVBQVUsT0FBTyxJQUFJLE9BQU8sRUFBRSxNQUFNLFFBQVEsRUFBRTtBQUNwRjtBQUFBLGNBQ0UsU0FBUztBQUFBLGNBQ1Q7QUFBQSxjQUNBLFNBQVMsTUFBTSxJQUFJLE9BQU8sT0FBTyxPQUFPLFFBQVEsTUFBTTtBQUFBLFlBQ3hEO0FBQUEsVUFDRjtBQUNGLGNBQU0sS0FBSyxXQUFXLFNBQVMsT0FBTyxNQUFNLFFBQVE7QUFBQSxNQUN0RDtBQUFBLEVBQ0o7QUFBQSxFQUNBLE1BQWMsWUFBWSxTQUFrQixNQUFZLFVBQW9CO0FBQzFFLFVBQU0sRUFBRSxTQUFTLE9BQU8sUUFBUSxLQUFLLElBQUksUUFBUTtBQU1qRCxVQUFNLFFBQVEsU0FBUyxTQUFTLE9BQU8sS0FBSyxDQUFDLFNBQVMsS0FBSyxPQUFPLE9BQU87QUFDekUsV0FBTyxPQUFPLG9CQUFvQix3QkFBd0I7QUFDMUQsZ0JBQVksT0FBTyxLQUFLO0FBQ3hCLGdCQUFZLE9BQU8sTUFBTTtBQUN6QixVQUFNLE9BQU8sTUFBTSxTQUFTLE1BQU07QUFDbEMsVUFBTSxVQUFVLE1BQU0sWUFBWSxNQUFNO0FBQ3hDO0FBQUEsTUFDRSxTQUFTLE9BQU8sU0FBUyxPQUFPLFlBQVksWUFBWSxPQUFPLFlBQVksT0FBTztBQUFBLE1BQ2xGO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFDQSxXQUFPLE9BQU8sV0FBVyxPQUFPLFlBQVksa0JBQWtCLDZCQUE2QjtBQUMzRjtBQUFBLE1BQ0UsQ0FBQyxNQUFNLE9BQU8sS0FBSyxDQUFDLFVBQVUsV0FBVyxPQUFPLEtBQUssS0FBSyxXQUFXLE9BQU8sTUFBTSxDQUFDO0FBQUEsTUFDbkY7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLFVBQU0sWUFDSixTQUFTLFdBQ0wsSUFBSTtBQUFBLE1BQ0YsQ0FBQyxJQUFJLEtBQUssV0FBVyxLQUFLLFdBQVcsSUFBSSxLQUFLLFFBQVEsTUFBTSxRQUFRO0FBQUEsTUFDcEUsQ0FBQyxTQUNDLFNBQVMsU0FBUyxPQUFPLEtBQUssQ0FBQyxNQUFNLEVBQUUsS0FBSyxZQUFZLE1BQU0sS0FBSyxZQUFZLENBQUMsR0FBRztBQUFBLE1BQ3JGLEtBQUssV0FBVztBQUFBLE1BQ2hCO0FBQUEsTUFDQSxNQUFNLFNBQVMsU0FBUztBQUFBLElBQzFCLEVBQUUsWUFBWSxJQUNkO0FBQ04sVUFBTSxPQUF1QixDQUFDO0FBQzlCLFVBQU0sUUFBcUIsQ0FBQztBQUM1QixRQUFJLFFBQVE7QUFDWixRQUFJLFVBQVU7QUFDZCxhQUFTLE1BQU0sTUFBTSxVQUFVLE1BQU0sTUFBTSxRQUFRLE9BQU87QUFDeEQsZUFBUyxTQUFTLE1BQU0sYUFBYSxTQUFTLE1BQU0sV0FBVyxVQUFVO0FBQ3ZFLGFBQUssTUFBTTtBQUNYLFlBQUksRUFBRSxVQUFVLFNBQVMsR0FBRztBQUMxQixnQkFBTSxZQUFZO0FBQ2xCLGVBQUssTUFBTTtBQUFBLFFBQ2I7QUFDQSxjQUFNLE9BQU8sTUFBTSxLQUFLLFdBQVcsU0FBUyxLQUFLLFFBQVEsTUFBTSxVQUFVLElBQUk7QUFDN0UsY0FBTSxRQUFRLE1BQU0sVUFBVSxTQUFTLFNBQVMsT0FBTyxLQUFLLE9BQU8sSUFBSSxDQUFDO0FBQ3hFLGNBQU0sT0FBTztBQUFBLFVBQ1g7QUFBQSxZQUNFO0FBQUEsWUFDQTtBQUFBLFlBQ0EsR0FBSSxTQUFTLFdBQ1Q7QUFBQSxjQUNFLE9BQ0UsTUFBTSxNQUFNLFNBQVMsWUFDakIsTUFBTSxVQUFXLFNBQVMsS0FBSyxNQUFNLElBQ3JDLE9BQ0UsWUFBWSxLQUFLLEtBQUssSUFDdEI7QUFBQSxZQUNWLElBQ0EsQ0FBQztBQUFBLFlBQ0wsR0FBSSxTQUFTLGFBQWEsRUFBRSxPQUFPLE1BQU0sTUFBTSxJQUFJLENBQUM7QUFBQSxZQUNwRCxHQUFJLFNBQVMsWUFDVCxFQUFFLE9BQU8sY0FBYyxNQUFNLGdCQUFnQixPQUFPLGFBQWEsSUFDakUsQ0FBQztBQUFBLFVBQ1A7QUFBQSxVQUNBO0FBQUEsVUFDQSxPQUFPLFdBQVcsTUFBTTtBQUFBLFVBQ3hCLE9BQU8sY0FBYyxNQUFNO0FBQUEsUUFDN0I7QUFDQSxpQkFBUyxLQUFLLFVBQVUsSUFBSSxFQUFFLFNBQVM7QUFDdkMsZUFBTyxTQUFTLEtBQUssT0FBTyxNQUFNLGtCQUFrQiwrQkFBK0I7QUFDbkYsY0FBTSxLQUFLLElBQUk7QUFBQSxNQUNqQjtBQUFBLElBQ0Y7QUFDQSxVQUFNLFFBQVEsZ0JBQWdCLEVBQUUsTUFBTSxvQkFBb0IsU0FBUyxFQUFFLFNBQVMsTUFBTSxFQUFFLENBQUM7QUFDdkYsVUFBTSxLQUFLLFdBQVcsT0FBTyxNQUFNLFFBQVE7QUFBQSxFQUM3QztBQUFBLEVBQ0EsTUFBYyxXQUFXLFNBQWtCLE1BQVksVUFBb0I7QUFDekUsVUFBTSxFQUFFLFNBQVMsT0FBTyxTQUFTLElBQUksUUFBUTtBQUM3QyxVQUFNLEtBQUssU0FBUyxTQUFTLE9BQU8sS0FBSyxDQUFDLFVBQVUsTUFBTSxPQUFPLE9BQU87QUFDeEUsV0FBTyxJQUFJLG9CQUFvQix3QkFBd0I7QUFDdkQsVUFBTSxRQUFRLG9CQUFJLElBQXlCO0FBQzNDLFFBQUksV0FBVyxVQUNiLFNBQVMsR0FDVCxjQUFjLFVBQ2QsWUFBWTtBQUNkLGVBQVcsUUFBUSxVQUFVO0FBQzNCO0FBQUEsUUFDRSxLQUFLLE1BQU0sR0FBRyxTQUFTLFVBQVUsS0FBSyxTQUFTLEdBQUcsWUFBWTtBQUFBLFFBQzlEO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFDQSxpQkFBVyxLQUFLLElBQUksVUFBVSxLQUFLLEdBQUc7QUFDdEMsZUFBUyxLQUFLLElBQUksUUFBUSxLQUFLLE1BQU0sQ0FBQztBQUN0QyxvQkFBYyxLQUFLLElBQUksYUFBYSxLQUFLLE1BQU07QUFDL0Msa0JBQVksS0FBSyxJQUFJLFdBQVcsS0FBSyxTQUFTLENBQUM7QUFDL0MsWUFBTSxVQUFVLGFBQWEsU0FBUyxHQUFHLFNBQVMsS0FBSyxHQUFHLEdBQUcsR0FBRyxZQUFZLEtBQUssTUFBTSxDQUFDO0FBQ3hGLFVBQUksT0FBTyxNQUFNLElBQUksT0FBTztBQUM1QixVQUFJLENBQUMsS0FBTSxPQUFNLElBQUksU0FBVSxPQUFPLENBQUMsQ0FBRTtBQUN6QyxXQUFLLEtBQUssSUFBSTtBQUFBLElBQ2hCO0FBQ0EsVUFBTSxTQUFTLEdBQUcsT0FBTztBQUFBLE1BQU8sQ0FBQyxVQUMvQixXQUFXLE9BQU8sRUFBRSxVQUFVLFFBQVEsYUFBYSxVQUFVLENBQUM7QUFBQSxJQUNoRTtBQUNBLFFBQUksU0FBUztBQUNiLGVBQVcsUUFBUTtBQUNqQixpQkFBVyxTQUFTLFFBQVE7QUFDMUIsZUFBTyxFQUFFLFVBQVUsS0FBVyxrQkFBa0IsbUNBQW1DO0FBQ25GO0FBQUEsVUFDRSxFQUNFLEtBQUssT0FBTyxNQUFNLFlBQ2xCLEtBQUssTUFBTSxNQUFNLFVBQ2pCLEtBQUssVUFBVSxNQUFNLGVBQ3JCLEtBQUssU0FBUyxNQUFNO0FBQUEsVUFFdEI7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDRixRQUFJLGNBQWMsT0FBTyxFQUFHLFVBQVMsU0FBUyxTQUFTLEVBQUUsR0FBRyxTQUFTLFNBQVMsT0FBTztBQUNyRixlQUFXLENBQUMsU0FBUyxJQUFJLEtBQUssT0FBTztBQUNuQyxXQUFLLE1BQU07QUFDWCxZQUFNLFFBQVEsaUJBQWlCLE1BQU0sS0FBSyxNQUFNLFNBQVMsSUFBSSxHQUFHLEtBQUs7QUFDckUsaUJBQVcsUUFBUSxNQUFNO0FBQ3ZCLGNBQU0sUUFBUSxHQUFHLFNBQVMsS0FBSyxHQUFHLEdBQ2hDLFdBQVcsR0FBRyxZQUFZLEtBQUssTUFBTTtBQUN2QyxjQUFNLFdBQVcsSUFBSSxPQUFPLFFBQVE7QUFDcEMsY0FBTSxTQUNKLE1BQU0sUUFBUSxNQUFNLE1BQU0sUUFBUSxJQUFJLEVBQUUsT0FBTyxVQUFVLE9BQU8sRUFBRSxNQUFNLFFBQVEsRUFBRTtBQUNwRix3QkFBZ0IsU0FBUyxVQUFVLFFBQVEsSUFBSTtBQUFBLE1BQ2pEO0FBQ0EsWUFBTSxLQUFLLFdBQVcsU0FBUyxPQUFPLE1BQU0sUUFBUTtBQUFBLElBQ3REO0FBQUEsRUFDRjtBQUFBLEVBQ0EsTUFBYyxXQUFXLFNBQWtCLE1BQVksVUFBb0I7QUFDekUsVUFBTSxFQUFFLFNBQVMsT0FBTyxPQUFPLE1BQU0sTUFBTSxTQUFTLElBQUksUUFBUTtBQVFoRSxVQUFNLEtBQUssU0FBUyxTQUFTLE9BQU8sS0FBSyxDQUFDLFVBQVUsTUFBTSxPQUFPLE9BQU87QUFDeEUsV0FBTyxJQUFJLG9CQUFvQix3QkFBd0I7QUFDdkQsZ0JBQVksSUFBSSxLQUFLO0FBQ3JCO0FBQUEsT0FDRyxNQUFNLFNBQVMsTUFBTSxhQUFhLE1BQU0sWUFBWSxNQUFNLGdCQUFnQixPQUFPO0FBQUEsTUFDbEY7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBO0FBQUEsTUFDRSxDQUFDLEdBQUcsT0FBTyxLQUFLLENBQUMsVUFBVSxXQUFXLE9BQU8sS0FBSyxDQUFDO0FBQUEsTUFDbkQ7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLFVBQU0sUUFDSixTQUFTLFFBQVEsTUFBTSxTQUFTLE1BQU0sV0FBVyxNQUFNLFlBQVksTUFBTTtBQUMzRSxVQUFNLFNBQVMsV0FDWCxlQUFlLE9BQU8sTUFBTSxPQUFPLFVBQVUsU0FBUyxTQUFTLFVBQVUsSUFDekUsY0FBYyxPQUFPLE1BQU0sS0FBSztBQUNwQyxVQUFNLFlBQVksVUFBVSxHQUFHLFVBQVUsTUFBTSxVQUFVLE1BQU0sUUFBUSxVQUFVO0FBQ2pGLFVBQU0sZUFBZTtBQUFBLE1BQ25CLEdBQUc7QUFBQSxNQUNILE1BQU07QUFBQSxNQUNOLE1BQU07QUFBQSxNQUNOO0FBQUEsSUFDRjtBQUNBLGVBQVcsUUFBUSxVQUFVLE9BQU8sR0FBRztBQUNyQyxpQkFBVyxXQUFXLGFBQWEsT0FBTyxHQUFHO0FBQzNDLGFBQUssTUFBTTtBQUNYLGNBQU0sVUFBVSxhQUFhLFNBQVMsS0FBSyxDQUFDLEVBQUUsSUFBSSxRQUFRLENBQUMsRUFBRSxFQUFFO0FBQy9ELGNBQU0sUUFBUSxpQkFBaUIsTUFBTSxLQUFLLE1BQU0sU0FBUyxJQUFJLEdBQUcsS0FBSztBQUNyRSxtQkFBVyxPQUFPO0FBQ2hCLHFCQUFXLFVBQVUsU0FBUztBQUM1QixrQkFBTSxXQUFXLElBQUksSUFBSSxJQUFJLE9BQU8sRUFBRTtBQUN0QyxrQkFBTSxTQUNKLE1BQU0sUUFBUSxNQUNiLE1BQU0sUUFBUSxJQUFJO0FBQUEsY0FDakIsT0FBTyxJQUFJO0FBQUEsY0FDWCxVQUFVLE9BQU87QUFBQSxjQUNqQixPQUFPLEVBQUUsTUFBTSxRQUFRO0FBQUEsWUFDekI7QUFDRixtQkFBTyxRQUFRO0FBQUEsY0FDYixNQUFNO0FBQUEsY0FDTixPQUNFLE9BQ0UsU0FBUyxRQUFRLElBQUksUUFBUSxNQUFNLFdBQVcsT0FBTyxRQUFRLE1BQU0sV0FDckU7QUFBQSxZQUNKO0FBQ0EsbUJBQU8sT0FBTztBQUFBLFVBQ2hCO0FBQ0YsY0FBTSxLQUFLLFdBQVcsU0FBUyxPQUFPLE1BQU0sUUFBUTtBQUFBLE1BQ3REO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLE1BQWMsV0FBVyxTQUFrQixNQUFZLFVBQW9CO0FBQ3pFLFVBQU0sRUFBRSxTQUFTLE9BQU8sTUFBTSxJQUFJLFFBQVE7QUFLMUMsVUFBTSxLQUFLLFNBQVMsU0FBUyxPQUFPLEtBQUssQ0FBQyxVQUFVLE1BQU0sT0FBTyxPQUFPO0FBQ3hFLFdBQU8sSUFBSSxvQkFBb0Isd0JBQXdCO0FBQ3ZELGdCQUFZLElBQUksS0FBSztBQUNyQjtBQUFBLE9BQ0csTUFBTSxTQUFTLE1BQU0sYUFBYSxNQUFNLFlBQVksTUFBTSxnQkFBZ0IsT0FBTztBQUFBLE1BQ2xGO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFDQTtBQUFBLE1BQ0UsR0FBRyxPQUFPLE1BQU0sQ0FBQyxVQUFVLENBQUMsV0FBVyxPQUFPLEtBQUssS0FBSyxTQUFTLE9BQU8sS0FBSyxDQUFDO0FBQUEsTUFDOUU7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLGFBQVMsU0FBUyxTQUFTLEVBQUUsR0FBRyxTQUFTLFNBQVMsT0FBTztBQUN6RCxVQUFNLFNBQVMsb0JBQUksSUFBb0I7QUFDdkMsVUFBTSxZQUFZLFVBQVUsR0FBRyxVQUFVLE1BQU0sVUFBVSxNQUFNLFFBQVEsVUFBVTtBQUNqRixVQUFNLGVBQWU7QUFBQSxNQUNuQixHQUFHO0FBQUEsTUFDSCxNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsTUFDTjtBQUFBLElBQ0Y7QUFDQSxlQUFXLFFBQVEsVUFBVSxPQUFPLEdBQUc7QUFDckMsaUJBQVcsV0FBVyxhQUFhLE9BQU8sR0FBRztBQUMzQyxhQUFLLE1BQU07QUFDWCxjQUFNLFVBQVUsYUFBYSxTQUFTLEtBQUssQ0FBQyxFQUFFLElBQUksUUFBUSxDQUFDLEVBQUUsRUFBRTtBQUMvRCxjQUFNLFFBQVEsaUJBQWlCLE1BQU0sS0FBSyxNQUFNLFNBQVMsSUFBSSxHQUFHLEtBQUs7QUFDckUsbUJBQVcsT0FBTztBQUNoQixxQkFBVyxVQUFVLFNBQVM7QUFDNUIsa0JBQU0sV0FBVyxJQUFJLElBQUksSUFBSSxPQUFPLEVBQUU7QUFDdEMsa0JBQU0sU0FDSixNQUFNLFFBQVEsTUFDYixNQUFNLFFBQVEsSUFBSTtBQUFBLGNBQ2pCLE9BQU8sSUFBSTtBQUFBLGNBQ1gsVUFBVSxPQUFPO0FBQUEsY0FDakIsT0FBTyxFQUFFLE1BQU0sUUFBUTtBQUFBLFlBQ3pCO0FBQ0Ysa0JBQU0sUUFBUSxPQUFPLFdBQVc7QUFDaEMsZ0JBQUksWUFBWSxPQUFPLElBQUksS0FBSztBQUNoQyxnQkFBSSxDQUFDLFdBQVc7QUFDZCwwQkFBWSxRQUFRLFNBQVMsVUFBVTtBQUFBLGdCQUNyQyxHQUFJLE9BQU8sVUFBVSxTQUFTLFNBQVMsT0FBTyxPQUFPLE9BQU8sSUFBSSxDQUFDO0FBQUEsZ0JBQ2pFLEdBQUc7QUFBQSxjQUNMLENBQUM7QUFDRCxxQkFBTyxJQUFJLE9BQU8sU0FBUztBQUFBLFlBQzdCO0FBQ0EsbUJBQU8sVUFBVTtBQUNqQixnQkFBSSxNQUFNLGlCQUFpQixPQUFXLFFBQU8sT0FBTztBQUFBLFVBQ3REO0FBQ0YsY0FBTSxLQUFLLFdBQVcsU0FBUyxPQUFPLE1BQU0sUUFBUTtBQUFBLE1BQ3REO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLE1BQWMsU0FBUyxTQUFrQixNQUFZLFVBQW9CO0FBQ3ZFLFVBQU0sRUFBRSxTQUFTLE1BQU0sSUFBSSxRQUFRO0FBQ25DLFVBQU0sS0FBSyxTQUFTLFNBQVMsT0FBTyxLQUFLLENBQUMsVUFBVSxNQUFNLE9BQU8sT0FBTztBQUN4RSxXQUFPLElBQUksb0JBQW9CLHdCQUF3QjtBQUN2RCxnQkFBWSxJQUFJLEtBQUs7QUFDckI7QUFBQSxNQUNFLENBQUMsR0FBRyxPQUFPLEtBQUssQ0FBQyxVQUFVLFdBQVcsT0FBTyxLQUFLLENBQUM7QUFBQSxNQUNuRDtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsVUFBTSxZQUFZLG9CQUFJLElBQTZDO0FBQ25FLFVBQU0sZUFBZSxvQkFBSSxJQUE2QztBQUN0RSxhQUFTLFFBQVEsTUFBTSxXQUFXLEdBQUcsUUFBUSxNQUFNLFFBQVEsU0FBUztBQUNsRSxZQUFNLEtBQUssR0FBRyxTQUFTLEtBQUssR0FDMUIsUUFBUSxLQUFLLE1BQU0sS0FBSyxVQUFVO0FBQ3BDLFVBQUksU0FBUyxVQUFVLElBQUksS0FBSztBQUNoQyxVQUFJLENBQUMsT0FBUSxXQUFVLElBQUksT0FBUSxTQUFTLENBQUMsQ0FBRTtBQUMvQyxhQUFPLEtBQUssRUFBRSxPQUFPLEdBQUcsQ0FBQztBQUFBLElBQzNCO0FBQ0EsYUFBUyxRQUFRLE1BQU0sYUFBYSxRQUFRLE1BQU0sV0FBVyxTQUFTO0FBQ3BFLFlBQU0sS0FBSyxHQUFHLFlBQVksS0FBSyxHQUM3QixRQUFRLEtBQUssTUFBTSxLQUFLLGFBQWE7QUFDdkMsVUFBSSxTQUFTLGFBQWEsSUFBSSxLQUFLO0FBQ25DLFVBQUksQ0FBQyxPQUFRLGNBQWEsSUFBSSxPQUFRLFNBQVMsQ0FBQyxDQUFFO0FBQ2xELGFBQU8sS0FBSyxFQUFFLE9BQU8sR0FBRyxDQUFDO0FBQUEsSUFDM0I7QUFDQSxVQUFNLFNBQVMsb0JBQUksSUFBd0I7QUFDM0MsVUFBTSxXQUFXLEdBQUcsU0FBUyxNQUFNLFFBQVE7QUFDM0MsZUFBVyxXQUFXLGFBQWEsT0FBTyxHQUFHO0FBQzNDLFdBQUssTUFBTTtBQUNYLFlBQU0sUUFBUSxNQUFNLEtBQUssTUFBTSxhQUFhLFNBQVMsVUFBVSxRQUFRLENBQUMsRUFBRSxFQUFFLEdBQUcsSUFBSTtBQUNuRixZQUFNLFFBQVEsTUFBTTtBQUNwQixpQkFBVyxVQUFVLFNBQVM7QUFDNUIsY0FBTSxRQUFRLE1BQU0sSUFBSSxVQUFVLE9BQU8sRUFBRSxDQUFDO0FBQzVDLFlBQUksTUFBTyxRQUFPLElBQUksT0FBTyxJQUFJLGdCQUFnQixLQUFLLENBQUM7QUFBQSxNQUN6RDtBQUFBLElBQ0Y7QUFDQSxlQUFXLFFBQVEsVUFBVSxPQUFPLEdBQUc7QUFDckMsaUJBQVcsV0FBVyxhQUFhLE9BQU8sR0FBRztBQUMzQyxhQUFLLE1BQU07QUFDWCxjQUFNLFVBQVUsYUFBYSxTQUFTLEtBQUssQ0FBQyxFQUFFLElBQUksUUFBUSxDQUFDLEVBQUUsRUFBRTtBQUMvRCxjQUFNLFFBQVEsaUJBQWlCLE1BQU0sS0FBSyxNQUFNLFNBQVMsSUFBSSxHQUFHLEtBQUs7QUFDckUsbUJBQVcsT0FBTztBQUNoQixxQkFBVyxVQUFVLFNBQVM7QUFDNUIsa0JBQU0sV0FBVyxJQUFJLElBQUksSUFBSSxPQUFPLEVBQUU7QUFDdEMsa0JBQU0sV0FBVyxPQUFPLElBQUksT0FBTyxFQUFFO0FBQ3JDLGdCQUFJLENBQUMsVUFBVTtBQUNiLHFCQUFPLE1BQU0sUUFBUTtBQUNyQjtBQUFBLFlBQ0Y7QUFDQSxrQkFBTSxRQUFRLGdCQUFnQixRQUFRO0FBQ3RDLGtCQUFNLFFBQVEsSUFBSTtBQUNsQixrQkFBTSxXQUFXLE9BQU87QUFDeEIsZ0JBQUksTUFBTSxNQUFNLFNBQVM7QUFDdkIsb0JBQU0sTUFBTSxhQUFhO0FBQUEsZ0JBQ3ZCLE1BQU0sTUFBTTtBQUFBLGdCQUNaLElBQUksUUFBUSxNQUFNO0FBQUEsZ0JBQ2xCO0FBQUEsY0FDRjtBQUNGLG1CQUFPLE1BQU07QUFDYixrQkFBTSxRQUFRLElBQUk7QUFBQSxVQUNwQjtBQUNGLGNBQU0sS0FBSyxXQUFXLFNBQVMsT0FBTyxNQUFNLFFBQVE7QUFBQSxNQUN0RDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUEsRUFDQSxNQUFjLFlBQVksU0FBa0IsTUFBWSxVQUFvQjtBQUMxRSxVQUFNLEtBQUssT0FBTyxRQUFRLFFBQVEsT0FBTztBQUN6QztBQUFBLE1BQ0UsU0FBUyxTQUFTLE9BQU8sS0FBSyxDQUFDLFVBQVUsTUFBTSxPQUFPLEVBQUU7QUFBQSxNQUN4RDtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsVUFBTSxRQUFRLE9BQU8sUUFBUSxRQUFRLEtBQUs7QUFDMUMsUUFBSSxVQUFVLFFBQVEsUUFBUSxZQUFhO0FBQzNDLGVBQVcsS0FBSyxPQUFPLEtBQUssS0FBSyxNQUFNO0FBQ3JDLFVBQUksRUFBRSxXQUFXLEdBQUcsRUFBRSxHQUFHLEdBQUc7QUFDMUIsYUFBSyxNQUFNO0FBQ1gsY0FBTSxZQUFZLE1BQU0sS0FBSyxNQUFNLEdBQUcsSUFBSSxHQUFHO0FBQzdDLFlBQ0UsQ0FBQyxPQUFPLE9BQU8sUUFBUSxFQUFFO0FBQUEsVUFDdkIsQ0FBQyxTQUFTLEtBQUssTUFBTSxTQUFTLFlBQVksS0FBSyxNQUFNLE1BQU0sU0FBUyxLQUFLO0FBQUEsUUFDM0U7QUFFQTtBQUNGLGNBQU0sUUFBUSxnQkFBZ0IsUUFBUTtBQUN0QyxjQUFNLFdBQVc7QUFBQSxVQUNmLEdBQUcsU0FBUztBQUFBLFVBQ1osUUFBUSxTQUFTLFNBQVMsT0FBTyxJQUFJLENBQUMsTUFBTyxFQUFFLE9BQU8sS0FBSyxFQUFFLEdBQUcsR0FBRyxNQUFNLElBQUksQ0FBRTtBQUFBLFFBQ2pGO0FBQ0Esc0JBQWMsVUFBVSxPQUFPO0FBQy9CLGNBQU0sS0FBSyxXQUFXLEdBQUcsT0FBTyxNQUFNLFFBQVE7QUFBQSxNQUNoRDtBQUFBLEVBQ0o7QUFBQSxFQUNBLE1BQWMsV0FBVyxTQUFrQixNQUFZLFVBQW9CO0FBQ3pFLFVBQU0sV0FBVyxTQUFTO0FBQzFCLFVBQU0sY0FBYyxnQkFBZ0IsUUFBUTtBQUU1QyxrQkFBYyxhQUFhLE9BQU87QUFDbEMsVUFBTSxjQUFjLFFBQVE7QUFDNUIsUUFBSSxRQUFRLFNBQVMsc0JBQXNCLFFBQVEsU0FBUyxvQkFBb0I7QUFDOUUsWUFBTSxTQUFTLFNBQVMsT0FBTyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sWUFBWSxPQUFPLEdBQ3JFLFFBQVEsWUFBWSxPQUFPLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxZQUFZLE9BQU87QUFDckUsWUFBTSxRQUFRLFlBQVksU0FBUyxRQUFRLGFBQWEsZUFDdEQsUUFBUSxLQUFLLEtBQUssT0FBTyxLQUFLLENBQUMsRUFBRSxNQUFNO0FBQ3pDLFlBQU07QUFBQSxRQUNKLFlBQVk7QUFBQSxRQUNaLFFBQVEsU0FBUyxxQkFBcUIsWUFBWSxRQUFRO0FBQUEsUUFDMUQsUUFBUSxTQUFTLHFCQUFxQixZQUFZLE1BQU0sQ0FBQztBQUFBLE1BQzNEO0FBQ0E7QUFBQSxRQUNFLE1BQU0sUUFBUSxFQUFFLE1BQU0sQ0FBQyxJQUFJLE1BQU0sT0FBTyxNQUFNLEtBQUssRUFBRSxDQUFDLENBQUM7QUFBQSxRQUN2RDtBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBQ0EsV0FBSyxLQUFLLElBQUksTUFBTSxLQUFLLEdBQUcsS0FBSztBQUFBLElBQ25DO0FBQ0EsVUFBTSxVQUFVLFFBQVEsU0FDdEIsY0FBYyxTQUFTLE9BQU8sS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLFFBQVEsT0FBTztBQUNwRSxVQUFNLGFBQWEsWUFBWSxLQUFLLFlBQVk7QUFDaEQsVUFBTSxRQUFRLElBQUksSUFBSSxTQUFTLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLElBQUksTUFBTSxJQUFJLENBQUMsQ0FBQztBQUM1RSxVQUFNLFVBQVU7QUFBQSxNQUNkLHFCQUFxQixTQUFTLFlBQVksSUFBSTtBQUFBLE1BQzlDLDBCQUEwQixTQUFTLFlBQVksSUFBSTtBQUFBLElBQ3JEO0FBQ0EsVUFBTSxXQUFXLFFBQVEsU0FBUyxzQkFBc0IsUUFBUSxTQUFTO0FBQ3pFLFVBQU0sVUFDSixRQUFRLFNBQVMscUJBQ2IsSUFBSTtBQUFBLE9BQ0QsUUFBUSxTQUFTLFFBQVEsWUFBWSxXQUFXLFlBQVksYUFBYTtBQUFBLFFBQ3hFLFFBQVE7QUFBQSxRQUNSLFFBQVEsUUFBUSxRQUFRO0FBQUEsTUFDMUI7QUFBQSxJQUNGLElBQ0Esb0JBQUksSUFBWTtBQUN0QixVQUFNLGlCQUFpQixJQUFJO0FBQUEsTUFDekIsQ0FBQyxHQUFHLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTyxLQUFLLE1BQU0sTUFBTSxRQUFRLFNBQVMsUUFBUSxLQUFLLEdBQUcsQ0FBQztBQUFBLElBQzlFO0FBQ0EsVUFBTSxtQkFBbUIsb0JBQUksSUFBWTtBQUN6QyxRQUFJLFFBQVEsU0FBUyxvQkFBb0I7QUFDdkMsWUFBTSxRQUFRLFlBQVksT0FBTyxLQUFLLENBQUMsU0FBUyxLQUFLLE9BQU8sUUFBUSxPQUFPO0FBQzNFLFlBQU0sUUFBUSxRQUFRLFNBQVMsUUFBUSxNQUFNLFdBQVcsTUFBTTtBQUM5RCxZQUFNLE9BQU8sUUFBUSxTQUFTLFFBQVEsYUFBYTtBQUNuRCxpQkFBVyxNQUFNLE9BQU87QUFDdEIsY0FBTSxTQUFTLEtBQUssTUFBTSxLQUFLLElBQUk7QUFDbkMsWUFBSSxlQUFlLElBQUksTUFBTSxFQUFHLGtCQUFpQixJQUFJLE1BQU07QUFDM0QsWUFBSSxpQkFBaUIsU0FBUyxlQUFlLEtBQU07QUFBQSxNQUNyRDtBQUFBLElBQ0Y7QUFDQSxhQUFTLFdBQVc7QUFDcEIsZUFBVyxDQUFDLFNBQVMsT0FBTyxLQUFLLE9BQU8sUUFBUSxLQUFLLE1BQU0sR0FBRztBQUM1RCxXQUFLLE1BQU07QUFDWCxZQUFNLENBQUMsU0FBUyxJQUFJLEVBQUUsSUFBSSxRQUFRLE1BQU0sR0FBRztBQUMzQyxZQUFNLGVBQWUsUUFBUSxTQUFTLHVCQUF1QixZQUFZLFlBQVk7QUFDckYsWUFBTSxXQUNKLFlBQVksWUFBWSxNQUFNLGVBQWUsSUFBSSxRQUFRLFNBQVMsUUFBUSxDQUFDLEtBQUssQ0FBQyxFQUFFO0FBQ3JGLFlBQU0sVUFBVSxRQUFRLFVBQVU7QUFBQSxRQUNoQyxDQUFDLFNBQVMsU0FBUyxPQUFPLEtBQUssWUFBWSxNQUFNO0FBQUEsTUFDbkQ7QUFDQSxVQUFJLGNBQWM7QUFDaEIsYUFBSyxRQUFRLElBQUksT0FBTztBQUN4QixlQUFPLEtBQUssT0FBTyxPQUFPO0FBQzFCO0FBQUEsTUFDRjtBQUNBLFVBQUksWUFBWSxDQUFDLGlCQUFpQixJQUFJLFFBQVEsU0FBUyxRQUFRLENBQUMsS0FBSyxDQUFDLEVBQUUsR0FBRztBQUN6RSxhQUFLLFFBQVEsSUFBSSxPQUFPO0FBQ3hCLGVBQU8sS0FBSyxPQUFPLE9BQU87QUFDMUI7QUFBQSxNQUNGO0FBQ0EsVUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFTO0FBQzNCLFlBQU0sUUFBUSxpQkFBaUIsTUFBTSxLQUFLLE1BQU0sU0FBUyxJQUFJLEdBQUcsS0FBSztBQUNyRSxVQUFJLFVBQVU7QUFDWixjQUFNLFFBQVEsUUFBUSxTQUFTLFFBQVEsVUFBVTtBQUNqRCxtQkFBVyxDQUFDSCxNQUFLLElBQUksS0FBSyxPQUFPLFFBQVEsS0FBSztBQUM1QyxjQUFJLFFBQVEsSUFBSSxLQUFLLEtBQUssQ0FBQyxFQUFHLFFBQU8sTUFBTUEsSUFBRztBQUFBLE1BQ2xEO0FBQ0EsY0FBUSxPQUFPLFdBQVcsTUFBTSxJQUFJLE9BQU8sSUFBSSxNQUFTO0FBQ3hELFlBQU0sS0FBSyxXQUFXLFNBQVMsT0FBTyxNQUFNLFFBQVE7QUFBQSxJQUN0RDtBQUFBLEVBQ0Y7QUFBQSxFQUNBLE1BQWMsS0FBSyxTQUFrQixNQUFZLFVBQW9CO0FBQ25FLFVBQU0sSUFBSSxRQUFRLFNBQ2hCLEtBQUssU0FBUyxTQUFTLE9BQU8sS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUUsT0FBTztBQUM5RCxnQkFBWSxJQUFJLEVBQUUsS0FBSztBQUV2QixVQUFNLE9BQU8sWUFBWSxHQUFHLEVBQUUsS0FBSztBQUNuQztBQUFBLE1BQ0UsQ0FBQyxHQUFHLE9BQU8sS0FBSyxDQUFDLE1BQU0sV0FBVyxHQUFHLEVBQUUsS0FBSyxDQUFDO0FBQUEsTUFDN0M7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLFVBQU0sU0FBUyxFQUFFLEdBQUcsTUFBTSxRQUFRLEVBQUUsR0FBRyxLQUFLLE9BQU8sRUFBRTtBQUNyRCxlQUFXLFNBQVMsT0FBTyxPQUFPLE9BQU8sTUFBTSxFQUFHLE1BQUssS0FBSyxJQUFJLE1BQU0sRUFBRTtBQUN4RSxRQUFJLE9BQWlGLENBQUM7QUFDdEYsUUFBSSxlQUFlO0FBQ25CLFFBQUksaUJBQWlCO0FBRXJCLFVBQU0sVUFBVSxDQUFDLEdBQVksTUFDM0IsZ0JBQWdCLEVBQUUsUUFBUSxFQUFFLFFBQVEsSUFBSSxLQUFLLEVBQUUsTUFBTSxFQUFFO0FBQ3pELFVBQU0sbUJBQW1CLEtBQUssSUFBSSxJQUFJLE9BQU8sTUFBTSxLQUFLLE1BQU0sTUFBTTtBQUNwRSxVQUFNLGdCQUFnQixLQUFLLE9BQU8sT0FBTztBQUN6QyxVQUFNLGFBQWEsSUFBSTtBQUFBLE1BQ3JCLENBQUMsT0FBTyxLQUFLLFdBQVcsS0FBSyxXQUFXLE9BQU8sS0FBSyxRQUFRLFFBQVEsUUFBUTtBQUFBLE1BQzVFLENBQUMsU0FDQyxTQUFTLFNBQVMsT0FBTyxLQUFLLENBQUMsTUFBTSxFQUFFLEtBQUssWUFBWSxNQUFNLEtBQUssWUFBWSxDQUFDLEdBQUc7QUFBQSxNQUNyRjtBQUFBLE1BQ0E7QUFBQSxNQUNBLE1BQU0sU0FBUyxTQUFTO0FBQUEsSUFDMUI7QUFDQSxRQUFJO0FBQ0YsVUFBSSxhQUFhLFlBQVksSUFBSTtBQUNqQyxZQUFNLFlBQVksRUFBRSxNQUFNLFNBQVMsRUFBRSxNQUFNO0FBQzNDLFlBQU0sVUFBVSxLQUFLO0FBQUEsUUFDbkI7QUFBQSxRQUNBLEtBQUssSUFBSSxLQUFLLEtBQUssTUFBTSxRQUFRLEVBQUUsTUFBTSxZQUFZLEVBQUUsTUFBTSxZQUFZLENBQUM7QUFBQSxNQUM1RTtBQUNBLGVBQVMsTUFBTSxFQUFFLE1BQU0sVUFBVSxNQUFNLEVBQUUsTUFBTSxRQUFRLE9BQU8sU0FBUztBQUNyRSxjQUFNLFFBQW1CLENBQUM7QUFDMUIsWUFBSSxlQUFlO0FBQ25CLGlCQUFTLElBQUksS0FBSyxJQUFJLEtBQUssSUFBSSxNQUFNLFNBQVMsRUFBRSxNQUFNLE1BQU0sR0FBRyxLQUFLO0FBQ2xFLGVBQUssTUFBTTtBQUNYLGdCQUFNLFFBQWtDLENBQUM7QUFDekMsbUJBQVMsSUFBSSxFQUFFLE1BQU0sYUFBYSxJQUFJLEVBQUUsTUFBTSxXQUFXLEtBQUs7QUFDNUQsa0JBQU0sUUFFRixNQUFNLEtBQUssTUFBTSxhQUFhLEdBQUcsSUFBSSxHQUFHLFNBQVMsQ0FBQyxHQUFHLEdBQUcsWUFBWSxDQUFDLENBQUMsR0FBRyxNQUFNLEdBQy9FLEtBQU0sR0FBRyxTQUFTLENBQUMsSUFBSSxLQUFNLEtBQU0sR0FBRyxZQUFZLENBQUMsSUFBSSxFQUFHLEtBQUs7QUFDbkUsNEJBQWdCLGFBQWEsSUFBSSxJQUFJO0FBQ3JDO0FBQUEsY0FDRSxnQkFBZ0I7QUFBQSxjQUNoQjtBQUFBLGNBQ0E7QUFBQSxZQUNGO0FBQ0Esa0JBQU0sS0FBSyxJQUFJO0FBQUEsVUFDakI7QUFDQSxnQkFBTSxTQUFzQixDQUFDO0FBQzdCLHFCQUFXQSxRQUFPLE1BQU07QUFDdEIsa0JBQU0sUUFBUSxNQUFNQSxLQUFJLFNBQVMsRUFBRSxNQUFNLFdBQVcsR0FBRztBQUN2RCxrQkFBTSxRQUFRO0FBQUEsY0FDWixPQUFPLFNBQVMsWUFDWixNQUFNLFdBQVcsTUFBTSxHQUFHLElBQUksR0FBR0EsS0FBSSxNQUFNLElBQzNDLFFBQ0UsWUFBWSxLQUFLLElBQ2pCO0FBQUEsWUFDUjtBQUNBLDRCQUFnQixhQUFhLEtBQUssSUFBSTtBQUN0QztBQUFBLGNBQ0UsZ0JBQWdCO0FBQUEsY0FDaEI7QUFBQSxjQUNBO0FBQUEsWUFDRjtBQUNBLG1CQUFPLEtBQUssS0FBSztBQUFBLFVBQ25CO0FBQ0EsZ0JBQU0sS0FBSyxFQUFFLEtBQUssR0FBRyxPQUFPLE9BQU8sQ0FBQztBQUFBLFFBQ3RDO0FBQ0E7QUFBQSxVQUNFLGFBQWEsS0FBSyxJQUFJLEtBQUs7QUFBQSxVQUMzQjtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQ0EsY0FBTSxLQUFLLE9BQU87QUFDbEIsY0FBTSxNQUFNLEdBQUcsS0FBSyxFQUFFLFdBQVcsS0FBSyxNQUFNO0FBQzVDLGNBQU0sT0FBc0MsTUFBTSxJQUFJLENBQUMsR0FBRyxNQUFNO0FBQUEsVUFDOUQsR0FBRyxHQUFHLElBQUksT0FBTyxDQUFDLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUFBLFVBQ3BDO0FBQUEsUUFDRixDQUFDO0FBQ0QsY0FBTSxXQUFXLEtBQUssT0FBTyxDQUFDLE9BQU8sV0FBVyxRQUFRLGFBQWEsTUFBTSxHQUFHLENBQUM7QUFDL0Usd0JBQWdCO0FBQ2hCLGFBQUssZUFBZTtBQUNwQjtBQUFBLFVBQ0UsS0FBSyxZQUFZLGdCQUFnQixLQUFLO0FBQUEsVUFDdEM7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUNBLGNBQU0sS0FBSyxHQUFHLE1BQU0sV0FBVyxJQUFJO0FBQ25DLGFBQUssS0FBSztBQUFBLFVBQ1IsSUFBSTtBQUFBLFVBQ0osT0FBTyxNQUFNO0FBQUEsVUFDYixPQUFPO0FBQUEsVUFDUCxhQUFhLEtBQUssSUFBSSxHQUFHLE1BQU0sSUFBSSxDQUFDSSxTQUFRLGFBQWFBLElBQUcsSUFBSSxJQUFJLElBQUksQ0FBQztBQUFBLFFBQzNFLENBQUM7QUFBQSxNQUNIO0FBQ0EsV0FBSyxTQUFTO0FBQUEsUUFDWixPQUFPO0FBQUEsUUFDUCxXQUFXO0FBQUEsUUFDWCxPQUFPO0FBQUEsUUFDUCxXQUFXLFlBQVksSUFBSSxJQUFJO0FBQUEsTUFDakMsQ0FBQztBQUNELG1CQUFhLFlBQVksSUFBSTtBQUU3QixVQUFJLE9BQU87QUFDWCxhQUFPLEtBQUssU0FBUyxHQUFHO0FBQ3RCLGNBQU0sU0FBc0IsQ0FBQztBQUM3QixpQkFBUyxJQUFJLEdBQUcsSUFBSSxLQUFLLFFBQVEsS0FBSyxHQUFHO0FBQ3ZDLGNBQUksQ0FBQyxLQUFLLElBQUksQ0FBQyxHQUFHO0FBQ2hCLG1CQUFPLEtBQUssS0FBSyxDQUFDLENBQUM7QUFDbkI7QUFBQSxVQUNGO0FBQ0EsZ0JBQU0sT0FBTyxLQUFLLENBQUMsR0FDakIsUUFBUSxLQUFLLElBQUksQ0FBQyxHQUNsQixLQUFLLEdBQUcsS0FBSyxFQUFFLFNBQVMsSUFBSSxJQUFJLENBQUM7QUFDbkMsZ0JBQU0sY0FBYyxLQUFLLElBQUksS0FBSyxhQUFhLE1BQU0sV0FBVztBQUNoRTtBQUFBLFlBQ0UsS0FBSyxjQUFjLE1BQU0sZUFBZTtBQUFBLFlBQ3hDO0FBQUEsWUFDQTtBQUFBLFVBQ0Y7QUFHQSxnQkFBTSxXQUFXLGVBQWUsZ0JBQWdCO0FBQ2hELGdCQUFNLFlBQVksV0FDZCxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sZ0JBQWdCLElBQUksV0FBVyxDQUFDLElBQ3hEO0FBQ0osZ0JBQU0sS0FBSyxLQUFLO0FBQ2hCLDBCQUFnQixLQUFLLEtBQTRCO0FBQy9DLGdCQUFJLGNBQWMsR0FBRztBQUNuQix1QkFBUyxRQUFRLEdBQUcsUUFBUSxJQUFJLE9BQU8sU0FBUztBQUM5QyxzQkFBTSxRQUFRLE1BQU0sR0FBRztBQUFBLGtCQUNyQjtBQUFBLGtCQUNBLEdBQUcsSUFBSSxFQUFFLElBQUksT0FBTyxLQUFLLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUFBLGdCQUM3QztBQUNBLHVCQUFPLE9BQU8sbUJBQW1CLGtCQUFrQjtBQUNuRCxzQkFBTTtBQUFBLGNBQ1I7QUFBQSxZQUNGLE9BQU87QUFDTCwrQkFBaUIsV0FBVyxHQUFHO0FBQUEsZ0JBQzdCO0FBQUEsZ0JBQ0EsWUFBWSxJQUFJLEVBQUU7QUFBQSxnQkFDbEI7QUFBQSxjQUNGO0FBQ0UsMkJBQVcsQ0FBQyxFQUFFLEtBQUssS0FBSyxRQUFTLE9BQU07QUFBQSxZQUMzQztBQUFBLFVBQ0Y7QUFDQSxnQkFBTSxXQUFXLEtBQUssSUFBSSxHQUN4QixZQUFZLEtBQUssS0FBSztBQUN4QixjQUFJLElBQUksTUFBTSxTQUFTLEtBQUssR0FDMUIsSUFBSSxNQUFNLFVBQVUsS0FBSztBQUMzQixjQUFJLFNBQVMsR0FDWCxRQUFRO0FBQ1YsY0FBSSxVQUF5QyxDQUFDO0FBQzlDLGdCQUFNLGFBQWEsWUFBWTtBQUM3QixnQkFBSSxRQUFRLE9BQVEsT0FBTSxLQUFLLEdBQUcsTUFBTSxXQUFXLE9BQU87QUFDMUQsc0JBQVUsQ0FBQztBQUFBLFVBQ2I7QUFDQSxjQUFJO0FBQ0YsbUJBQU8sQ0FBQyxFQUFFLFFBQVEsQ0FBQyxFQUFFLE1BQU07QUFDekIsbUJBQUssTUFBTTtBQUNYLG9CQUFNLFdBQVcsQ0FBQyxFQUFFLFNBQVMsRUFBRSxRQUFRLFFBQVEsRUFBRSxPQUFPLEVBQUUsS0FBSyxLQUFLO0FBQ3BFLG9CQUFNLFFBQVEsV0FBVyxFQUFFLFFBQVMsRUFBRTtBQUN0QyxvQkFBTSxTQUFpQztBQUFBLGdCQUNyQyxHQUFHLEVBQUUsSUFBSSxPQUFPLFFBQVEsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDO0FBQUEsZ0JBQzFDO0FBQUEsY0FDRjtBQUNBLG9CQUFNLE9BQU8sYUFBYSxNQUFNO0FBQ2hDLDhCQUFnQjtBQUNoQix1QkFBUztBQUNULG1CQUFLLGVBQWU7QUFDcEI7QUFBQSxnQkFDRSxLQUFLLFlBQVksZ0JBQWdCLEtBQUs7QUFBQSxnQkFDdEM7QUFBQSxnQkFDQTtBQUFBLGNBQ0Y7QUFDQSxzQkFBUSxLQUFLLE1BQU07QUFDbkIsa0JBQUksUUFBUSxVQUFVLFVBQVcsT0FBTSxXQUFXO0FBQ2xELGtCQUFJLFNBQVUsS0FBSSxNQUFNLFNBQVMsS0FBSztBQUFBLGtCQUNqQyxLQUFJLE1BQU0sVUFBVSxLQUFLO0FBQUEsWUFDaEM7QUFDQSxrQkFBTSxXQUFXO0FBQ2pCLG1CQUFPLFdBQVcsS0FBSyxRQUFRLE1BQU0sT0FBTyxtQkFBbUIscUJBQXFCO0FBQUEsVUFDdEYsVUFBRTtBQUNBLGtCQUFNLFNBQVMsT0FBTyxNQUFTO0FBQy9CLGtCQUFNLFVBQVUsT0FBTyxNQUFTO0FBQUEsVUFDbEM7QUFDQSxnQkFBTSxLQUFLLEdBQUcsTUFBTSxXQUFXLENBQUMsR0FBRyxDQUFDLFlBQVksS0FBSyxFQUFFLEdBQUcsWUFBWSxNQUFNLEVBQUUsQ0FBQyxDQUFDO0FBQ2hGLDBCQUFnQixLQUFLLFFBQVEsTUFBTTtBQUNuQyxlQUFLLGVBQWU7QUFDcEIsaUJBQU8sS0FBSyxFQUFFLElBQUksT0FBTyxRQUFRLE9BQU8sWUFBWSxDQUFDO0FBQUEsUUFDdkQ7QUFDQSxlQUFPO0FBQ1A7QUFBQSxNQUNGO0FBQ0EsV0FBSyxTQUFTO0FBQUEsUUFDWixPQUFPO0FBQUEsUUFDUCxXQUFXO0FBQUEsUUFDWCxPQUFPO0FBQUEsUUFDUCxXQUFXLFlBQVksSUFBSSxJQUFJO0FBQUEsTUFDakMsQ0FBQztBQUNELG1CQUFhLFlBQVksSUFBSTtBQUM3QixVQUFJLFdBQVc7QUFDZixZQUFNLFVBQVUsb0JBQUksSUFBd0M7QUFDNUQsVUFBSSxlQUFlLEdBQ2pCLFVBQVU7QUFDWixZQUFNLFFBQVEsWUFBWTtBQUN4QixtQkFBVyxDQUFDLFNBQVMsS0FBSyxLQUFLLFNBQVM7QUFDdEMsZUFBSyxNQUFNO0FBQ1gsZ0JBQU0sS0FBSyxXQUFXLFNBQVMsT0FBTyxNQUFNLFFBQVE7QUFBQSxRQUN0RDtBQUNBLGdCQUFRLE1BQU07QUFDZCx1QkFBZTtBQUFBLE1BQ2pCO0FBQ0EsZUFBUyxNQUFNLEVBQUUsTUFBTSxVQUFVLE1BQU0sRUFBRSxNQUFNLFFBQVEsT0FBTztBQUM1RCxhQUFLLE1BQU07QUFDWCxjQUFNLFFBQVMsTUFBTSxLQUFLLEdBQUc7QUFBQSxVQUMzQjtBQUFBLFVBQ0EsR0FBRyxLQUFLLENBQUMsRUFBRSxFQUFFLElBQUksT0FBTyxVQUFVLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUFBLFFBQ3REO0FBQ0EsY0FBTSxhQUFhLGFBQWEsS0FBSyxJQUFJO0FBQ3pDO0FBQUEsVUFDRSxjQUFjO0FBQUEsVUFDZDtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQ0EsY0FBTSxPQUFPLEtBQUssTUFBTSxHQUFHLFNBQVMsR0FBRyxJQUFJLEVBQUU7QUFDN0MsWUFBSSxZQUFZLFFBQVEsZUFBZSxhQUFhLGNBQWUsT0FBTSxNQUFNO0FBQy9FLGtCQUFVO0FBQ1YsY0FBTSxVQUFVLE9BQU8sU0FBaUIsUUFBUSxNQUFNO0FBQ3BELGNBQUksUUFBUSxJQUFJLE9BQU8sS0FBSyxlQUFlLGFBQWEsUUFBUTtBQUM5RCxrQkFBTSxNQUFNO0FBQ2QsY0FBSSxDQUFDLFFBQVEsSUFBSSxPQUFPLEdBQUc7QUFDekIsa0JBQU0sU0FBUyxNQUFNLEtBQUssTUFBTSxTQUFTLElBQUksR0FBRztBQUNoRCxrQkFBTSxRQUFRLGFBQWEsS0FBSyxJQUFJO0FBQ3BDLGdCQUFJLGVBQWUsUUFBUSxhQUFhLFFBQVEsY0FBZSxPQUFNLE1BQU07QUFDM0U7QUFBQSxjQUNFLFFBQVEsYUFBYSxTQUFTO0FBQUEsY0FDOUI7QUFBQSxjQUNBO0FBQUEsWUFDRjtBQUNBLG9CQUFRLElBQUksU0FBUyxnQkFBZ0IsS0FBSyxDQUFDO0FBQzNDLDRCQUFnQjtBQUFBLFVBQ2xCO0FBQ0EsaUJBQU8sUUFBUSxJQUFJLE9BQU87QUFBQSxRQUM1QjtBQUNBLGlCQUFTLElBQUksRUFBRSxNQUFNLGFBQWEsSUFBSSxFQUFFLE1BQU0sV0FBVyxLQUFLO0FBQzVELGdCQUFNLElBQUksYUFBYSxHQUFHLElBQUksR0FBRyxTQUFTLEdBQUcsR0FBRyxHQUFHLFlBQVksQ0FBQyxDQUFDO0FBQ2pFLGNBQUksUUFBUSxNQUFNLFFBQVEsQ0FBQztBQUMzQixnQkFBTSxJQUFJLElBQUksR0FBRyxTQUFTLEdBQUcsR0FBRyxHQUFHLFlBQVksQ0FBQyxDQUFDO0FBQ2pELGdCQUFNLE9BQU8sTUFBTSxNQUFNLElBQUksRUFBRSxNQUFNLFdBQVc7QUFDaEQsY0FBSSxDQUFDLE1BQU07QUFDVCxnQkFBSSxNQUFNLENBQUMsRUFBRyxpQkFBZ0IsYUFBYSxNQUFNLENBQUMsQ0FBQyxJQUFJO0FBQ3ZELG1CQUFPLE1BQU0sQ0FBQztBQUFBLFVBQ2hCLE9BQU87QUFDTCxrQkFBTSxTQUFTLGdCQUFnQixJQUFJO0FBQ25DLG1CQUFPLFFBQVEsR0FBRyxTQUFTLEdBQUc7QUFDOUIsbUJBQU8sV0FBVyxHQUFHLFlBQVksQ0FBQztBQUNsQyxtQkFBTyxPQUFPO0FBQ2QsZ0JBQUksT0FBTyxNQUFNLFNBQVM7QUFDeEIscUJBQU8sTUFBTSxhQUFhO0FBQUEsZ0JBQ3hCLE9BQU8sTUFBTTtBQUFBLGdCQUNiLE1BQU0sTUFBTTtBQUFBLGdCQUNaO0FBQUEsY0FDRjtBQUNGLGtCQUFNLFVBQ0gsYUFBYSxNQUFNLEtBQ2pCLE1BQU0sQ0FBQyxJQUFJLGFBQWEsTUFBTSxDQUFDLENBQUMsSUFBSSxNQUNwQyxNQUFNLENBQUMsSUFBSSxJQUFJLEVBQUUsU0FBUyxNQUM3QjtBQUNGLG9CQUFRLE1BQU0sUUFBUSxHQUFHLEtBQUssSUFBSSxHQUFHLE1BQU0sQ0FBQztBQUM1QyxrQkFBTSxDQUFDLElBQUk7QUFDWCw0QkFBZ0I7QUFBQSxVQUNsQjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EsWUFBTSxNQUFNO0FBQ1osV0FBSyxTQUFTO0FBQUEsUUFDWixPQUFPO0FBQUEsUUFDUCxXQUFXO0FBQUEsUUFDWCxPQUFPO0FBQUEsUUFDUCxXQUFXLFlBQVksSUFBSSxJQUFJO0FBQUEsTUFDakMsQ0FBQztBQUNELHVCQUFpQjtBQUFBLElBQ25CLFVBQUU7QUFDQSxpQkFBVyxNQUFNO0FBQ2pCLFVBQUk7QUFDRixjQUFNLEtBQUssR0FBRyxNQUFNLFdBQVcsQ0FBQyxHQUFHLENBQUMsWUFBWSxHQUFHLEtBQUssRUFBRSxPQUFPLENBQUMsQ0FBQztBQUNuRSxhQUFLLGVBQWU7QUFBQSxNQUN0QixRQUFRO0FBQ04sYUFBSyxXQUFXO0FBQ2hCLFlBQUk7QUFDRixnQkFBTSxJQUFJLGVBQWUsaUJBQWlCLDZDQUE2QztBQUFBLE1BQzNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLE1BQU0sUUFBUSxNQUFlO0FBQzNCLFdBQU8sS0FBSyxRQUFRLGFBQWEsaUNBQWlDO0FBQ2xFLFNBQUssWUFBWTtBQUNqQixTQUFLLFFBQVEsTUFBTTtBQUNuQixVQUFNLE9BQU87QUFBQSxNQUNULEdBQUcsS0FBSztBQUFBLE1BQ1IsUUFBUSxFQUFFLEdBQUcsS0FBSyxLQUFLLE9BQU87QUFBQSxNQUM5QixNQUFNLENBQUMsR0FBRyxLQUFLLEtBQUssSUFBSTtBQUFBLE1BQ3hCLFFBQVEsQ0FBQyxHQUFHLEtBQUssS0FBSyxNQUFNO0FBQUEsSUFDOUIsR0FDQSxPQUFPLE9BQU8sS0FBSyxTQUFTLEtBQUssTUFDakMsS0FBSyxPQUFPLEtBQUssT0FBTyxLQUFLO0FBQy9CLFVBQU0sS0FBSyxLQUFLLElBQUk7QUFDcEIsUUFBSSxDQUFDLEdBQUksUUFBTyxFQUFFLE1BQU0sS0FBSyxLQUFLLEdBQUcsUUFBUSxPQUFVO0FBQ3ZELFVBQU0sSUFBSSxLQUFLLFVBQVUsSUFBSSxFQUFFLEtBQU0sTUFBTSxLQUFLLFlBQVksRUFBRTtBQUM5RCxXQUFPLEdBQUcsbUJBQW1CLGlCQUFpQjtBQUM5QyxlQUFXLENBQUMsR0FBRyxRQUFRLEtBQUssS0FBSyxFQUFFLFNBQVM7QUFDMUMsV0FBSyxRQUFRLElBQUksQ0FBQztBQUNsQixZQUFNLElBQUksT0FBTyxRQUFRO0FBQ3pCLFVBQUksRUFBRyxNQUFLLE9BQU8sQ0FBQyxJQUFJO0FBQUEsVUFDbkIsUUFBTyxLQUFLLE9BQU8sQ0FBQztBQUFBLElBQzNCO0FBQ0EsU0FBSyxPQUFPLE9BQU8sRUFBRSxRQUFRLEVBQUU7QUFDL0IsU0FBSztBQUNMLE9BQUcsS0FBSyxFQUFFO0FBQ1YsU0FBSyxnQkFBZ0IsT0FBTyxFQUFFLFFBQVEsQ0FBQyxFQUFFO0FBQ3pDLFVBQU0sV0FBVztBQUFBLE1BQ2YsR0FBSSxLQUFLLFNBQVMsS0FBSyxLQUFLLE9BQU8sS0FBSyxXQUFXLE1BQU0sS0FBSyxhQUFhLEtBQUssSUFBSTtBQUFBLElBQ3RGO0FBQ0EsVUFBTSxLQUFLLFFBQVEsTUFBTSxRQUFRO0FBQ2pDLFVBQU0sS0FBSyxRQUFRLE1BQU0sVUFBVSxLQUFLLFNBQVMsS0FBSyxLQUFLLE9BQU8sRUFBRSxTQUFTLE1BQVM7QUFDdEYsV0FBTztBQUFBLE1BQ0wsTUFBTSxLQUFLLEtBQUs7QUFBQSxNQUNoQixRQUFRO0FBQUEsUUFDTixXQUFXLElBQUksS0FBSztBQUFBLFFBQ3BCLGtCQUFrQixLQUFLLFdBQVc7QUFBQSxRQUNsQyxVQUFVLEtBQUs7QUFBQSxRQUNmLFFBQVEsT0FBTyxTQUFTO0FBQUEsUUFDeEIsVUFBVSxDQUFDO0FBQUEsUUFDWCxlQUFlLEVBQUU7QUFBQSxNQUNuQjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUEsRUFDQSxNQUFNLE9BQ0osU0FDQSxPQUNBLFFBQVEsSUFDUixjQUFjLE9BQ2QsWUFBaUMsUUFDakM7QUFDQSxTQUFLLE1BQU07QUFDWCw0QkFBd0IsU0FBUyxPQUFPLE9BQU8sU0FBUztBQUN4RDtBQUFBLE1BQ0UsT0FBTyxnQkFBZ0I7QUFBQSxNQUN2QjtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsVUFBTSxLQUFLLEtBQUssU0FBUyxTQUFTLE9BQU8sS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDckUsV0FBTyxJQUFJLG9CQUFvQixzQkFBc0I7QUFDckQsVUFBTSxJQUFJLE1BQU0sWUFBWTtBQUM1QixVQUFNLFVBQVUsY0FBYztBQUM5QixVQUFNLFdBQVcsQ0FBQyxHQUFXLE1BQWUsVUFBVSxJQUFJLElBQUksSUFBSTtBQUNsRSxVQUFNLFFBQVEsR0FBRyxZQUFZO0FBQzdCLFVBQU0sV0FBVyxDQUFDLFVBQThCQyxZQUFtQjtBQUFBLE1BQ2pFLE9BQ0UsYUFBYSxTQUNULFNBQ0EsRUFBRSxLQUFLLEtBQUssTUFBTSxXQUFXLEtBQUssR0FBRyxRQUFRLFdBQVcsTUFBTTtBQUFBLE1BQ3BFLE9BQUFBO0FBQUEsSUFDRjtBQUNBLFVBQU0sT0FBTyxLQUFLO0FBQ2xCLFVBQU0sU0FBUyxLQUFLLGNBQWMsSUFBSSxJQUFJO0FBQzFDLFFBQUksUUFBUSxZQUFZLFdBQVcsT0FBTyxVQUFVLEdBQUc7QUFDckQsWUFBTSxFQUFFLFdBQUFDLFdBQVUsSUFBSTtBQUN0QixVQUFJLE1BQU0sR0FDUixPQUFPQSxXQUFVO0FBQ25CLGFBQU8sTUFBTSxNQUFNO0FBQ2pCLGNBQU0sTUFBTyxNQUFNLFNBQVU7QUFDN0IsWUFBSSxVQUFVQSxXQUFVLEdBQUcsSUFBSSxRQUFRQSxXQUFVLEdBQUcsS0FBSyxNQUFPLE9BQU0sTUFBTTtBQUFBLFlBQ3ZFLFFBQU87QUFBQSxNQUNkO0FBQ0EsYUFBTztBQUFBLFFBQ0wsVUFBV0EsV0FBVSxNQUFNLENBQUMsS0FBS0EsV0FBVSxHQUFHLEVBQUUsSUFBTUEsV0FBVSxHQUFHLEtBQUtBLFdBQVUsQ0FBQztBQUFBLFFBQ25GQSxXQUFVO0FBQUEsTUFDWjtBQUFBLElBQ0Y7QUFDQSxRQUFJLFlBQWtDLEVBQUUsVUFBVSxPQUFPLENBQUMsSUFBSTtBQUM5RCxRQUFJLE1BQ0YsTUFDQSxRQUFRO0FBQ1YsVUFBTSxPQUFPLEtBQUssS0FBSyxHQUFHLFFBQVEsR0FDaEMsT0FBTyxLQUFLLEtBQUssR0FBRyxXQUFXO0FBQ2pDLFFBQUksVUFBVSxHQUNaLFlBQVk7QUFDZCxlQUFXLENBQUMsQ0FBQyxLQUFLLE9BQU8sUUFBUSxLQUFLLEtBQUssTUFBTTtBQUMvQyxVQUFJLEVBQUUsV0FBVyxHQUFHLE9BQU8sR0FBRztBQUM1QixtQkFBVyxTQUFTLE1BQU0sS0FBSyxNQUFNLENBQUMsR0FBRyxRQUFRLEdBQUc7QUFDbEQsY0FBSSxlQUFlLEVBQUUsVUFBVSxVQUFVLEdBQUc7QUFDMUMsa0JBQU0sSUFBSSxRQUFjLENBQUMsWUFBWSxXQUFXLFNBQVMsQ0FBQyxDQUFDO0FBQzNELHdCQUFZO0FBQUEsVUFDZDtBQUNBLGVBQUssTUFBTTtBQUNYLGdCQUFNLE1BQU0sS0FBSyxJQUFJLEtBQUssS0FBSyxHQUM3QixTQUFTLEtBQUssSUFBSSxLQUFLLFFBQVE7QUFDakMsZ0JBQU0sUUFDSixLQUFLLE1BQU0sU0FBUyxZQUNoQixNQUFNLEtBQUssV0FBVyxNQUFNLFNBQVMsS0FBSyxNQUFNLElBQ2hELFlBQVksS0FBSyxLQUFLO0FBQzVCO0FBQUEsWUFDRSxFQUFFLFNBQVMsT0FBTyxVQUFVLFlBQVksTUFBTSxVQUFVO0FBQUEsWUFDeEQ7QUFBQSxZQUNBO0FBQUEsVUFDRjtBQUNBLGdCQUFNLFVBQ0osU0FDQSxPQUFPLFVBQVUsWUFDakIsS0FBSyxVQUNMLEtBQUssS0FBSyxhQUFhLEtBQUssU0FBUyxpQkFDakM7QUFBQSxZQUNFLFlBQVksS0FBSyxNQUFNO0FBQUEsWUFDdkIsS0FBSztBQUFBLFlBQ0wsS0FBSyxTQUFTLFNBQVM7QUFBQSxVQUN6QixJQUFJLE9BQ0o7QUFBQSxZQUNFO0FBQUEsWUFDQSxLQUFLLGdCQUNILEtBQUssU0FBUyxTQUFTLE9BQU8sS0FBSyxXQUFXLEVBQUUsR0FBRztBQUFBLFlBQ3JELEtBQUssU0FBUyxTQUFTO0FBQUEsVUFDekI7QUFHTixjQUFJLGFBQWE7QUFDZix5QkFBYSxRQUFRO0FBQ3JCLGdCQUFJLGFBQWEseUJBQXlCO0FBQ3hDLDBCQUFZO0FBQ1osb0JBQU0sSUFBSSxRQUFjLENBQUMsWUFBWSxXQUFXLFNBQVMsQ0FBQyxDQUFDO0FBQzNELG1CQUFLLE1BQU07QUFBQSxZQUNiO0FBQUEsVUFDRjtBQUNBLGNBQUksQ0FBQyxRQUFRLFlBQVksRUFBRSxTQUFTLENBQUMsRUFBRztBQUN4QztBQUNBLGdCQUFNLFdBQVcsTUFBTSxRQUFRO0FBQy9CLGNBQUksV0FBVztBQUNiLGdCQUFJLFVBQVUsV0FBVyxNQUFPLGFBQVk7QUFBQSxnQkFDdkMsV0FBVSxLQUFLLFFBQVE7QUFBQSxVQUM5QjtBQUNBLGNBQUksU0FBUyxVQUFhLFNBQVMsVUFBVSxJQUFJLEVBQUcsUUFBTztBQUMzRCxjQUFJLFNBQVMsT0FBTyxRQUFRLE1BQU0sU0FBUyxVQUFhLFNBQVMsVUFBVSxJQUFJO0FBQzdFLG1CQUFPO0FBQUEsUUFDWDtBQUNKLFNBQUssTUFBTTtBQUVYLFFBQUksYUFBYSxLQUFLLFNBQVM7QUFDN0IsV0FBSyxjQUFjLElBQUksTUFBTTtBQUFBLFFBQzNCO0FBQUEsUUFDQSxPQUFPO0FBQUEsUUFDUCxXQUFXLFlBQVksS0FBSyxTQUFTLEVBQUUsS0FBSztBQUFBLE1BQzlDLENBQUM7QUFDSCxXQUFPLFNBQVMsUUFBUSxNQUFNLEtBQUs7QUFBQSxFQUNyQztBQUFBLEVBQ0EsTUFBTSxRQUFRO0FBQ1osV0FBTyxLQUFLLFFBQVEsYUFBYSxpQ0FBaUM7QUFDbEUsVUFBTSxLQUFLLEdBQUcsZUFBZSxLQUFLLElBQUksWUFBWSxLQUFLLEVBQUUsQ0FBQztBQUMxRCxTQUFLLE1BQU0sTUFBTTtBQUFBLEVBQ25CO0FBQUEsRUFDQSxRQUFRO0FBQ04sU0FBSyxTQUFTO0FBQ2QsU0FBSyxVQUFVO0FBQ2YsU0FBSyxVQUFVO0FBQ2YsU0FBSyxHQUFHLE1BQU07QUFDZCxTQUFLLE1BQU0sTUFBTTtBQUNqQixTQUFLLEtBQUssTUFBTTtBQUFBLEVBQ2xCO0FBQ0Y7QUFFTyxnQkFBUyxhQUFhLEdBQXNDO0FBQ2pFLE1BQUksSUFBSyxLQUFLLEtBQUssSUFBSSxHQUFHLE9BQU8sSUFBSSxlQUFnQjtBQUNyRCxNQUFJLElBQUksS0FBSyxFQUFHLFFBQU8sTUFBTSxJQUFJLElBQUksSUFBSTtBQUN6QyxNQUFJLElBQUksT0FBTyxFQUFHLFNBQVMsSUFBSSxLQUFNLEtBQUssTUFBTTtBQUNoRCxNQUFJLE9BQU87QUFDWCxXQUFTLElBQUksR0FBRyxJQUFJLElBQUksS0FBSztBQUMzQixRQUFLLEtBQUssS0FBSyxHQUFHLE9BQU8sSUFBSSxlQUFnQjtBQUM3QyxZQUFRLE9BQU8sYUFBYSxLQUFNLElBQUksRUFBRztBQUFBLEVBQzNDO0FBQ0EsU0FBTztBQUNUOyIsIm5hbWVzIjpbImtleSIsImlkIiwiaW5kZXgiLCJvbGQiLCJyb3ciLCJjb3VudCIsInBvc2l0aW9ucyJdfQ==
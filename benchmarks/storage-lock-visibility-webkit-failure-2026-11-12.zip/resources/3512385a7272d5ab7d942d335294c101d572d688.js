import { parseFormula } from "/@fs/Volumes/github/private/opensheet/packages/formula/src/parser.ts";
import { printFormula } from "/@fs/Volumes/github/private/opensheet/packages/formula/src/printer.ts";
import { FORMULA_COLUMNS, FORMULA_ROWS } from "/@fs/Volumes/github/private/opensheet/packages/formula/src/reference-bounds.ts";
function checkedReference(ref, fn) {
  const result = fn(ref);
  return result && Number.isInteger(result.row) && Number.isInteger(result.column) && result.row >= 0 && result.row < FORMULA_ROWS && result.column >= 0 && result.column < FORMULA_COLUMNS ? result : null;
}
export function transformReferences(ast, fn, transformRange) {
  if (ast.kind === "ref")
    return checkedReference(ast, fn) ?? { kind: "literal", value: { error: "#REF!" } };
  if (ast.kind === "range") {
    const range = transformRange?.(ast.start, ast.end);
    if (transformRange && !range) return { kind: "literal", value: { error: "#REF!" } };
    const start = checkedReference(range?.[0] ?? ast.start, transformRange ? (ref) => ref : fn), end = checkedReference(range?.[1] ?? ast.end, transformRange ? (ref) => ref : fn);
    return start && end ? { kind: "range", start, end } : { kind: "literal", value: { error: "#REF!" } };
  }
  if (ast.kind === "unary")
    return { ...ast, value: transformReferences(ast.value, fn, transformRange) };
  if (ast.kind === "binary")
    return {
      ...ast,
      left: transformReferences(ast.left, fn, transformRange),
      right: transformReferences(ast.right, fn, transformRange)
    };
  if (ast.kind === "call")
    return { ...ast, args: ast.args.map((a) => transformReferences(a, fn, transformRange)) };
  return ast;
}
function offsetAST(ast, rows, columns) {
  return printFormula(
    transformReferences(ast, (r) => {
      const row = r.row + (r.absoluteRow ? 0 : rows), column = r.column + (r.absoluteColumn ? 0 : columns);
      return row < 0 || column < 0 ? null : { ...r, row, column };
    })
  );
}
export function offsetFormula(expression, rows, columns) {
  return offsetAST(parseFormula(expression), rows, columns);
}
export function createFormulaOffsetter(expression) {
  const ast = parseFormula(expression);
  const movable = (node) => {
    if (node.kind === "ref") return !node.absoluteRow || !node.absoluteColumn;
    if (node.kind === "range") return movable(node.start) || movable(node.end);
    if (node.kind === "unary") return movable(node.value);
    if (node.kind === "binary") return movable(node.left) || movable(node.right);
    if (node.kind === "call") return node.args.some(movable);
    return false;
  };
  if (!movable(ast)) {
    const result = offsetAST(ast, 0, 0);
    return () => result;
  }
  return (rows, columns) => offsetAST(ast, rows, columns);
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlZmVyZW5jZXMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgcGFyc2VGb3JtdWxhIH0gZnJvbSAnLi9wYXJzZXIuanMnO1xuaW1wb3J0IHsgcHJpbnRGb3JtdWxhIH0gZnJvbSAnLi9wcmludGVyLmpzJztcbmltcG9ydCB0eXBlIHsgQVNULCBSZWZlcmVuY2UgfSBmcm9tICcuL3R5cGVzLmpzJztcbmltcG9ydCB7IEZPUk1VTEFfQ09MVU1OUywgRk9STVVMQV9ST1dTIH0gZnJvbSAnLi9yZWZlcmVuY2UtYm91bmRzLmpzJztcblxuZnVuY3Rpb24gY2hlY2tlZFJlZmVyZW5jZShyZWY6IFJlZmVyZW5jZSwgZm46IChyZWY6IFJlZmVyZW5jZSkgPT4gUmVmZXJlbmNlIHwgbnVsbCkge1xuICBjb25zdCByZXN1bHQgPSBmbihyZWYpO1xuICByZXR1cm4gcmVzdWx0ICYmXG4gICAgTnVtYmVyLmlzSW50ZWdlcihyZXN1bHQucm93KSAmJlxuICAgIE51bWJlci5pc0ludGVnZXIocmVzdWx0LmNvbHVtbikgJiZcbiAgICByZXN1bHQucm93ID49IDAgJiZcbiAgICByZXN1bHQucm93IDwgRk9STVVMQV9ST1dTICYmXG4gICAgcmVzdWx0LmNvbHVtbiA+PSAwICYmXG4gICAgcmVzdWx0LmNvbHVtbiA8IEZPUk1VTEFfQ09MVU1OU1xuICAgID8gcmVzdWx0XG4gICAgOiBudWxsO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gdHJhbnNmb3JtUmVmZXJlbmNlcyhcbiAgYXN0OiBBU1QsXG4gIGZuOiAocmVmOiBSZWZlcmVuY2UpID0+IFJlZmVyZW5jZSB8IG51bGwsXG4gIHRyYW5zZm9ybVJhbmdlPzogKHN0YXJ0OiBSZWZlcmVuY2UsIGVuZDogUmVmZXJlbmNlKSA9PiBbUmVmZXJlbmNlLCBSZWZlcmVuY2VdIHwgbnVsbCxcbik6IEFTVCB7XG4gIGlmIChhc3Qua2luZCA9PT0gJ3JlZicpXG4gICAgcmV0dXJuIGNoZWNrZWRSZWZlcmVuY2UoYXN0LCBmbikgPz8geyBraW5kOiAnbGl0ZXJhbCcsIHZhbHVlOiB7IGVycm9yOiAnI1JFRiEnIH0gfTtcbiAgaWYgKGFzdC5raW5kID09PSAncmFuZ2UnKSB7XG4gICAgY29uc3QgcmFuZ2UgPSB0cmFuc2Zvcm1SYW5nZT8uKGFzdC5zdGFydCwgYXN0LmVuZCk7XG4gICAgaWYgKHRyYW5zZm9ybVJhbmdlICYmICFyYW5nZSkgcmV0dXJuIHsga2luZDogJ2xpdGVyYWwnLCB2YWx1ZTogeyBlcnJvcjogJyNSRUYhJyB9IH07XG4gICAgY29uc3Qgc3RhcnQgPSBjaGVja2VkUmVmZXJlbmNlKHJhbmdlPy5bMF0gPz8gYXN0LnN0YXJ0LCB0cmFuc2Zvcm1SYW5nZSA/IChyZWYpID0+IHJlZiA6IGZuKSxcbiAgICAgIGVuZCA9IGNoZWNrZWRSZWZlcmVuY2UocmFuZ2U/LlsxXSA/PyBhc3QuZW5kLCB0cmFuc2Zvcm1SYW5nZSA/IChyZWYpID0+IHJlZiA6IGZuKTtcbiAgICByZXR1cm4gc3RhcnQgJiYgZW5kXG4gICAgICA/IHsga2luZDogJ3JhbmdlJywgc3RhcnQsIGVuZCB9XG4gICAgICA6IHsga2luZDogJ2xpdGVyYWwnLCB2YWx1ZTogeyBlcnJvcjogJyNSRUYhJyB9IH07XG4gIH1cbiAgaWYgKGFzdC5raW5kID09PSAndW5hcnknKVxuICAgIHJldHVybiB7IC4uLmFzdCwgdmFsdWU6IHRyYW5zZm9ybVJlZmVyZW5jZXMoYXN0LnZhbHVlLCBmbiwgdHJhbnNmb3JtUmFuZ2UpIH07XG4gIGlmIChhc3Qua2luZCA9PT0gJ2JpbmFyeScpXG4gICAgcmV0dXJuIHtcbiAgICAgIC4uLmFzdCxcbiAgICAgIGxlZnQ6IHRyYW5zZm9ybVJlZmVyZW5jZXMoYXN0LmxlZnQsIGZuLCB0cmFuc2Zvcm1SYW5nZSksXG4gICAgICByaWdodDogdHJhbnNmb3JtUmVmZXJlbmNlcyhhc3QucmlnaHQsIGZuLCB0cmFuc2Zvcm1SYW5nZSksXG4gICAgfTtcbiAgaWYgKGFzdC5raW5kID09PSAnY2FsbCcpXG4gICAgcmV0dXJuIHsgLi4uYXN0LCBhcmdzOiBhc3QuYXJncy5tYXAoKGEpID0+IHRyYW5zZm9ybVJlZmVyZW5jZXMoYSwgZm4sIHRyYW5zZm9ybVJhbmdlKSkgfTtcbiAgcmV0dXJuIGFzdDtcbn1cbmZ1bmN0aW9uIG9mZnNldEFTVChhc3Q6IEFTVCwgcm93czogbnVtYmVyLCBjb2x1bW5zOiBudW1iZXIpOiBzdHJpbmcge1xuICByZXR1cm4gcHJpbnRGb3JtdWxhKFxuICAgIHRyYW5zZm9ybVJlZmVyZW5jZXMoYXN0LCAocikgPT4ge1xuICAgICAgY29uc3Qgcm93ID0gci5yb3cgKyAoci5hYnNvbHV0ZVJvdyA/IDAgOiByb3dzKSxcbiAgICAgICAgY29sdW1uID0gci5jb2x1bW4gKyAoci5hYnNvbHV0ZUNvbHVtbiA/IDAgOiBjb2x1bW5zKTtcbiAgICAgIHJldHVybiByb3cgPCAwIHx8IGNvbHVtbiA8IDAgPyBudWxsIDogeyAuLi5yLCByb3csIGNvbHVtbiB9O1xuICAgIH0pLFxuICApO1xufVxuZXhwb3J0IGZ1bmN0aW9uIG9mZnNldEZvcm11bGEoZXhwcmVzc2lvbjogc3RyaW5nLCByb3dzOiBudW1iZXIsIGNvbHVtbnM6IG51bWJlcik6IHN0cmluZyB7XG4gIHJldHVybiBvZmZzZXRBU1QocGFyc2VGb3JtdWxhKGV4cHJlc3Npb24pLCByb3dzLCBjb2x1bW5zKTtcbn1cblxuLyoqIFBhcnNlIG9uY2UgZm9yIHJlcGVhdGVkIHJlZmVyZW5jZSByZWxvY2F0aW9uOyB0aGUgcmV0dXJuZWQgZnVuY3Rpb24gb3ducyBpdHMgaW1tdXRhYmxlIEFTVC4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVGb3JtdWxhT2Zmc2V0dGVyKFxuICBleHByZXNzaW9uOiBzdHJpbmcsXG4pOiAocm93czogbnVtYmVyLCBjb2x1bW5zOiBudW1iZXIpID0+IHN0cmluZyB7XG4gIGNvbnN0IGFzdCA9IHBhcnNlRm9ybXVsYShleHByZXNzaW9uKTtcbiAgY29uc3QgbW92YWJsZSA9IChub2RlOiBBU1QpOiBib29sZWFuID0+IHtcbiAgICBpZiAobm9kZS5raW5kID09PSAncmVmJykgcmV0dXJuICFub2RlLmFic29sdXRlUm93IHx8ICFub2RlLmFic29sdXRlQ29sdW1uO1xuICAgIGlmIChub2RlLmtpbmQgPT09ICdyYW5nZScpIHJldHVybiBtb3ZhYmxlKG5vZGUuc3RhcnQpIHx8IG1vdmFibGUobm9kZS5lbmQpO1xuICAgIGlmIChub2RlLmtpbmQgPT09ICd1bmFyeScpIHJldHVybiBtb3ZhYmxlKG5vZGUudmFsdWUpO1xuICAgIGlmIChub2RlLmtpbmQgPT09ICdiaW5hcnknKSByZXR1cm4gbW92YWJsZShub2RlLmxlZnQpIHx8IG1vdmFibGUobm9kZS5yaWdodCk7XG4gICAgaWYgKG5vZGUua2luZCA9PT0gJ2NhbGwnKSByZXR1cm4gbm9kZS5hcmdzLnNvbWUobW92YWJsZSk7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9O1xuICBpZiAoIW1vdmFibGUoYXN0KSkge1xuICAgIGNvbnN0IHJlc3VsdCA9IG9mZnNldEFTVChhc3QsIDAsIDApO1xuICAgIHJldHVybiAoKSA9PiByZXN1bHQ7XG4gIH1cbiAgcmV0dXJuIChyb3dzLCBjb2x1bW5zKSA9PiBvZmZzZXRBU1QoYXN0LCByb3dzLCBjb2x1bW5zKTtcbn1cbiJdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxvQkFBb0I7QUFFN0IsU0FBUyxpQkFBaUIsb0JBQW9CO0FBRTlDLFNBQVMsaUJBQWlCLEtBQWdCLElBQTBDO0FBQ2xGLFFBQU0sU0FBUyxHQUFHLEdBQUc7QUFDckIsU0FBTyxVQUNMLE9BQU8sVUFBVSxPQUFPLEdBQUcsS0FDM0IsT0FBTyxVQUFVLE9BQU8sTUFBTSxLQUM5QixPQUFPLE9BQU8sS0FDZCxPQUFPLE1BQU0sZ0JBQ2IsT0FBTyxVQUFVLEtBQ2pCLE9BQU8sU0FBUyxrQkFDZCxTQUNBO0FBQ047QUFFTyxnQkFBUyxvQkFDZCxLQUNBLElBQ0EsZ0JBQ0s7QUFDTCxNQUFJLElBQUksU0FBUztBQUNmLFdBQU8saUJBQWlCLEtBQUssRUFBRSxLQUFLLEVBQUUsTUFBTSxXQUFXLE9BQU8sRUFBRSxPQUFPLFFBQVEsRUFBRTtBQUNuRixNQUFJLElBQUksU0FBUyxTQUFTO0FBQ3hCLFVBQU0sUUFBUSxpQkFBaUIsSUFBSSxPQUFPLElBQUksR0FBRztBQUNqRCxRQUFJLGtCQUFrQixDQUFDLE1BQU8sUUFBTyxFQUFFLE1BQU0sV0FBVyxPQUFPLEVBQUUsT0FBTyxRQUFRLEVBQUU7QUFDbEYsVUFBTSxRQUFRLGlCQUFpQixRQUFRLENBQUMsS0FBSyxJQUFJLE9BQU8saUJBQWlCLENBQUMsUUFBUSxNQUFNLEVBQUUsR0FDeEYsTUFBTSxpQkFBaUIsUUFBUSxDQUFDLEtBQUssSUFBSSxLQUFLLGlCQUFpQixDQUFDLFFBQVEsTUFBTSxFQUFFO0FBQ2xGLFdBQU8sU0FBUyxNQUNaLEVBQUUsTUFBTSxTQUFTLE9BQU8sSUFBSSxJQUM1QixFQUFFLE1BQU0sV0FBVyxPQUFPLEVBQUUsT0FBTyxRQUFRLEVBQUU7QUFBQSxFQUNuRDtBQUNBLE1BQUksSUFBSSxTQUFTO0FBQ2YsV0FBTyxFQUFFLEdBQUcsS0FBSyxPQUFPLG9CQUFvQixJQUFJLE9BQU8sSUFBSSxjQUFjLEVBQUU7QUFDN0UsTUFBSSxJQUFJLFNBQVM7QUFDZixXQUFPO0FBQUEsTUFDTCxHQUFHO0FBQUEsTUFDSCxNQUFNLG9CQUFvQixJQUFJLE1BQU0sSUFBSSxjQUFjO0FBQUEsTUFDdEQsT0FBTyxvQkFBb0IsSUFBSSxPQUFPLElBQUksY0FBYztBQUFBLElBQzFEO0FBQ0YsTUFBSSxJQUFJLFNBQVM7QUFDZixXQUFPLEVBQUUsR0FBRyxLQUFLLE1BQU0sSUFBSSxLQUFLLElBQUksQ0FBQyxNQUFNLG9CQUFvQixHQUFHLElBQUksY0FBYyxDQUFDLEVBQUU7QUFDekYsU0FBTztBQUNUO0FBQ0EsU0FBUyxVQUFVLEtBQVUsTUFBYyxTQUF5QjtBQUNsRSxTQUFPO0FBQUEsSUFDTCxvQkFBb0IsS0FBSyxDQUFDLE1BQU07QUFDOUIsWUFBTSxNQUFNLEVBQUUsT0FBTyxFQUFFLGNBQWMsSUFBSSxPQUN2QyxTQUFTLEVBQUUsVUFBVSxFQUFFLGlCQUFpQixJQUFJO0FBQzlDLGFBQU8sTUFBTSxLQUFLLFNBQVMsSUFBSSxPQUFPLEVBQUUsR0FBRyxHQUFHLEtBQUssT0FBTztBQUFBLElBQzVELENBQUM7QUFBQSxFQUNIO0FBQ0Y7QUFDTyxnQkFBUyxjQUFjLFlBQW9CLE1BQWMsU0FBeUI7QUFDdkYsU0FBTyxVQUFVLGFBQWEsVUFBVSxHQUFHLE1BQU0sT0FBTztBQUMxRDtBQUdPLGdCQUFTLHVCQUNkLFlBQzJDO0FBQzNDLFFBQU0sTUFBTSxhQUFhLFVBQVU7QUFDbkMsUUFBTSxVQUFVLENBQUMsU0FBdUI7QUFDdEMsUUFBSSxLQUFLLFNBQVMsTUFBTyxRQUFPLENBQUMsS0FBSyxlQUFlLENBQUMsS0FBSztBQUMzRCxRQUFJLEtBQUssU0FBUyxRQUFTLFFBQU8sUUFBUSxLQUFLLEtBQUssS0FBSyxRQUFRLEtBQUssR0FBRztBQUN6RSxRQUFJLEtBQUssU0FBUyxRQUFTLFFBQU8sUUFBUSxLQUFLLEtBQUs7QUFDcEQsUUFBSSxLQUFLLFNBQVMsU0FBVSxRQUFPLFFBQVEsS0FBSyxJQUFJLEtBQUssUUFBUSxLQUFLLEtBQUs7QUFDM0UsUUFBSSxLQUFLLFNBQVMsT0FBUSxRQUFPLEtBQUssS0FBSyxLQUFLLE9BQU87QUFDdkQsV0FBTztBQUFBLEVBQ1Q7QUFDQSxNQUFJLENBQUMsUUFBUSxHQUFHLEdBQUc7QUFDakIsVUFBTSxTQUFTLFVBQVUsS0FBSyxHQUFHLENBQUM7QUFDbEMsV0FBTyxNQUFNO0FBQUEsRUFDZjtBQUNBLFNBQU8sQ0FBQyxNQUFNLFlBQVksVUFBVSxLQUFLLE1BQU0sT0FBTztBQUN4RDsiLCJuYW1lcyI6W119
import { parseFormula } from "/@fs/Volumes/github/private/opensheet/packages/formula/src/index.ts";
import { assert, key, LIMITS, OpenSheetError } from "/@fs/Volumes/github/private/opensheet/packages/core/src/types.ts";
import { encodeFileCells, decodeFileCells } from "/@fs/Volumes/github/private/opensheet/packages/core/src/file-codec.ts";
const encoder = new TextEncoder();
const decoder = new TextDecoder("utf-8", { fatal: true });
function decodeText(bytes) {
  try {
    return decoder.decode(bytes);
  } catch {
    throw new OpenSheetError("CORRUPT_STORAGE", "Invalid page UTF-8");
  }
}
const kinds = ["numbers", "strings", "booleans", "formulas", "errors"];
function columnInput(name, value) {
  switch (name) {
    case "numbers":
      return { type: "number", value };
    case "strings":
      return { type: "string", value };
    case "booleans":
      return { type: "boolean", value };
    case "formulas":
      return { type: "formula", expression: value };
    case "errors":
      return { type: "error", code: value };
  }
}
const align = (n) => Math.ceil(n / 8) * 8;
const bitmap = (indices, length) => {
  const bytes = new Uint8Array(Math.ceil(length / 8));
  for (const i of indices) bytes[i >> 3] |= 1 << (i & 7);
  return bytes;
};
function positions(indices) {
  const runs = [];
  for (const i of indices) {
    if (runs.length && runs.at(-2) + runs.at(-1) === i) runs[runs.length - 1]++;
    else runs.push(i, 1);
  }
  const little = (values) => {
    const bytes = new Uint8Array(values.length * 2), view = new DataView(bytes.buffer);
    values.forEach((value, i) => view.setUint16(i * 2, value, true));
    return bytes;
  };
  const list = little(indices), run = little(runs), bits = bitmap(indices, 2048);
  if (run.byteLength < list.byteLength && run.byteLength <= bits.byteLength)
    return { mode: 1, bytes: run };
  if (bits.byteLength < list.byteLength) return { mode: 2, bytes: bits };
  return { mode: 0, bytes: list };
}
function numbers(values) {
  const integers = values.every((v) => Number.isInteger(v) && !Object.is(v, -0));
  let data;
  if (integers && values.every((v) => v >= -128 && v <= 127)) data = new Int8Array(values);
  else if (integers && values.every((v) => v >= -32768 && v <= 32767))
    data = new Int16Array(values);
  else if (integers && values.every((v) => v >= -2147483648 && v <= 2147483647))
    data = new Int32Array(values);
  else data = new Float64Array(values);
  const bytes = new Uint8Array(data.byteLength), view = new DataView(bytes.buffer);
  values.forEach((v, i) => {
    if (data.BYTES_PER_ELEMENT === 1) view.setInt8(i, v);
    else if (data.BYTES_PER_ELEMENT === 2) view.setInt16(i * 2, v, true);
    else if (data.BYTES_PER_ELEMENT === 4) view.setInt32(i * 4, v, true);
    else view.setFloat64(i * 8, v, true);
  });
  return { type: data.BYTES_PER_ELEMENT, bytes };
}
const utf16 = (text) => {
  const bytes = new Uint8Array(text.length * 2), view = new DataView(bytes.buffer);
  for (let i = 0; i < text.length; i++) view.setUint16(i * 2, text.charCodeAt(i), true);
  return bytes;
};
function strings(values) {
  const wide = values.some(
    (v) => /[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/u.test(v)
  );
  const unique = [...new Set(values)], encode = wide ? utf16 : (s) => encoder.encode(s);
  const pack = (texts, dictionary) => {
    const parts = texts.map(encode), arenaBytes = parts.reduce((n, b) => n + b.byteLength, 0);
    const header = 4 + (dictionary ? values.length * 2 : 0) + (texts.length + 1) * 4;
    const bytes = new Uint8Array(header + arenaBytes), view = new DataView(bytes.buffer);
    view.setUint32(0, texts.length, true);
    let cursor = 4;
    if (dictionary) {
      const map = new Map(texts.map((v, i) => [v, i]));
      values.forEach((v, i) => view.setUint16(cursor + i * 2, map.get(v), true));
      cursor += values.length * 2;
    }
    let offset = 0;
    parts.forEach((part, i) => {
      view.setUint32(cursor + i * 4, offset, true);
      bytes.set(part, header + offset);
      offset += part.byteLength;
    });
    view.setUint32(cursor + texts.length * 4, offset, true);
    return { type: (wide ? 16 : 0) + (dictionary ? 1 : 0), bytes };
  };
  const plain = pack(values, false), dict = pack(unique, true);
  return dict.bytes.byteLength < plain.bytes.byteLength ? dict : plain;
}
export function encodeBlock(cells, rowIds, columnIds, _dependencies) {
  const values = Object.values(cells), row = Math.floor((values[0]?.rowId ?? rowIds[0] ?? 0) / 64), column = Math.floor((values[0]?.columnId ?? columnIds[0] ?? 0) / 32);
  assert(
    values.every((c) => Math.floor(c.rowId / 64) === row && Math.floor(c.columnId / 32) === column),
    "INVALID_ARGUMENT",
    "Cells cross page boundaries"
  );
  const styles = [...new Set(values.flatMap((c) => c.styleId === void 0 ? [] : [c.styleId]))];
  const data = encodeFileCells(values, new Map(styles.map((s, i) => [s, i])));
  const sections = [], buffers = [];
  let offset = 0;
  for (const name of kinds) {
    const col = data[name];
    if (!col) continue;
    const pos = positions(col.positions);
    const vals = name === "numbers" ? numbers(
      col.values.map(
        (v, i) => data.negativeZero?.includes(col.positions[i]) ? -0 : v
      )
    ) : name === "booleans" ? {
      type: 0,
      bytes: bitmap(
        col.values.flatMap((v, i) => v ? [i] : []),
        col.values.length
      )
    } : strings(col.values);
    const section = {
      name,
      positions: { mode: pos.mode, count: col.positions.length, offset, bytes: pos.bytes.length },
      type: vals.type,
      offset: 0,
      bytes: vals.bytes.length
    };
    buffers.push(pos.bytes);
    offset += align(pos.bytes.length);
    section.offset = offset;
    buffers.push(vals.bytes);
    offset += align(vals.bytes.length);
    sections.push(section);
    delete data[name];
  }
  delete data.negativeZero;
  const meta = encoder.encode(JSON.stringify({ row, column, styles, data, sections }));
  assert(
    align(8 + meta.length) + offset <= 32 * 1024 * 1024,
    "LIMIT_EXCEEDED",
    "Page exceeds 32 MiB working budget"
  );
  const header = align(8 + meta.length), result = new Uint8Array(header + offset), view = new DataView(result.buffer);
  result.set([79, 83, 80, 3]);
  view.setUint32(4, meta.length, true);
  result.set(meta, 8);
  let cursor = header;
  for (const bytes of buffers) {
    result.set(bytes, cursor);
    cursor += align(bytes.length);
  }
  return result;
}
export class ColumnPage {
  constructor(buffer) {
    this.buffer = buffer;
    assert(
      buffer.length >= 8 && buffer[0] === 79 && buffer[1] === 83 && buffer[2] === 80 && buffer[3] === 3,
      "CORRUPT_STORAGE",
      "Unsupported page format"
    );
    const view = new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength), size = view.getUint32(4, true), base = align(8 + size);
    assert(base <= buffer.length, "CORRUPT_STORAGE", "Invalid page header");
    const text = decodeText(buffer.subarray(8, 8 + size));
    let meta;
    try {
      meta = JSON.parse(text);
    } catch {
      throw new OpenSheetError("CORRUPT_STORAGE", "Invalid page metadata JSON");
    }
    const object = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
    assert(
      object(meta) && Object.keys(meta).every(
        (name) => ["row", "column", "styles", "data", "sections"].includes(name)
      ) && typeof meta.row === "number" && Number.isInteger(meta.row) && typeof meta.column === "number" && Number.isInteger(meta.column) && Array.isArray(meta.styles) && meta.styles.every((style) => typeof style === "string") && object(meta.data) && Array.isArray(meta.sections),
      "CORRUPT_STORAGE",
      "Invalid page metadata"
    );
    this.row = meta.row;
    this.column = meta.column;
    this.styles = meta.styles;
    const data = meta.data;
    const inlineKinds = new Set(kinds.filter((name) => Object.hasOwn(data, name)));
    let previousEnd = 0;
    let sectionTextBytes = 0;
    for (const section of meta.sections) {
      assert(
        object(section) && Object.keys(section).every(
          (name) => ["name", "positions", "type", "offset", "bytes"].includes(name)
        ) && object(section.positions) && Object.keys(section.positions).every(
          (name) => ["mode", "count", "offset", "bytes"].includes(name)
        ) && kinds.includes(section.name) && !Object.hasOwn(data, section.name) && !this.columns.some((c) => c.name === section.name) && Number.isInteger(section.positions.count) && section.positions.count > 0 && section.positions.count <= 2048,
        "CORRUPT_STORAGE",
        "Invalid page section"
      );
      const bounds = (offset, bytes) => {
        assert(
          Number.isInteger(offset) && Number.isInteger(bytes) && offset >= previousEnd && bytes >= 0 && base + offset + bytes <= buffer.length,
          "CORRUPT_STORAGE",
          "Invalid page offsets"
        );
        previousEnd = offset + bytes;
      };
      bounds(section.positions.offset, section.positions.bytes);
      const pview = new DataView(
        buffer.buffer,
        buffer.byteOffset + base + section.positions.offset,
        section.positions.bytes
      ), list = [];
      if (section.positions.mode === 0) {
        assert(
          pview.byteLength === section.positions.count * 2,
          "CORRUPT_STORAGE",
          "Position length"
        );
        for (let i = 0; i < section.positions.count; i++) list.push(pview.getUint16(i * 2, true));
      } else if (section.positions.mode === 1) {
        assert(pview.byteLength % 4 === 0, "CORRUPT_STORAGE", "Run length");
        for (let i = 0; i < pview.byteLength; i += 4) {
          const start = pview.getUint16(i, true), count2 = pview.getUint16(i + 2, true);
          assert(
            count2 > 0 && start + count2 <= 2048 && list.length + count2 <= section.positions.count && (list.length === 0 || list[list.length - 1] < start),
            "CORRUPT_STORAGE",
            "Invalid position run"
          );
          for (let j = 0; j < count2; j++) list.push(start + j);
        }
      } else {
        assert(
          section.positions.mode === 2 && pview.byteLength === 256,
          "CORRUPT_STORAGE",
          "Bitmap length"
        );
        for (let i = 0; i < 2048; i++) if (pview.getUint8(i >> 3) & 1 << (i & 7)) list.push(i);
      }
      assert(
        list.length === section.positions.count && list.every((v, i) => v < 2048 && (i === 0 || list[i - 1] < v)),
        "CORRUPT_STORAGE",
        "Invalid page positions"
      );
      bounds(section.offset, section.bytes);
      const vview = new DataView(
        buffer.buffer,
        buffer.byteOffset + base + section.offset,
        section.bytes
      ), count = list.length;
      let value;
      if (section.name === "numbers") {
        assert(
          [1, 2, 4, 8].includes(section.type) && vview.byteLength === count * section.type,
          "CORRUPT_STORAGE",
          "Numeric length"
        );
        value = (i) => section.type === 1 ? vview.getInt8(i) : section.type === 2 ? vview.getInt16(i * 2, true) : section.type === 4 ? vview.getInt32(i * 4, true) : vview.getFloat64(i * 8, true);
      } else if (section.name === "booleans") {
        assert(
          section.type === 0 && vview.byteLength === Math.ceil(count / 8),
          "CORRUPT_STORAGE",
          "Boolean length"
        );
        value = (i) => !!(vview.getUint8(i >> 3) & 1 << (i & 7));
      } else {
        assert(
          [0, 1, 16, 17].includes(section.type) && vview.byteLength >= 4,
          "CORRUPT_STORAGE",
          "String type"
        );
        const dict = section.type % 16 === 1, wide = section.type >= 16, n = vview.getUint32(0, true), offsets = 4 + (dict ? count * 2 : 0), arena = offsets + (n + 1) * 4;
        assert(
          n > 0 && n <= count && (!dict ? n === count : true) && arena <= vview.byteLength,
          "CORRUPT_STORAGE",
          "String directory"
        );
        let prev = 0;
        for (let i = 0; i <= n; i++) {
          const at = vview.getUint32(offsets + i * 4, true);
          assert(
            at >= prev && arena + at <= vview.byteLength && (!wide || at % 2 === 0),
            "CORRUPT_STORAGE",
            "String offset"
          );
          if (i > 0) {
            const maxCharacters = section.name === "errors" ? 50 : LIMITS.text;
            assert(
              at - prev <= maxCharacters * (wide ? 2 : 3),
              "LIMIT_EXCEEDED",
              "Page string exceeds text limit"
            );
          }
          prev = at;
        }
        assert(arena + prev === vview.byteLength, "CORRUPT_STORAGE", "Trailing string bytes");
        value = (i) => {
          const index = dict ? vview.getUint16(4 + i * 2, true) : i;
          assert(index < n, "CORRUPT_STORAGE", "String dictionary index");
          const start = vview.getUint32(offsets + index * 4, true), end = vview.getUint32(offsets + (index + 1) * 4, true);
          if (!wide)
            return decodeText(
              new Uint8Array(vview.buffer, vview.byteOffset + arena + start, end - start)
            );
          let text2 = "";
          for (let p = start; p < end; p += 2)
            text2 += String.fromCharCode(vview.getUint16(arena + p, true));
          return text2;
        };
      }
      this.columns.push({ name: section.name, positions: new Uint16Array(list), value });
      const decodedValues = [];
      for (let i = 0; i < list.length; i++) {
        const decoded = value(i);
        if (typeof decoded === "string") {
          assert(
            decoded.length <= (section.name === "errors" ? 50 : LIMITS.text),
            "LIMIT_EXCEEDED",
            "Page string exceeds text limit"
          );
          sectionTextBytes += decoded.length * 3;
          assert(
            sectionTextBytes <= 32 * 1024 * 1024,
            "LIMIT_EXCEEDED",
            "Page text exceeds 32 MiB working budget"
          );
        }
        decodedValues.push(decoded);
      }
      data[section.name] = { positions: list, values: decodedValues };
    }
    this.extra = decodeFileCells(
      { row: this.row, column: this.column, data },
      this.styles,
      void 0,
      void 0,
      inlineKinds.size === 0
    );
    for (const cell of Object.values(this.extra)) {
      if (cell.input.type === "formula") {
        try {
          this.dependencies[key(cell.rowId, cell.columnId)] = parseFormula(cell.input.expression);
        } catch {
          this.dependencies[key(cell.rowId, cell.columnId)] = null;
        }
      }
      const kind = {
        number: "numbers",
        string: "strings",
        boolean: "booleans",
        formula: "formulas",
        error: "errors",
        blank: void 0
      }[cell.input.type];
      if (cell.input.type !== "blank" && (!kind || !inlineKinds.has(kind)))
        delete cell.input;
      if (Object.keys(cell).length === 2) delete this.extra[key(cell.rowId, cell.columnId)];
    }
    this.bytes = buffer.byteLength + this.columns.reduce((n, c) => n + c.positions.byteLength + 128, 0) + JSON.stringify(this.extra).length * 2 + Object.keys(this.extra).length * 192 + JSON.stringify(this.dependencies).length * 6 + 1024;
  }
  buffer;
  dependencies = {};
  row;
  column;
  styles;
  extra;
  columns = [];
  bytes;
  cell(offset) {
    const rowId = this.row * 64 + Math.floor(offset / 32), columnId = this.column * 32 + offset % 32;
    let input;
    for (const col of this.columns) {
      let low = 0, high = col.positions.length;
      while (low < high) {
        const mid = low + high >>> 1;
        if (col.positions[mid] < offset) low = mid + 1;
        else high = mid;
      }
      if (col.positions[low] !== offset) continue;
      input = columnInput(col.name, col.value(low));
      break;
    }
    const extra = this.extra[key(rowId, columnId)];
    if (!input && !extra) return;
    return { ...extra, rowId, columnId, input: input ?? extra?.input ?? { type: "blank" } };
  }
  /** Scan occupied cells without constructing a page map or binary-searching each column. */
  *records() {
    for (const column of this.columns) {
      for (let index = 0; index < column.positions.length; index++) {
        const offset = column.positions[index];
        const rowId = this.row * 64 + Math.floor(offset / 32);
        const columnId = this.column * 32 + offset % 32;
        yield {
          ...this.extra[key(rowId, columnId)],
          rowId,
          columnId,
          input: columnInput(column.name, column.value(index))
        };
      }
    }
    for (const cell of Object.values(this.extra)) if (cell.input) yield { ...cell };
  }
  get cells() {
    const offsets = new Set(
      Object.values(this.extra).map((c) => c.rowId % 64 * 32 + c.columnId % 32)
    );
    for (const col of this.columns) for (const offset of col.positions) offsets.add(offset);
    return Object.fromEntries(
      [...offsets].map((offset) => {
        const cell = this.cell(offset);
        return [key(cell.rowId, cell.columnId), cell];
      })
    );
  }
}
export const decodeBlock = (encoded) => new ColumnPage(encoded);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJsb2NrLWNvZGVjLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHBhcnNlRm9ybXVsYSB9IGZyb20gJ0BvcGVuc2hlZXRqcy9mb3JtdWxhJztcbmltcG9ydCB7IGFzc2VydCwga2V5LCBMSU1JVFMsIE9wZW5TaGVldEVycm9yLCB0eXBlIENlbGxSZWNvcmQsIHR5cGUgQ2VsbElucHV0IH0gZnJvbSAnLi90eXBlcy5qcyc7XG5pbXBvcnQgeyBlbmNvZGVGaWxlQ2VsbHMsIGRlY29kZUZpbGVDZWxscywgdHlwZSBGaWxlQmxvY2tEYXRhIH0gZnJvbSAnLi9maWxlLWNvZGVjLmpzJztcbmV4cG9ydCB0eXBlIEVuY29kZWRCbG9jayA9IFVpbnQ4QXJyYXk7XG5jb25zdCBlbmNvZGVyID0gbmV3IFRleHRFbmNvZGVyKCk7XG5jb25zdCBkZWNvZGVyID0gbmV3IFRleHREZWNvZGVyKCd1dGYtOCcsIHsgZmF0YWw6IHRydWUgfSk7XG5mdW5jdGlvbiBkZWNvZGVUZXh0KGJ5dGVzOiBVaW50OEFycmF5KTogc3RyaW5nIHtcbiAgdHJ5IHtcbiAgICByZXR1cm4gZGVjb2Rlci5kZWNvZGUoYnl0ZXMpO1xuICB9IGNhdGNoIHtcbiAgICB0aHJvdyBuZXcgT3BlblNoZWV0RXJyb3IoJ0NPUlJVUFRfU1RPUkFHRScsICdJbnZhbGlkIHBhZ2UgVVRGLTgnKTtcbiAgfVxufVxuY29uc3Qga2luZHMgPSBbJ251bWJlcnMnLCAnc3RyaW5ncycsICdib29sZWFucycsICdmb3JtdWxhcycsICdlcnJvcnMnXSBhcyBjb25zdDtcbnR5cGUgS2luZCA9ICh0eXBlb2Yga2luZHMpW251bWJlcl07XG5mdW5jdGlvbiBjb2x1bW5JbnB1dChuYW1lOiBLaW5kLCB2YWx1ZTogdW5rbm93bik6IENlbGxJbnB1dCB7XG4gIHN3aXRjaCAobmFtZSkge1xuICAgIGNhc2UgJ251bWJlcnMnOlxuICAgICAgcmV0dXJuIHsgdHlwZTogJ251bWJlcicsIHZhbHVlOiB2YWx1ZSBhcyBudW1iZXIgfTtcbiAgICBjYXNlICdzdHJpbmdzJzpcbiAgICAgIHJldHVybiB7IHR5cGU6ICdzdHJpbmcnLCB2YWx1ZTogdmFsdWUgYXMgc3RyaW5nIH07XG4gICAgY2FzZSAnYm9vbGVhbnMnOlxuICAgICAgcmV0dXJuIHsgdHlwZTogJ2Jvb2xlYW4nLCB2YWx1ZTogdmFsdWUgYXMgYm9vbGVhbiB9O1xuICAgIGNhc2UgJ2Zvcm11bGFzJzpcbiAgICAgIHJldHVybiB7IHR5cGU6ICdmb3JtdWxhJywgZXhwcmVzc2lvbjogdmFsdWUgYXMgc3RyaW5nIH07XG4gICAgY2FzZSAnZXJyb3JzJzpcbiAgICAgIHJldHVybiB7IHR5cGU6ICdlcnJvcicsIGNvZGU6IHZhbHVlIGFzIHN0cmluZyB9O1xuICB9XG59XG50eXBlIFNlY3Rpb24gPSB7XG4gIG5hbWU6IEtpbmQ7XG4gIHBvc2l0aW9uczogeyBtb2RlOiBudW1iZXI7IGNvdW50OiBudW1iZXI7IG9mZnNldDogbnVtYmVyOyBieXRlczogbnVtYmVyIH07XG4gIHR5cGU6IG51bWJlcjtcbiAgb2Zmc2V0OiBudW1iZXI7XG4gIGJ5dGVzOiBudW1iZXI7XG59O1xuY29uc3QgYWxpZ24gPSAobjogbnVtYmVyKSA9PiBNYXRoLmNlaWwobiAvIDgpICogODtcbmNvbnN0IGJpdG1hcCA9IChpbmRpY2VzOiBudW1iZXJbXSwgbGVuZ3RoOiBudW1iZXIpID0+IHtcbiAgY29uc3QgYnl0ZXMgPSBuZXcgVWludDhBcnJheShNYXRoLmNlaWwobGVuZ3RoIC8gOCkpO1xuICBmb3IgKGNvbnN0IGkgb2YgaW5kaWNlcykgYnl0ZXNbaSA+PiAzXSB8PSAxIDw8IChpICYgNyk7XG4gIHJldHVybiBieXRlcztcbn07XG5mdW5jdGlvbiBwb3NpdGlvbnMoaW5kaWNlczogbnVtYmVyW10pIHtcbiAgY29uc3QgcnVuczogbnVtYmVyW10gPSBbXTtcbiAgZm9yIChjb25zdCBpIG9mIGluZGljZXMpIHtcbiAgICBpZiAocnVucy5sZW5ndGggJiYgcnVucy5hdCgtMikhICsgcnVucy5hdCgtMSkhID09PSBpKSBydW5zW3J1bnMubGVuZ3RoIC0gMV0rKztcbiAgICBlbHNlIHJ1bnMucHVzaChpLCAxKTtcbiAgfVxuICBjb25zdCBsaXR0bGUgPSAodmFsdWVzOiBudW1iZXJbXSkgPT4ge1xuICAgIGNvbnN0IGJ5dGVzID0gbmV3IFVpbnQ4QXJyYXkodmFsdWVzLmxlbmd0aCAqIDIpLFxuICAgICAgdmlldyA9IG5ldyBEYXRhVmlldyhieXRlcy5idWZmZXIpO1xuICAgIHZhbHVlcy5mb3JFYWNoKCh2YWx1ZSwgaSkgPT4gdmlldy5zZXRVaW50MTYoaSAqIDIsIHZhbHVlLCB0cnVlKSk7XG4gICAgcmV0dXJuIGJ5dGVzO1xuICB9O1xuICBjb25zdCBsaXN0ID0gbGl0dGxlKGluZGljZXMpLFxuICAgIHJ1biA9IGxpdHRsZShydW5zKSxcbiAgICBiaXRzID0gYml0bWFwKGluZGljZXMsIDIwNDgpO1xuICBpZiAocnVuLmJ5dGVMZW5ndGggPCBsaXN0LmJ5dGVMZW5ndGggJiYgcnVuLmJ5dGVMZW5ndGggPD0gYml0cy5ieXRlTGVuZ3RoKVxuICAgIHJldHVybiB7IG1vZGU6IDEsIGJ5dGVzOiBydW4gfTtcbiAgaWYgKGJpdHMuYnl0ZUxlbmd0aCA8IGxpc3QuYnl0ZUxlbmd0aCkgcmV0dXJuIHsgbW9kZTogMiwgYnl0ZXM6IGJpdHMgfTtcbiAgcmV0dXJuIHsgbW9kZTogMCwgYnl0ZXM6IGxpc3QgfTtcbn1cbmZ1bmN0aW9uIG51bWJlcnModmFsdWVzOiBudW1iZXJbXSkge1xuICBjb25zdCBpbnRlZ2VycyA9IHZhbHVlcy5ldmVyeSgodikgPT4gTnVtYmVyLmlzSW50ZWdlcih2KSAmJiAhT2JqZWN0LmlzKHYsIC0wKSk7XG4gIGxldCBkYXRhOiBJbnQ4QXJyYXkgfCBJbnQxNkFycmF5IHwgSW50MzJBcnJheSB8IEZsb2F0NjRBcnJheTtcbiAgaWYgKGludGVnZXJzICYmIHZhbHVlcy5ldmVyeSgodikgPT4gdiA+PSAtMTI4ICYmIHYgPD0gMTI3KSkgZGF0YSA9IG5ldyBJbnQ4QXJyYXkodmFsdWVzKTtcbiAgZWxzZSBpZiAoaW50ZWdlcnMgJiYgdmFsdWVzLmV2ZXJ5KCh2KSA9PiB2ID49IC0zMjc2OCAmJiB2IDw9IDMyNzY3KSlcbiAgICBkYXRhID0gbmV3IEludDE2QXJyYXkodmFsdWVzKTtcbiAgZWxzZSBpZiAoaW50ZWdlcnMgJiYgdmFsdWVzLmV2ZXJ5KCh2KSA9PiB2ID49IC0yMTQ3NDgzNjQ4ICYmIHYgPD0gMjE0NzQ4MzY0NykpXG4gICAgZGF0YSA9IG5ldyBJbnQzMkFycmF5KHZhbHVlcyk7XG4gIGVsc2UgZGF0YSA9IG5ldyBGbG9hdDY0QXJyYXkodmFsdWVzKTtcbiAgLy8gUGVyc2lzdGVkIG51bWVyaWMgYnl0ZXMgYXJlIGxpdHRsZSBlbmRpYW4gb24gZXZlcnkgcGxhdGZvcm0uXG4gIGNvbnN0IGJ5dGVzID0gbmV3IFVpbnQ4QXJyYXkoZGF0YS5ieXRlTGVuZ3RoKSxcbiAgICB2aWV3ID0gbmV3IERhdGFWaWV3KGJ5dGVzLmJ1ZmZlcik7XG4gIHZhbHVlcy5mb3JFYWNoKCh2LCBpKSA9PiB7XG4gICAgaWYgKGRhdGEuQllURVNfUEVSX0VMRU1FTlQgPT09IDEpIHZpZXcuc2V0SW50OChpLCB2KTtcbiAgICBlbHNlIGlmIChkYXRhLkJZVEVTX1BFUl9FTEVNRU5UID09PSAyKSB2aWV3LnNldEludDE2KGkgKiAyLCB2LCB0cnVlKTtcbiAgICBlbHNlIGlmIChkYXRhLkJZVEVTX1BFUl9FTEVNRU5UID09PSA0KSB2aWV3LnNldEludDMyKGkgKiA0LCB2LCB0cnVlKTtcbiAgICBlbHNlIHZpZXcuc2V0RmxvYXQ2NChpICogOCwgdiwgdHJ1ZSk7XG4gIH0pO1xuICByZXR1cm4geyB0eXBlOiBkYXRhLkJZVEVTX1BFUl9FTEVNRU5ULCBieXRlcyB9O1xufVxuY29uc3QgdXRmMTYgPSAodGV4dDogc3RyaW5nKSA9PiB7XG4gIGNvbnN0IGJ5dGVzID0gbmV3IFVpbnQ4QXJyYXkodGV4dC5sZW5ndGggKiAyKSxcbiAgICB2aWV3ID0gbmV3IERhdGFWaWV3KGJ5dGVzLmJ1ZmZlcik7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgdGV4dC5sZW5ndGg7IGkrKykgdmlldy5zZXRVaW50MTYoaSAqIDIsIHRleHQuY2hhckNvZGVBdChpKSwgdHJ1ZSk7XG4gIHJldHVybiBieXRlcztcbn07XG5mdW5jdGlvbiBzdHJpbmdzKHZhbHVlczogc3RyaW5nW10pIHtcbiAgY29uc3Qgd2lkZSA9IHZhbHVlcy5zb21lKCh2KSA9PlxuICAgIC9bXFx1RDgwMC1cXHVEQkZGXSg/IVtcXHVEQzAwLVxcdURGRkZdKXwoPzwhW1xcdUQ4MDAtXFx1REJGRl0pW1xcdURDMDAtXFx1REZGRl0vdS50ZXN0KHYpLFxuICApO1xuICBjb25zdCB1bmlxdWUgPSBbLi4ubmV3IFNldCh2YWx1ZXMpXSxcbiAgICBlbmNvZGUgPSB3aWRlID8gdXRmMTYgOiAoczogc3RyaW5nKSA9PiBlbmNvZGVyLmVuY29kZShzKTtcbiAgY29uc3QgcGFjayA9ICh0ZXh0czogc3RyaW5nW10sIGRpY3Rpb25hcnk6IGJvb2xlYW4pID0+IHtcbiAgICBjb25zdCBwYXJ0cyA9IHRleHRzLm1hcChlbmNvZGUpLFxuICAgICAgYXJlbmFCeXRlcyA9IHBhcnRzLnJlZHVjZSgobiwgYikgPT4gbiArIGIuYnl0ZUxlbmd0aCwgMCk7XG4gICAgY29uc3QgaGVhZGVyID0gNCArIChkaWN0aW9uYXJ5ID8gdmFsdWVzLmxlbmd0aCAqIDIgOiAwKSArICh0ZXh0cy5sZW5ndGggKyAxKSAqIDQ7XG4gICAgY29uc3QgYnl0ZXMgPSBuZXcgVWludDhBcnJheShoZWFkZXIgKyBhcmVuYUJ5dGVzKSxcbiAgICAgIHZpZXcgPSBuZXcgRGF0YVZpZXcoYnl0ZXMuYnVmZmVyKTtcbiAgICB2aWV3LnNldFVpbnQzMigwLCB0ZXh0cy5sZW5ndGgsIHRydWUpO1xuICAgIGxldCBjdXJzb3IgPSA0O1xuICAgIGlmIChkaWN0aW9uYXJ5KSB7XG4gICAgICBjb25zdCBtYXAgPSBuZXcgTWFwKHRleHRzLm1hcCgodiwgaSkgPT4gW3YsIGldKSk7XG4gICAgICB2YWx1ZXMuZm9yRWFjaCgodiwgaSkgPT4gdmlldy5zZXRVaW50MTYoY3Vyc29yICsgaSAqIDIsIG1hcC5nZXQodikhLCB0cnVlKSk7XG4gICAgICBjdXJzb3IgKz0gdmFsdWVzLmxlbmd0aCAqIDI7XG4gICAgfVxuICAgIGxldCBvZmZzZXQgPSAwO1xuICAgIHBhcnRzLmZvckVhY2goKHBhcnQsIGkpID0+IHtcbiAgICAgIHZpZXcuc2V0VWludDMyKGN1cnNvciArIGkgKiA0LCBvZmZzZXQsIHRydWUpO1xuICAgICAgYnl0ZXMuc2V0KHBhcnQsIGhlYWRlciArIG9mZnNldCk7XG4gICAgICBvZmZzZXQgKz0gcGFydC5ieXRlTGVuZ3RoO1xuICAgIH0pO1xuICAgIHZpZXcuc2V0VWludDMyKGN1cnNvciArIHRleHRzLmxlbmd0aCAqIDQsIG9mZnNldCwgdHJ1ZSk7XG4gICAgcmV0dXJuIHsgdHlwZTogKHdpZGUgPyAxNiA6IDApICsgKGRpY3Rpb25hcnkgPyAxIDogMCksIGJ5dGVzIH07XG4gIH07XG4gIGNvbnN0IHBsYWluID0gcGFjayh2YWx1ZXMsIGZhbHNlKSxcbiAgICBkaWN0ID0gcGFjayh1bmlxdWUsIHRydWUpO1xuICByZXR1cm4gZGljdC5ieXRlcy5ieXRlTGVuZ3RoIDwgcGxhaW4uYnl0ZXMuYnl0ZUxlbmd0aCA/IGRpY3QgOiBwbGFpbjtcbn1cbmV4cG9ydCBmdW5jdGlvbiBlbmNvZGVCbG9jayhcbiAgY2VsbHM6IFJlY29yZDxzdHJpbmcsIENlbGxSZWNvcmQ+LFxuICByb3dJZHM6IG51bWJlcltdLFxuICBjb2x1bW5JZHM6IG51bWJlcltdLFxuICBfZGVwZW5kZW5jaWVzOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPixcbik6IEVuY29kZWRCbG9jayB7XG4gIGNvbnN0IHZhbHVlcyA9IE9iamVjdC52YWx1ZXMoY2VsbHMpLFxuICAgIHJvdyA9IE1hdGguZmxvb3IoKHZhbHVlc1swXT8ucm93SWQgPz8gcm93SWRzWzBdID8/IDApIC8gNjQpLFxuICAgIGNvbHVtbiA9IE1hdGguZmxvb3IoKHZhbHVlc1swXT8uY29sdW1uSWQgPz8gY29sdW1uSWRzWzBdID8/IDApIC8gMzIpO1xuICBhc3NlcnQoXG4gICAgdmFsdWVzLmV2ZXJ5KChjKSA9PiBNYXRoLmZsb29yKGMucm93SWQgLyA2NCkgPT09IHJvdyAmJiBNYXRoLmZsb29yKGMuY29sdW1uSWQgLyAzMikgPT09IGNvbHVtbiksXG4gICAgJ0lOVkFMSURfQVJHVU1FTlQnLFxuICAgICdDZWxscyBjcm9zcyBwYWdlIGJvdW5kYXJpZXMnLFxuICApO1xuICBjb25zdCBzdHlsZXMgPSBbLi4ubmV3IFNldCh2YWx1ZXMuZmxhdE1hcCgoYykgPT4gKGMuc3R5bGVJZCA9PT0gdW5kZWZpbmVkID8gW10gOiBbYy5zdHlsZUlkXSkpKV07XG4gIGNvbnN0IGRhdGEgPSBlbmNvZGVGaWxlQ2VsbHModmFsdWVzLCBuZXcgTWFwKHN0eWxlcy5tYXAoKHMsIGkpID0+IFtzLCBpXSkpKTtcbiAgY29uc3Qgc2VjdGlvbnM6IFNlY3Rpb25bXSA9IFtdLFxuICAgIGJ1ZmZlcnM6IFVpbnQ4QXJyYXlbXSA9IFtdO1xuICBsZXQgb2Zmc2V0ID0gMDtcbiAgZm9yIChjb25zdCBuYW1lIG9mIGtpbmRzKSB7XG4gICAgY29uc3QgY29sID0gZGF0YVtuYW1lXTtcbiAgICBpZiAoIWNvbCkgY29udGludWU7XG4gICAgY29uc3QgcG9zID0gcG9zaXRpb25zKGNvbC5wb3NpdGlvbnMpO1xuICAgIGNvbnN0IHZhbHMgPVxuICAgICAgbmFtZSA9PT0gJ251bWJlcnMnXG4gICAgICAgID8gbnVtYmVycyhcbiAgICAgICAgICAgIChjb2wudmFsdWVzIGFzIG51bWJlcltdKS5tYXAoKHYsIGkpID0+XG4gICAgICAgICAgICAgIGRhdGEubmVnYXRpdmVaZXJvPy5pbmNsdWRlcyhjb2wucG9zaXRpb25zW2ldKSA/IC0wIDogdixcbiAgICAgICAgICAgICksXG4gICAgICAgICAgKVxuICAgICAgICA6IG5hbWUgPT09ICdib29sZWFucydcbiAgICAgICAgICA/IHtcbiAgICAgICAgICAgICAgdHlwZTogMCxcbiAgICAgICAgICAgICAgYnl0ZXM6IGJpdG1hcChcbiAgICAgICAgICAgICAgICBjb2wudmFsdWVzLmZsYXRNYXAoKHYsIGkpID0+ICh2ID8gW2ldIDogW10pKSxcbiAgICAgICAgICAgICAgICBjb2wudmFsdWVzLmxlbmd0aCxcbiAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgIH1cbiAgICAgICAgICA6IHN0cmluZ3MoY29sLnZhbHVlcyBhcyBzdHJpbmdbXSk7XG4gICAgY29uc3Qgc2VjdGlvbjogU2VjdGlvbiA9IHtcbiAgICAgIG5hbWUsXG4gICAgICBwb3NpdGlvbnM6IHsgbW9kZTogcG9zLm1vZGUsIGNvdW50OiBjb2wucG9zaXRpb25zLmxlbmd0aCwgb2Zmc2V0LCBieXRlczogcG9zLmJ5dGVzLmxlbmd0aCB9LFxuICAgICAgdHlwZTogdmFscy50eXBlLFxuICAgICAgb2Zmc2V0OiAwLFxuICAgICAgYnl0ZXM6IHZhbHMuYnl0ZXMubGVuZ3RoLFxuICAgIH07XG4gICAgYnVmZmVycy5wdXNoKHBvcy5ieXRlcyk7XG4gICAgb2Zmc2V0ICs9IGFsaWduKHBvcy5ieXRlcy5sZW5ndGgpO1xuICAgIHNlY3Rpb24ub2Zmc2V0ID0gb2Zmc2V0O1xuICAgIGJ1ZmZlcnMucHVzaCh2YWxzLmJ5dGVzKTtcbiAgICBvZmZzZXQgKz0gYWxpZ24odmFscy5ieXRlcy5sZW5ndGgpO1xuICAgIHNlY3Rpb25zLnB1c2goc2VjdGlvbik7XG4gICAgZGVsZXRlIGRhdGFbbmFtZV07XG4gIH1cbiAgZGVsZXRlIGRhdGEubmVnYXRpdmVaZXJvO1xuICBjb25zdCBtZXRhID0gZW5jb2Rlci5lbmNvZGUoSlNPTi5zdHJpbmdpZnkoeyByb3csIGNvbHVtbiwgc3R5bGVzLCBkYXRhLCBzZWN0aW9ucyB9KSk7XG4gIGFzc2VydChcbiAgICBhbGlnbig4ICsgbWV0YS5sZW5ndGgpICsgb2Zmc2V0IDw9IDMyICogMTAyNCAqIDEwMjQsXG4gICAgJ0xJTUlUX0VYQ0VFREVEJyxcbiAgICAnUGFnZSBleGNlZWRzIDMyIE1pQiB3b3JraW5nIGJ1ZGdldCcsXG4gICk7XG4gIGNvbnN0IGhlYWRlciA9IGFsaWduKDggKyBtZXRhLmxlbmd0aCksXG4gICAgcmVzdWx0ID0gbmV3IFVpbnQ4QXJyYXkoaGVhZGVyICsgb2Zmc2V0KSxcbiAgICB2aWV3ID0gbmV3IERhdGFWaWV3KHJlc3VsdC5idWZmZXIpO1xuICByZXN1bHQuc2V0KFs3OSwgODMsIDgwLCAzXSk7XG4gIHZpZXcuc2V0VWludDMyKDQsIG1ldGEubGVuZ3RoLCB0cnVlKTtcbiAgcmVzdWx0LnNldChtZXRhLCA4KTtcbiAgbGV0IGN1cnNvciA9IGhlYWRlcjtcbiAgZm9yIChjb25zdCBieXRlcyBvZiBidWZmZXJzKSB7XG4gICAgcmVzdWx0LnNldChieXRlcywgY3Vyc29yKTtcbiAgICBjdXJzb3IgKz0gYWxpZ24oYnl0ZXMubGVuZ3RoKTtcbiAgfVxuICByZXR1cm4gcmVzdWx0O1xufVxuZXhwb3J0IGNsYXNzIENvbHVtblBhZ2Uge1xuICByZWFkb25seSBkZXBlbmRlbmNpZXM6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge307XG4gIHJlYWRvbmx5IHJvdzogbnVtYmVyO1xuICByZWFkb25seSBjb2x1bW46IG51bWJlcjtcbiAgcmVhZG9ubHkgc3R5bGVzOiBzdHJpbmdbXTtcbiAgcHJpdmF0ZSBleHRyYTogUmVjb3JkPHN0cmluZywgQ2VsbFJlY29yZD47XG4gIHByaXZhdGUgY29sdW1uczogQXJyYXk8e1xuICAgIG5hbWU6IEtpbmQ7XG4gICAgcG9zaXRpb25zOiBVaW50MTZBcnJheTtcbiAgICB2YWx1ZTogKGluZGV4OiBudW1iZXIpID0+IHVua25vd247XG4gIH0+ID0gW107XG4gIHJlYWRvbmx5IGJ5dGVzOiBudW1iZXI7XG4gIGNvbnN0cnVjdG9yKHJlYWRvbmx5IGJ1ZmZlcjogVWludDhBcnJheSkge1xuICAgIGFzc2VydChcbiAgICAgIGJ1ZmZlci5sZW5ndGggPj0gOCAmJlxuICAgICAgICBidWZmZXJbMF0gPT09IDc5ICYmXG4gICAgICAgIGJ1ZmZlclsxXSA9PT0gODMgJiZcbiAgICAgICAgYnVmZmVyWzJdID09PSA4MCAmJlxuICAgICAgICBidWZmZXJbM10gPT09IDMsXG4gICAgICAnQ09SUlVQVF9TVE9SQUdFJyxcbiAgICAgICdVbnN1cHBvcnRlZCBwYWdlIGZvcm1hdCcsXG4gICAgKTtcbiAgICBjb25zdCB2aWV3ID0gbmV3IERhdGFWaWV3KGJ1ZmZlci5idWZmZXIsIGJ1ZmZlci5ieXRlT2Zmc2V0LCBidWZmZXIuYnl0ZUxlbmd0aCksXG4gICAgICBzaXplID0gdmlldy5nZXRVaW50MzIoNCwgdHJ1ZSksXG4gICAgICBiYXNlID0gYWxpZ24oOCArIHNpemUpO1xuICAgIGFzc2VydChiYXNlIDw9IGJ1ZmZlci5sZW5ndGgsICdDT1JSVVBUX1NUT1JBR0UnLCAnSW52YWxpZCBwYWdlIGhlYWRlcicpO1xuICAgIGNvbnN0IHRleHQgPSBkZWNvZGVUZXh0KGJ1ZmZlci5zdWJhcnJheSg4LCA4ICsgc2l6ZSkpO1xuICAgIGxldCBtZXRhOiBhbnk7XG4gICAgdHJ5IHtcbiAgICAgIG1ldGEgPSBKU09OLnBhcnNlKHRleHQpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgdGhyb3cgbmV3IE9wZW5TaGVldEVycm9yKCdDT1JSVVBUX1NUT1JBR0UnLCAnSW52YWxpZCBwYWdlIG1ldGFkYXRhIEpTT04nKTtcbiAgICB9XG4gICAgY29uc3Qgb2JqZWN0ID0gKHZhbHVlOiB1bmtub3duKTogdmFsdWUgaXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPT5cbiAgICAgIHZhbHVlICE9PSBudWxsICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgIUFycmF5LmlzQXJyYXkodmFsdWUpO1xuICAgIGFzc2VydChcbiAgICAgIG9iamVjdChtZXRhKSAmJlxuICAgICAgICBPYmplY3Qua2V5cyhtZXRhKS5ldmVyeSgobmFtZSkgPT5cbiAgICAgICAgICBbJ3JvdycsICdjb2x1bW4nLCAnc3R5bGVzJywgJ2RhdGEnLCAnc2VjdGlvbnMnXS5pbmNsdWRlcyhuYW1lKSxcbiAgICAgICAgKSAmJlxuICAgICAgICB0eXBlb2YgbWV0YS5yb3cgPT09ICdudW1iZXInICYmXG4gICAgICAgIE51bWJlci5pc0ludGVnZXIobWV0YS5yb3cpICYmXG4gICAgICAgIHR5cGVvZiBtZXRhLmNvbHVtbiA9PT0gJ251bWJlcicgJiZcbiAgICAgICAgTnVtYmVyLmlzSW50ZWdlcihtZXRhLmNvbHVtbikgJiZcbiAgICAgICAgQXJyYXkuaXNBcnJheShtZXRhLnN0eWxlcykgJiZcbiAgICAgICAgbWV0YS5zdHlsZXMuZXZlcnkoKHN0eWxlOiB1bmtub3duKSA9PiB0eXBlb2Ygc3R5bGUgPT09ICdzdHJpbmcnKSAmJlxuICAgICAgICBvYmplY3QobWV0YS5kYXRhKSAmJlxuICAgICAgICBBcnJheS5pc0FycmF5KG1ldGEuc2VjdGlvbnMpLFxuICAgICAgJ0NPUlJVUFRfU1RPUkFHRScsXG4gICAgICAnSW52YWxpZCBwYWdlIG1ldGFkYXRhJyxcbiAgICApO1xuICAgIHRoaXMucm93ID0gbWV0YS5yb3c7XG4gICAgdGhpcy5jb2x1bW4gPSBtZXRhLmNvbHVtbjtcbiAgICB0aGlzLnN0eWxlcyA9IG1ldGEuc3R5bGVzO1xuICAgIGNvbnN0IGRhdGE6IEZpbGVCbG9ja0RhdGEgPSBtZXRhLmRhdGE7XG4gICAgY29uc3QgaW5saW5lS2luZHMgPSBuZXcgU2V0KGtpbmRzLmZpbHRlcigobmFtZSkgPT4gT2JqZWN0Lmhhc093bihkYXRhLCBuYW1lKSkpO1xuICAgIGxldCBwcmV2aW91c0VuZCA9IDA7XG4gICAgbGV0IHNlY3Rpb25UZXh0Qnl0ZXMgPSAwO1xuICAgIGZvciAoY29uc3Qgc2VjdGlvbiBvZiBtZXRhLnNlY3Rpb25zIGFzIFNlY3Rpb25bXSkge1xuICAgICAgYXNzZXJ0KFxuICAgICAgICBvYmplY3Qoc2VjdGlvbikgJiZcbiAgICAgICAgICBPYmplY3Qua2V5cyhzZWN0aW9uKS5ldmVyeSgobmFtZSkgPT5cbiAgICAgICAgICAgIFsnbmFtZScsICdwb3NpdGlvbnMnLCAndHlwZScsICdvZmZzZXQnLCAnYnl0ZXMnXS5pbmNsdWRlcyhuYW1lKSxcbiAgICAgICAgICApICYmXG4gICAgICAgICAgb2JqZWN0KHNlY3Rpb24ucG9zaXRpb25zKSAmJlxuICAgICAgICAgIE9iamVjdC5rZXlzKHNlY3Rpb24ucG9zaXRpb25zKS5ldmVyeSgobmFtZSkgPT5cbiAgICAgICAgICAgIFsnbW9kZScsICdjb3VudCcsICdvZmZzZXQnLCAnYnl0ZXMnXS5pbmNsdWRlcyhuYW1lKSxcbiAgICAgICAgICApICYmXG4gICAgICAgICAga2luZHMuaW5jbHVkZXMoc2VjdGlvbi5uYW1lKSAmJlxuICAgICAgICAgICFPYmplY3QuaGFzT3duKGRhdGEsIHNlY3Rpb24ubmFtZSkgJiZcbiAgICAgICAgICAhdGhpcy5jb2x1bW5zLnNvbWUoKGMpID0+IGMubmFtZSA9PT0gc2VjdGlvbi5uYW1lKSAmJlxuICAgICAgICAgIE51bWJlci5pc0ludGVnZXIoc2VjdGlvbi5wb3NpdGlvbnMuY291bnQpICYmXG4gICAgICAgICAgc2VjdGlvbi5wb3NpdGlvbnMuY291bnQgPiAwICYmXG4gICAgICAgICAgc2VjdGlvbi5wb3NpdGlvbnMuY291bnQgPD0gMjA0OCxcbiAgICAgICAgJ0NPUlJVUFRfU1RPUkFHRScsXG4gICAgICAgICdJbnZhbGlkIHBhZ2Ugc2VjdGlvbicsXG4gICAgICApO1xuICAgICAgY29uc3QgYm91bmRzID0gKG9mZnNldDogbnVtYmVyLCBieXRlczogbnVtYmVyKSA9PiB7XG4gICAgICAgIGFzc2VydChcbiAgICAgICAgICBOdW1iZXIuaXNJbnRlZ2VyKG9mZnNldCkgJiZcbiAgICAgICAgICAgIE51bWJlci5pc0ludGVnZXIoYnl0ZXMpICYmXG4gICAgICAgICAgICBvZmZzZXQgPj0gcHJldmlvdXNFbmQgJiZcbiAgICAgICAgICAgIGJ5dGVzID49IDAgJiZcbiAgICAgICAgICAgIGJhc2UgKyBvZmZzZXQgKyBieXRlcyA8PSBidWZmZXIubGVuZ3RoLFxuICAgICAgICAgICdDT1JSVVBUX1NUT1JBR0UnLFxuICAgICAgICAgICdJbnZhbGlkIHBhZ2Ugb2Zmc2V0cycsXG4gICAgICAgICk7XG4gICAgICAgIHByZXZpb3VzRW5kID0gb2Zmc2V0ICsgYnl0ZXM7XG4gICAgICB9O1xuICAgICAgYm91bmRzKHNlY3Rpb24ucG9zaXRpb25zLm9mZnNldCwgc2VjdGlvbi5wb3NpdGlvbnMuYnl0ZXMpO1xuICAgICAgY29uc3QgcHZpZXcgPSBuZXcgRGF0YVZpZXcoXG4gICAgICAgICAgYnVmZmVyLmJ1ZmZlcixcbiAgICAgICAgICBidWZmZXIuYnl0ZU9mZnNldCArIGJhc2UgKyBzZWN0aW9uLnBvc2l0aW9ucy5vZmZzZXQsXG4gICAgICAgICAgc2VjdGlvbi5wb3NpdGlvbnMuYnl0ZXMsXG4gICAgICAgICksXG4gICAgICAgIGxpc3Q6IG51bWJlcltdID0gW107XG4gICAgICBpZiAoc2VjdGlvbi5wb3NpdGlvbnMubW9kZSA9PT0gMCkge1xuICAgICAgICBhc3NlcnQoXG4gICAgICAgICAgcHZpZXcuYnl0ZUxlbmd0aCA9PT0gc2VjdGlvbi5wb3NpdGlvbnMuY291bnQgKiAyLFxuICAgICAgICAgICdDT1JSVVBUX1NUT1JBR0UnLFxuICAgICAgICAgICdQb3NpdGlvbiBsZW5ndGgnLFxuICAgICAgICApO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHNlY3Rpb24ucG9zaXRpb25zLmNvdW50OyBpKyspIGxpc3QucHVzaChwdmlldy5nZXRVaW50MTYoaSAqIDIsIHRydWUpKTtcbiAgICAgIH0gZWxzZSBpZiAoc2VjdGlvbi5wb3NpdGlvbnMubW9kZSA9PT0gMSkge1xuICAgICAgICBhc3NlcnQocHZpZXcuYnl0ZUxlbmd0aCAlIDQgPT09IDAsICdDT1JSVVBUX1NUT1JBR0UnLCAnUnVuIGxlbmd0aCcpO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHB2aWV3LmJ5dGVMZW5ndGg7IGkgKz0gNCkge1xuICAgICAgICAgIGNvbnN0IHN0YXJ0ID0gcHZpZXcuZ2V0VWludDE2KGksIHRydWUpLFxuICAgICAgICAgICAgY291bnQgPSBwdmlldy5nZXRVaW50MTYoaSArIDIsIHRydWUpO1xuICAgICAgICAgIGFzc2VydChcbiAgICAgICAgICAgIGNvdW50ID4gMCAmJlxuICAgICAgICAgICAgICBzdGFydCArIGNvdW50IDw9IDIwNDggJiZcbiAgICAgICAgICAgICAgbGlzdC5sZW5ndGggKyBjb3VudCA8PSBzZWN0aW9uLnBvc2l0aW9ucy5jb3VudCAmJlxuICAgICAgICAgICAgICAobGlzdC5sZW5ndGggPT09IDAgfHwgbGlzdFtsaXN0Lmxlbmd0aCAtIDFdIDwgc3RhcnQpLFxuICAgICAgICAgICAgJ0NPUlJVUFRfU1RPUkFHRScsXG4gICAgICAgICAgICAnSW52YWxpZCBwb3NpdGlvbiBydW4nLFxuICAgICAgICAgICk7XG4gICAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCBjb3VudDsgaisrKSBsaXN0LnB1c2goc3RhcnQgKyBqKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYXNzZXJ0KFxuICAgICAgICAgIHNlY3Rpb24ucG9zaXRpb25zLm1vZGUgPT09IDIgJiYgcHZpZXcuYnl0ZUxlbmd0aCA9PT0gMjU2LFxuICAgICAgICAgICdDT1JSVVBUX1NUT1JBR0UnLFxuICAgICAgICAgICdCaXRtYXAgbGVuZ3RoJyxcbiAgICAgICAgKTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCAyMDQ4OyBpKyspIGlmIChwdmlldy5nZXRVaW50OChpID4+IDMpICYgKDEgPDwgKGkgJiA3KSkpIGxpc3QucHVzaChpKTtcbiAgICAgIH1cbiAgICAgIGFzc2VydChcbiAgICAgICAgbGlzdC5sZW5ndGggPT09IHNlY3Rpb24ucG9zaXRpb25zLmNvdW50ICYmXG4gICAgICAgICAgbGlzdC5ldmVyeSgodiwgaSkgPT4gdiA8IDIwNDggJiYgKGkgPT09IDAgfHwgbGlzdFtpIC0gMV0gPCB2KSksXG4gICAgICAgICdDT1JSVVBUX1NUT1JBR0UnLFxuICAgICAgICAnSW52YWxpZCBwYWdlIHBvc2l0aW9ucycsXG4gICAgICApO1xuICAgICAgYm91bmRzKHNlY3Rpb24ub2Zmc2V0LCBzZWN0aW9uLmJ5dGVzKTtcbiAgICAgIGNvbnN0IHZ2aWV3ID0gbmV3IERhdGFWaWV3KFxuICAgICAgICAgIGJ1ZmZlci5idWZmZXIsXG4gICAgICAgICAgYnVmZmVyLmJ5dGVPZmZzZXQgKyBiYXNlICsgc2VjdGlvbi5vZmZzZXQsXG4gICAgICAgICAgc2VjdGlvbi5ieXRlcyxcbiAgICAgICAgKSxcbiAgICAgICAgY291bnQgPSBsaXN0Lmxlbmd0aDtcbiAgICAgIGxldCB2YWx1ZTogKGluZGV4OiBudW1iZXIpID0+IHVua25vd247XG4gICAgICBpZiAoc2VjdGlvbi5uYW1lID09PSAnbnVtYmVycycpIHtcbiAgICAgICAgYXNzZXJ0KFxuICAgICAgICAgIFsxLCAyLCA0LCA4XS5pbmNsdWRlcyhzZWN0aW9uLnR5cGUpICYmIHZ2aWV3LmJ5dGVMZW5ndGggPT09IGNvdW50ICogc2VjdGlvbi50eXBlLFxuICAgICAgICAgICdDT1JSVVBUX1NUT1JBR0UnLFxuICAgICAgICAgICdOdW1lcmljIGxlbmd0aCcsXG4gICAgICAgICk7XG4gICAgICAgIHZhbHVlID0gKGkpID0+XG4gICAgICAgICAgc2VjdGlvbi50eXBlID09PSAxXG4gICAgICAgICAgICA/IHZ2aWV3LmdldEludDgoaSlcbiAgICAgICAgICAgIDogc2VjdGlvbi50eXBlID09PSAyXG4gICAgICAgICAgICAgID8gdnZpZXcuZ2V0SW50MTYoaSAqIDIsIHRydWUpXG4gICAgICAgICAgICAgIDogc2VjdGlvbi50eXBlID09PSA0XG4gICAgICAgICAgICAgICAgPyB2dmlldy5nZXRJbnQzMihpICogNCwgdHJ1ZSlcbiAgICAgICAgICAgICAgICA6IHZ2aWV3LmdldEZsb2F0NjQoaSAqIDgsIHRydWUpO1xuICAgICAgfSBlbHNlIGlmIChzZWN0aW9uLm5hbWUgPT09ICdib29sZWFucycpIHtcbiAgICAgICAgYXNzZXJ0KFxuICAgICAgICAgIHNlY3Rpb24udHlwZSA9PT0gMCAmJiB2dmlldy5ieXRlTGVuZ3RoID09PSBNYXRoLmNlaWwoY291bnQgLyA4KSxcbiAgICAgICAgICAnQ09SUlVQVF9TVE9SQUdFJyxcbiAgICAgICAgICAnQm9vbGVhbiBsZW5ndGgnLFxuICAgICAgICApO1xuICAgICAgICB2YWx1ZSA9IChpKSA9PiAhISh2dmlldy5nZXRVaW50OChpID4+IDMpICYgKDEgPDwgKGkgJiA3KSkpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYXNzZXJ0KFxuICAgICAgICAgIFswLCAxLCAxNiwgMTddLmluY2x1ZGVzKHNlY3Rpb24udHlwZSkgJiYgdnZpZXcuYnl0ZUxlbmd0aCA+PSA0LFxuICAgICAgICAgICdDT1JSVVBUX1NUT1JBR0UnLFxuICAgICAgICAgICdTdHJpbmcgdHlwZScsXG4gICAgICAgICk7XG4gICAgICAgIGNvbnN0IGRpY3QgPSBzZWN0aW9uLnR5cGUgJSAxNiA9PT0gMSxcbiAgICAgICAgICB3aWRlID0gc2VjdGlvbi50eXBlID49IDE2LFxuICAgICAgICAgIG4gPSB2dmlldy5nZXRVaW50MzIoMCwgdHJ1ZSksXG4gICAgICAgICAgb2Zmc2V0cyA9IDQgKyAoZGljdCA/IGNvdW50ICogMiA6IDApLFxuICAgICAgICAgIGFyZW5hID0gb2Zmc2V0cyArIChuICsgMSkgKiA0O1xuICAgICAgICBhc3NlcnQoXG4gICAgICAgICAgbiA+IDAgJiYgbiA8PSBjb3VudCAmJiAoIWRpY3QgPyBuID09PSBjb3VudCA6IHRydWUpICYmIGFyZW5hIDw9IHZ2aWV3LmJ5dGVMZW5ndGgsXG4gICAgICAgICAgJ0NPUlJVUFRfU1RPUkFHRScsXG4gICAgICAgICAgJ1N0cmluZyBkaXJlY3RvcnknLFxuICAgICAgICApO1xuICAgICAgICBsZXQgcHJldiA9IDA7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDw9IG47IGkrKykge1xuICAgICAgICAgIGNvbnN0IGF0ID0gdnZpZXcuZ2V0VWludDMyKG9mZnNldHMgKyBpICogNCwgdHJ1ZSk7XG4gICAgICAgICAgYXNzZXJ0KFxuICAgICAgICAgICAgYXQgPj0gcHJldiAmJiBhcmVuYSArIGF0IDw9IHZ2aWV3LmJ5dGVMZW5ndGggJiYgKCF3aWRlIHx8IGF0ICUgMiA9PT0gMCksXG4gICAgICAgICAgICAnQ09SUlVQVF9TVE9SQUdFJyxcbiAgICAgICAgICAgICdTdHJpbmcgb2Zmc2V0JyxcbiAgICAgICAgICApO1xuICAgICAgICAgIGlmIChpID4gMCkge1xuICAgICAgICAgICAgY29uc3QgbWF4Q2hhcmFjdGVycyA9IHNlY3Rpb24ubmFtZSA9PT0gJ2Vycm9ycycgPyA1MCA6IExJTUlUUy50ZXh0O1xuICAgICAgICAgICAgYXNzZXJ0KFxuICAgICAgICAgICAgICBhdCAtIHByZXYgPD0gbWF4Q2hhcmFjdGVycyAqICh3aWRlID8gMiA6IDMpLFxuICAgICAgICAgICAgICAnTElNSVRfRVhDRUVERUQnLFxuICAgICAgICAgICAgICAnUGFnZSBzdHJpbmcgZXhjZWVkcyB0ZXh0IGxpbWl0JyxcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHByZXYgPSBhdDtcbiAgICAgICAgfVxuICAgICAgICBhc3NlcnQoYXJlbmEgKyBwcmV2ID09PSB2dmlldy5ieXRlTGVuZ3RoLCAnQ09SUlVQVF9TVE9SQUdFJywgJ1RyYWlsaW5nIHN0cmluZyBieXRlcycpO1xuICAgICAgICB2YWx1ZSA9IChpKSA9PiB7XG4gICAgICAgICAgY29uc3QgaW5kZXggPSBkaWN0ID8gdnZpZXcuZ2V0VWludDE2KDQgKyBpICogMiwgdHJ1ZSkgOiBpO1xuICAgICAgICAgIGFzc2VydChpbmRleCA8IG4sICdDT1JSVVBUX1NUT1JBR0UnLCAnU3RyaW5nIGRpY3Rpb25hcnkgaW5kZXgnKTtcbiAgICAgICAgICBjb25zdCBzdGFydCA9IHZ2aWV3LmdldFVpbnQzMihvZmZzZXRzICsgaW5kZXggKiA0LCB0cnVlKSxcbiAgICAgICAgICAgIGVuZCA9IHZ2aWV3LmdldFVpbnQzMihvZmZzZXRzICsgKGluZGV4ICsgMSkgKiA0LCB0cnVlKTtcbiAgICAgICAgICBpZiAoIXdpZGUpXG4gICAgICAgICAgICByZXR1cm4gZGVjb2RlVGV4dChcbiAgICAgICAgICAgICAgbmV3IFVpbnQ4QXJyYXkodnZpZXcuYnVmZmVyLCB2dmlldy5ieXRlT2Zmc2V0ICsgYXJlbmEgKyBzdGFydCwgZW5kIC0gc3RhcnQpLFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICBsZXQgdGV4dCA9ICcnO1xuICAgICAgICAgIGZvciAobGV0IHAgPSBzdGFydDsgcCA8IGVuZDsgcCArPSAyKVxuICAgICAgICAgICAgdGV4dCArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKHZ2aWV3LmdldFVpbnQxNihhcmVuYSArIHAsIHRydWUpKTtcbiAgICAgICAgICByZXR1cm4gdGV4dDtcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIHRoaXMuY29sdW1ucy5wdXNoKHsgbmFtZTogc2VjdGlvbi5uYW1lLCBwb3NpdGlvbnM6IG5ldyBVaW50MTZBcnJheShsaXN0KSwgdmFsdWUgfSk7XG4gICAgICBjb25zdCBkZWNvZGVkVmFsdWVzOiB1bmtub3duW10gPSBbXTtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbGlzdC5sZW5ndGg7IGkrKykge1xuICAgICAgICBjb25zdCBkZWNvZGVkID0gdmFsdWUoaSk7XG4gICAgICAgIGlmICh0eXBlb2YgZGVjb2RlZCA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICBhc3NlcnQoXG4gICAgICAgICAgICBkZWNvZGVkLmxlbmd0aCA8PSAoc2VjdGlvbi5uYW1lID09PSAnZXJyb3JzJyA/IDUwIDogTElNSVRTLnRleHQpLFxuICAgICAgICAgICAgJ0xJTUlUX0VYQ0VFREVEJyxcbiAgICAgICAgICAgICdQYWdlIHN0cmluZyBleGNlZWRzIHRleHQgbGltaXQnLFxuICAgICAgICAgICk7XG4gICAgICAgICAgc2VjdGlvblRleHRCeXRlcyArPSBkZWNvZGVkLmxlbmd0aCAqIDM7XG4gICAgICAgICAgYXNzZXJ0KFxuICAgICAgICAgICAgc2VjdGlvblRleHRCeXRlcyA8PSAzMiAqIDEwMjQgKiAxMDI0LFxuICAgICAgICAgICAgJ0xJTUlUX0VYQ0VFREVEJyxcbiAgICAgICAgICAgICdQYWdlIHRleHQgZXhjZWVkcyAzMiBNaUIgd29ya2luZyBidWRnZXQnLFxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgICAgZGVjb2RlZFZhbHVlcy5wdXNoKGRlY29kZWQpO1xuICAgICAgfVxuICAgICAgKGRhdGEgYXMgYW55KVtzZWN0aW9uLm5hbWVdID0geyBwb3NpdGlvbnM6IGxpc3QsIHZhbHVlczogZGVjb2RlZFZhbHVlcyB9O1xuICAgIH1cbiAgICB0aGlzLmV4dHJhID0gZGVjb2RlRmlsZUNlbGxzKFxuICAgICAgeyByb3c6IHRoaXMucm93LCBjb2x1bW46IHRoaXMuY29sdW1uLCBkYXRhIH0sXG4gICAgICB0aGlzLnN0eWxlcyxcbiAgICAgIHVuZGVmaW5lZCxcbiAgICAgIHVuZGVmaW5lZCxcbiAgICAgIGlubGluZUtpbmRzLnNpemUgPT09IDAsXG4gICAgKTtcbiAgICAvLyBWYWxpZGF0ZSBvbmNlLCB0aGVuIHJldGFpbiBvbmx5IHNwYXJzZSBwcm9wZXJ0aWVzLiBTY2FsYXIgb2JqZWN0cyBuZXZlciBsaXZlIGluIHRoZSBwYWdlIGNhY2hlLlxuICAgIGZvciAoY29uc3QgY2VsbCBvZiBPYmplY3QudmFsdWVzKHRoaXMuZXh0cmEpKSB7XG4gICAgICBpZiAoY2VsbC5pbnB1dC50eXBlID09PSAnZm9ybXVsYScpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICB0aGlzLmRlcGVuZGVuY2llc1trZXkoY2VsbC5yb3dJZCwgY2VsbC5jb2x1bW5JZCldID0gcGFyc2VGb3JtdWxhKGNlbGwuaW5wdXQuZXhwcmVzc2lvbik7XG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgIHRoaXMuZGVwZW5kZW5jaWVzW2tleShjZWxsLnJvd0lkLCBjZWxsLmNvbHVtbklkKV0gPSBudWxsO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBjb25zdCBraW5kID0ge1xuICAgICAgICBudW1iZXI6ICdudW1iZXJzJyxcbiAgICAgICAgc3RyaW5nOiAnc3RyaW5ncycsXG4gICAgICAgIGJvb2xlYW46ICdib29sZWFucycsXG4gICAgICAgIGZvcm11bGE6ICdmb3JtdWxhcycsXG4gICAgICAgIGVycm9yOiAnZXJyb3JzJyxcbiAgICAgICAgYmxhbms6IHVuZGVmaW5lZCxcbiAgICAgIH1bY2VsbC5pbnB1dC50eXBlXSBhcyBLaW5kIHwgdW5kZWZpbmVkO1xuICAgICAgaWYgKGNlbGwuaW5wdXQudHlwZSAhPT0gJ2JsYW5rJyAmJiAoIWtpbmQgfHwgIWlubGluZUtpbmRzLmhhcyhraW5kKSkpXG4gICAgICAgIGRlbGV0ZSAoY2VsbCBhcyBQYXJ0aWFsPENlbGxSZWNvcmQ+KS5pbnB1dDtcbiAgICAgIGlmIChPYmplY3Qua2V5cyhjZWxsKS5sZW5ndGggPT09IDIpIGRlbGV0ZSB0aGlzLmV4dHJhW2tleShjZWxsLnJvd0lkLCBjZWxsLmNvbHVtbklkKV07XG4gICAgfVxuICAgIHRoaXMuYnl0ZXMgPVxuICAgICAgYnVmZmVyLmJ5dGVMZW5ndGggK1xuICAgICAgdGhpcy5jb2x1bW5zLnJlZHVjZSgobiwgYykgPT4gbiArIGMucG9zaXRpb25zLmJ5dGVMZW5ndGggKyAxMjgsIDApICtcbiAgICAgIEpTT04uc3RyaW5naWZ5KHRoaXMuZXh0cmEpLmxlbmd0aCAqIDIgK1xuICAgICAgT2JqZWN0LmtleXModGhpcy5leHRyYSkubGVuZ3RoICogMTkyICtcbiAgICAgIEpTT04uc3RyaW5naWZ5KHRoaXMuZGVwZW5kZW5jaWVzKS5sZW5ndGggKiA2ICtcbiAgICAgIDEwMjQ7XG4gIH1cbiAgY2VsbChvZmZzZXQ6IG51bWJlcik6IENlbGxSZWNvcmQgfCB1bmRlZmluZWQge1xuICAgIGNvbnN0IHJvd0lkID0gdGhpcy5yb3cgKiA2NCArIE1hdGguZmxvb3Iob2Zmc2V0IC8gMzIpLFxuICAgICAgY29sdW1uSWQgPSB0aGlzLmNvbHVtbiAqIDMyICsgKG9mZnNldCAlIDMyKTtcbiAgICBsZXQgaW5wdXQ6IENlbGxJbnB1dCB8IHVuZGVmaW5lZDtcbiAgICBmb3IgKGNvbnN0IGNvbCBvZiB0aGlzLmNvbHVtbnMpIHtcbiAgICAgIGxldCBsb3cgPSAwLFxuICAgICAgICBoaWdoID0gY29sLnBvc2l0aW9ucy5sZW5ndGg7XG4gICAgICB3aGlsZSAobG93IDwgaGlnaCkge1xuICAgICAgICBjb25zdCBtaWQgPSAobG93ICsgaGlnaCkgPj4+IDE7XG4gICAgICAgIGlmIChjb2wucG9zaXRpb25zW21pZF0gPCBvZmZzZXQpIGxvdyA9IG1pZCArIDE7XG4gICAgICAgIGVsc2UgaGlnaCA9IG1pZDtcbiAgICAgIH1cbiAgICAgIGlmIChjb2wucG9zaXRpb25zW2xvd10gIT09IG9mZnNldCkgY29udGludWU7XG4gICAgICBpbnB1dCA9IGNvbHVtbklucHV0KGNvbC5uYW1lLCBjb2wudmFsdWUobG93KSk7XG4gICAgICBicmVhaztcbiAgICB9XG4gICAgY29uc3QgZXh0cmEgPSB0aGlzLmV4dHJhW2tleShyb3dJZCwgY29sdW1uSWQpXTtcbiAgICBpZiAoIWlucHV0ICYmICFleHRyYSkgcmV0dXJuO1xuICAgIHJldHVybiB7IC4uLmV4dHJhLCByb3dJZCwgY29sdW1uSWQsIGlucHV0OiBpbnB1dCA/PyBleHRyYT8uaW5wdXQgPz8geyB0eXBlOiAnYmxhbmsnIH0gfTtcbiAgfVxuICAvKiogU2NhbiBvY2N1cGllZCBjZWxscyB3aXRob3V0IGNvbnN0cnVjdGluZyBhIHBhZ2UgbWFwIG9yIGJpbmFyeS1zZWFyY2hpbmcgZWFjaCBjb2x1bW4uICovXG4gICpyZWNvcmRzKCk6IEl0ZXJhYmxlSXRlcmF0b3I8Q2VsbFJlY29yZD4ge1xuICAgIGZvciAoY29uc3QgY29sdW1uIG9mIHRoaXMuY29sdW1ucykge1xuICAgICAgZm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IGNvbHVtbi5wb3NpdGlvbnMubGVuZ3RoOyBpbmRleCsrKSB7XG4gICAgICAgIGNvbnN0IG9mZnNldCA9IGNvbHVtbi5wb3NpdGlvbnNbaW5kZXhdO1xuICAgICAgICBjb25zdCByb3dJZCA9IHRoaXMucm93ICogNjQgKyBNYXRoLmZsb29yKG9mZnNldCAvIDMyKTtcbiAgICAgICAgY29uc3QgY29sdW1uSWQgPSB0aGlzLmNvbHVtbiAqIDMyICsgKG9mZnNldCAlIDMyKTtcbiAgICAgICAgeWllbGQge1xuICAgICAgICAgIC4uLnRoaXMuZXh0cmFba2V5KHJvd0lkLCBjb2x1bW5JZCldLFxuICAgICAgICAgIHJvd0lkLFxuICAgICAgICAgIGNvbHVtbklkLFxuICAgICAgICAgIGlucHV0OiBjb2x1bW5JbnB1dChjb2x1bW4ubmFtZSwgY29sdW1uLnZhbHVlKGluZGV4KSksXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgfVxuICAgIGZvciAoY29uc3QgY2VsbCBvZiBPYmplY3QudmFsdWVzKHRoaXMuZXh0cmEpKSBpZiAoY2VsbC5pbnB1dCkgeWllbGQgeyAuLi5jZWxsIH07XG4gIH1cbiAgZ2V0IGNlbGxzKCk6IFJlY29yZDxzdHJpbmcsIENlbGxSZWNvcmQ+IHtcbiAgICBjb25zdCBvZmZzZXRzID0gbmV3IFNldDxudW1iZXI+KFxuICAgICAgT2JqZWN0LnZhbHVlcyh0aGlzLmV4dHJhKS5tYXAoKGMpID0+IChjLnJvd0lkICUgNjQpICogMzIgKyAoYy5jb2x1bW5JZCAlIDMyKSksXG4gICAgKTtcbiAgICBmb3IgKGNvbnN0IGNvbCBvZiB0aGlzLmNvbHVtbnMpIGZvciAoY29uc3Qgb2Zmc2V0IG9mIGNvbC5wb3NpdGlvbnMpIG9mZnNldHMuYWRkKG9mZnNldCk7XG4gICAgcmV0dXJuIE9iamVjdC5mcm9tRW50cmllcyhcbiAgICAgIFsuLi5vZmZzZXRzXS5tYXAoKG9mZnNldCkgPT4ge1xuICAgICAgICBjb25zdCBjZWxsID0gdGhpcy5jZWxsKG9mZnNldCkhO1xuICAgICAgICByZXR1cm4gW2tleShjZWxsLnJvd0lkLCBjZWxsLmNvbHVtbklkKSwgY2VsbF07XG4gICAgICB9KSxcbiAgICApO1xuICB9XG59XG5leHBvcnQgY29uc3QgZGVjb2RlQmxvY2sgPSAoZW5jb2RlZDogRW5jb2RlZEJsb2NrKSA9PiBuZXcgQ29sdW1uUGFnZShlbmNvZGVkKTtcbiJdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxRQUFRLEtBQUssUUFBUSxzQkFBdUQ7QUFDckYsU0FBUyxpQkFBaUIsdUJBQTJDO0FBRXJFLE1BQU0sVUFBVSxJQUFJLFlBQVk7QUFDaEMsTUFBTSxVQUFVLElBQUksWUFBWSxTQUFTLEVBQUUsT0FBTyxLQUFLLENBQUM7QUFDeEQsU0FBUyxXQUFXLE9BQTJCO0FBQzdDLE1BQUk7QUFDRixXQUFPLFFBQVEsT0FBTyxLQUFLO0FBQUEsRUFDN0IsUUFBUTtBQUNOLFVBQU0sSUFBSSxlQUFlLG1CQUFtQixvQkFBb0I7QUFBQSxFQUNsRTtBQUNGO0FBQ0EsTUFBTSxRQUFRLENBQUMsV0FBVyxXQUFXLFlBQVksWUFBWSxRQUFRO0FBRXJFLFNBQVMsWUFBWSxNQUFZLE9BQTJCO0FBQzFELFVBQVEsTUFBTTtBQUFBLElBQ1osS0FBSztBQUNILGFBQU8sRUFBRSxNQUFNLFVBQVUsTUFBdUI7QUFBQSxJQUNsRCxLQUFLO0FBQ0gsYUFBTyxFQUFFLE1BQU0sVUFBVSxNQUF1QjtBQUFBLElBQ2xELEtBQUs7QUFDSCxhQUFPLEVBQUUsTUFBTSxXQUFXLE1BQXdCO0FBQUEsSUFDcEQsS0FBSztBQUNILGFBQU8sRUFBRSxNQUFNLFdBQVcsWUFBWSxNQUFnQjtBQUFBLElBQ3hELEtBQUs7QUFDSCxhQUFPLEVBQUUsTUFBTSxTQUFTLE1BQU0sTUFBZ0I7QUFBQSxFQUNsRDtBQUNGO0FBUUEsTUFBTSxRQUFRLENBQUMsTUFBYyxLQUFLLEtBQUssSUFBSSxDQUFDLElBQUk7QUFDaEQsTUFBTSxTQUFTLENBQUMsU0FBbUIsV0FBbUI7QUFDcEQsUUFBTSxRQUFRLElBQUksV0FBVyxLQUFLLEtBQUssU0FBUyxDQUFDLENBQUM7QUFDbEQsYUFBVyxLQUFLLFFBQVMsT0FBTSxLQUFLLENBQUMsS0FBSyxNQUFNLElBQUk7QUFDcEQsU0FBTztBQUNUO0FBQ0EsU0FBUyxVQUFVLFNBQW1CO0FBQ3BDLFFBQU0sT0FBaUIsQ0FBQztBQUN4QixhQUFXLEtBQUssU0FBUztBQUN2QixRQUFJLEtBQUssVUFBVSxLQUFLLEdBQUcsRUFBRSxJQUFLLEtBQUssR0FBRyxFQUFFLE1BQU8sRUFBRyxNQUFLLEtBQUssU0FBUyxDQUFDO0FBQUEsUUFDckUsTUFBSyxLQUFLLEdBQUcsQ0FBQztBQUFBLEVBQ3JCO0FBQ0EsUUFBTSxTQUFTLENBQUMsV0FBcUI7QUFDbkMsVUFBTSxRQUFRLElBQUksV0FBVyxPQUFPLFNBQVMsQ0FBQyxHQUM1QyxPQUFPLElBQUksU0FBUyxNQUFNLE1BQU07QUFDbEMsV0FBTyxRQUFRLENBQUMsT0FBTyxNQUFNLEtBQUssVUFBVSxJQUFJLEdBQUcsT0FBTyxJQUFJLENBQUM7QUFDL0QsV0FBTztBQUFBLEVBQ1Q7QUFDQSxRQUFNLE9BQU8sT0FBTyxPQUFPLEdBQ3pCLE1BQU0sT0FBTyxJQUFJLEdBQ2pCLE9BQU8sT0FBTyxTQUFTLElBQUk7QUFDN0IsTUFBSSxJQUFJLGFBQWEsS0FBSyxjQUFjLElBQUksY0FBYyxLQUFLO0FBQzdELFdBQU8sRUFBRSxNQUFNLEdBQUcsT0FBTyxJQUFJO0FBQy9CLE1BQUksS0FBSyxhQUFhLEtBQUssV0FBWSxRQUFPLEVBQUUsTUFBTSxHQUFHLE9BQU8sS0FBSztBQUNyRSxTQUFPLEVBQUUsTUFBTSxHQUFHLE9BQU8sS0FBSztBQUNoQztBQUNBLFNBQVMsUUFBUSxRQUFrQjtBQUNqQyxRQUFNLFdBQVcsT0FBTyxNQUFNLENBQUMsTUFBTSxPQUFPLFVBQVUsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLEdBQUcsRUFBRSxDQUFDO0FBQzdFLE1BQUk7QUFDSixNQUFJLFlBQVksT0FBTyxNQUFNLENBQUMsTUFBTSxLQUFLLFFBQVEsS0FBSyxHQUFHLEVBQUcsUUFBTyxJQUFJLFVBQVUsTUFBTTtBQUFBLFdBQzlFLFlBQVksT0FBTyxNQUFNLENBQUMsTUFBTSxLQUFLLFVBQVUsS0FBSyxLQUFLO0FBQ2hFLFdBQU8sSUFBSSxXQUFXLE1BQU07QUFBQSxXQUNyQixZQUFZLE9BQU8sTUFBTSxDQUFDLE1BQU0sS0FBSyxlQUFlLEtBQUssVUFBVTtBQUMxRSxXQUFPLElBQUksV0FBVyxNQUFNO0FBQUEsTUFDekIsUUFBTyxJQUFJLGFBQWEsTUFBTTtBQUVuQyxRQUFNLFFBQVEsSUFBSSxXQUFXLEtBQUssVUFBVSxHQUMxQyxPQUFPLElBQUksU0FBUyxNQUFNLE1BQU07QUFDbEMsU0FBTyxRQUFRLENBQUMsR0FBRyxNQUFNO0FBQ3ZCLFFBQUksS0FBSyxzQkFBc0IsRUFBRyxNQUFLLFFBQVEsR0FBRyxDQUFDO0FBQUEsYUFDMUMsS0FBSyxzQkFBc0IsRUFBRyxNQUFLLFNBQVMsSUFBSSxHQUFHLEdBQUcsSUFBSTtBQUFBLGFBQzFELEtBQUssc0JBQXNCLEVBQUcsTUFBSyxTQUFTLElBQUksR0FBRyxHQUFHLElBQUk7QUFBQSxRQUM5RCxNQUFLLFdBQVcsSUFBSSxHQUFHLEdBQUcsSUFBSTtBQUFBLEVBQ3JDLENBQUM7QUFDRCxTQUFPLEVBQUUsTUFBTSxLQUFLLG1CQUFtQixNQUFNO0FBQy9DO0FBQ0EsTUFBTSxRQUFRLENBQUMsU0FBaUI7QUFDOUIsUUFBTSxRQUFRLElBQUksV0FBVyxLQUFLLFNBQVMsQ0FBQyxHQUMxQyxPQUFPLElBQUksU0FBUyxNQUFNLE1BQU07QUFDbEMsV0FBUyxJQUFJLEdBQUcsSUFBSSxLQUFLLFFBQVEsSUFBSyxNQUFLLFVBQVUsSUFBSSxHQUFHLEtBQUssV0FBVyxDQUFDLEdBQUcsSUFBSTtBQUNwRixTQUFPO0FBQ1Q7QUFDQSxTQUFTLFFBQVEsUUFBa0I7QUFDakMsUUFBTSxPQUFPLE9BQU87QUFBQSxJQUFLLENBQUMsTUFDeEIsMEVBQTBFLEtBQUssQ0FBQztBQUFBLEVBQ2xGO0FBQ0EsUUFBTSxTQUFTLENBQUMsR0FBRyxJQUFJLElBQUksTUFBTSxDQUFDLEdBQ2hDLFNBQVMsT0FBTyxRQUFRLENBQUMsTUFBYyxRQUFRLE9BQU8sQ0FBQztBQUN6RCxRQUFNLE9BQU8sQ0FBQyxPQUFpQixlQUF3QjtBQUNyRCxVQUFNLFFBQVEsTUFBTSxJQUFJLE1BQU0sR0FDNUIsYUFBYSxNQUFNLE9BQU8sQ0FBQyxHQUFHLE1BQU0sSUFBSSxFQUFFLFlBQVksQ0FBQztBQUN6RCxVQUFNLFNBQVMsS0FBSyxhQUFhLE9BQU8sU0FBUyxJQUFJLE1BQU0sTUFBTSxTQUFTLEtBQUs7QUFDL0UsVUFBTSxRQUFRLElBQUksV0FBVyxTQUFTLFVBQVUsR0FDOUMsT0FBTyxJQUFJLFNBQVMsTUFBTSxNQUFNO0FBQ2xDLFNBQUssVUFBVSxHQUFHLE1BQU0sUUFBUSxJQUFJO0FBQ3BDLFFBQUksU0FBUztBQUNiLFFBQUksWUFBWTtBQUNkLFlBQU0sTUFBTSxJQUFJLElBQUksTUFBTSxJQUFJLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUMvQyxhQUFPLFFBQVEsQ0FBQyxHQUFHLE1BQU0sS0FBSyxVQUFVLFNBQVMsSUFBSSxHQUFHLElBQUksSUFBSSxDQUFDLEdBQUksSUFBSSxDQUFDO0FBQzFFLGdCQUFVLE9BQU8sU0FBUztBQUFBLElBQzVCO0FBQ0EsUUFBSSxTQUFTO0FBQ2IsVUFBTSxRQUFRLENBQUMsTUFBTSxNQUFNO0FBQ3pCLFdBQUssVUFBVSxTQUFTLElBQUksR0FBRyxRQUFRLElBQUk7QUFDM0MsWUFBTSxJQUFJLE1BQU0sU0FBUyxNQUFNO0FBQy9CLGdCQUFVLEtBQUs7QUFBQSxJQUNqQixDQUFDO0FBQ0QsU0FBSyxVQUFVLFNBQVMsTUFBTSxTQUFTLEdBQUcsUUFBUSxJQUFJO0FBQ3RELFdBQU8sRUFBRSxPQUFPLE9BQU8sS0FBSyxNQUFNLGFBQWEsSUFBSSxJQUFJLE1BQU07QUFBQSxFQUMvRDtBQUNBLFFBQU0sUUFBUSxLQUFLLFFBQVEsS0FBSyxHQUM5QixPQUFPLEtBQUssUUFBUSxJQUFJO0FBQzFCLFNBQU8sS0FBSyxNQUFNLGFBQWEsTUFBTSxNQUFNLGFBQWEsT0FBTztBQUNqRTtBQUNPLGdCQUFTLFlBQ2QsT0FDQSxRQUNBLFdBQ0EsZUFDYztBQUNkLFFBQU0sU0FBUyxPQUFPLE9BQU8sS0FBSyxHQUNoQyxNQUFNLEtBQUssT0FBTyxPQUFPLENBQUMsR0FBRyxTQUFTLE9BQU8sQ0FBQyxLQUFLLEtBQUssRUFBRSxHQUMxRCxTQUFTLEtBQUssT0FBTyxPQUFPLENBQUMsR0FBRyxZQUFZLFVBQVUsQ0FBQyxLQUFLLEtBQUssRUFBRTtBQUNyRTtBQUFBLElBQ0UsT0FBTyxNQUFNLENBQUMsTUFBTSxLQUFLLE1BQU0sRUFBRSxRQUFRLEVBQUUsTUFBTSxPQUFPLEtBQUssTUFBTSxFQUFFLFdBQVcsRUFBRSxNQUFNLE1BQU07QUFBQSxJQUM5RjtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0EsUUFBTSxTQUFTLENBQUMsR0FBRyxJQUFJLElBQUksT0FBTyxRQUFRLENBQUMsTUFBTyxFQUFFLFlBQVksU0FBWSxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sQ0FBRSxDQUFDLENBQUM7QUFDL0YsUUFBTSxPQUFPLGdCQUFnQixRQUFRLElBQUksSUFBSSxPQUFPLElBQUksQ0FBQyxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUUsUUFBTSxXQUFzQixDQUFDLEdBQzNCLFVBQXdCLENBQUM7QUFDM0IsTUFBSSxTQUFTO0FBQ2IsYUFBVyxRQUFRLE9BQU87QUFDeEIsVUFBTSxNQUFNLEtBQUssSUFBSTtBQUNyQixRQUFJLENBQUMsSUFBSztBQUNWLFVBQU0sTUFBTSxVQUFVLElBQUksU0FBUztBQUNuQyxVQUFNLE9BQ0osU0FBUyxZQUNMO0FBQUEsTUFDRyxJQUFJLE9BQW9CO0FBQUEsUUFBSSxDQUFDLEdBQUcsTUFDL0IsS0FBSyxjQUFjLFNBQVMsSUFBSSxVQUFVLENBQUMsQ0FBQyxJQUFJLEtBQUs7QUFBQSxNQUN2RDtBQUFBLElBQ0YsSUFDQSxTQUFTLGFBQ1A7QUFBQSxNQUNFLE1BQU07QUFBQSxNQUNOLE9BQU87QUFBQSxRQUNMLElBQUksT0FBTyxRQUFRLENBQUMsR0FBRyxNQUFPLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFFO0FBQUEsUUFDM0MsSUFBSSxPQUFPO0FBQUEsTUFDYjtBQUFBLElBQ0YsSUFDQSxRQUFRLElBQUksTUFBa0I7QUFDdEMsVUFBTSxVQUFtQjtBQUFBLE1BQ3ZCO0FBQUEsTUFDQSxXQUFXLEVBQUUsTUFBTSxJQUFJLE1BQU0sT0FBTyxJQUFJLFVBQVUsUUFBUSxRQUFRLE9BQU8sSUFBSSxNQUFNLE9BQU87QUFBQSxNQUMxRixNQUFNLEtBQUs7QUFBQSxNQUNYLFFBQVE7QUFBQSxNQUNSLE9BQU8sS0FBSyxNQUFNO0FBQUEsSUFDcEI7QUFDQSxZQUFRLEtBQUssSUFBSSxLQUFLO0FBQ3RCLGNBQVUsTUFBTSxJQUFJLE1BQU0sTUFBTTtBQUNoQyxZQUFRLFNBQVM7QUFDakIsWUFBUSxLQUFLLEtBQUssS0FBSztBQUN2QixjQUFVLE1BQU0sS0FBSyxNQUFNLE1BQU07QUFDakMsYUFBUyxLQUFLLE9BQU87QUFDckIsV0FBTyxLQUFLLElBQUk7QUFBQSxFQUNsQjtBQUNBLFNBQU8sS0FBSztBQUNaLFFBQU0sT0FBTyxRQUFRLE9BQU8sS0FBSyxVQUFVLEVBQUUsS0FBSyxRQUFRLFFBQVEsTUFBTSxTQUFTLENBQUMsQ0FBQztBQUNuRjtBQUFBLElBQ0UsTUFBTSxJQUFJLEtBQUssTUFBTSxJQUFJLFVBQVUsS0FBSyxPQUFPO0FBQUEsSUFDL0M7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNBLFFBQU0sU0FBUyxNQUFNLElBQUksS0FBSyxNQUFNLEdBQ2xDLFNBQVMsSUFBSSxXQUFXLFNBQVMsTUFBTSxHQUN2QyxPQUFPLElBQUksU0FBUyxPQUFPLE1BQU07QUFDbkMsU0FBTyxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxDQUFDO0FBQzFCLE9BQUssVUFBVSxHQUFHLEtBQUssUUFBUSxJQUFJO0FBQ25DLFNBQU8sSUFBSSxNQUFNLENBQUM7QUFDbEIsTUFBSSxTQUFTO0FBQ2IsYUFBVyxTQUFTLFNBQVM7QUFDM0IsV0FBTyxJQUFJLE9BQU8sTUFBTTtBQUN4QixjQUFVLE1BQU0sTUFBTSxNQUFNO0FBQUEsRUFDOUI7QUFDQSxTQUFPO0FBQ1Q7QUFDTyxhQUFNLFdBQVc7QUFBQSxFQVl0QixZQUFxQixRQUFvQjtBQUFwQjtBQUNuQjtBQUFBLE1BQ0UsT0FBTyxVQUFVLEtBQ2YsT0FBTyxDQUFDLE1BQU0sTUFDZCxPQUFPLENBQUMsTUFBTSxNQUNkLE9BQU8sQ0FBQyxNQUFNLE1BQ2QsT0FBTyxDQUFDLE1BQU07QUFBQSxNQUNoQjtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsVUFBTSxPQUFPLElBQUksU0FBUyxPQUFPLFFBQVEsT0FBTyxZQUFZLE9BQU8sVUFBVSxHQUMzRSxPQUFPLEtBQUssVUFBVSxHQUFHLElBQUksR0FDN0IsT0FBTyxNQUFNLElBQUksSUFBSTtBQUN2QixXQUFPLFFBQVEsT0FBTyxRQUFRLG1CQUFtQixxQkFBcUI7QUFDdEUsVUFBTSxPQUFPLFdBQVcsT0FBTyxTQUFTLEdBQUcsSUFBSSxJQUFJLENBQUM7QUFDcEQsUUFBSTtBQUNKLFFBQUk7QUFDRixhQUFPLEtBQUssTUFBTSxJQUFJO0FBQUEsSUFDeEIsUUFBUTtBQUNOLFlBQU0sSUFBSSxlQUFlLG1CQUFtQiw0QkFBNEI7QUFBQSxJQUMxRTtBQUNBLFVBQU0sU0FBUyxDQUFDLFVBQ2QsVUFBVSxRQUFRLE9BQU8sVUFBVSxZQUFZLENBQUMsTUFBTSxRQUFRLEtBQUs7QUFDckU7QUFBQSxNQUNFLE9BQU8sSUFBSSxLQUNULE9BQU8sS0FBSyxJQUFJLEVBQUU7QUFBQSxRQUFNLENBQUMsU0FDdkIsQ0FBQyxPQUFPLFVBQVUsVUFBVSxRQUFRLFVBQVUsRUFBRSxTQUFTLElBQUk7QUFBQSxNQUMvRCxLQUNBLE9BQU8sS0FBSyxRQUFRLFlBQ3BCLE9BQU8sVUFBVSxLQUFLLEdBQUcsS0FDekIsT0FBTyxLQUFLLFdBQVcsWUFDdkIsT0FBTyxVQUFVLEtBQUssTUFBTSxLQUM1QixNQUFNLFFBQVEsS0FBSyxNQUFNLEtBQ3pCLEtBQUssT0FBTyxNQUFNLENBQUMsVUFBbUIsT0FBTyxVQUFVLFFBQVEsS0FDL0QsT0FBTyxLQUFLLElBQUksS0FDaEIsTUFBTSxRQUFRLEtBQUssUUFBUTtBQUFBLE1BQzdCO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFDQSxTQUFLLE1BQU0sS0FBSztBQUNoQixTQUFLLFNBQVMsS0FBSztBQUNuQixTQUFLLFNBQVMsS0FBSztBQUNuQixVQUFNLE9BQXNCLEtBQUs7QUFDakMsVUFBTSxjQUFjLElBQUksSUFBSSxNQUFNLE9BQU8sQ0FBQyxTQUFTLE9BQU8sT0FBTyxNQUFNLElBQUksQ0FBQyxDQUFDO0FBQzdFLFFBQUksY0FBYztBQUNsQixRQUFJLG1CQUFtQjtBQUN2QixlQUFXLFdBQVcsS0FBSyxVQUF1QjtBQUNoRDtBQUFBLFFBQ0UsT0FBTyxPQUFPLEtBQ1osT0FBTyxLQUFLLE9BQU8sRUFBRTtBQUFBLFVBQU0sQ0FBQyxTQUMxQixDQUFDLFFBQVEsYUFBYSxRQUFRLFVBQVUsT0FBTyxFQUFFLFNBQVMsSUFBSTtBQUFBLFFBQ2hFLEtBQ0EsT0FBTyxRQUFRLFNBQVMsS0FDeEIsT0FBTyxLQUFLLFFBQVEsU0FBUyxFQUFFO0FBQUEsVUFBTSxDQUFDLFNBQ3BDLENBQUMsUUFBUSxTQUFTLFVBQVUsT0FBTyxFQUFFLFNBQVMsSUFBSTtBQUFBLFFBQ3BELEtBQ0EsTUFBTSxTQUFTLFFBQVEsSUFBSSxLQUMzQixDQUFDLE9BQU8sT0FBTyxNQUFNLFFBQVEsSUFBSSxLQUNqQyxDQUFDLEtBQUssUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLFNBQVMsUUFBUSxJQUFJLEtBQ2pELE9BQU8sVUFBVSxRQUFRLFVBQVUsS0FBSyxLQUN4QyxRQUFRLFVBQVUsUUFBUSxLQUMxQixRQUFRLFVBQVUsU0FBUztBQUFBLFFBQzdCO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFDQSxZQUFNLFNBQVMsQ0FBQyxRQUFnQixVQUFrQjtBQUNoRDtBQUFBLFVBQ0UsT0FBTyxVQUFVLE1BQU0sS0FDckIsT0FBTyxVQUFVLEtBQUssS0FDdEIsVUFBVSxlQUNWLFNBQVMsS0FDVCxPQUFPLFNBQVMsU0FBUyxPQUFPO0FBQUEsVUFDbEM7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUNBLHNCQUFjLFNBQVM7QUFBQSxNQUN6QjtBQUNBLGFBQU8sUUFBUSxVQUFVLFFBQVEsUUFBUSxVQUFVLEtBQUs7QUFDeEQsWUFBTSxRQUFRLElBQUk7QUFBQSxRQUNkLE9BQU87QUFBQSxRQUNQLE9BQU8sYUFBYSxPQUFPLFFBQVEsVUFBVTtBQUFBLFFBQzdDLFFBQVEsVUFBVTtBQUFBLE1BQ3BCLEdBQ0EsT0FBaUIsQ0FBQztBQUNwQixVQUFJLFFBQVEsVUFBVSxTQUFTLEdBQUc7QUFDaEM7QUFBQSxVQUNFLE1BQU0sZUFBZSxRQUFRLFVBQVUsUUFBUTtBQUFBLFVBQy9DO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFDQSxpQkFBUyxJQUFJLEdBQUcsSUFBSSxRQUFRLFVBQVUsT0FBTyxJQUFLLE1BQUssS0FBSyxNQUFNLFVBQVUsSUFBSSxHQUFHLElBQUksQ0FBQztBQUFBLE1BQzFGLFdBQVcsUUFBUSxVQUFVLFNBQVMsR0FBRztBQUN2QyxlQUFPLE1BQU0sYUFBYSxNQUFNLEdBQUcsbUJBQW1CLFlBQVk7QUFDbEUsaUJBQVMsSUFBSSxHQUFHLElBQUksTUFBTSxZQUFZLEtBQUssR0FBRztBQUM1QyxnQkFBTSxRQUFRLE1BQU0sVUFBVSxHQUFHLElBQUksR0FDbkNBLFNBQVEsTUFBTSxVQUFVLElBQUksR0FBRyxJQUFJO0FBQ3JDO0FBQUEsWUFDRUEsU0FBUSxLQUNOLFFBQVFBLFVBQVMsUUFDakIsS0FBSyxTQUFTQSxVQUFTLFFBQVEsVUFBVSxVQUN4QyxLQUFLLFdBQVcsS0FBSyxLQUFLLEtBQUssU0FBUyxDQUFDLElBQUk7QUFBQSxZQUNoRDtBQUFBLFlBQ0E7QUFBQSxVQUNGO0FBQ0EsbUJBQVMsSUFBSSxHQUFHLElBQUlBLFFBQU8sSUFBSyxNQUFLLEtBQUssUUFBUSxDQUFDO0FBQUEsUUFDckQ7QUFBQSxNQUNGLE9BQU87QUFDTDtBQUFBLFVBQ0UsUUFBUSxVQUFVLFNBQVMsS0FBSyxNQUFNLGVBQWU7QUFBQSxVQUNyRDtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQ0EsaUJBQVMsSUFBSSxHQUFHLElBQUksTUFBTSxJQUFLLEtBQUksTUFBTSxTQUFTLEtBQUssQ0FBQyxJQUFLLE1BQU0sSUFBSSxHQUFLLE1BQUssS0FBSyxDQUFDO0FBQUEsTUFDekY7QUFDQTtBQUFBLFFBQ0UsS0FBSyxXQUFXLFFBQVEsVUFBVSxTQUNoQyxLQUFLLE1BQU0sQ0FBQyxHQUFHLE1BQU0sSUFBSSxTQUFTLE1BQU0sS0FBSyxLQUFLLElBQUksQ0FBQyxJQUFJLEVBQUU7QUFBQSxRQUMvRDtBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBQ0EsYUFBTyxRQUFRLFFBQVEsUUFBUSxLQUFLO0FBQ3BDLFlBQU0sUUFBUSxJQUFJO0FBQUEsUUFDZCxPQUFPO0FBQUEsUUFDUCxPQUFPLGFBQWEsT0FBTyxRQUFRO0FBQUEsUUFDbkMsUUFBUTtBQUFBLE1BQ1YsR0FDQSxRQUFRLEtBQUs7QUFDZixVQUFJO0FBQ0osVUFBSSxRQUFRLFNBQVMsV0FBVztBQUM5QjtBQUFBLFVBQ0UsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLEVBQUUsU0FBUyxRQUFRLElBQUksS0FBSyxNQUFNLGVBQWUsUUFBUSxRQUFRO0FBQUEsVUFDNUU7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUNBLGdCQUFRLENBQUMsTUFDUCxRQUFRLFNBQVMsSUFDYixNQUFNLFFBQVEsQ0FBQyxJQUNmLFFBQVEsU0FBUyxJQUNmLE1BQU0sU0FBUyxJQUFJLEdBQUcsSUFBSSxJQUMxQixRQUFRLFNBQVMsSUFDZixNQUFNLFNBQVMsSUFBSSxHQUFHLElBQUksSUFDMUIsTUFBTSxXQUFXLElBQUksR0FBRyxJQUFJO0FBQUEsTUFDeEMsV0FBVyxRQUFRLFNBQVMsWUFBWTtBQUN0QztBQUFBLFVBQ0UsUUFBUSxTQUFTLEtBQUssTUFBTSxlQUFlLEtBQUssS0FBSyxRQUFRLENBQUM7QUFBQSxVQUM5RDtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQ0EsZ0JBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRSxNQUFNLFNBQVMsS0FBSyxDQUFDLElBQUssTUFBTSxJQUFJO0FBQUEsTUFDeEQsT0FBTztBQUNMO0FBQUEsVUFDRSxDQUFDLEdBQUcsR0FBRyxJQUFJLEVBQUUsRUFBRSxTQUFTLFFBQVEsSUFBSSxLQUFLLE1BQU0sY0FBYztBQUFBLFVBQzdEO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFDQSxjQUFNLE9BQU8sUUFBUSxPQUFPLE9BQU8sR0FDakMsT0FBTyxRQUFRLFFBQVEsSUFDdkIsSUFBSSxNQUFNLFVBQVUsR0FBRyxJQUFJLEdBQzNCLFVBQVUsS0FBSyxPQUFPLFFBQVEsSUFBSSxJQUNsQyxRQUFRLFdBQVcsSUFBSSxLQUFLO0FBQzlCO0FBQUEsVUFDRSxJQUFJLEtBQUssS0FBSyxVQUFVLENBQUMsT0FBTyxNQUFNLFFBQVEsU0FBUyxTQUFTLE1BQU07QUFBQSxVQUN0RTtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQ0EsWUFBSSxPQUFPO0FBQ1gsaUJBQVMsSUFBSSxHQUFHLEtBQUssR0FBRyxLQUFLO0FBQzNCLGdCQUFNLEtBQUssTUFBTSxVQUFVLFVBQVUsSUFBSSxHQUFHLElBQUk7QUFDaEQ7QUFBQSxZQUNFLE1BQU0sUUFBUSxRQUFRLE1BQU0sTUFBTSxlQUFlLENBQUMsUUFBUSxLQUFLLE1BQU07QUFBQSxZQUNyRTtBQUFBLFlBQ0E7QUFBQSxVQUNGO0FBQ0EsY0FBSSxJQUFJLEdBQUc7QUFDVCxrQkFBTSxnQkFBZ0IsUUFBUSxTQUFTLFdBQVcsS0FBSyxPQUFPO0FBQzlEO0FBQUEsY0FDRSxLQUFLLFFBQVEsaUJBQWlCLE9BQU8sSUFBSTtBQUFBLGNBQ3pDO0FBQUEsY0FDQTtBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBQ0EsaUJBQU87QUFBQSxRQUNUO0FBQ0EsZUFBTyxRQUFRLFNBQVMsTUFBTSxZQUFZLG1CQUFtQix1QkFBdUI7QUFDcEYsZ0JBQVEsQ0FBQyxNQUFNO0FBQ2IsZ0JBQU0sUUFBUSxPQUFPLE1BQU0sVUFBVSxJQUFJLElBQUksR0FBRyxJQUFJLElBQUk7QUFDeEQsaUJBQU8sUUFBUSxHQUFHLG1CQUFtQix5QkFBeUI7QUFDOUQsZ0JBQU0sUUFBUSxNQUFNLFVBQVUsVUFBVSxRQUFRLEdBQUcsSUFBSSxHQUNyRCxNQUFNLE1BQU0sVUFBVSxXQUFXLFFBQVEsS0FBSyxHQUFHLElBQUk7QUFDdkQsY0FBSSxDQUFDO0FBQ0gsbUJBQU87QUFBQSxjQUNMLElBQUksV0FBVyxNQUFNLFFBQVEsTUFBTSxhQUFhLFFBQVEsT0FBTyxNQUFNLEtBQUs7QUFBQSxZQUM1RTtBQUNGLGNBQUlDLFFBQU87QUFDWCxtQkFBUyxJQUFJLE9BQU8sSUFBSSxLQUFLLEtBQUs7QUFDaEMsWUFBQUEsU0FBUSxPQUFPLGFBQWEsTUFBTSxVQUFVLFFBQVEsR0FBRyxJQUFJLENBQUM7QUFDOUQsaUJBQU9BO0FBQUEsUUFDVDtBQUFBLE1BQ0Y7QUFDQSxXQUFLLFFBQVEsS0FBSyxFQUFFLE1BQU0sUUFBUSxNQUFNLFdBQVcsSUFBSSxZQUFZLElBQUksR0FBRyxNQUFNLENBQUM7QUFDakYsWUFBTSxnQkFBMkIsQ0FBQztBQUNsQyxlQUFTLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxLQUFLO0FBQ3BDLGNBQU0sVUFBVSxNQUFNLENBQUM7QUFDdkIsWUFBSSxPQUFPLFlBQVksVUFBVTtBQUMvQjtBQUFBLFlBQ0UsUUFBUSxXQUFXLFFBQVEsU0FBUyxXQUFXLEtBQUssT0FBTztBQUFBLFlBQzNEO0FBQUEsWUFDQTtBQUFBLFVBQ0Y7QUFDQSw4QkFBb0IsUUFBUSxTQUFTO0FBQ3JDO0FBQUEsWUFDRSxvQkFBb0IsS0FBSyxPQUFPO0FBQUEsWUFDaEM7QUFBQSxZQUNBO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFDQSxzQkFBYyxLQUFLLE9BQU87QUFBQSxNQUM1QjtBQUNBLE1BQUMsS0FBYSxRQUFRLElBQUksSUFBSSxFQUFFLFdBQVcsTUFBTSxRQUFRLGNBQWM7QUFBQSxJQUN6RTtBQUNBLFNBQUssUUFBUTtBQUFBLE1BQ1gsRUFBRSxLQUFLLEtBQUssS0FBSyxRQUFRLEtBQUssUUFBUSxLQUFLO0FBQUEsTUFDM0MsS0FBSztBQUFBLE1BQ0w7QUFBQSxNQUNBO0FBQUEsTUFDQSxZQUFZLFNBQVM7QUFBQSxJQUN2QjtBQUVBLGVBQVcsUUFBUSxPQUFPLE9BQU8sS0FBSyxLQUFLLEdBQUc7QUFDNUMsVUFBSSxLQUFLLE1BQU0sU0FBUyxXQUFXO0FBQ2pDLFlBQUk7QUFDRixlQUFLLGFBQWEsSUFBSSxLQUFLLE9BQU8sS0FBSyxRQUFRLENBQUMsSUFBSSxhQUFhLEtBQUssTUFBTSxVQUFVO0FBQUEsUUFDeEYsUUFBUTtBQUNOLGVBQUssYUFBYSxJQUFJLEtBQUssT0FBTyxLQUFLLFFBQVEsQ0FBQyxJQUFJO0FBQUEsUUFDdEQ7QUFBQSxNQUNGO0FBQ0EsWUFBTSxPQUFPO0FBQUEsUUFDWCxRQUFRO0FBQUEsUUFDUixRQUFRO0FBQUEsUUFDUixTQUFTO0FBQUEsUUFDVCxTQUFTO0FBQUEsUUFDVCxPQUFPO0FBQUEsUUFDUCxPQUFPO0FBQUEsTUFDVCxFQUFFLEtBQUssTUFBTSxJQUFJO0FBQ2pCLFVBQUksS0FBSyxNQUFNLFNBQVMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxZQUFZLElBQUksSUFBSTtBQUNoRSxlQUFRLEtBQTZCO0FBQ3ZDLFVBQUksT0FBTyxLQUFLLElBQUksRUFBRSxXQUFXLEVBQUcsUUFBTyxLQUFLLE1BQU0sSUFBSSxLQUFLLE9BQU8sS0FBSyxRQUFRLENBQUM7QUFBQSxJQUN0RjtBQUNBLFNBQUssUUFDSCxPQUFPLGFBQ1AsS0FBSyxRQUFRLE9BQU8sQ0FBQyxHQUFHLE1BQU0sSUFBSSxFQUFFLFVBQVUsYUFBYSxLQUFLLENBQUMsSUFDakUsS0FBSyxVQUFVLEtBQUssS0FBSyxFQUFFLFNBQVMsSUFDcEMsT0FBTyxLQUFLLEtBQUssS0FBSyxFQUFFLFNBQVMsTUFDakMsS0FBSyxVQUFVLEtBQUssWUFBWSxFQUFFLFNBQVMsSUFDM0M7QUFBQSxFQUNKO0FBQUEsRUEvUHFCO0FBQUEsRUFYWixlQUF3QyxDQUFDO0FBQUEsRUFDekM7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0Q7QUFBQSxFQUNBLFVBSUgsQ0FBQztBQUFBLEVBQ0c7QUFBQSxFQWlRVCxLQUFLLFFBQXdDO0FBQzNDLFVBQU0sUUFBUSxLQUFLLE1BQU0sS0FBSyxLQUFLLE1BQU0sU0FBUyxFQUFFLEdBQ2xELFdBQVcsS0FBSyxTQUFTLEtBQU0sU0FBUztBQUMxQyxRQUFJO0FBQ0osZUFBVyxPQUFPLEtBQUssU0FBUztBQUM5QixVQUFJLE1BQU0sR0FDUixPQUFPLElBQUksVUFBVTtBQUN2QixhQUFPLE1BQU0sTUFBTTtBQUNqQixjQUFNLE1BQU8sTUFBTSxTQUFVO0FBQzdCLFlBQUksSUFBSSxVQUFVLEdBQUcsSUFBSSxPQUFRLE9BQU0sTUFBTTtBQUFBLFlBQ3hDLFFBQU87QUFBQSxNQUNkO0FBQ0EsVUFBSSxJQUFJLFVBQVUsR0FBRyxNQUFNLE9BQVE7QUFDbkMsY0FBUSxZQUFZLElBQUksTUFBTSxJQUFJLE1BQU0sR0FBRyxDQUFDO0FBQzVDO0FBQUEsSUFDRjtBQUNBLFVBQU0sUUFBUSxLQUFLLE1BQU0sSUFBSSxPQUFPLFFBQVEsQ0FBQztBQUM3QyxRQUFJLENBQUMsU0FBUyxDQUFDLE1BQU87QUFDdEIsV0FBTyxFQUFFLEdBQUcsT0FBTyxPQUFPLFVBQVUsT0FBTyxTQUFTLE9BQU8sU0FBUyxFQUFFLE1BQU0sUUFBUSxFQUFFO0FBQUEsRUFDeEY7QUFBQTtBQUFBLEVBRUEsQ0FBQyxVQUF3QztBQUN2QyxlQUFXLFVBQVUsS0FBSyxTQUFTO0FBQ2pDLGVBQVMsUUFBUSxHQUFHLFFBQVEsT0FBTyxVQUFVLFFBQVEsU0FBUztBQUM1RCxjQUFNLFNBQVMsT0FBTyxVQUFVLEtBQUs7QUFDckMsY0FBTSxRQUFRLEtBQUssTUFBTSxLQUFLLEtBQUssTUFBTSxTQUFTLEVBQUU7QUFDcEQsY0FBTSxXQUFXLEtBQUssU0FBUyxLQUFNLFNBQVM7QUFDOUMsY0FBTTtBQUFBLFVBQ0osR0FBRyxLQUFLLE1BQU0sSUFBSSxPQUFPLFFBQVEsQ0FBQztBQUFBLFVBQ2xDO0FBQUEsVUFDQTtBQUFBLFVBQ0EsT0FBTyxZQUFZLE9BQU8sTUFBTSxPQUFPLE1BQU0sS0FBSyxDQUFDO0FBQUEsUUFDckQ7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLGVBQVcsUUFBUSxPQUFPLE9BQU8sS0FBSyxLQUFLLEVBQUcsS0FBSSxLQUFLLE1BQU8sT0FBTSxFQUFFLEdBQUcsS0FBSztBQUFBLEVBQ2hGO0FBQUEsRUFDQSxJQUFJLFFBQW9DO0FBQ3RDLFVBQU0sVUFBVSxJQUFJO0FBQUEsTUFDbEIsT0FBTyxPQUFPLEtBQUssS0FBSyxFQUFFLElBQUksQ0FBQyxNQUFPLEVBQUUsUUFBUSxLQUFNLEtBQU0sRUFBRSxXQUFXLEVBQUc7QUFBQSxJQUM5RTtBQUNBLGVBQVcsT0FBTyxLQUFLLFFBQVMsWUFBVyxVQUFVLElBQUksVUFBVyxTQUFRLElBQUksTUFBTTtBQUN0RixXQUFPLE9BQU87QUFBQSxNQUNaLENBQUMsR0FBRyxPQUFPLEVBQUUsSUFBSSxDQUFDLFdBQVc7QUFDM0IsY0FBTSxPQUFPLEtBQUssS0FBSyxNQUFNO0FBQzdCLGVBQU8sQ0FBQyxJQUFJLEtBQUssT0FBTyxLQUFLLFFBQVEsR0FBRyxJQUFJO0FBQUEsTUFDOUMsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBQ0Y7QUFDTyxhQUFNLGNBQWMsQ0FBQyxZQUEwQixJQUFJLFdBQVcsT0FBTzsiLCJuYW1lcyI6WyJjb3VudCIsInRleHQiXX0=
import { readBinary } from "/@fs/Volumes/github/private/opensheet/packages/core/src/binary-file.ts";
import { decodeBlock } from "/@fs/Volumes/github/private/opensheet/packages/core/src/block-codec.ts";
import { assert } from "/@fs/Volumes/github/private/opensheet/packages/core/src/types.ts";
import { verificationYield } from "/@fs/Volumes/github/private/opensheet/packages/core/src/verification-yield.ts";
export function decodeVerifiedBinaryPage(bytes, row, column, rows, columns, styles) {
  const page = decodeBlock(bytes);
  assert(
    page.row === row && page.column === column,
    "INVALID_ARGUMENT",
    "Binary page coordinates differ"
  );
  const cells = page.cells;
  for (const cell of Object.values(cells)) {
    assert(
      rows.has(cell.rowId) && columns.has(cell.columnId),
      "INVALID_ARGUMENT",
      "Cell outside sheet axes"
    );
    assert(
      cell.styleId === void 0 || styles.has(cell.styleId),
      "INVALID_ARGUMENT",
      "Unknown style"
    );
  }
  return cells;
}
export async function verifyBinary(input, options = {}) {
  options.signal?.throwIfAborted();
  const checkpoint = verificationYield(options.signal);
  let workbookId = "", sheets = 0, pages = 0, cells = 0;
  let rows = [], columns = [];
  let styles = /* @__PURE__ */ new Set();
  for await (const item of readBinary(input, { signal: options.signal })) {
    options.signal?.throwIfAborted();
    if ("metadata" in item) {
      workbookId = item.snapshot.workbookId;
      sheets = item.snapshot.sheets.length;
      rows = item.snapshot.sheets.map((sheet) => new Set(sheet.rowOrder));
      columns = item.snapshot.sheets.map((sheet) => new Set(sheet.columnOrder));
      styles = new Set(Object.keys(item.snapshot.styles));
      await checkpoint();
      continue;
    }
    const records = decodeVerifiedBinaryPage(
      item.bytes,
      item.row,
      item.column,
      rows[item.sheet],
      columns[item.sheet],
      styles
    );
    pages++;
    cells += Object.keys(records).length;
    await checkpoint();
  }
  options.signal?.throwIfAborted();
  return { workbookId, sheets, pages, cells };
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJpbmFyeS12ZXJpZnkudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgcmVhZEJpbmFyeSB9IGZyb20gJy4vYmluYXJ5LWZpbGUuanMnO1xuaW1wb3J0IHsgZGVjb2RlQmxvY2sgfSBmcm9tICcuL2Jsb2NrLWNvZGVjLmpzJztcbmltcG9ydCB7IGFzc2VydCB9IGZyb20gJy4vdHlwZXMuanMnO1xuaW1wb3J0IHsgdmVyaWZpY2F0aW9uWWllbGQgfSBmcm9tICcuL3ZlcmlmaWNhdGlvbi15aWVsZC5qcyc7XG5cbmV4cG9ydCBmdW5jdGlvbiBkZWNvZGVWZXJpZmllZEJpbmFyeVBhZ2UoXG4gIGJ5dGVzOiBVaW50OEFycmF5LFxuICByb3c6IG51bWJlcixcbiAgY29sdW1uOiBudW1iZXIsXG4gIHJvd3M6IFNldDxudW1iZXI+LFxuICBjb2x1bW5zOiBTZXQ8bnVtYmVyPixcbiAgc3R5bGVzOiBTZXQ8c3RyaW5nPixcbikge1xuICBjb25zdCBwYWdlID0gZGVjb2RlQmxvY2soYnl0ZXMpO1xuICBhc3NlcnQoXG4gICAgcGFnZS5yb3cgPT09IHJvdyAmJiBwYWdlLmNvbHVtbiA9PT0gY29sdW1uLFxuICAgICdJTlZBTElEX0FSR1VNRU5UJyxcbiAgICAnQmluYXJ5IHBhZ2UgY29vcmRpbmF0ZXMgZGlmZmVyJyxcbiAgKTtcbiAgY29uc3QgY2VsbHMgPSBwYWdlLmNlbGxzO1xuICBmb3IgKGNvbnN0IGNlbGwgb2YgT2JqZWN0LnZhbHVlcyhjZWxscykpIHtcbiAgICBhc3NlcnQoXG4gICAgICByb3dzLmhhcyhjZWxsLnJvd0lkKSAmJiBjb2x1bW5zLmhhcyhjZWxsLmNvbHVtbklkKSxcbiAgICAgICdJTlZBTElEX0FSR1VNRU5UJyxcbiAgICAgICdDZWxsIG91dHNpZGUgc2hlZXQgYXhlcycsXG4gICAgKTtcbiAgICBhc3NlcnQoXG4gICAgICBjZWxsLnN0eWxlSWQgPT09IHVuZGVmaW5lZCB8fCBzdHlsZXMuaGFzKGNlbGwuc3R5bGVJZCksXG4gICAgICAnSU5WQUxJRF9BUkdVTUVOVCcsXG4gICAgICAnVW5rbm93biBzdHlsZScsXG4gICAgKTtcbiAgfVxuICByZXR1cm4gY2VsbHM7XG59XG5cbi8qKiBWYWxpZGF0ZSBhIGNvbXBsZXRlIG5hdGl2ZSBiaW5hcnkgZmlsZSB3aXRob3V0IGNoYW5naW5nIGJyb3dzZXIgc3RvcmFnZS4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB2ZXJpZnlCaW5hcnkoXG4gIGlucHV0OiBCbG9iIHwgVWludDhBcnJheSxcbiAgb3B0aW9uczogeyBzaWduYWw/OiBBYm9ydFNpZ25hbCB9ID0ge30sXG4pIHtcbiAgb3B0aW9ucy5zaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG4gIGNvbnN0IGNoZWNrcG9pbnQgPSB2ZXJpZmljYXRpb25ZaWVsZChvcHRpb25zLnNpZ25hbCk7XG4gIGxldCB3b3JrYm9va0lkID0gJycsXG4gICAgc2hlZXRzID0gMCxcbiAgICBwYWdlcyA9IDAsXG4gICAgY2VsbHMgPSAwO1xuICBsZXQgcm93czogU2V0PG51bWJlcj5bXSA9IFtdLFxuICAgIGNvbHVtbnM6IFNldDxudW1iZXI+W10gPSBbXTtcbiAgbGV0IHN0eWxlcyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICBmb3IgYXdhaXQgKGNvbnN0IGl0ZW0gb2YgcmVhZEJpbmFyeShpbnB1dCwgeyBzaWduYWw6IG9wdGlvbnMuc2lnbmFsIH0pKSB7XG4gICAgb3B0aW9ucy5zaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG4gICAgaWYgKCdtZXRhZGF0YScgaW4gaXRlbSkge1xuICAgICAgd29ya2Jvb2tJZCA9IGl0ZW0uc25hcHNob3Qud29ya2Jvb2tJZDtcbiAgICAgIHNoZWV0cyA9IGl0ZW0uc25hcHNob3Quc2hlZXRzLmxlbmd0aDtcbiAgICAgIHJvd3MgPSBpdGVtLnNuYXBzaG90LnNoZWV0cy5tYXAoKHNoZWV0KSA9PiBuZXcgU2V0KHNoZWV0LnJvd09yZGVyKSk7XG4gICAgICBjb2x1bW5zID0gaXRlbS5zbmFwc2hvdC5zaGVldHMubWFwKChzaGVldCkgPT4gbmV3IFNldChzaGVldC5jb2x1bW5PcmRlcikpO1xuICAgICAgc3R5bGVzID0gbmV3IFNldChPYmplY3Qua2V5cyhpdGVtLnNuYXBzaG90LnN0eWxlcykpO1xuICAgICAgYXdhaXQgY2hlY2twb2ludCgpO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGNvbnN0IHJlY29yZHMgPSBkZWNvZGVWZXJpZmllZEJpbmFyeVBhZ2UoXG4gICAgICBpdGVtLmJ5dGVzLFxuICAgICAgaXRlbS5yb3csXG4gICAgICBpdGVtLmNvbHVtbixcbiAgICAgIHJvd3NbaXRlbS5zaGVldF0sXG4gICAgICBjb2x1bW5zW2l0ZW0uc2hlZXRdLFxuICAgICAgc3R5bGVzLFxuICAgICk7XG4gICAgcGFnZXMrKztcbiAgICBjZWxscyArPSBPYmplY3Qua2V5cyhyZWNvcmRzKS5sZW5ndGg7XG4gICAgYXdhaXQgY2hlY2twb2ludCgpO1xuICB9XG4gIG9wdGlvbnMuc2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuICByZXR1cm4geyB3b3JrYm9va0lkLCBzaGVldHMsIHBhZ2VzLCBjZWxscyB9O1xufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLGtCQUFrQjtBQUMzQixTQUFTLG1CQUFtQjtBQUM1QixTQUFTLGNBQWM7QUFDdkIsU0FBUyx5QkFBeUI7QUFFM0IsZ0JBQVMseUJBQ2QsT0FDQSxLQUNBLFFBQ0EsTUFDQSxTQUNBLFFBQ0E7QUFDQSxRQUFNLE9BQU8sWUFBWSxLQUFLO0FBQzlCO0FBQUEsSUFDRSxLQUFLLFFBQVEsT0FBTyxLQUFLLFdBQVc7QUFBQSxJQUNwQztBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0EsUUFBTSxRQUFRLEtBQUs7QUFDbkIsYUFBVyxRQUFRLE9BQU8sT0FBTyxLQUFLLEdBQUc7QUFDdkM7QUFBQSxNQUNFLEtBQUssSUFBSSxLQUFLLEtBQUssS0FBSyxRQUFRLElBQUksS0FBSyxRQUFRO0FBQUEsTUFDakQ7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBO0FBQUEsTUFDRSxLQUFLLFlBQVksVUFBYSxPQUFPLElBQUksS0FBSyxPQUFPO0FBQUEsTUFDckQ7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFHQSxzQkFBc0IsYUFDcEIsT0FDQSxVQUFvQyxDQUFDLEdBQ3JDO0FBQ0EsVUFBUSxRQUFRLGVBQWU7QUFDL0IsUUFBTSxhQUFhLGtCQUFrQixRQUFRLE1BQU07QUFDbkQsTUFBSSxhQUFhLElBQ2YsU0FBUyxHQUNULFFBQVEsR0FDUixRQUFRO0FBQ1YsTUFBSSxPQUFzQixDQUFDLEdBQ3pCLFVBQXlCLENBQUM7QUFDNUIsTUFBSSxTQUFTLG9CQUFJLElBQVk7QUFDN0IsbUJBQWlCLFFBQVEsV0FBVyxPQUFPLEVBQUUsUUFBUSxRQUFRLE9BQU8sQ0FBQyxHQUFHO0FBQ3RFLFlBQVEsUUFBUSxlQUFlO0FBQy9CLFFBQUksY0FBYyxNQUFNO0FBQ3RCLG1CQUFhLEtBQUssU0FBUztBQUMzQixlQUFTLEtBQUssU0FBUyxPQUFPO0FBQzlCLGFBQU8sS0FBSyxTQUFTLE9BQU8sSUFBSSxDQUFDLFVBQVUsSUFBSSxJQUFJLE1BQU0sUUFBUSxDQUFDO0FBQ2xFLGdCQUFVLEtBQUssU0FBUyxPQUFPLElBQUksQ0FBQyxVQUFVLElBQUksSUFBSSxNQUFNLFdBQVcsQ0FBQztBQUN4RSxlQUFTLElBQUksSUFBSSxPQUFPLEtBQUssS0FBSyxTQUFTLE1BQU0sQ0FBQztBQUNsRCxZQUFNLFdBQVc7QUFDakI7QUFBQSxJQUNGO0FBQ0EsVUFBTSxVQUFVO0FBQUEsTUFDZCxLQUFLO0FBQUEsTUFDTCxLQUFLO0FBQUEsTUFDTCxLQUFLO0FBQUEsTUFDTCxLQUFLLEtBQUssS0FBSztBQUFBLE1BQ2YsUUFBUSxLQUFLLEtBQUs7QUFBQSxNQUNsQjtBQUFBLElBQ0Y7QUFDQTtBQUNBLGFBQVMsT0FBTyxLQUFLLE9BQU8sRUFBRTtBQUM5QixVQUFNLFdBQVc7QUFBQSxFQUNuQjtBQUNBLFVBQVEsUUFBUSxlQUFlO0FBQy9CLFNBQU8sRUFBRSxZQUFZLFFBQVEsT0FBTyxNQUFNO0FBQzVDOyIsIm5hbWVzIjpbXX0=
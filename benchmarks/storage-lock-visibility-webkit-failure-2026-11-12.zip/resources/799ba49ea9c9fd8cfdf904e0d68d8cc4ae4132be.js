export function verificationYield(signal) {
  let deadline = performance.now() + 8;
  return async () => {
    signal?.throwIfAborted();
    if (performance.now() < deadline) return;
    await new Promise((resolve) => setTimeout(resolve, 0));
    signal?.throwIfAborted();
    deadline = performance.now() + 8;
  };
}
export function abortable(operation, signal) {
  if (!signal) return operation;
  return new Promise((resolve, reject) => {
    const abort = () => {
      signal.removeEventListener("abort", abort);
      reject(signal.reason);
    };
    signal.addEventListener("abort", abort, { once: true });
    operation.then(
      (value) => {
        signal.removeEventListener("abort", abort);
        resolve(value);
      },
      (error) => {
        signal.removeEventListener("abort", abort);
        reject(error);
      }
    );
    if (signal.aborted) abort();
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInZlcmlmaWNhdGlvbi15aWVsZC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiogWWllbGQgYmV0d2VlbiBjb21wbGV0ZWQgcGFnZXMgd2hlbiB2ZXJpZmljYXRpb24gaGFzIG9jY3VwaWVkIHRoZSBjdXJyZW50IHRhc2sgYnVkZ2V0LiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHZlcmlmaWNhdGlvbllpZWxkKHNpZ25hbD86IEFib3J0U2lnbmFsKSB7XG4gIGxldCBkZWFkbGluZSA9IHBlcmZvcm1hbmNlLm5vdygpICsgODtcbiAgcmV0dXJuIGFzeW5jICgpID0+IHtcbiAgICBzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG4gICAgaWYgKHBlcmZvcm1hbmNlLm5vdygpIDwgZGVhZGxpbmUpIHJldHVybjtcbiAgICBhd2FpdCBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSkgPT4gc2V0VGltZW91dChyZXNvbHZlLCAwKSk7XG4gICAgc2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuICAgIGRlYWRsaW5lID0gcGVyZm9ybWFuY2Uubm93KCkgKyA4O1xuICB9O1xufVxuXG4vKiogU3RvcCB3YWl0aW5nIG9uIGEgcGVuZGluZyBvcGVyYXRpb247IHRoZSBvcGVyYXRpb24gaXRzZWxmIHJlbWFpbnMgY2FsbGVyLW93bmVkLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGFib3J0YWJsZTxUPihvcGVyYXRpb246IFByb21pc2U8VD4sIHNpZ25hbD86IEFib3J0U2lnbmFsKTogUHJvbWlzZTxUPiB7XG4gIGlmICghc2lnbmFsKSByZXR1cm4gb3BlcmF0aW9uO1xuICByZXR1cm4gbmV3IFByb21pc2U8VD4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgIGNvbnN0IGFib3J0ID0gKCkgPT4ge1xuICAgICAgc2lnbmFsLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2Fib3J0JywgYWJvcnQpO1xuICAgICAgcmVqZWN0KHNpZ25hbC5yZWFzb24pO1xuICAgIH07XG4gICAgc2lnbmFsLmFkZEV2ZW50TGlzdGVuZXIoJ2Fib3J0JywgYWJvcnQsIHsgb25jZTogdHJ1ZSB9KTtcbiAgICBvcGVyYXRpb24udGhlbihcbiAgICAgICh2YWx1ZSkgPT4ge1xuICAgICAgICBzaWduYWwucmVtb3ZlRXZlbnRMaXN0ZW5lcignYWJvcnQnLCBhYm9ydCk7XG4gICAgICAgIHJlc29sdmUodmFsdWUpO1xuICAgICAgfSxcbiAgICAgIChlcnJvcikgPT4ge1xuICAgICAgICBzaWduYWwucmVtb3ZlRXZlbnRMaXN0ZW5lcignYWJvcnQnLCBhYm9ydCk7XG4gICAgICAgIHJlamVjdChlcnJvcik7XG4gICAgICB9LFxuICAgICk7XG4gICAgaWYgKHNpZ25hbC5hYm9ydGVkKSBhYm9ydCgpO1xuICB9KTtcbn1cbiJdLCJtYXBwaW5ncyI6IkFBQ08sZ0JBQVMsa0JBQWtCLFFBQXNCO0FBQ3RELE1BQUksV0FBVyxZQUFZLElBQUksSUFBSTtBQUNuQyxTQUFPLFlBQVk7QUFDakIsWUFBUSxlQUFlO0FBQ3ZCLFFBQUksWUFBWSxJQUFJLElBQUksU0FBVTtBQUNsQyxVQUFNLElBQUksUUFBYyxDQUFDLFlBQVksV0FBVyxTQUFTLENBQUMsQ0FBQztBQUMzRCxZQUFRLGVBQWU7QUFDdkIsZUFBVyxZQUFZLElBQUksSUFBSTtBQUFBLEVBQ2pDO0FBQ0Y7QUFHTyxnQkFBUyxVQUFhLFdBQXVCLFFBQWtDO0FBQ3BGLE1BQUksQ0FBQyxPQUFRLFFBQU87QUFDcEIsU0FBTyxJQUFJLFFBQVcsQ0FBQyxTQUFTLFdBQVc7QUFDekMsVUFBTSxRQUFRLE1BQU07QUFDbEIsYUFBTyxvQkFBb0IsU0FBUyxLQUFLO0FBQ3pDLGFBQU8sT0FBTyxNQUFNO0FBQUEsSUFDdEI7QUFDQSxXQUFPLGlCQUFpQixTQUFTLE9BQU8sRUFBRSxNQUFNLEtBQUssQ0FBQztBQUN0RCxjQUFVO0FBQUEsTUFDUixDQUFDLFVBQVU7QUFDVCxlQUFPLG9CQUFvQixTQUFTLEtBQUs7QUFDekMsZ0JBQVEsS0FBSztBQUFBLE1BQ2Y7QUFBQSxNQUNBLENBQUMsVUFBVTtBQUNULGVBQU8sb0JBQW9CLFNBQVMsS0FBSztBQUN6QyxlQUFPLEtBQUs7QUFBQSxNQUNkO0FBQUEsSUFDRjtBQUNBLFFBQUksT0FBTyxRQUFTLE9BQU07QUFBQSxFQUM1QixDQUFDO0FBQ0g7IiwibmFtZXMiOltdfQ==
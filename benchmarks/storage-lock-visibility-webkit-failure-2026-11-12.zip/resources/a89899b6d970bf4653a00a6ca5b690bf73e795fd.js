export function filterColumns(filter) {
  return "column" in filter ? [filter.column] : filter.criteria.map((criterion) => criterion.column);
}
export function matchesFilter(value, criterion, foldedQuery) {
  const error = value !== null && typeof value === "object";
  const blank = value === null || value === "";
  switch (criterion.operator) {
    case "isBlank":
      return blank;
    case "isNotBlank":
      return !blank;
    case "isError":
      return error;
    case "isNotError":
      return !error;
    case "eq":
    case "neq": {
      if (error || value === null) return false;
      const equal = typeof value === typeof criterion.value && (typeof value === "string" && typeof criterion.value === "string" ? value.toLowerCase() === (foldedQuery ?? criterion.value.toLowerCase()) : value === criterion.value);
      return criterion.operator === "eq" ? equal : !equal;
    }
    case "gt":
      return typeof value === "number" && value > criterion.value;
    case "gte":
      return typeof value === "number" && value >= criterion.value;
    case "lt":
      return typeof value === "number" && value < criterion.value;
    case "lte":
      return typeof value === "number" && value <= criterion.value;
    default: {
      if (typeof value !== "string") return false;
      const text = value.toLowerCase(), query = foldedQuery ?? criterion.value.toLowerCase();
      switch (criterion.operator) {
        case "contains":
          return text.includes(query);
        case "notContains":
          return !text.includes(query);
        case "startsWith":
          return text.startsWith(query);
        case "endsWith":
          return text.endsWith(query);
      }
    }
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbHRlci50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IENlbGxWYWx1ZSB9IGZyb20gJy4vdHlwZXMuanMnO1xuaW1wb3J0IHR5cGUgeyBGaWx0ZXJDcml0ZXJpb24sIFdvcmtzaGVldEZpbHRlciB9IGZyb20gJy4vZmlsdGVyLXNjaGVtYS5qcyc7XG5cbmV4cG9ydCBmdW5jdGlvbiBmaWx0ZXJDb2x1bW5zKGZpbHRlcjogTm9uTnVsbGFibGU8V29ya3NoZWV0RmlsdGVyPik6IG51bWJlcltdIHtcbiAgcmV0dXJuICdjb2x1bW4nIGluIGZpbHRlclxuICAgID8gW2ZpbHRlci5jb2x1bW5dXG4gICAgOiBmaWx0ZXIuY3JpdGVyaWEubWFwKChjcml0ZXJpb24pID0+IGNyaXRlcmlvbi5jb2x1bW4pO1xufVxuXG4vKiogVHlwZWQgcHJlZGljYXRlcyBuZXZlciBjb2VyY2UgbnVtZXJpYyB0ZXh0LCBib29sZWFucyBvciBmb3JtdWxhIGVycm9ycyBpbnRvIG51bWJlcnMuICovXG5leHBvcnQgZnVuY3Rpb24gbWF0Y2hlc0ZpbHRlcihcbiAgdmFsdWU6IENlbGxWYWx1ZSxcbiAgY3JpdGVyaW9uOiBGaWx0ZXJDcml0ZXJpb24sXG4gIGZvbGRlZFF1ZXJ5Pzogc3RyaW5nLFxuKTogYm9vbGVhbiB7XG4gIGNvbnN0IGVycm9yID0gdmFsdWUgIT09IG51bGwgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JztcbiAgY29uc3QgYmxhbmsgPSB2YWx1ZSA9PT0gbnVsbCB8fCB2YWx1ZSA9PT0gJyc7XG4gIHN3aXRjaCAoY3JpdGVyaW9uLm9wZXJhdG9yKSB7XG4gICAgY2FzZSAnaXNCbGFuayc6XG4gICAgICByZXR1cm4gYmxhbms7XG4gICAgY2FzZSAnaXNOb3RCbGFuayc6XG4gICAgICByZXR1cm4gIWJsYW5rO1xuICAgIGNhc2UgJ2lzRXJyb3InOlxuICAgICAgcmV0dXJuIGVycm9yO1xuICAgIGNhc2UgJ2lzTm90RXJyb3InOlxuICAgICAgcmV0dXJuICFlcnJvcjtcbiAgICBjYXNlICdlcSc6XG4gICAgY2FzZSAnbmVxJzoge1xuICAgICAgaWYgKGVycm9yIHx8IHZhbHVlID09PSBudWxsKSByZXR1cm4gZmFsc2U7XG4gICAgICBjb25zdCBlcXVhbCA9XG4gICAgICAgIHR5cGVvZiB2YWx1ZSA9PT0gdHlwZW9mIGNyaXRlcmlvbi52YWx1ZSAmJlxuICAgICAgICAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJyAmJiB0eXBlb2YgY3JpdGVyaW9uLnZhbHVlID09PSAnc3RyaW5nJ1xuICAgICAgICAgID8gdmFsdWUudG9Mb3dlckNhc2UoKSA9PT0gKGZvbGRlZFF1ZXJ5ID8/IGNyaXRlcmlvbi52YWx1ZS50b0xvd2VyQ2FzZSgpKVxuICAgICAgICAgIDogdmFsdWUgPT09IGNyaXRlcmlvbi52YWx1ZSk7XG4gICAgICByZXR1cm4gY3JpdGVyaW9uLm9wZXJhdG9yID09PSAnZXEnID8gZXF1YWwgOiAhZXF1YWw7XG4gICAgfVxuICAgIGNhc2UgJ2d0JzpcbiAgICAgIHJldHVybiB0eXBlb2YgdmFsdWUgPT09ICdudW1iZXInICYmIHZhbHVlID4gY3JpdGVyaW9uLnZhbHVlO1xuICAgIGNhc2UgJ2d0ZSc6XG4gICAgICByZXR1cm4gdHlwZW9mIHZhbHVlID09PSAnbnVtYmVyJyAmJiB2YWx1ZSA+PSBjcml0ZXJpb24udmFsdWU7XG4gICAgY2FzZSAnbHQnOlxuICAgICAgcmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gJ251bWJlcicgJiYgdmFsdWUgPCBjcml0ZXJpb24udmFsdWU7XG4gICAgY2FzZSAnbHRlJzpcbiAgICAgIHJldHVybiB0eXBlb2YgdmFsdWUgPT09ICdudW1iZXInICYmIHZhbHVlIDw9IGNyaXRlcmlvbi52YWx1ZTtcbiAgICBkZWZhdWx0OiB7XG4gICAgICBpZiAodHlwZW9mIHZhbHVlICE9PSAnc3RyaW5nJykgcmV0dXJuIGZhbHNlO1xuICAgICAgY29uc3QgdGV4dCA9IHZhbHVlLnRvTG93ZXJDYXNlKCksXG4gICAgICAgIHF1ZXJ5ID0gZm9sZGVkUXVlcnkgPz8gY3JpdGVyaW9uLnZhbHVlLnRvTG93ZXJDYXNlKCk7XG4gICAgICBzd2l0Y2ggKGNyaXRlcmlvbi5vcGVyYXRvcikge1xuICAgICAgICBjYXNlICdjb250YWlucyc6XG4gICAgICAgICAgcmV0dXJuIHRleHQuaW5jbHVkZXMocXVlcnkpO1xuICAgICAgICBjYXNlICdub3RDb250YWlucyc6XG4gICAgICAgICAgcmV0dXJuICF0ZXh0LmluY2x1ZGVzKHF1ZXJ5KTtcbiAgICAgICAgY2FzZSAnc3RhcnRzV2l0aCc6XG4gICAgICAgICAgcmV0dXJuIHRleHQuc3RhcnRzV2l0aChxdWVyeSk7XG4gICAgICAgIGNhc2UgJ2VuZHNXaXRoJzpcbiAgICAgICAgICByZXR1cm4gdGV4dC5lbmRzV2l0aChxdWVyeSk7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG4iXSwibWFwcGluZ3MiOiJBQUdPLGdCQUFTLGNBQWMsUUFBZ0Q7QUFDNUUsU0FBTyxZQUFZLFNBQ2YsQ0FBQyxPQUFPLE1BQU0sSUFDZCxPQUFPLFNBQVMsSUFBSSxDQUFDLGNBQWMsVUFBVSxNQUFNO0FBQ3pEO0FBR08sZ0JBQVMsY0FDZCxPQUNBLFdBQ0EsYUFDUztBQUNULFFBQU0sUUFBUSxVQUFVLFFBQVEsT0FBTyxVQUFVO0FBQ2pELFFBQU0sUUFBUSxVQUFVLFFBQVEsVUFBVTtBQUMxQyxVQUFRLFVBQVUsVUFBVTtBQUFBLElBQzFCLEtBQUs7QUFDSCxhQUFPO0FBQUEsSUFDVCxLQUFLO0FBQ0gsYUFBTyxDQUFDO0FBQUEsSUFDVixLQUFLO0FBQ0gsYUFBTztBQUFBLElBQ1QsS0FBSztBQUNILGFBQU8sQ0FBQztBQUFBLElBQ1YsS0FBSztBQUFBLElBQ0wsS0FBSyxPQUFPO0FBQ1YsVUFBSSxTQUFTLFVBQVUsS0FBTSxRQUFPO0FBQ3BDLFlBQU0sUUFDSixPQUFPLFVBQVUsT0FBTyxVQUFVLFVBQ2pDLE9BQU8sVUFBVSxZQUFZLE9BQU8sVUFBVSxVQUFVLFdBQ3JELE1BQU0sWUFBWSxPQUFPLGVBQWUsVUFBVSxNQUFNLFlBQVksS0FDcEUsVUFBVSxVQUFVO0FBQzFCLGFBQU8sVUFBVSxhQUFhLE9BQU8sUUFBUSxDQUFDO0FBQUEsSUFDaEQ7QUFBQSxJQUNBLEtBQUs7QUFDSCxhQUFPLE9BQU8sVUFBVSxZQUFZLFFBQVEsVUFBVTtBQUFBLElBQ3hELEtBQUs7QUFDSCxhQUFPLE9BQU8sVUFBVSxZQUFZLFNBQVMsVUFBVTtBQUFBLElBQ3pELEtBQUs7QUFDSCxhQUFPLE9BQU8sVUFBVSxZQUFZLFFBQVEsVUFBVTtBQUFBLElBQ3hELEtBQUs7QUFDSCxhQUFPLE9BQU8sVUFBVSxZQUFZLFNBQVMsVUFBVTtBQUFBLElBQ3pELFNBQVM7QUFDUCxVQUFJLE9BQU8sVUFBVSxTQUFVLFFBQU87QUFDdEMsWUFBTSxPQUFPLE1BQU0sWUFBWSxHQUM3QixRQUFRLGVBQWUsVUFBVSxNQUFNLFlBQVk7QUFDckQsY0FBUSxVQUFVLFVBQVU7QUFBQSxRQUMxQixLQUFLO0FBQ0gsaUJBQU8sS0FBSyxTQUFTLEtBQUs7QUFBQSxRQUM1QixLQUFLO0FBQ0gsaUJBQU8sQ0FBQyxLQUFLLFNBQVMsS0FBSztBQUFBLFFBQzdCLEtBQUs7QUFDSCxpQkFBTyxLQUFLLFdBQVcsS0FBSztBQUFBLFFBQzlCLEtBQUs7QUFDSCxpQkFBTyxLQUFLLFNBQVMsS0FBSztBQUFBLE1BQzlCO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjsiLCJuYW1lcyI6W119
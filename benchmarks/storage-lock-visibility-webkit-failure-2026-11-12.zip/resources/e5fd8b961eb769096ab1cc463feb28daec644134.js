import { evaluateFormula, parseFormula } from "/@fs/Volumes/github/private/opensheet/packages/formula/src/index.ts";
import { key, scalarValue } from "/@fs/Volumes/github/private/opensheet/packages/core/src/types.ts";
export class FormulaCalculation {
  constructor(readSheet, findSheet, dateSystem = "1900") {
    this.readSheet = readSheet;
    this.findSheet = findSheet;
    this.dateSystem = dateSystem;
  }
  readSheet;
  findSheet;
  dateSystem;
  cache = /* @__PURE__ */ new Map();
  clear() {
    this.cache.clear();
  }
  value(sheetId, row, column, stack = /* @__PURE__ */ new Set()) {
    const sh = this.readSheet(sheetId);
    if (row >= sh.rowOrder.length || column >= sh.columnOrder.length || row < 0 || column < 0)
      return { error: "#REF!" };
    const k = `${sheetId}:${row}:${column}`;
    if (this.cache.has(k)) return this.cache.get(k);
    if (stack.has(k)) return { error: "#CYCLE!" };
    const c = sh.cells[key(sh.rowOrder[row], sh.columnOrder[column])];
    if (!c) return null;
    if (c.input.type !== "formula") return scalarValue(c.input);
    if (stack.size >= 128) return { error: "#LIMIT!" };
    stack.add(k);
    let result;
    try {
      result = evaluateFormula(
        parseFormula(c.input.expression),
        (ref) => {
          const target = ref.sheet ? this.findSheet(ref.sheet) : sheetId;
          return target ? this.value(target, ref.row, ref.column, stack) : { error: "#REF!" };
        },
        void 0,
        this.dateSystem
      );
    } catch (e) {
      result = { error: e instanceof Error ? e.message : "#VALUE!" };
    } finally {
      stack.delete(k);
    }
    if (!(result && typeof result === "object" && ["#LIMIT!", "#CYCLE!"].includes(result.error)))
      this.cache.set(k, result);
    return result;
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhbGN1bGF0aW9uLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGV2YWx1YXRlRm9ybXVsYSwgcGFyc2VGb3JtdWxhLCB0eXBlIFJlZmVyZW5jZSB9IGZyb20gJ0BvcGVuc2hlZXRqcy9mb3JtdWxhJztcbmltcG9ydCB7IGtleSwgc2NhbGFyVmFsdWUsIHR5cGUgQ2VsbFZhbHVlLCB0eXBlIFNoZWV0U25hcHNob3QgfSBmcm9tICcuL3R5cGVzLmpzJztcblxuZXhwb3J0IGNsYXNzIEZvcm11bGFDYWxjdWxhdGlvbiB7XG4gIHByaXZhdGUgY2FjaGUgPSBuZXcgTWFwPHN0cmluZywgQ2VsbFZhbHVlPigpO1xuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIHJlYWRTaGVldDogKGlkOiBzdHJpbmcpID0+IFJlYWRvbmx5PFNoZWV0U25hcHNob3Q+LFxuICAgIHByaXZhdGUgZmluZFNoZWV0OiAobmFtZTogc3RyaW5nKSA9PiBzdHJpbmcgfCB1bmRlZmluZWQsXG4gICAgcHJpdmF0ZSBkYXRlU3lzdGVtOiAnMTkwMCcgfCAnMTkwNCcgPSAnMTkwMCcsXG4gICkge31cbiAgY2xlYXIoKSB7XG4gICAgdGhpcy5jYWNoZS5jbGVhcigpO1xuICB9XG4gIHZhbHVlKHNoZWV0SWQ6IHN0cmluZywgcm93OiBudW1iZXIsIGNvbHVtbjogbnVtYmVyLCBzdGFjayA9IG5ldyBTZXQ8c3RyaW5nPigpKTogQ2VsbFZhbHVlIHtcbiAgICBjb25zdCBzaCA9IHRoaXMucmVhZFNoZWV0KHNoZWV0SWQpO1xuICAgIGlmIChyb3cgPj0gc2gucm93T3JkZXIubGVuZ3RoIHx8IGNvbHVtbiA+PSBzaC5jb2x1bW5PcmRlci5sZW5ndGggfHwgcm93IDwgMCB8fCBjb2x1bW4gPCAwKVxuICAgICAgcmV0dXJuIHsgZXJyb3I6ICcjUkVGIScgfTtcbiAgICBjb25zdCBrID0gYCR7c2hlZXRJZH06JHtyb3d9OiR7Y29sdW1ufWA7XG4gICAgaWYgKHRoaXMuY2FjaGUuaGFzKGspKSByZXR1cm4gdGhpcy5jYWNoZS5nZXQoaykhO1xuICAgIGlmIChzdGFjay5oYXMoaykpIHJldHVybiB7IGVycm9yOiAnI0NZQ0xFIScgfTtcbiAgICBjb25zdCBjID0gc2guY2VsbHNba2V5KHNoLnJvd09yZGVyW3Jvd10sIHNoLmNvbHVtbk9yZGVyW2NvbHVtbl0pXTtcbiAgICBpZiAoIWMpIHJldHVybiBudWxsO1xuICAgIGlmIChjLmlucHV0LnR5cGUgIT09ICdmb3JtdWxhJykgcmV0dXJuIHNjYWxhclZhbHVlKGMuaW5wdXQpO1xuICAgIGlmIChzdGFjay5zaXplID49IDEyOCkgcmV0dXJuIHsgZXJyb3I6ICcjTElNSVQhJyB9O1xuICAgIHN0YWNrLmFkZChrKTtcbiAgICBsZXQgcmVzdWx0OiBDZWxsVmFsdWU7XG4gICAgdHJ5IHtcbiAgICAgIHJlc3VsdCA9IGV2YWx1YXRlRm9ybXVsYShcbiAgICAgICAgcGFyc2VGb3JtdWxhKGMuaW5wdXQuZXhwcmVzc2lvbiksXG4gICAgICAgIChyZWY6IFJlZmVyZW5jZSkgPT4ge1xuICAgICAgICAgIGNvbnN0IHRhcmdldCA9IHJlZi5zaGVldCA/IHRoaXMuZmluZFNoZWV0KHJlZi5zaGVldCkgOiBzaGVldElkO1xuICAgICAgICAgIHJldHVybiB0YXJnZXQgPyB0aGlzLnZhbHVlKHRhcmdldCwgcmVmLnJvdywgcmVmLmNvbHVtbiwgc3RhY2spIDogeyBlcnJvcjogJyNSRUYhJyB9O1xuICAgICAgICB9LFxuICAgICAgICB1bmRlZmluZWQsXG4gICAgICAgIHRoaXMuZGF0ZVN5c3RlbSxcbiAgICAgICk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgcmVzdWx0ID0geyBlcnJvcjogZSBpbnN0YW5jZW9mIEVycm9yID8gZS5tZXNzYWdlIDogJyNWQUxVRSEnIH07XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHN0YWNrLmRlbGV0ZShrKTtcbiAgICB9XG4gICAgaWYgKCEocmVzdWx0ICYmIHR5cGVvZiByZXN1bHQgPT09ICdvYmplY3QnICYmIFsnI0xJTUlUIScsICcjQ1lDTEUhJ10uaW5jbHVkZXMocmVzdWx0LmVycm9yKSkpXG4gICAgICB0aGlzLmNhY2hlLnNldChrLCByZXN1bHQpO1xuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cbn1cbiJdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUIsb0JBQW9DO0FBQzlELFNBQVMsS0FBSyxtQkFBdUQ7QUFFOUQsYUFBTSxtQkFBbUI7QUFBQSxFQUU5QixZQUNVLFdBQ0EsV0FDQSxhQUE4QixRQUN0QztBQUhRO0FBQ0E7QUFDQTtBQUFBLEVBQ1A7QUFBQSxFQUhPO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUpGLFFBQVEsb0JBQUksSUFBdUI7QUFBQSxFQU0zQyxRQUFRO0FBQ04sU0FBSyxNQUFNLE1BQU07QUFBQSxFQUNuQjtBQUFBLEVBQ0EsTUFBTSxTQUFpQixLQUFhLFFBQWdCLFFBQVEsb0JBQUksSUFBWSxHQUFjO0FBQ3hGLFVBQU0sS0FBSyxLQUFLLFVBQVUsT0FBTztBQUNqQyxRQUFJLE9BQU8sR0FBRyxTQUFTLFVBQVUsVUFBVSxHQUFHLFlBQVksVUFBVSxNQUFNLEtBQUssU0FBUztBQUN0RixhQUFPLEVBQUUsT0FBTyxRQUFRO0FBQzFCLFVBQU0sSUFBSSxHQUFHLE9BQU8sSUFBSSxHQUFHLElBQUksTUFBTTtBQUNyQyxRQUFJLEtBQUssTUFBTSxJQUFJLENBQUMsRUFBRyxRQUFPLEtBQUssTUFBTSxJQUFJLENBQUM7QUFDOUMsUUFBSSxNQUFNLElBQUksQ0FBQyxFQUFHLFFBQU8sRUFBRSxPQUFPLFVBQVU7QUFDNUMsVUFBTSxJQUFJLEdBQUcsTUFBTSxJQUFJLEdBQUcsU0FBUyxHQUFHLEdBQUcsR0FBRyxZQUFZLE1BQU0sQ0FBQyxDQUFDO0FBQ2hFLFFBQUksQ0FBQyxFQUFHLFFBQU87QUFDZixRQUFJLEVBQUUsTUFBTSxTQUFTLFVBQVcsUUFBTyxZQUFZLEVBQUUsS0FBSztBQUMxRCxRQUFJLE1BQU0sUUFBUSxJQUFLLFFBQU8sRUFBRSxPQUFPLFVBQVU7QUFDakQsVUFBTSxJQUFJLENBQUM7QUFDWCxRQUFJO0FBQ0osUUFBSTtBQUNGLGVBQVM7QUFBQSxRQUNQLGFBQWEsRUFBRSxNQUFNLFVBQVU7QUFBQSxRQUMvQixDQUFDLFFBQW1CO0FBQ2xCLGdCQUFNLFNBQVMsSUFBSSxRQUFRLEtBQUssVUFBVSxJQUFJLEtBQUssSUFBSTtBQUN2RCxpQkFBTyxTQUFTLEtBQUssTUFBTSxRQUFRLElBQUksS0FBSyxJQUFJLFFBQVEsS0FBSyxJQUFJLEVBQUUsT0FBTyxRQUFRO0FBQUEsUUFDcEY7QUFBQSxRQUNBO0FBQUEsUUFDQSxLQUFLO0FBQUEsTUFDUDtBQUFBLElBQ0YsU0FBUyxHQUFHO0FBQ1YsZUFBUyxFQUFFLE9BQU8sYUFBYSxRQUFRLEVBQUUsVUFBVSxVQUFVO0FBQUEsSUFDL0QsVUFBRTtBQUNBLFlBQU0sT0FBTyxDQUFDO0FBQUEsSUFDaEI7QUFDQSxRQUFJLEVBQUUsVUFBVSxPQUFPLFdBQVcsWUFBWSxDQUFDLFdBQVcsU0FBUyxFQUFFLFNBQVMsT0FBTyxLQUFLO0FBQ3hGLFdBQUssTUFBTSxJQUFJLEdBQUcsTUFBTTtBQUMxQixXQUFPO0FBQUEsRUFDVDtBQUNGOyIsIm5hbWVzIjpbXX0=
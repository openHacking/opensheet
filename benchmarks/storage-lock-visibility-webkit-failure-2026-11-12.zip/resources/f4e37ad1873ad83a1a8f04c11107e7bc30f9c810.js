import { columnName } from "/@fs/Volumes/github/private/opensheet/packages/formula/src/address.ts";
export function printFormula(n) {
  return print(n, false);
}
export function printFormulaExplicit(n) {
  return print(n, true);
}
function print(n, explicitUnary) {
  const ref = (r) => `${r.sheet ? `'${r.sheet.replace(/'/g, "''")}'!` : ""}${r.absoluteColumn ? "$" : ""}${columnName(r.column)}${r.absoluteRow ? "$" : ""}${r.row + 1}`;
  switch (n.kind) {
    case "ref":
      return ref(n);
    case "range":
      return ref(n.start) + ":" + ref({ ...n.end, sheet: void 0 });
    case "literal":
      return n.value === null ? "0" : typeof n.value === "object" ? n.value.error : typeof n.value === "string" ? `"${n.value.replace(/"/g, '""')}"` : String(n.value).toUpperCase();
    case "unary":
      if (n.op === "%") return `(${print(n.value, explicitUnary)})%`;
      return explicitUnary ? `(${n.op}(${print(n.value, explicitUnary)}))` : `${n.op}(${print(n.value, explicitUnary)})`;
    case "binary":
      return `(${print(n.left, explicitUnary)}${n.op}${print(n.right, explicitUnary)})`;
    case "call":
      return `${n.name}(${n.args.map((arg) => print(arg, explicitUnary)).join(",")})`;
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByaW50ZXIudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY29sdW1uTmFtZSB9IGZyb20gJy4vYWRkcmVzcy5qcyc7XG5pbXBvcnQgdHlwZSB7IEFTVCwgUmVmZXJlbmNlIH0gZnJvbSAnLi90eXBlcy5qcyc7XG5cbmV4cG9ydCBmdW5jdGlvbiBwcmludEZvcm11bGEobjogQVNUKTogc3RyaW5nIHtcbiAgcmV0dXJuIHByaW50KG4sIGZhbHNlKTtcbn1cblxuLyoqIFBhcmVudGhlc2l6ZSB1bmFyeSBvcGVyYXRvcnMgYXMgd2hvbGUgb3BlcmFuZHMgYWNyb3NzIHByZWNlZGVuY2UgcHJvZmlsZXMuICovXG5leHBvcnQgZnVuY3Rpb24gcHJpbnRGb3JtdWxhRXhwbGljaXQobjogQVNUKTogc3RyaW5nIHtcbiAgcmV0dXJuIHByaW50KG4sIHRydWUpO1xufVxuXG5mdW5jdGlvbiBwcmludChuOiBBU1QsIGV4cGxpY2l0VW5hcnk6IGJvb2xlYW4pOiBzdHJpbmcge1xuICBjb25zdCByZWYgPSAocjogUmVmZXJlbmNlKSA9PlxuICAgIGAke3Iuc2hlZXQgPyBgJyR7ci5zaGVldC5yZXBsYWNlKC8nL2csIFwiJydcIil9JyFgIDogJyd9JHtyLmFic29sdXRlQ29sdW1uID8gJyQnIDogJyd9JHtjb2x1bW5OYW1lKHIuY29sdW1uKX0ke3IuYWJzb2x1dGVSb3cgPyAnJCcgOiAnJ30ke3Iucm93ICsgMX1gO1xuICBzd2l0Y2ggKG4ua2luZCkge1xuICAgIGNhc2UgJ3JlZic6XG4gICAgICByZXR1cm4gcmVmKG4pO1xuICAgIGNhc2UgJ3JhbmdlJzpcbiAgICAgIHJldHVybiByZWYobi5zdGFydCkgKyAnOicgKyByZWYoeyAuLi5uLmVuZCwgc2hlZXQ6IHVuZGVmaW5lZCB9KTtcbiAgICBjYXNlICdsaXRlcmFsJzpcbiAgICAgIHJldHVybiBuLnZhbHVlID09PSBudWxsXG4gICAgICAgID8gJzAnXG4gICAgICAgIDogdHlwZW9mIG4udmFsdWUgPT09ICdvYmplY3QnXG4gICAgICAgICAgPyBuLnZhbHVlLmVycm9yXG4gICAgICAgICAgOiB0eXBlb2Ygbi52YWx1ZSA9PT0gJ3N0cmluZydcbiAgICAgICAgICAgID8gYFwiJHtuLnZhbHVlLnJlcGxhY2UoL1wiL2csICdcIlwiJyl9XCJgXG4gICAgICAgICAgICA6IFN0cmluZyhuLnZhbHVlKS50b1VwcGVyQ2FzZSgpO1xuICAgIGNhc2UgJ3VuYXJ5JzpcbiAgICAgIGlmIChuLm9wID09PSAnJScpIHJldHVybiBgKCR7cHJpbnQobi52YWx1ZSwgZXhwbGljaXRVbmFyeSl9KSVgO1xuICAgICAgcmV0dXJuIGV4cGxpY2l0VW5hcnlcbiAgICAgICAgPyBgKCR7bi5vcH0oJHtwcmludChuLnZhbHVlLCBleHBsaWNpdFVuYXJ5KX0pKWBcbiAgICAgICAgOiBgJHtuLm9wfSgke3ByaW50KG4udmFsdWUsIGV4cGxpY2l0VW5hcnkpfSlgO1xuICAgIGNhc2UgJ2JpbmFyeSc6XG4gICAgICByZXR1cm4gYCgke3ByaW50KG4ubGVmdCwgZXhwbGljaXRVbmFyeSl9JHtuLm9wfSR7cHJpbnQobi5yaWdodCwgZXhwbGljaXRVbmFyeSl9KWA7XG4gICAgY2FzZSAnY2FsbCc6XG4gICAgICByZXR1cm4gYCR7bi5uYW1lfSgke24uYXJncy5tYXAoKGFyZykgPT4gcHJpbnQoYXJnLCBleHBsaWNpdFVuYXJ5KSkuam9pbignLCcpfSlgO1xuICB9XG59XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsa0JBQWtCO0FBR3BCLGdCQUFTLGFBQWEsR0FBZ0I7QUFDM0MsU0FBTyxNQUFNLEdBQUcsS0FBSztBQUN2QjtBQUdPLGdCQUFTLHFCQUFxQixHQUFnQjtBQUNuRCxTQUFPLE1BQU0sR0FBRyxJQUFJO0FBQ3RCO0FBRUEsU0FBUyxNQUFNLEdBQVEsZUFBZ0M7QUFDckQsUUFBTSxNQUFNLENBQUMsTUFDWCxHQUFHLEVBQUUsUUFBUSxJQUFJLEVBQUUsTUFBTSxRQUFRLE1BQU0sSUFBSSxDQUFDLE9BQU8sRUFBRSxHQUFHLEVBQUUsaUJBQWlCLE1BQU0sRUFBRSxHQUFHLFdBQVcsRUFBRSxNQUFNLENBQUMsR0FBRyxFQUFFLGNBQWMsTUFBTSxFQUFFLEdBQUcsRUFBRSxNQUFNLENBQUM7QUFDbkosVUFBUSxFQUFFLE1BQU07QUFBQSxJQUNkLEtBQUs7QUFDSCxhQUFPLElBQUksQ0FBQztBQUFBLElBQ2QsS0FBSztBQUNILGFBQU8sSUFBSSxFQUFFLEtBQUssSUFBSSxNQUFNLElBQUksRUFBRSxHQUFHLEVBQUUsS0FBSyxPQUFPLE9BQVUsQ0FBQztBQUFBLElBQ2hFLEtBQUs7QUFDSCxhQUFPLEVBQUUsVUFBVSxPQUNmLE1BQ0EsT0FBTyxFQUFFLFVBQVUsV0FDakIsRUFBRSxNQUFNLFFBQ1IsT0FBTyxFQUFFLFVBQVUsV0FDakIsSUFBSSxFQUFFLE1BQU0sUUFBUSxNQUFNLElBQUksQ0FBQyxNQUMvQixPQUFPLEVBQUUsS0FBSyxFQUFFLFlBQVk7QUFBQSxJQUN0QyxLQUFLO0FBQ0gsVUFBSSxFQUFFLE9BQU8sSUFBSyxRQUFPLElBQUksTUFBTSxFQUFFLE9BQU8sYUFBYSxDQUFDO0FBQzFELGFBQU8sZ0JBQ0gsSUFBSSxFQUFFLEVBQUUsSUFBSSxNQUFNLEVBQUUsT0FBTyxhQUFhLENBQUMsT0FDekMsR0FBRyxFQUFFLEVBQUUsSUFBSSxNQUFNLEVBQUUsT0FBTyxhQUFhLENBQUM7QUFBQSxJQUM5QyxLQUFLO0FBQ0gsYUFBTyxJQUFJLE1BQU0sRUFBRSxNQUFNLGFBQWEsQ0FBQyxHQUFHLEVBQUUsRUFBRSxHQUFHLE1BQU0sRUFBRSxPQUFPLGFBQWEsQ0FBQztBQUFBLElBQ2hGLEtBQUs7QUFDSCxhQUFPLEdBQUcsRUFBRSxJQUFJLElBQUksRUFBRSxLQUFLLElBQUksQ0FBQyxRQUFRLE1BQU0sS0FBSyxhQUFhLENBQUMsRUFBRSxLQUFLLEdBQUcsQ0FBQztBQUFBLEVBQ2hGO0FBQ0Y7IiwibmFtZXMiOltdfQ==
import { z } from "/@fs/Volumes/github/private/opensheet/node_modules/.vite/deps/zod.js?v=c95e703c";
import { createSnapshot, validateSnapshot, validateJSONValue } from "/@fs/Volumes/github/private/opensheet/packages/core/src/model.ts";
import { BLOCK_ROWS, BLOCK_COLUMNS } from "/@fs/Volumes/github/private/opensheet/packages/core/src/block-layout.ts";
import {
  assert,
  cellSchema,
  sheetSchema,
  styleSchema,
  snapshotSchema,
  scalarSchema,
  key,
  LIMITS
} from "/@fs/Volumes/github/private/opensheet/packages/core/src/types.ts";
const index = z.number().int().min(0).max(4294967295);
const position = z.number().int().min(0).max(BLOCK_ROWS * BLOCK_COLUMNS - 1);
const column = (value) => z.object({ positions: z.array(position).max(2048), values: z.array(value).max(2048) }).strict();
const fileScalarSchema = z.discriminatedUnion("type", [
  scalarSchema.options[0].strict(),
  scalarSchema.options[1].strict(),
  scalarSchema.options[2].strict(),
  scalarSchema.options[3].strict(),
  scalarSchema.options[4].strict()
]);
const axisSchema = z.object({
  nextId: z.number().int().min(1).max(4294967296),
  order: z.array(
    z.tuple([
      index,
      z.number().int().positive().max(LIMITS.rows),
      z.union([z.literal(1), z.literal(-1)])
    ])
  ).max(LIMITS.rows),
  meta: z.record(z.string(), sheetSchema.shape.rows.valueType.strict()).optional()
}).strict();
export const fileBlockDataSchema = z.object({
  numbers: column(z.number().finite()).optional(),
  negativeZero: z.array(position).max(2048).optional(),
  strings: column(z.string().max(LIMITS.text)).optional(),
  booleans: column(z.boolean()).optional(),
  formulas: column(z.string().min(1).max(LIMITS.text)).optional(),
  errors: column(z.string().max(50)).optional(),
  blanks: z.array(position).max(2048).optional(),
  styles: z.array(z.tuple([position, z.number().int().positive().max(2048), index])).max(2048).optional(),
  notes: column(cellSchema.shape.note.unwrap()).optional(),
  links: column(cellSchema.shape.link.unwrap()).optional(),
  formats: column(cellSchema.shape.numberFormat.unwrap()).optional(),
  cached: column(fileScalarSchema).optional(),
  cachedNegativeZero: z.array(position).max(2048).optional()
}).strict();
export const fileBlockSchema = z.object({ row: index, column: index, data: fileBlockDataSchema }).strict();
const fileSheetSchema = sheetSchema.omit({
  rowOrder: true,
  columnOrder: true,
  nextRowId: true,
  nextColumnId: true,
  rows: true,
  columns: true,
  cells: true
}).extend({
  rows: axisSchema,
  columns: axisSchema,
  freeze: sheetSchema.shape.freeze.strict(),
  blocks: z.array(fileBlockSchema)
}).strict();
export const workbookFileSchema = snapshotSchema.omit({ sheets: true, styles: true, sheetOrder: true }).extend({
  schemaVersion: z.literal(3),
  sheets: z.array(fileSheetSchema).min(1).max(LIMITS.sheets),
  styles: z.array(styleSchema.strict())
}).strict();
export function encodeAxis(ids, nextId, meta = {}) {
  const order = [];
  for (let i = 0; i < ids.length; ) {
    const step = ids[i + 1] === ids[i] - 1 ? -1 : 1;
    let end = i + 1;
    while (end < ids.length && ids[end] === ids[i] + step * (end - i)) end++;
    order.push([ids[i], end - i, step]);
    i = end;
  }
  return { nextId, order, ...Object.keys(meta).length ? { meta } : {} };
}
export function decodeAxis(axis, limit) {
  const ids = [], seen = /* @__PURE__ */ new Set();
  for (const [start, count, step] of axis.order) {
    assert(ids.length + count <= limit, "LIMIT_EXCEEDED", "Axis exceeds dimension limit");
    for (let i = 0; i < count; i++) {
      const id = start + i * step;
      assert(
        id >= 0 && id < axis.nextId && !seen.has(id),
        "INVALID_ARGUMENT",
        "Invalid or duplicate axis identity"
      );
      seen.add(id);
      ids.push(id);
    }
  }
  assert(ids.length > 0, "INVALID_ARGUMENT", "Empty axis");
  for (const id of Object.keys(axis.meta ?? {}))
    assert(/^(0|[1-9]\d*)$/.test(id) && seen.has(+id), "INVALID_ARGUMENT", "Unknown axis metadata");
  return ids;
}
const inputColumns = {
  number: "numbers",
  string: "strings",
  boolean: "booleans",
  formula: "formulas",
  error: "errors"
};
export function encodeFileCells(cells, styles, keepCached = true) {
  const data = {};
  const append = (name, offset, value) => {
    const col = data[name] ??= { positions: [], values: [] };
    col.positions.push(offset);
    col.values.push(value);
  };
  let run;
  for (const cell of [...cells].sort(
    (a, b) => a.rowId % 64 * 32 + a.columnId % 32 - b.rowId % 64 * 32 - b.columnId % 32
  )) {
    const offset = cell.rowId % BLOCK_ROWS * BLOCK_COLUMNS + cell.columnId % BLOCK_COLUMNS;
    const input = cell.input;
    if (input.type === "blank") (data.blanks ??= []).push(offset);
    else
      append(
        inputColumns[input.type],
        offset,
        "value" in input ? input.type === "number" && Object.is(input.value, -0) ? 0 : input.value : input.type === "formula" ? input.expression : input.code
      );
    if (input.type === "number" && Object.is(input.value, -0))
      (data.negativeZero ??= []).push(offset);
    if (cell.styleId !== void 0) {
      const style = styles.get(cell.styleId);
      assert(style !== void 0, "INVALID_ARGUMENT", "Unknown style");
      if (run && run[0] + run[1] === offset && run[2] === style) run[1]++;
      else {
        run = [offset, 1, style];
        (data.styles ??= []).push(run);
      }
    } else run = void 0;
    if (cell.note !== void 0) append("notes", offset, cell.note);
    if (cell.link !== void 0) append("links", offset, cell.link);
    if (cell.numberFormat !== void 0) append("formats", offset, cell.numberFormat);
    if (keepCached && cell.cached !== void 0) {
      append(
        "cached",
        offset,
        cell.cached.type === "number" && Object.is(cell.cached.value, -0) ? { ...cell.cached, value: 0 } : cell.cached
      );
      if (cell.cached.type === "number" && Object.is(cell.cached.value, -0))
        (data.cachedNegativeZero ??= []).push(offset);
    }
  }
  return data;
}
export function decodeFileCells(block, styles, rows, columns, sparse = false) {
  let textBytes = 0;
  for (const col of Object.values(block?.data ?? {})) {
    if (col && typeof col === "object" && "values" in col && Array.isArray(col.values)) {
      for (const value of col.values) {
        if (typeof value === "string") textBytes += value.length * 3;
        else if (value && typeof value === "object") textBytes += JSON.stringify(value).length * 3;
      }
    }
  }
  assert(
    textBytes <= 32 * 1024 * 1024,
    "LIMIT_EXCEEDED",
    "Page text exceeds 32 MiB working budget"
  );
  const parsed = fileBlockSchema.safeParse(block);
  assert(parsed.success, "INVALID_ARGUMENT", "Invalid data block");
  const { row, column: column2, data } = parsed.data;
  assert(
    row <= Math.floor(4294967295 / 64) && column2 <= Math.floor(4294967295 / 32),
    "INVALID_ARGUMENT",
    "Block outside identity space"
  );
  const cells = /* @__PURE__ */ new Map();
  const create = (offset, input) => {
    const rowId = row * 64 + Math.floor(offset / 32), columnId = column2 * 32 + offset % 32;
    assert(
      !cells.has(offset) && (!rows || rows.has(rowId)) && (!columns || columns.has(columnId)),
      "INVALID_ARGUMENT",
      "Duplicate or out-of-axis cell"
    );
    const cell = { rowId, columnId, input };
    cells.set(offset, cell);
    return cell;
  };
  for (const [type, name] of Object.entries(inputColumns)) {
    const col = data[name];
    if (!col) continue;
    assert(col.positions.length === col.values.length, "INVALID_ARGUMENT", "Column lengths differ");
    col.positions.forEach(
      (offset, i) => create(
        offset,
        type === "formula" ? { type, expression: col.values[i] } : type === "error" ? { type, code: col.values[i] } : { type, value: col.values[i] }
      )
    );
  }
  for (const offset of data.blanks ?? []) create(offset, { type: "blank" });
  const zero = (positions, cached) => {
    const seen = /* @__PURE__ */ new Set();
    for (const offset of positions ?? []) {
      const input = cached ? cells.get(offset)?.cached : cells.get(offset)?.input;
      assert(
        input?.type === "number" && input.value === 0 && !seen.has(offset),
        "INVALID_ARGUMENT",
        "Invalid negative zero"
      );
      input.value = -0;
      seen.add(offset);
    }
  };
  const styled = /* @__PURE__ */ new Set();
  for (const [start, count, index2] of data.styles ?? []) {
    assert(
      styles[index2] !== void 0 && start + count <= 2048,
      "INVALID_ARGUMENT",
      "Invalid style range"
    );
    for (let offset = start; offset < start + count; offset++) {
      assert(
        cells.has(offset) && !styled.has(offset),
        "INVALID_ARGUMENT",
        "Overlapping or orphan style"
      );
      cells.get(offset).styleId = styles[index2];
      styled.add(offset);
    }
  }
  for (const [name, property] of [
    ["notes", "note"],
    ["links", "link"],
    ["formats", "numberFormat"],
    ["cached", "cached"]
  ]) {
    const col = data[name], seen = /* @__PURE__ */ new Set();
    if (!col) continue;
    assert(col.positions.length === col.values.length, "INVALID_ARGUMENT", "Column lengths differ");
    col.positions.forEach((offset, i) => {
      assert(
        cells.has(offset) && !seen.has(offset),
        "INVALID_ARGUMENT",
        "Duplicate or orphan property"
      );
      cells.get(offset)[property] = col.values[i];
      seen.add(offset);
    });
  }
  zero(data.negativeZero, false);
  zero(data.cachedNegativeZero, true);
  const result = {};
  for (const cell of cells.values()) {
    if (sparse && cell.input.type !== "formula" && cell.input.type !== "blank" && cell.styleId === void 0 && cell.note === void 0 && cell.link === void 0 && cell.numberFormat === void 0 && cell.cached === void 0)
      continue;
    result[key(cell.rowId, cell.columnId)] = cell;
  }
  return result;
}
export function encodeWorkbookFile(snapshot) {
  const entries = Object.entries(snapshot.styles), styleIndices = new Map(entries.map(([id], i) => [id, i]));
  return {
    schemaVersion: 3,
    workbookId: snapshot.workbookId,
    revision: snapshot.revision,
    dateSystem: snapshot.dateSystem,
    extensions: snapshot.extensions,
    styles: entries.map(([, style]) => style),
    sheets: snapshot.sheetOrder.map((id) => snapshot.sheets.find((sheet) => sheet.id === id)).map((sh) => {
      const { rowOrder, columnOrder, nextRowId, nextColumnId, rows, columns, cells, ...meta } = sh;
      const grouped = /* @__PURE__ */ new Map();
      for (const cell of Object.values(cells)) {
        const address = `${Math.floor(cell.rowId / 64)}/${Math.floor(cell.columnId / 32)}`;
        if (!grouped.has(address)) grouped.set(address, []);
        grouped.get(address).push(cell);
      }
      return {
        ...meta,
        rows: encodeAxis(rowOrder, nextRowId, rows),
        columns: encodeAxis(columnOrder, nextColumnId, columns),
        blocks: [...grouped].map(([address, cells2]) => {
          const [row, column2] = address.split("/").map(Number);
          return { row, column: column2, data: encodeFileCells(cells2, styleIndices) };
        }).sort((a, b) => a.row - b.row || a.column - b.column)
      };
    })
  };
}
export function decodeFileMetadata(input) {
  validateJSONValue(input);
  if (input && typeof input === "object" && !Array.isArray(input)) {
    const candidate = input;
    if (typeof candidate.schemaVersion === "number" && Number.isSafeInteger(candidate.schemaVersion) && typeof candidate.workbookId === "string" && Array.isArray(candidate.sheets) && Array.isArray(candidate.styles)) {
      assert(
        candidate.schemaVersion === 3,
        "UNSUPPORTED_VERSION",
        `Workbook schema ${candidate.schemaVersion} is unsupported; open it with a compatible version and export a schema 3 backup`
      );
    }
  }
  const parsed = workbookFileSchema.safeParse(input);
  assert(parsed.success, "INVALID_ARGUMENT", "Invalid workbook file (schemaVersion 3 required)");
  const file = parsed.data;
  return validateSnapshot({
    ...file,
    sheetOrder: file.sheets.map((sh) => sh.id),
    styles: Object.fromEntries(file.styles.map((style, i) => [`s${i}`, style])),
    sheets: file.sheets.map((sh) => ({
      ...sh,
      rowOrder: decodeAxis(sh.rows, LIMITS.rows),
      columnOrder: decodeAxis(sh.columns, LIMITS.columns),
      nextRowId: sh.rows.nextId,
      nextColumnId: sh.columns.nextId,
      rows: sh.rows.meta ?? {},
      columns: sh.columns.meta ?? {},
      cells: {}
    }))
  });
}
export function decodeWorkbookFile(input) {
  const file = input;
  const snapshot = decodeFileMetadata({
    ...file,
    sheets: file.sheets?.map((sh) => ({ ...sh, blocks: [] }))
  });
  const styles = Object.keys(snapshot.styles);
  for (let i = 0; i < file.sheets.length; i++) {
    const sh = snapshot.sheets[i], rows = new Set(sh.rowOrder), columns = new Set(sh.columnOrder), seen = /* @__PURE__ */ new Set();
    for (const block of file.sheets[i].blocks) {
      assert(block && typeof block === "object", "INVALID_ARGUMENT", "Invalid data block");
      const address = `${block.row}/${block.column}`;
      assert(!seen.has(address), "INVALID_ARGUMENT", "Duplicate block");
      seen.add(address);
      Object.assign(sh.cells, decodeFileCells(block, styles, rows, columns));
    }
  }
  return snapshot;
}
export function createWorkbookFile(options = {}) {
  return encodeWorkbookFile(createSnapshot(options));
}
export function* validateWorkbookFilePages(input, onMetadata) {
  assert(
    input && typeof input === "object" && Array.isArray(input.sheets),
    "INVALID_ARGUMENT",
    "Invalid workbook file"
  );
  const file = input;
  const metadata = decodeFileMetadata({
    ...file,
    sheets: file.sheets.map((sh) => ({ ...sh, blocks: [] }))
  });
  onMetadata?.(file);
  const styles = Object.keys(metadata.styles);
  for (let i = 0; i < file.sheets.length; i++) {
    const sh = metadata.sheets[i], rows = new Set(sh.rowOrder), columns = new Set(sh.columnOrder), seen = /* @__PURE__ */ new Set();
    assert(Array.isArray(file.sheets[i].blocks), "INVALID_ARGUMENT", "Invalid blocks");
    for (const block of file.sheets[i].blocks) {
      assert(block && typeof block === "object", "INVALID_ARGUMENT", "Invalid data block");
      const address = `${block.row}/${block.column}`;
      assert(!seen.has(address), "INVALID_ARGUMENT", "Duplicate page");
      seen.add(address);
      validateJSONValue(block);
      decodeFileCells(block, styles, rows, columns);
      yield { sheetIndex: i, block };
    }
  }
  return file;
}
export function validateWorkbookFile(input) {
  const pages = validateWorkbookFilePages(input);
  for (let step = pages.next(); ; step = pages.next()) {
    if (step.done) return step.value;
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGUtY29kZWMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgeiB9IGZyb20gJ3pvZCc7XG5pbXBvcnQgeyBjcmVhdGVTbmFwc2hvdCwgdmFsaWRhdGVTbmFwc2hvdCwgdmFsaWRhdGVKU09OVmFsdWUgfSBmcm9tICcuL21vZGVsLmpzJztcbmltcG9ydCB7IEJMT0NLX1JPV1MsIEJMT0NLX0NPTFVNTlMgfSBmcm9tICcuL2Jsb2NrLWxheW91dC5qcyc7XG5pbXBvcnQge1xuICBhc3NlcnQsXG4gIGNlbGxTY2hlbWEsXG4gIHNoZWV0U2NoZW1hLFxuICBzdHlsZVNjaGVtYSxcbiAgc25hcHNob3RTY2hlbWEsXG4gIHNjYWxhclNjaGVtYSxcbiAga2V5LFxuICBMSU1JVFMsXG4gIHR5cGUgQ2VsbFJlY29yZCxcbiAgdHlwZSBDZWxsSW5wdXQsXG4gIHR5cGUgV29ya2Jvb2tTbmFwc2hvdCxcbn0gZnJvbSAnLi90eXBlcy5qcyc7XG5cbmNvbnN0IGluZGV4ID0gei5udW1iZXIoKS5pbnQoKS5taW4oMCkubWF4KDB4ZmZmZmZmZmYpO1xuY29uc3QgcG9zaXRpb24gPSB6XG4gIC5udW1iZXIoKVxuICAuaW50KClcbiAgLm1pbigwKVxuICAubWF4KEJMT0NLX1JPV1MgKiBCTE9DS19DT0xVTU5TIC0gMSk7XG5jb25zdCBjb2x1bW4gPSA8VCBleHRlbmRzIHouWm9kVHlwZT4odmFsdWU6IFQpID0+XG4gIHoub2JqZWN0KHsgcG9zaXRpb25zOiB6LmFycmF5KHBvc2l0aW9uKS5tYXgoMjA0OCksIHZhbHVlczogei5hcnJheSh2YWx1ZSkubWF4KDIwNDgpIH0pLnN0cmljdCgpO1xuY29uc3QgZmlsZVNjYWxhclNjaGVtYSA9IHouZGlzY3JpbWluYXRlZFVuaW9uKCd0eXBlJywgW1xuICBzY2FsYXJTY2hlbWEub3B0aW9uc1swXS5zdHJpY3QoKSxcbiAgc2NhbGFyU2NoZW1hLm9wdGlvbnNbMV0uc3RyaWN0KCksXG4gIHNjYWxhclNjaGVtYS5vcHRpb25zWzJdLnN0cmljdCgpLFxuICBzY2FsYXJTY2hlbWEub3B0aW9uc1szXS5zdHJpY3QoKSxcbiAgc2NhbGFyU2NoZW1hLm9wdGlvbnNbNF0uc3RyaWN0KCksXG5dKTtcbmNvbnN0IGF4aXNTY2hlbWEgPSB6XG4gIC5vYmplY3Qoe1xuICAgIG5leHRJZDogei5udW1iZXIoKS5pbnQoKS5taW4oMSkubWF4KDB4MTAwMDAwMDAwKSxcbiAgICBvcmRlcjogelxuICAgICAgLmFycmF5KFxuICAgICAgICB6LnR1cGxlKFtcbiAgICAgICAgICBpbmRleCxcbiAgICAgICAgICB6Lm51bWJlcigpLmludCgpLnBvc2l0aXZlKCkubWF4KExJTUlUUy5yb3dzKSxcbiAgICAgICAgICB6LnVuaW9uKFt6LmxpdGVyYWwoMSksIHoubGl0ZXJhbCgtMSldKSxcbiAgICAgICAgXSksXG4gICAgICApXG4gICAgICAubWF4KExJTUlUUy5yb3dzKSxcbiAgICBtZXRhOiB6LnJlY29yZCh6LnN0cmluZygpLCBzaGVldFNjaGVtYS5zaGFwZS5yb3dzLnZhbHVlVHlwZS5zdHJpY3QoKSkub3B0aW9uYWwoKSxcbiAgfSlcbiAgLnN0cmljdCgpO1xuZXhwb3J0IGNvbnN0IGZpbGVCbG9ja0RhdGFTY2hlbWEgPSB6XG4gIC5vYmplY3Qoe1xuICAgIG51bWJlcnM6IGNvbHVtbih6Lm51bWJlcigpLmZpbml0ZSgpKS5vcHRpb25hbCgpLFxuICAgIG5lZ2F0aXZlWmVybzogei5hcnJheShwb3NpdGlvbikubWF4KDIwNDgpLm9wdGlvbmFsKCksXG4gICAgc3RyaW5nczogY29sdW1uKHouc3RyaW5nKCkubWF4KExJTUlUUy50ZXh0KSkub3B0aW9uYWwoKSxcbiAgICBib29sZWFuczogY29sdW1uKHouYm9vbGVhbigpKS5vcHRpb25hbCgpLFxuICAgIGZvcm11bGFzOiBjb2x1bW4oei5zdHJpbmcoKS5taW4oMSkubWF4KExJTUlUUy50ZXh0KSkub3B0aW9uYWwoKSxcbiAgICBlcnJvcnM6IGNvbHVtbih6LnN0cmluZygpLm1heCg1MCkpLm9wdGlvbmFsKCksXG4gICAgYmxhbmtzOiB6LmFycmF5KHBvc2l0aW9uKS5tYXgoMjA0OCkub3B0aW9uYWwoKSxcbiAgICBzdHlsZXM6IHpcbiAgICAgIC5hcnJheSh6LnR1cGxlKFtwb3NpdGlvbiwgei5udW1iZXIoKS5pbnQoKS5wb3NpdGl2ZSgpLm1heCgyMDQ4KSwgaW5kZXhdKSlcbiAgICAgIC5tYXgoMjA0OClcbiAgICAgIC5vcHRpb25hbCgpLFxuICAgIG5vdGVzOiBjb2x1bW4oY2VsbFNjaGVtYS5zaGFwZS5ub3RlLnVud3JhcCgpKS5vcHRpb25hbCgpLFxuICAgIGxpbmtzOiBjb2x1bW4oY2VsbFNjaGVtYS5zaGFwZS5saW5rLnVud3JhcCgpKS5vcHRpb25hbCgpLFxuICAgIGZvcm1hdHM6IGNvbHVtbihjZWxsU2NoZW1hLnNoYXBlLm51bWJlckZvcm1hdC51bndyYXAoKSkub3B0aW9uYWwoKSxcbiAgICBjYWNoZWQ6IGNvbHVtbihmaWxlU2NhbGFyU2NoZW1hKS5vcHRpb25hbCgpLFxuICAgIGNhY2hlZE5lZ2F0aXZlWmVybzogei5hcnJheShwb3NpdGlvbikubWF4KDIwNDgpLm9wdGlvbmFsKCksXG4gIH0pXG4gIC5zdHJpY3QoKTtcbmV4cG9ydCBjb25zdCBmaWxlQmxvY2tTY2hlbWEgPSB6XG4gIC5vYmplY3QoeyByb3c6IGluZGV4LCBjb2x1bW46IGluZGV4LCBkYXRhOiBmaWxlQmxvY2tEYXRhU2NoZW1hIH0pXG4gIC5zdHJpY3QoKTtcbmNvbnN0IGZpbGVTaGVldFNjaGVtYSA9IHNoZWV0U2NoZW1hXG4gIC5vbWl0KHtcbiAgICByb3dPcmRlcjogdHJ1ZSxcbiAgICBjb2x1bW5PcmRlcjogdHJ1ZSxcbiAgICBuZXh0Um93SWQ6IHRydWUsXG4gICAgbmV4dENvbHVtbklkOiB0cnVlLFxuICAgIHJvd3M6IHRydWUsXG4gICAgY29sdW1uczogdHJ1ZSxcbiAgICBjZWxsczogdHJ1ZSxcbiAgfSlcbiAgLmV4dGVuZCh7XG4gICAgcm93czogYXhpc1NjaGVtYSxcbiAgICBjb2x1bW5zOiBheGlzU2NoZW1hLFxuICAgIGZyZWV6ZTogc2hlZXRTY2hlbWEuc2hhcGUuZnJlZXplLnN0cmljdCgpLFxuICAgIGJsb2Nrczogei5hcnJheShmaWxlQmxvY2tTY2hlbWEpLFxuICB9KVxuICAuc3RyaWN0KCk7XG5leHBvcnQgY29uc3Qgd29ya2Jvb2tGaWxlU2NoZW1hID0gc25hcHNob3RTY2hlbWFcbiAgLm9taXQoeyBzaGVldHM6IHRydWUsIHN0eWxlczogdHJ1ZSwgc2hlZXRPcmRlcjogdHJ1ZSB9KVxuICAuZXh0ZW5kKHtcbiAgICBzY2hlbWFWZXJzaW9uOiB6LmxpdGVyYWwoMyksXG4gICAgc2hlZXRzOiB6LmFycmF5KGZpbGVTaGVldFNjaGVtYSkubWluKDEpLm1heChMSU1JVFMuc2hlZXRzKSxcbiAgICBzdHlsZXM6IHouYXJyYXkoc3R5bGVTY2hlbWEuc3RyaWN0KCkpLFxuICB9KVxuICAuc3RyaWN0KCk7XG5leHBvcnQgdHlwZSBXb3JrYm9va0ZpbGUgPSB6LmluZmVyPHR5cGVvZiB3b3JrYm9va0ZpbGVTY2hlbWE+O1xuZXhwb3J0IHR5cGUgRmlsZUJsb2NrID0gei5pbmZlcjx0eXBlb2YgZmlsZUJsb2NrU2NoZW1hPjtcbmV4cG9ydCB0eXBlIEZpbGVCbG9ja0RhdGEgPSB6LmluZmVyPHR5cGVvZiBmaWxlQmxvY2tEYXRhU2NoZW1hPjtcbmV4cG9ydCB0eXBlIEZpbGVBeGlzID0gei5pbmZlcjx0eXBlb2YgYXhpc1NjaGVtYT47XG5cbmV4cG9ydCBmdW5jdGlvbiBlbmNvZGVBeGlzKFxuICBpZHM6IHJlYWRvbmx5IG51bWJlcltdLFxuICBuZXh0SWQ6IG51bWJlcixcbiAgbWV0YTogUmVjb3JkPHN0cmluZywgeyBzaXplPzogbnVtYmVyOyBoaWRkZW4/OiBib29sZWFuIH0+ID0ge30sXG4pOiBGaWxlQXhpcyB7XG4gIGNvbnN0IG9yZGVyOiBGaWxlQXhpc1snb3JkZXInXSA9IFtdO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGlkcy5sZW5ndGg7ICkge1xuICAgIGNvbnN0IHN0ZXAgPSBpZHNbaSArIDFdID09PSBpZHNbaV0gLSAxID8gLTEgOiAxO1xuICAgIGxldCBlbmQgPSBpICsgMTtcbiAgICB3aGlsZSAoZW5kIDwgaWRzLmxlbmd0aCAmJiBpZHNbZW5kXSA9PT0gaWRzW2ldICsgc3RlcCAqIChlbmQgLSBpKSkgZW5kKys7XG4gICAgb3JkZXIucHVzaChbaWRzW2ldLCBlbmQgLSBpLCBzdGVwXSk7XG4gICAgaSA9IGVuZDtcbiAgfVxuICByZXR1cm4geyBuZXh0SWQsIG9yZGVyLCAuLi4oT2JqZWN0LmtleXMobWV0YSkubGVuZ3RoID8geyBtZXRhIH0gOiB7fSkgfTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBkZWNvZGVBeGlzKGF4aXM6IEZpbGVBeGlzLCBsaW1pdDogbnVtYmVyKTogbnVtYmVyW10ge1xuICBjb25zdCBpZHM6IG51bWJlcltdID0gW10sXG4gICAgc2VlbiA9IG5ldyBTZXQ8bnVtYmVyPigpO1xuICBmb3IgKGNvbnN0IFtzdGFydCwgY291bnQsIHN0ZXBdIG9mIGF4aXMub3JkZXIpIHtcbiAgICBhc3NlcnQoaWRzLmxlbmd0aCArIGNvdW50IDw9IGxpbWl0LCAnTElNSVRfRVhDRUVERUQnLCAnQXhpcyBleGNlZWRzIGRpbWVuc2lvbiBsaW1pdCcpO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY291bnQ7IGkrKykge1xuICAgICAgY29uc3QgaWQgPSBzdGFydCArIGkgKiBzdGVwO1xuICAgICAgYXNzZXJ0KFxuICAgICAgICBpZCA+PSAwICYmIGlkIDwgYXhpcy5uZXh0SWQgJiYgIXNlZW4uaGFzKGlkKSxcbiAgICAgICAgJ0lOVkFMSURfQVJHVU1FTlQnLFxuICAgICAgICAnSW52YWxpZCBvciBkdXBsaWNhdGUgYXhpcyBpZGVudGl0eScsXG4gICAgICApO1xuICAgICAgc2Vlbi5hZGQoaWQpO1xuICAgICAgaWRzLnB1c2goaWQpO1xuICAgIH1cbiAgfVxuICBhc3NlcnQoaWRzLmxlbmd0aCA+IDAsICdJTlZBTElEX0FSR1VNRU5UJywgJ0VtcHR5IGF4aXMnKTtcbiAgZm9yIChjb25zdCBpZCBvZiBPYmplY3Qua2V5cyhheGlzLm1ldGEgPz8ge30pKVxuICAgIGFzc2VydCgvXigwfFsxLTldXFxkKikkLy50ZXN0KGlkKSAmJiBzZWVuLmhhcygraWQpLCAnSU5WQUxJRF9BUkdVTUVOVCcsICdVbmtub3duIGF4aXMgbWV0YWRhdGEnKTtcbiAgcmV0dXJuIGlkcztcbn1cbmNvbnN0IGlucHV0Q29sdW1ucyA9IHtcbiAgbnVtYmVyOiAnbnVtYmVycycsXG4gIHN0cmluZzogJ3N0cmluZ3MnLFxuICBib29sZWFuOiAnYm9vbGVhbnMnLFxuICBmb3JtdWxhOiAnZm9ybXVsYXMnLFxuICBlcnJvcjogJ2Vycm9ycycsXG59IGFzIGNvbnN0O1xuLyoqIEEgc2luZ2xlIGJsb2NrIGNvbnZlcnNpb24gaXMgc2hhcmVkIGJ5IG9iamVjdCBhbmQgc3RyZWFtaW5nIGV4cG9ydHMuICovXG5leHBvcnQgZnVuY3Rpb24gZW5jb2RlRmlsZUNlbGxzKFxuICBjZWxsczogSXRlcmFibGU8Q2VsbFJlY29yZD4sXG4gIHN0eWxlczogTWFwPHN0cmluZywgbnVtYmVyPixcbiAga2VlcENhY2hlZCA9IHRydWUsXG4pOiBGaWxlQmxvY2tEYXRhIHtcbiAgY29uc3QgZGF0YTogRmlsZUJsb2NrRGF0YSA9IHt9O1xuICBjb25zdCBhcHBlbmQgPSAobmFtZTogc3RyaW5nLCBvZmZzZXQ6IG51bWJlciwgdmFsdWU6IHVua25vd24pID0+IHtcbiAgICBjb25zdCBjb2wgPSAoKGRhdGEgYXMgYW55KVtuYW1lXSA/Pz0geyBwb3NpdGlvbnM6IFtdLCB2YWx1ZXM6IFtdIH0pO1xuICAgIGNvbC5wb3NpdGlvbnMucHVzaChvZmZzZXQpO1xuICAgIGNvbC52YWx1ZXMucHVzaCh2YWx1ZSk7XG4gIH07XG4gIGxldCBydW46IFtudW1iZXIsIG51bWJlciwgbnVtYmVyXSB8IHVuZGVmaW5lZDtcbiAgZm9yIChjb25zdCBjZWxsIG9mIFsuLi5jZWxsc10uc29ydChcbiAgICAoYSwgYikgPT4gKGEucm93SWQgJSA2NCkgKiAzMiArIChhLmNvbHVtbklkICUgMzIpIC0gKGIucm93SWQgJSA2NCkgKiAzMiAtIChiLmNvbHVtbklkICUgMzIpLFxuICApKSB7XG4gICAgY29uc3Qgb2Zmc2V0ID0gKGNlbGwucm93SWQgJSBCTE9DS19ST1dTKSAqIEJMT0NLX0NPTFVNTlMgKyAoY2VsbC5jb2x1bW5JZCAlIEJMT0NLX0NPTFVNTlMpO1xuICAgIGNvbnN0IGlucHV0ID0gY2VsbC5pbnB1dDtcbiAgICBpZiAoaW5wdXQudHlwZSA9PT0gJ2JsYW5rJykgKGRhdGEuYmxhbmtzID8/PSBbXSkucHVzaChvZmZzZXQpO1xuICAgIGVsc2VcbiAgICAgIGFwcGVuZChcbiAgICAgICAgaW5wdXRDb2x1bW5zW2lucHV0LnR5cGVdLFxuICAgICAgICBvZmZzZXQsXG4gICAgICAgICd2YWx1ZScgaW4gaW5wdXRcbiAgICAgICAgICA/IGlucHV0LnR5cGUgPT09ICdudW1iZXInICYmIE9iamVjdC5pcyhpbnB1dC52YWx1ZSwgLTApXG4gICAgICAgICAgICA/IDBcbiAgICAgICAgICAgIDogaW5wdXQudmFsdWVcbiAgICAgICAgICA6IGlucHV0LnR5cGUgPT09ICdmb3JtdWxhJ1xuICAgICAgICAgICAgPyBpbnB1dC5leHByZXNzaW9uXG4gICAgICAgICAgICA6IGlucHV0LmNvZGUsXG4gICAgICApO1xuICAgIGlmIChpbnB1dC50eXBlID09PSAnbnVtYmVyJyAmJiBPYmplY3QuaXMoaW5wdXQudmFsdWUsIC0wKSlcbiAgICAgIChkYXRhLm5lZ2F0aXZlWmVybyA/Pz0gW10pLnB1c2gob2Zmc2V0KTtcbiAgICBpZiAoY2VsbC5zdHlsZUlkICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIGNvbnN0IHN0eWxlID0gc3R5bGVzLmdldChjZWxsLnN0eWxlSWQpO1xuICAgICAgYXNzZXJ0KHN0eWxlICE9PSB1bmRlZmluZWQsICdJTlZBTElEX0FSR1VNRU5UJywgJ1Vua25vd24gc3R5bGUnKTtcbiAgICAgIGlmIChydW4gJiYgcnVuWzBdICsgcnVuWzFdID09PSBvZmZzZXQgJiYgcnVuWzJdID09PSBzdHlsZSkgcnVuWzFdKys7XG4gICAgICBlbHNlIHtcbiAgICAgICAgcnVuID0gW29mZnNldCwgMSwgc3R5bGVdO1xuICAgICAgICAoZGF0YS5zdHlsZXMgPz89IFtdKS5wdXNoKHJ1bik7XG4gICAgICB9XG4gICAgfSBlbHNlIHJ1biA9IHVuZGVmaW5lZDtcbiAgICBpZiAoY2VsbC5ub3RlICE9PSB1bmRlZmluZWQpIGFwcGVuZCgnbm90ZXMnLCBvZmZzZXQsIGNlbGwubm90ZSk7XG4gICAgaWYgKGNlbGwubGluayAhPT0gdW5kZWZpbmVkKSBhcHBlbmQoJ2xpbmtzJywgb2Zmc2V0LCBjZWxsLmxpbmspO1xuICAgIGlmIChjZWxsLm51bWJlckZvcm1hdCAhPT0gdW5kZWZpbmVkKSBhcHBlbmQoJ2Zvcm1hdHMnLCBvZmZzZXQsIGNlbGwubnVtYmVyRm9ybWF0KTtcbiAgICBpZiAoa2VlcENhY2hlZCAmJiBjZWxsLmNhY2hlZCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICBhcHBlbmQoXG4gICAgICAgICdjYWNoZWQnLFxuICAgICAgICBvZmZzZXQsXG4gICAgICAgIGNlbGwuY2FjaGVkLnR5cGUgPT09ICdudW1iZXInICYmIE9iamVjdC5pcyhjZWxsLmNhY2hlZC52YWx1ZSwgLTApXG4gICAgICAgICAgPyB7IC4uLmNlbGwuY2FjaGVkLCB2YWx1ZTogMCB9XG4gICAgICAgICAgOiBjZWxsLmNhY2hlZCxcbiAgICAgICk7XG4gICAgICBpZiAoY2VsbC5jYWNoZWQudHlwZSA9PT0gJ251bWJlcicgJiYgT2JqZWN0LmlzKGNlbGwuY2FjaGVkLnZhbHVlLCAtMCkpXG4gICAgICAgIChkYXRhLmNhY2hlZE5lZ2F0aXZlWmVybyA/Pz0gW10pLnB1c2gob2Zmc2V0KTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGRhdGE7XG59XG5leHBvcnQgZnVuY3Rpb24gZGVjb2RlRmlsZUNlbGxzKFxuICBibG9jazogRmlsZUJsb2NrLFxuICBzdHlsZXM6IHJlYWRvbmx5IHN0cmluZ1tdLFxuICByb3dzPzogU2V0PG51bWJlcj4sXG4gIGNvbHVtbnM/OiBTZXQ8bnVtYmVyPixcbiAgc3BhcnNlID0gZmFsc2UsXG4pOiBSZWNvcmQ8c3RyaW5nLCBDZWxsUmVjb3JkPiB7XG4gIGxldCB0ZXh0Qnl0ZXMgPSAwO1xuICBmb3IgKGNvbnN0IGNvbCBvZiBPYmplY3QudmFsdWVzKGJsb2NrPy5kYXRhID8/IHt9KSkge1xuICAgIGlmIChjb2wgJiYgdHlwZW9mIGNvbCA9PT0gJ29iamVjdCcgJiYgJ3ZhbHVlcycgaW4gY29sICYmIEFycmF5LmlzQXJyYXkoY29sLnZhbHVlcykpIHtcbiAgICAgIGZvciAoY29uc3QgdmFsdWUgb2YgY29sLnZhbHVlcykge1xuICAgICAgICBpZiAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJykgdGV4dEJ5dGVzICs9IHZhbHVlLmxlbmd0aCAqIDM7XG4gICAgICAgIGVsc2UgaWYgKHZhbHVlICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcpIHRleHRCeXRlcyArPSBKU09OLnN0cmluZ2lmeSh2YWx1ZSkubGVuZ3RoICogMztcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgYXNzZXJ0KFxuICAgIHRleHRCeXRlcyA8PSAzMiAqIDEwMjQgKiAxMDI0LFxuICAgICdMSU1JVF9FWENFRURFRCcsXG4gICAgJ1BhZ2UgdGV4dCBleGNlZWRzIDMyIE1pQiB3b3JraW5nIGJ1ZGdldCcsXG4gICk7XG4gIGNvbnN0IHBhcnNlZCA9IGZpbGVCbG9ja1NjaGVtYS5zYWZlUGFyc2UoYmxvY2spO1xuICBhc3NlcnQocGFyc2VkLnN1Y2Nlc3MsICdJTlZBTElEX0FSR1VNRU5UJywgJ0ludmFsaWQgZGF0YSBibG9jaycpO1xuICBjb25zdCB7IHJvdywgY29sdW1uLCBkYXRhIH0gPSBwYXJzZWQuZGF0YTtcbiAgYXNzZXJ0KFxuICAgIHJvdyA8PSBNYXRoLmZsb29yKDB4ZmZmZmZmZmYgLyA2NCkgJiYgY29sdW1uIDw9IE1hdGguZmxvb3IoMHhmZmZmZmZmZiAvIDMyKSxcbiAgICAnSU5WQUxJRF9BUkdVTUVOVCcsXG4gICAgJ0Jsb2NrIG91dHNpZGUgaWRlbnRpdHkgc3BhY2UnLFxuICApO1xuICBjb25zdCBjZWxscyA9IG5ldyBNYXA8bnVtYmVyLCBDZWxsUmVjb3JkPigpO1xuICBjb25zdCBjcmVhdGUgPSAob2Zmc2V0OiBudW1iZXIsIGlucHV0OiBDZWxsSW5wdXQpID0+IHtcbiAgICBjb25zdCByb3dJZCA9IHJvdyAqIDY0ICsgTWF0aC5mbG9vcihvZmZzZXQgLyAzMiksXG4gICAgICBjb2x1bW5JZCA9IGNvbHVtbiAqIDMyICsgKG9mZnNldCAlIDMyKTtcbiAgICBhc3NlcnQoXG4gICAgICAhY2VsbHMuaGFzKG9mZnNldCkgJiYgKCFyb3dzIHx8IHJvd3MuaGFzKHJvd0lkKSkgJiYgKCFjb2x1bW5zIHx8IGNvbHVtbnMuaGFzKGNvbHVtbklkKSksXG4gICAgICAnSU5WQUxJRF9BUkdVTUVOVCcsXG4gICAgICAnRHVwbGljYXRlIG9yIG91dC1vZi1heGlzIGNlbGwnLFxuICAgICk7XG4gICAgY29uc3QgY2VsbCA9IHsgcm93SWQsIGNvbHVtbklkLCBpbnB1dCB9O1xuICAgIGNlbGxzLnNldChvZmZzZXQsIGNlbGwpO1xuICAgIHJldHVybiBjZWxsO1xuICB9O1xuICBmb3IgKGNvbnN0IFt0eXBlLCBuYW1lXSBvZiBPYmplY3QuZW50cmllcyhpbnB1dENvbHVtbnMpKSB7XG4gICAgY29uc3QgY29sID0gKGRhdGEgYXMgYW55KVtuYW1lXTtcbiAgICBpZiAoIWNvbCkgY29udGludWU7XG4gICAgYXNzZXJ0KGNvbC5wb3NpdGlvbnMubGVuZ3RoID09PSBjb2wudmFsdWVzLmxlbmd0aCwgJ0lOVkFMSURfQVJHVU1FTlQnLCAnQ29sdW1uIGxlbmd0aHMgZGlmZmVyJyk7XG4gICAgY29sLnBvc2l0aW9ucy5mb3JFYWNoKChvZmZzZXQ6IG51bWJlciwgaTogbnVtYmVyKSA9PlxuICAgICAgY3JlYXRlKFxuICAgICAgICBvZmZzZXQsXG4gICAgICAgIHR5cGUgPT09ICdmb3JtdWxhJ1xuICAgICAgICAgID8geyB0eXBlLCBleHByZXNzaW9uOiBjb2wudmFsdWVzW2ldIH1cbiAgICAgICAgICA6IHR5cGUgPT09ICdlcnJvcidcbiAgICAgICAgICAgID8geyB0eXBlLCBjb2RlOiBjb2wudmFsdWVzW2ldIH1cbiAgICAgICAgICAgIDogKHsgdHlwZSwgdmFsdWU6IGNvbC52YWx1ZXNbaV0gfSBhcyBDZWxsSW5wdXQpLFxuICAgICAgKSxcbiAgICApO1xuICB9XG4gIGZvciAoY29uc3Qgb2Zmc2V0IG9mIGRhdGEuYmxhbmtzID8/IFtdKSBjcmVhdGUob2Zmc2V0LCB7IHR5cGU6ICdibGFuaycgfSk7XG4gIGNvbnN0IHplcm8gPSAocG9zaXRpb25zOiBudW1iZXJbXSB8IHVuZGVmaW5lZCwgY2FjaGVkOiBib29sZWFuKSA9PiB7XG4gICAgY29uc3Qgc2VlbiA9IG5ldyBTZXQ8bnVtYmVyPigpO1xuICAgIGZvciAoY29uc3Qgb2Zmc2V0IG9mIHBvc2l0aW9ucyA/PyBbXSkge1xuICAgICAgY29uc3QgaW5wdXQgPSBjYWNoZWQgPyBjZWxscy5nZXQob2Zmc2V0KT8uY2FjaGVkIDogY2VsbHMuZ2V0KG9mZnNldCk/LmlucHV0O1xuICAgICAgYXNzZXJ0KFxuICAgICAgICBpbnB1dD8udHlwZSA9PT0gJ251bWJlcicgJiYgaW5wdXQudmFsdWUgPT09IDAgJiYgIXNlZW4uaGFzKG9mZnNldCksXG4gICAgICAgICdJTlZBTElEX0FSR1VNRU5UJyxcbiAgICAgICAgJ0ludmFsaWQgbmVnYXRpdmUgemVybycsXG4gICAgICApO1xuICAgICAgaW5wdXQudmFsdWUgPSAtMDtcbiAgICAgIHNlZW4uYWRkKG9mZnNldCk7XG4gICAgfVxuICB9O1xuICBjb25zdCBzdHlsZWQgPSBuZXcgU2V0PG51bWJlcj4oKTtcbiAgZm9yIChjb25zdCBbc3RhcnQsIGNvdW50LCBpbmRleF0gb2YgZGF0YS5zdHlsZXMgPz8gW10pIHtcbiAgICBhc3NlcnQoXG4gICAgICBzdHlsZXNbaW5kZXhdICE9PSB1bmRlZmluZWQgJiYgc3RhcnQgKyBjb3VudCA8PSAyMDQ4LFxuICAgICAgJ0lOVkFMSURfQVJHVU1FTlQnLFxuICAgICAgJ0ludmFsaWQgc3R5bGUgcmFuZ2UnLFxuICAgICk7XG4gICAgZm9yIChsZXQgb2Zmc2V0ID0gc3RhcnQ7IG9mZnNldCA8IHN0YXJ0ICsgY291bnQ7IG9mZnNldCsrKSB7XG4gICAgICBhc3NlcnQoXG4gICAgICAgIGNlbGxzLmhhcyhvZmZzZXQpICYmICFzdHlsZWQuaGFzKG9mZnNldCksXG4gICAgICAgICdJTlZBTElEX0FSR1VNRU5UJyxcbiAgICAgICAgJ092ZXJsYXBwaW5nIG9yIG9ycGhhbiBzdHlsZScsXG4gICAgICApO1xuICAgICAgY2VsbHMuZ2V0KG9mZnNldCkhLnN0eWxlSWQgPSBzdHlsZXNbaW5kZXhdO1xuICAgICAgc3R5bGVkLmFkZChvZmZzZXQpO1xuICAgIH1cbiAgfVxuICBmb3IgKGNvbnN0IFtuYW1lLCBwcm9wZXJ0eV0gb2YgW1xuICAgIFsnbm90ZXMnLCAnbm90ZSddLFxuICAgIFsnbGlua3MnLCAnbGluayddLFxuICAgIFsnZm9ybWF0cycsICdudW1iZXJGb3JtYXQnXSxcbiAgICBbJ2NhY2hlZCcsICdjYWNoZWQnXSxcbiAgXSBhcyBjb25zdCkge1xuICAgIGNvbnN0IGNvbCA9IGRhdGFbbmFtZV0sXG4gICAgICBzZWVuID0gbmV3IFNldDxudW1iZXI+KCk7XG4gICAgaWYgKCFjb2wpIGNvbnRpbnVlO1xuICAgIGFzc2VydChjb2wucG9zaXRpb25zLmxlbmd0aCA9PT0gY29sLnZhbHVlcy5sZW5ndGgsICdJTlZBTElEX0FSR1VNRU5UJywgJ0NvbHVtbiBsZW5ndGhzIGRpZmZlcicpO1xuICAgIGNvbC5wb3NpdGlvbnMuZm9yRWFjaCgob2Zmc2V0LCBpKSA9PiB7XG4gICAgICBhc3NlcnQoXG4gICAgICAgIGNlbGxzLmhhcyhvZmZzZXQpICYmICFzZWVuLmhhcyhvZmZzZXQpLFxuICAgICAgICAnSU5WQUxJRF9BUkdVTUVOVCcsXG4gICAgICAgICdEdXBsaWNhdGUgb3Igb3JwaGFuIHByb3BlcnR5JyxcbiAgICAgICk7XG4gICAgICAoY2VsbHMuZ2V0KG9mZnNldCkhIGFzIGFueSlbcHJvcGVydHldID0gY29sLnZhbHVlc1tpXTtcbiAgICAgIHNlZW4uYWRkKG9mZnNldCk7XG4gICAgfSk7XG4gIH1cbiAgemVybyhkYXRhLm5lZ2F0aXZlWmVybywgZmFsc2UpO1xuICB6ZXJvKGRhdGEuY2FjaGVkTmVnYXRpdmVaZXJvLCB0cnVlKTtcbiAgY29uc3QgcmVzdWx0OiBSZWNvcmQ8c3RyaW5nLCBDZWxsUmVjb3JkPiA9IHt9O1xuICBmb3IgKGNvbnN0IGNlbGwgb2YgY2VsbHMudmFsdWVzKCkpIHtcbiAgICBpZiAoXG4gICAgICBzcGFyc2UgJiZcbiAgICAgIGNlbGwuaW5wdXQudHlwZSAhPT0gJ2Zvcm11bGEnICYmXG4gICAgICBjZWxsLmlucHV0LnR5cGUgIT09ICdibGFuaycgJiZcbiAgICAgIGNlbGwuc3R5bGVJZCA9PT0gdW5kZWZpbmVkICYmXG4gICAgICBjZWxsLm5vdGUgPT09IHVuZGVmaW5lZCAmJlxuICAgICAgY2VsbC5saW5rID09PSB1bmRlZmluZWQgJiZcbiAgICAgIGNlbGwubnVtYmVyRm9ybWF0ID09PSB1bmRlZmluZWQgJiZcbiAgICAgIGNlbGwuY2FjaGVkID09PSB1bmRlZmluZWRcbiAgICApXG4gICAgICBjb250aW51ZTtcbiAgICByZXN1bHRba2V5KGNlbGwucm93SWQsIGNlbGwuY29sdW1uSWQpXSA9IGNlbGw7XG4gIH1cbiAgcmV0dXJuIHJlc3VsdDtcbn1cbmV4cG9ydCBmdW5jdGlvbiBlbmNvZGVXb3JrYm9va0ZpbGUoc25hcHNob3Q6IFdvcmtib29rU25hcHNob3QpOiBXb3JrYm9va0ZpbGUge1xuICBjb25zdCBlbnRyaWVzID0gT2JqZWN0LmVudHJpZXMoc25hcHNob3Quc3R5bGVzKSxcbiAgICBzdHlsZUluZGljZXMgPSBuZXcgTWFwKGVudHJpZXMubWFwKChbaWRdLCBpKSA9PiBbaWQsIGldKSk7XG4gIHJldHVybiB7XG4gICAgc2NoZW1hVmVyc2lvbjogMyxcbiAgICB3b3JrYm9va0lkOiBzbmFwc2hvdC53b3JrYm9va0lkLFxuICAgIHJldmlzaW9uOiBzbmFwc2hvdC5yZXZpc2lvbixcbiAgICBkYXRlU3lzdGVtOiBzbmFwc2hvdC5kYXRlU3lzdGVtLFxuICAgIGV4dGVuc2lvbnM6IHNuYXBzaG90LmV4dGVuc2lvbnMsXG4gICAgc3R5bGVzOiBlbnRyaWVzLm1hcCgoWywgc3R5bGVdKSA9PiBzdHlsZSksXG4gICAgc2hlZXRzOiBzbmFwc2hvdC5zaGVldE9yZGVyXG4gICAgICAubWFwKChpZCkgPT4gc25hcHNob3Quc2hlZXRzLmZpbmQoKHNoZWV0KSA9PiBzaGVldC5pZCA9PT0gaWQpISlcbiAgICAgIC5tYXAoKHNoKSA9PiB7XG4gICAgICAgIGNvbnN0IHsgcm93T3JkZXIsIGNvbHVtbk9yZGVyLCBuZXh0Um93SWQsIG5leHRDb2x1bW5JZCwgcm93cywgY29sdW1ucywgY2VsbHMsIC4uLm1ldGEgfSA9XG4gICAgICAgICAgc2g7XG4gICAgICAgIGNvbnN0IGdyb3VwZWQgPSBuZXcgTWFwPHN0cmluZywgQ2VsbFJlY29yZFtdPigpO1xuICAgICAgICBmb3IgKGNvbnN0IGNlbGwgb2YgT2JqZWN0LnZhbHVlcyhjZWxscykpIHtcbiAgICAgICAgICBjb25zdCBhZGRyZXNzID0gYCR7TWF0aC5mbG9vcihjZWxsLnJvd0lkIC8gNjQpfS8ke01hdGguZmxvb3IoY2VsbC5jb2x1bW5JZCAvIDMyKX1gO1xuICAgICAgICAgIGlmICghZ3JvdXBlZC5oYXMoYWRkcmVzcykpIGdyb3VwZWQuc2V0KGFkZHJlc3MsIFtdKTtcbiAgICAgICAgICBncm91cGVkLmdldChhZGRyZXNzKSEucHVzaChjZWxsKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIC4uLm1ldGEsXG4gICAgICAgICAgcm93czogZW5jb2RlQXhpcyhyb3dPcmRlciwgbmV4dFJvd0lkLCByb3dzKSxcbiAgICAgICAgICBjb2x1bW5zOiBlbmNvZGVBeGlzKGNvbHVtbk9yZGVyLCBuZXh0Q29sdW1uSWQsIGNvbHVtbnMpLFxuICAgICAgICAgIGJsb2NrczogWy4uLmdyb3VwZWRdXG4gICAgICAgICAgICAubWFwKChbYWRkcmVzcywgY2VsbHNdKSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IFtyb3csIGNvbHVtbl0gPSBhZGRyZXNzLnNwbGl0KCcvJykubWFwKE51bWJlcik7XG4gICAgICAgICAgICAgIHJldHVybiB7IHJvdywgY29sdW1uLCBkYXRhOiBlbmNvZGVGaWxlQ2VsbHMoY2VsbHMsIHN0eWxlSW5kaWNlcykgfTtcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAuc29ydCgoYSwgYikgPT4gYS5yb3cgLSBiLnJvdyB8fCBhLmNvbHVtbiAtIGIuY29sdW1uKSxcbiAgICAgICAgfTtcbiAgICAgIH0pLFxuICB9O1xufVxuLyoqIE9ubHkgbWV0YWRhdGEgaXMgZXhwYW5kZWQ7IGltcG9ydCBwcm9jZXNzZXMgZWFjaCBwYWdlIGluZGVwZW5kZW50bHkuICovXG5leHBvcnQgZnVuY3Rpb24gZGVjb2RlRmlsZU1ldGFkYXRhKGlucHV0OiB1bmtub3duKTogV29ya2Jvb2tTbmFwc2hvdCB7XG4gIHZhbGlkYXRlSlNPTlZhbHVlKGlucHV0KTtcbiAgaWYgKGlucHV0ICYmIHR5cGVvZiBpbnB1dCA9PT0gJ29iamVjdCcgJiYgIUFycmF5LmlzQXJyYXkoaW5wdXQpKSB7XG4gICAgY29uc3QgY2FuZGlkYXRlID0gaW5wdXQgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgaWYgKFxuICAgICAgdHlwZW9mIGNhbmRpZGF0ZS5zY2hlbWFWZXJzaW9uID09PSAnbnVtYmVyJyAmJlxuICAgICAgTnVtYmVyLmlzU2FmZUludGVnZXIoY2FuZGlkYXRlLnNjaGVtYVZlcnNpb24pICYmXG4gICAgICB0eXBlb2YgY2FuZGlkYXRlLndvcmtib29rSWQgPT09ICdzdHJpbmcnICYmXG4gICAgICBBcnJheS5pc0FycmF5KGNhbmRpZGF0ZS5zaGVldHMpICYmXG4gICAgICBBcnJheS5pc0FycmF5KGNhbmRpZGF0ZS5zdHlsZXMpXG4gICAgKSB7XG4gICAgICBhc3NlcnQoXG4gICAgICAgIGNhbmRpZGF0ZS5zY2hlbWFWZXJzaW9uID09PSAzLFxuICAgICAgICAnVU5TVVBQT1JURURfVkVSU0lPTicsXG4gICAgICAgIGBXb3JrYm9vayBzY2hlbWEgJHtjYW5kaWRhdGUuc2NoZW1hVmVyc2lvbn0gaXMgdW5zdXBwb3J0ZWQ7IG9wZW4gaXQgd2l0aCBhIGNvbXBhdGlibGUgdmVyc2lvbiBhbmQgZXhwb3J0IGEgc2NoZW1hIDMgYmFja3VwYCxcbiAgICAgICk7XG4gICAgfVxuICB9XG4gIGNvbnN0IHBhcnNlZCA9IHdvcmtib29rRmlsZVNjaGVtYS5zYWZlUGFyc2UoaW5wdXQpO1xuICBhc3NlcnQocGFyc2VkLnN1Y2Nlc3MsICdJTlZBTElEX0FSR1VNRU5UJywgJ0ludmFsaWQgd29ya2Jvb2sgZmlsZSAoc2NoZW1hVmVyc2lvbiAzIHJlcXVpcmVkKScpO1xuICBjb25zdCBmaWxlID0gcGFyc2VkLmRhdGE7XG4gIHJldHVybiB2YWxpZGF0ZVNuYXBzaG90KHtcbiAgICAuLi5maWxlLFxuICAgIHNoZWV0T3JkZXI6IGZpbGUuc2hlZXRzLm1hcCgoc2gpID0+IHNoLmlkKSxcbiAgICBzdHlsZXM6IE9iamVjdC5mcm9tRW50cmllcyhmaWxlLnN0eWxlcy5tYXAoKHN0eWxlLCBpKSA9PiBbYHMke2l9YCwgc3R5bGVdKSksXG4gICAgc2hlZXRzOiBmaWxlLnNoZWV0cy5tYXAoKHNoKSA9PiAoe1xuICAgICAgLi4uc2gsXG4gICAgICByb3dPcmRlcjogZGVjb2RlQXhpcyhzaC5yb3dzLCBMSU1JVFMucm93cyksXG4gICAgICBjb2x1bW5PcmRlcjogZGVjb2RlQXhpcyhzaC5jb2x1bW5zLCBMSU1JVFMuY29sdW1ucyksXG4gICAgICBuZXh0Um93SWQ6IHNoLnJvd3MubmV4dElkLFxuICAgICAgbmV4dENvbHVtbklkOiBzaC5jb2x1bW5zLm5leHRJZCxcbiAgICAgIHJvd3M6IHNoLnJvd3MubWV0YSA/PyB7fSxcbiAgICAgIGNvbHVtbnM6IHNoLmNvbHVtbnMubWV0YSA/PyB7fSxcbiAgICAgIGNlbGxzOiB7fSxcbiAgICB9KSksXG4gIH0pO1xufVxuLyoqIEludGVybmFsIGFkYXB0ZXIgaGVscGVyOyBwdWJsaWMgbG9hZGluZyBkb2VzIG5vdCB1c2UgdGhpcyBtYXRlcmlhbGl6YXRpb24uICovXG5leHBvcnQgZnVuY3Rpb24gZGVjb2RlV29ya2Jvb2tGaWxlKGlucHV0OiB1bmtub3duKTogV29ya2Jvb2tTbmFwc2hvdCB7XG4gIGNvbnN0IGZpbGUgPSBpbnB1dCBhcyBXb3JrYm9va0ZpbGU7XG4gIGNvbnN0IHNuYXBzaG90ID0gZGVjb2RlRmlsZU1ldGFkYXRhKHtcbiAgICAuLi5maWxlLFxuICAgIHNoZWV0czogZmlsZS5zaGVldHM/Lm1hcCgoc2gpID0+ICh7IC4uLnNoLCBibG9ja3M6IFtdIH0pKSxcbiAgfSk7XG4gIGNvbnN0IHN0eWxlcyA9IE9iamVjdC5rZXlzKHNuYXBzaG90LnN0eWxlcyk7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgZmlsZS5zaGVldHMubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCBzaCA9IHNuYXBzaG90LnNoZWV0c1tpXSxcbiAgICAgIHJvd3MgPSBuZXcgU2V0KHNoLnJvd09yZGVyKSxcbiAgICAgIGNvbHVtbnMgPSBuZXcgU2V0KHNoLmNvbHVtbk9yZGVyKSxcbiAgICAgIHNlZW4gPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgICBmb3IgKGNvbnN0IGJsb2NrIG9mIGZpbGUuc2hlZXRzW2ldLmJsb2Nrcykge1xuICAgICAgYXNzZXJ0KGJsb2NrICYmIHR5cGVvZiBibG9jayA9PT0gJ29iamVjdCcsICdJTlZBTElEX0FSR1VNRU5UJywgJ0ludmFsaWQgZGF0YSBibG9jaycpO1xuICAgICAgY29uc3QgYWRkcmVzcyA9IGAke2Jsb2NrLnJvd30vJHtibG9jay5jb2x1bW59YDtcbiAgICAgIGFzc2VydCghc2Vlbi5oYXMoYWRkcmVzcyksICdJTlZBTElEX0FSR1VNRU5UJywgJ0R1cGxpY2F0ZSBibG9jaycpO1xuICAgICAgc2Vlbi5hZGQoYWRkcmVzcyk7XG4gICAgICBPYmplY3QuYXNzaWduKHNoLmNlbGxzLCBkZWNvZGVGaWxlQ2VsbHMoYmxvY2ssIHN0eWxlcywgcm93cywgY29sdW1ucykpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gc25hcHNob3Q7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVXb3JrYm9va0ZpbGUoXG4gIG9wdGlvbnM6IFBhcmFtZXRlcnM8dHlwZW9mIGltcG9ydCgnLi9tb2RlbC5qcycpLmNyZWF0ZVNuYXBzaG90PlswXSA9IHt9LFxuKTogV29ya2Jvb2tGaWxlIHtcbiAgcmV0dXJuIGVuY29kZVdvcmtib29rRmlsZShjcmVhdGVTbmFwc2hvdChvcHRpb25zKSk7XG59XG4vKiogSW50ZXJuYWwgaXRlcmF0b3I6IHRoZSBmaXJzdCBzdGVwIHZhbGlkYXRlcyBtZXRhZGF0YSwgdGhlbiBlYWNoIHN0ZXAgdmFsaWRhdGVzIG9uZSBwYWdlLiAqL1xuZXhwb3J0IGZ1bmN0aW9uKiB2YWxpZGF0ZVdvcmtib29rRmlsZVBhZ2VzKFxuICBpbnB1dDogdW5rbm93bixcbiAgb25NZXRhZGF0YT86IChmaWxlOiBXb3JrYm9va0ZpbGUpID0+IHZvaWQsXG4pOiBHZW5lcmF0b3I8eyBzaGVldEluZGV4OiBudW1iZXI7IGJsb2NrOiBGaWxlQmxvY2sgfSwgV29ya2Jvb2tGaWxlPiB7XG4gIGFzc2VydChcbiAgICBpbnB1dCAmJiB0eXBlb2YgaW5wdXQgPT09ICdvYmplY3QnICYmIEFycmF5LmlzQXJyYXkoKGlucHV0IGFzIFdvcmtib29rRmlsZSkuc2hlZXRzKSxcbiAgICAnSU5WQUxJRF9BUkdVTUVOVCcsXG4gICAgJ0ludmFsaWQgd29ya2Jvb2sgZmlsZScsXG4gICk7XG4gIGNvbnN0IGZpbGUgPSBpbnB1dCBhcyBXb3JrYm9va0ZpbGU7XG4gIGNvbnN0IG1ldGFkYXRhID0gZGVjb2RlRmlsZU1ldGFkYXRhKHtcbiAgICAuLi5maWxlLFxuICAgIHNoZWV0czogZmlsZS5zaGVldHMubWFwKChzaCkgPT4gKHsgLi4uc2gsIGJsb2NrczogW10gfSkpLFxuICB9KTtcbiAgb25NZXRhZGF0YT8uKGZpbGUpO1xuICBjb25zdCBzdHlsZXMgPSBPYmplY3Qua2V5cyhtZXRhZGF0YS5zdHlsZXMpO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGZpbGUuc2hlZXRzLmxlbmd0aDsgaSsrKSB7XG4gICAgY29uc3Qgc2ggPSBtZXRhZGF0YS5zaGVldHNbaV0sXG4gICAgICByb3dzID0gbmV3IFNldChzaC5yb3dPcmRlciksXG4gICAgICBjb2x1bW5zID0gbmV3IFNldChzaC5jb2x1bW5PcmRlciksXG4gICAgICBzZWVuID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gICAgYXNzZXJ0KEFycmF5LmlzQXJyYXkoZmlsZS5zaGVldHNbaV0uYmxvY2tzKSwgJ0lOVkFMSURfQVJHVU1FTlQnLCAnSW52YWxpZCBibG9ja3MnKTtcbiAgICBmb3IgKGNvbnN0IGJsb2NrIG9mIGZpbGUuc2hlZXRzW2ldLmJsb2Nrcykge1xuICAgICAgYXNzZXJ0KGJsb2NrICYmIHR5cGVvZiBibG9jayA9PT0gJ29iamVjdCcsICdJTlZBTElEX0FSR1VNRU5UJywgJ0ludmFsaWQgZGF0YSBibG9jaycpO1xuICAgICAgY29uc3QgYWRkcmVzcyA9IGAke2Jsb2NrLnJvd30vJHtibG9jay5jb2x1bW59YDtcbiAgICAgIGFzc2VydCghc2Vlbi5oYXMoYWRkcmVzcyksICdJTlZBTElEX0FSR1VNRU5UJywgJ0R1cGxpY2F0ZSBwYWdlJyk7XG4gICAgICBzZWVuLmFkZChhZGRyZXNzKTtcbiAgICAgIHZhbGlkYXRlSlNPTlZhbHVlKGJsb2NrKTtcbiAgICAgIGRlY29kZUZpbGVDZWxscyhibG9jaywgc3R5bGVzLCByb3dzLCBjb2x1bW5zKTtcbiAgICAgIHlpZWxkIHsgc2hlZXRJbmRleDogaSwgYmxvY2sgfTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGZpbGU7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB2YWxpZGF0ZVdvcmtib29rRmlsZShpbnB1dDogdW5rbm93bik6IFdvcmtib29rRmlsZSB7XG4gIGNvbnN0IHBhZ2VzID0gdmFsaWRhdGVXb3JrYm9va0ZpbGVQYWdlcyhpbnB1dCk7XG4gIGZvciAobGV0IHN0ZXAgPSBwYWdlcy5uZXh0KCk7IDsgc3RlcCA9IHBhZ2VzLm5leHQoKSkge1xuICAgIGlmIChzdGVwLmRvbmUpIHJldHVybiBzdGVwLnZhbHVlO1xuICB9XG59XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsU0FBUztBQUNsQixTQUFTLGdCQUFnQixrQkFBa0IseUJBQXlCO0FBQ3BFLFNBQVMsWUFBWSxxQkFBcUI7QUFDMUM7QUFBQSxFQUNFO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLE9BSUs7QUFFUCxNQUFNLFFBQVEsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxFQUFFLElBQUksVUFBVTtBQUNwRCxNQUFNLFdBQVcsRUFDZCxPQUFPLEVBQ1AsSUFBSSxFQUNKLElBQUksQ0FBQyxFQUNMLElBQUksYUFBYSxnQkFBZ0IsQ0FBQztBQUNyQyxNQUFNLFNBQVMsQ0FBc0IsVUFDbkMsRUFBRSxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0sUUFBUSxFQUFFLElBQUksSUFBSSxHQUFHLFFBQVEsRUFBRSxNQUFNLEtBQUssRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLEVBQUUsT0FBTztBQUNoRyxNQUFNLG1CQUFtQixFQUFFLG1CQUFtQixRQUFRO0FBQUEsRUFDcEQsYUFBYSxRQUFRLENBQUMsRUFBRSxPQUFPO0FBQUEsRUFDL0IsYUFBYSxRQUFRLENBQUMsRUFBRSxPQUFPO0FBQUEsRUFDL0IsYUFBYSxRQUFRLENBQUMsRUFBRSxPQUFPO0FBQUEsRUFDL0IsYUFBYSxRQUFRLENBQUMsRUFBRSxPQUFPO0FBQUEsRUFDL0IsYUFBYSxRQUFRLENBQUMsRUFBRSxPQUFPO0FBQ2pDLENBQUM7QUFDRCxNQUFNLGFBQWEsRUFDaEIsT0FBTztBQUFBLEVBQ04sUUFBUSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLEVBQUUsSUFBSSxVQUFXO0FBQUEsRUFDL0MsT0FBTyxFQUNKO0FBQUEsSUFDQyxFQUFFLE1BQU07QUFBQSxNQUNOO0FBQUEsTUFDQSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFLElBQUksT0FBTyxJQUFJO0FBQUEsTUFDM0MsRUFBRSxNQUFNLENBQUMsRUFBRSxRQUFRLENBQUMsR0FBRyxFQUFFLFFBQVEsRUFBRSxDQUFDLENBQUM7QUFBQSxJQUN2QyxDQUFDO0FBQUEsRUFDSCxFQUNDLElBQUksT0FBTyxJQUFJO0FBQUEsRUFDbEIsTUFBTSxFQUFFLE9BQU8sRUFBRSxPQUFPLEdBQUcsWUFBWSxNQUFNLEtBQUssVUFBVSxPQUFPLENBQUMsRUFBRSxTQUFTO0FBQ2pGLENBQUMsRUFDQSxPQUFPO0FBQ0gsYUFBTSxzQkFBc0IsRUFDaEMsT0FBTztBQUFBLEVBQ04sU0FBUyxPQUFPLEVBQUUsT0FBTyxFQUFFLE9BQU8sQ0FBQyxFQUFFLFNBQVM7QUFBQSxFQUM5QyxjQUFjLEVBQUUsTUFBTSxRQUFRLEVBQUUsSUFBSSxJQUFJLEVBQUUsU0FBUztBQUFBLEVBQ25ELFNBQVMsT0FBTyxFQUFFLE9BQU8sRUFBRSxJQUFJLE9BQU8sSUFBSSxDQUFDLEVBQUUsU0FBUztBQUFBLEVBQ3RELFVBQVUsT0FBTyxFQUFFLFFBQVEsQ0FBQyxFQUFFLFNBQVM7QUFBQSxFQUN2QyxVQUFVLE9BQU8sRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLEVBQUUsSUFBSSxPQUFPLElBQUksQ0FBQyxFQUFFLFNBQVM7QUFBQSxFQUM5RCxRQUFRLE9BQU8sRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxTQUFTO0FBQUEsRUFDNUMsUUFBUSxFQUFFLE1BQU0sUUFBUSxFQUFFLElBQUksSUFBSSxFQUFFLFNBQVM7QUFBQSxFQUM3QyxRQUFRLEVBQ0wsTUFBTSxFQUFFLE1BQU0sQ0FBQyxVQUFVLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsSUFBSSxJQUFJLEdBQUcsS0FBSyxDQUFDLENBQUMsRUFDdkUsSUFBSSxJQUFJLEVBQ1IsU0FBUztBQUFBLEVBQ1osT0FBTyxPQUFPLFdBQVcsTUFBTSxLQUFLLE9BQU8sQ0FBQyxFQUFFLFNBQVM7QUFBQSxFQUN2RCxPQUFPLE9BQU8sV0FBVyxNQUFNLEtBQUssT0FBTyxDQUFDLEVBQUUsU0FBUztBQUFBLEVBQ3ZELFNBQVMsT0FBTyxXQUFXLE1BQU0sYUFBYSxPQUFPLENBQUMsRUFBRSxTQUFTO0FBQUEsRUFDakUsUUFBUSxPQUFPLGdCQUFnQixFQUFFLFNBQVM7QUFBQSxFQUMxQyxvQkFBb0IsRUFBRSxNQUFNLFFBQVEsRUFBRSxJQUFJLElBQUksRUFBRSxTQUFTO0FBQzNELENBQUMsRUFDQSxPQUFPO0FBQ0gsYUFBTSxrQkFBa0IsRUFDNUIsT0FBTyxFQUFFLEtBQUssT0FBTyxRQUFRLE9BQU8sTUFBTSxvQkFBb0IsQ0FBQyxFQUMvRCxPQUFPO0FBQ1YsTUFBTSxrQkFBa0IsWUFDckIsS0FBSztBQUFBLEVBQ0osVUFBVTtBQUFBLEVBQ1YsYUFBYTtBQUFBLEVBQ2IsV0FBVztBQUFBLEVBQ1gsY0FBYztBQUFBLEVBQ2QsTUFBTTtBQUFBLEVBQ04sU0FBUztBQUFBLEVBQ1QsT0FBTztBQUNULENBQUMsRUFDQSxPQUFPO0FBQUEsRUFDTixNQUFNO0FBQUEsRUFDTixTQUFTO0FBQUEsRUFDVCxRQUFRLFlBQVksTUFBTSxPQUFPLE9BQU87QUFBQSxFQUN4QyxRQUFRLEVBQUUsTUFBTSxlQUFlO0FBQ2pDLENBQUMsRUFDQSxPQUFPO0FBQ0gsYUFBTSxxQkFBcUIsZUFDL0IsS0FBSyxFQUFFLFFBQVEsTUFBTSxRQUFRLE1BQU0sWUFBWSxLQUFLLENBQUMsRUFDckQsT0FBTztBQUFBLEVBQ04sZUFBZSxFQUFFLFFBQVEsQ0FBQztBQUFBLEVBQzFCLFFBQVEsRUFBRSxNQUFNLGVBQWUsRUFBRSxJQUFJLENBQUMsRUFBRSxJQUFJLE9BQU8sTUFBTTtBQUFBLEVBQ3pELFFBQVEsRUFBRSxNQUFNLFlBQVksT0FBTyxDQUFDO0FBQ3RDLENBQUMsRUFDQSxPQUFPO0FBTUgsZ0JBQVMsV0FDZCxLQUNBLFFBQ0EsT0FBNEQsQ0FBQyxHQUNuRDtBQUNWLFFBQU0sUUFBMkIsQ0FBQztBQUNsQyxXQUFTLElBQUksR0FBRyxJQUFJLElBQUksVUFBVTtBQUNoQyxVQUFNLE9BQU8sSUFBSSxJQUFJLENBQUMsTUFBTSxJQUFJLENBQUMsSUFBSSxJQUFJLEtBQUs7QUFDOUMsUUFBSSxNQUFNLElBQUk7QUFDZCxXQUFPLE1BQU0sSUFBSSxVQUFVLElBQUksR0FBRyxNQUFNLElBQUksQ0FBQyxJQUFJLFFBQVEsTUFBTSxHQUFJO0FBQ25FLFVBQU0sS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLE1BQU0sR0FBRyxJQUFJLENBQUM7QUFDbEMsUUFBSTtBQUFBLEVBQ047QUFDQSxTQUFPLEVBQUUsUUFBUSxPQUFPLEdBQUksT0FBTyxLQUFLLElBQUksRUFBRSxTQUFTLEVBQUUsS0FBSyxJQUFJLENBQUMsRUFBRztBQUN4RTtBQUNPLGdCQUFTLFdBQVcsTUFBZ0IsT0FBeUI7QUFDbEUsUUFBTSxNQUFnQixDQUFDLEdBQ3JCLE9BQU8sb0JBQUksSUFBWTtBQUN6QixhQUFXLENBQUMsT0FBTyxPQUFPLElBQUksS0FBSyxLQUFLLE9BQU87QUFDN0MsV0FBTyxJQUFJLFNBQVMsU0FBUyxPQUFPLGtCQUFrQiw4QkFBOEI7QUFDcEYsYUFBUyxJQUFJLEdBQUcsSUFBSSxPQUFPLEtBQUs7QUFDOUIsWUFBTSxLQUFLLFFBQVEsSUFBSTtBQUN2QjtBQUFBLFFBQ0UsTUFBTSxLQUFLLEtBQUssS0FBSyxVQUFVLENBQUMsS0FBSyxJQUFJLEVBQUU7QUFBQSxRQUMzQztBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBQ0EsV0FBSyxJQUFJLEVBQUU7QUFDWCxVQUFJLEtBQUssRUFBRTtBQUFBLElBQ2I7QUFBQSxFQUNGO0FBQ0EsU0FBTyxJQUFJLFNBQVMsR0FBRyxvQkFBb0IsWUFBWTtBQUN2RCxhQUFXLE1BQU0sT0FBTyxLQUFLLEtBQUssUUFBUSxDQUFDLENBQUM7QUFDMUMsV0FBTyxpQkFBaUIsS0FBSyxFQUFFLEtBQUssS0FBSyxJQUFJLENBQUMsRUFBRSxHQUFHLG9CQUFvQix1QkFBdUI7QUFDaEcsU0FBTztBQUNUO0FBQ0EsTUFBTSxlQUFlO0FBQUEsRUFDbkIsUUFBUTtBQUFBLEVBQ1IsUUFBUTtBQUFBLEVBQ1IsU0FBUztBQUFBLEVBQ1QsU0FBUztBQUFBLEVBQ1QsT0FBTztBQUNUO0FBRU8sZ0JBQVMsZ0JBQ2QsT0FDQSxRQUNBLGFBQWEsTUFDRTtBQUNmLFFBQU0sT0FBc0IsQ0FBQztBQUM3QixRQUFNLFNBQVMsQ0FBQyxNQUFjLFFBQWdCLFVBQW1CO0FBQy9ELFVBQU0sTUFBUSxLQUFhLElBQUksTUFBTSxFQUFFLFdBQVcsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxFQUFFO0FBQ2pFLFFBQUksVUFBVSxLQUFLLE1BQU07QUFDekIsUUFBSSxPQUFPLEtBQUssS0FBSztBQUFBLEVBQ3ZCO0FBQ0EsTUFBSTtBQUNKLGFBQVcsUUFBUSxDQUFDLEdBQUcsS0FBSyxFQUFFO0FBQUEsSUFDNUIsQ0FBQyxHQUFHLE1BQU8sRUFBRSxRQUFRLEtBQU0sS0FBTSxFQUFFLFdBQVcsS0FBTyxFQUFFLFFBQVEsS0FBTSxLQUFNLEVBQUUsV0FBVztBQUFBLEVBQzFGLEdBQUc7QUFDRCxVQUFNLFNBQVUsS0FBSyxRQUFRLGFBQWMsZ0JBQWlCLEtBQUssV0FBVztBQUM1RSxVQUFNLFFBQVEsS0FBSztBQUNuQixRQUFJLE1BQU0sU0FBUyxRQUFTLEVBQUMsS0FBSyxXQUFXLENBQUMsR0FBRyxLQUFLLE1BQU07QUFBQTtBQUUxRDtBQUFBLFFBQ0UsYUFBYSxNQUFNLElBQUk7QUFBQSxRQUN2QjtBQUFBLFFBQ0EsV0FBVyxRQUNQLE1BQU0sU0FBUyxZQUFZLE9BQU8sR0FBRyxNQUFNLE9BQU8sRUFBRSxJQUNsRCxJQUNBLE1BQU0sUUFDUixNQUFNLFNBQVMsWUFDYixNQUFNLGFBQ04sTUFBTTtBQUFBLE1BQ2Q7QUFDRixRQUFJLE1BQU0sU0FBUyxZQUFZLE9BQU8sR0FBRyxNQUFNLE9BQU8sRUFBRTtBQUN0RCxPQUFDLEtBQUssaUJBQWlCLENBQUMsR0FBRyxLQUFLLE1BQU07QUFDeEMsUUFBSSxLQUFLLFlBQVksUUFBVztBQUM5QixZQUFNLFFBQVEsT0FBTyxJQUFJLEtBQUssT0FBTztBQUNyQyxhQUFPLFVBQVUsUUFBVyxvQkFBb0IsZUFBZTtBQUMvRCxVQUFJLE9BQU8sSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLE1BQU0sVUFBVSxJQUFJLENBQUMsTUFBTSxNQUFPLEtBQUksQ0FBQztBQUFBLFdBQzNEO0FBQ0gsY0FBTSxDQUFDLFFBQVEsR0FBRyxLQUFLO0FBQ3ZCLFNBQUMsS0FBSyxXQUFXLENBQUMsR0FBRyxLQUFLLEdBQUc7QUFBQSxNQUMvQjtBQUFBLElBQ0YsTUFBTyxPQUFNO0FBQ2IsUUFBSSxLQUFLLFNBQVMsT0FBVyxRQUFPLFNBQVMsUUFBUSxLQUFLLElBQUk7QUFDOUQsUUFBSSxLQUFLLFNBQVMsT0FBVyxRQUFPLFNBQVMsUUFBUSxLQUFLLElBQUk7QUFDOUQsUUFBSSxLQUFLLGlCQUFpQixPQUFXLFFBQU8sV0FBVyxRQUFRLEtBQUssWUFBWTtBQUNoRixRQUFJLGNBQWMsS0FBSyxXQUFXLFFBQVc7QUFDM0M7QUFBQSxRQUNFO0FBQUEsUUFDQTtBQUFBLFFBQ0EsS0FBSyxPQUFPLFNBQVMsWUFBWSxPQUFPLEdBQUcsS0FBSyxPQUFPLE9BQU8sRUFBRSxJQUM1RCxFQUFFLEdBQUcsS0FBSyxRQUFRLE9BQU8sRUFBRSxJQUMzQixLQUFLO0FBQUEsTUFDWDtBQUNBLFVBQUksS0FBSyxPQUFPLFNBQVMsWUFBWSxPQUFPLEdBQUcsS0FBSyxPQUFPLE9BQU8sRUFBRTtBQUNsRSxTQUFDLEtBQUssdUJBQXVCLENBQUMsR0FBRyxLQUFLLE1BQU07QUFBQSxJQUNoRDtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFDTyxnQkFBUyxnQkFDZCxPQUNBLFFBQ0EsTUFDQSxTQUNBLFNBQVMsT0FDbUI7QUFDNUIsTUFBSSxZQUFZO0FBQ2hCLGFBQVcsT0FBTyxPQUFPLE9BQU8sT0FBTyxRQUFRLENBQUMsQ0FBQyxHQUFHO0FBQ2xELFFBQUksT0FBTyxPQUFPLFFBQVEsWUFBWSxZQUFZLE9BQU8sTUFBTSxRQUFRLElBQUksTUFBTSxHQUFHO0FBQ2xGLGlCQUFXLFNBQVMsSUFBSSxRQUFRO0FBQzlCLFlBQUksT0FBTyxVQUFVLFNBQVUsY0FBYSxNQUFNLFNBQVM7QUFBQSxpQkFDbEQsU0FBUyxPQUFPLFVBQVUsU0FBVSxjQUFhLEtBQUssVUFBVSxLQUFLLEVBQUUsU0FBUztBQUFBLE1BQzNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQTtBQUFBLElBQ0UsYUFBYSxLQUFLLE9BQU87QUFBQSxJQUN6QjtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0EsUUFBTSxTQUFTLGdCQUFnQixVQUFVLEtBQUs7QUFDOUMsU0FBTyxPQUFPLFNBQVMsb0JBQW9CLG9CQUFvQjtBQUMvRCxRQUFNLEVBQUUsS0FBSyxRQUFBQSxTQUFRLEtBQUssSUFBSSxPQUFPO0FBQ3JDO0FBQUEsSUFDRSxPQUFPLEtBQUssTUFBTSxhQUFhLEVBQUUsS0FBS0EsV0FBVSxLQUFLLE1BQU0sYUFBYSxFQUFFO0FBQUEsSUFDMUU7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNBLFFBQU0sUUFBUSxvQkFBSSxJQUF3QjtBQUMxQyxRQUFNLFNBQVMsQ0FBQyxRQUFnQixVQUFxQjtBQUNuRCxVQUFNLFFBQVEsTUFBTSxLQUFLLEtBQUssTUFBTSxTQUFTLEVBQUUsR0FDN0MsV0FBV0EsVUFBUyxLQUFNLFNBQVM7QUFDckM7QUFBQSxNQUNFLENBQUMsTUFBTSxJQUFJLE1BQU0sTUFBTSxDQUFDLFFBQVEsS0FBSyxJQUFJLEtBQUssT0FBTyxDQUFDLFdBQVcsUUFBUSxJQUFJLFFBQVE7QUFBQSxNQUNyRjtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsVUFBTSxPQUFPLEVBQUUsT0FBTyxVQUFVLE1BQU07QUFDdEMsVUFBTSxJQUFJLFFBQVEsSUFBSTtBQUN0QixXQUFPO0FBQUEsRUFDVDtBQUNBLGFBQVcsQ0FBQyxNQUFNLElBQUksS0FBSyxPQUFPLFFBQVEsWUFBWSxHQUFHO0FBQ3ZELFVBQU0sTUFBTyxLQUFhLElBQUk7QUFDOUIsUUFBSSxDQUFDLElBQUs7QUFDVixXQUFPLElBQUksVUFBVSxXQUFXLElBQUksT0FBTyxRQUFRLG9CQUFvQix1QkFBdUI7QUFDOUYsUUFBSSxVQUFVO0FBQUEsTUFBUSxDQUFDLFFBQWdCLE1BQ3JDO0FBQUEsUUFDRTtBQUFBLFFBQ0EsU0FBUyxZQUNMLEVBQUUsTUFBTSxZQUFZLElBQUksT0FBTyxDQUFDLEVBQUUsSUFDbEMsU0FBUyxVQUNQLEVBQUUsTUFBTSxNQUFNLElBQUksT0FBTyxDQUFDLEVBQUUsSUFDM0IsRUFBRSxNQUFNLE9BQU8sSUFBSSxPQUFPLENBQUMsRUFBRTtBQUFBLE1BQ3RDO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxhQUFXLFVBQVUsS0FBSyxVQUFVLENBQUMsRUFBRyxRQUFPLFFBQVEsRUFBRSxNQUFNLFFBQVEsQ0FBQztBQUN4RSxRQUFNLE9BQU8sQ0FBQyxXQUFpQyxXQUFvQjtBQUNqRSxVQUFNLE9BQU8sb0JBQUksSUFBWTtBQUM3QixlQUFXLFVBQVUsYUFBYSxDQUFDLEdBQUc7QUFDcEMsWUFBTSxRQUFRLFNBQVMsTUFBTSxJQUFJLE1BQU0sR0FBRyxTQUFTLE1BQU0sSUFBSSxNQUFNLEdBQUc7QUFDdEU7QUFBQSxRQUNFLE9BQU8sU0FBUyxZQUFZLE1BQU0sVUFBVSxLQUFLLENBQUMsS0FBSyxJQUFJLE1BQU07QUFBQSxRQUNqRTtBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBQ0EsWUFBTSxRQUFRO0FBQ2QsV0FBSyxJQUFJLE1BQU07QUFBQSxJQUNqQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLFNBQVMsb0JBQUksSUFBWTtBQUMvQixhQUFXLENBQUMsT0FBTyxPQUFPQyxNQUFLLEtBQUssS0FBSyxVQUFVLENBQUMsR0FBRztBQUNyRDtBQUFBLE1BQ0UsT0FBT0EsTUFBSyxNQUFNLFVBQWEsUUFBUSxTQUFTO0FBQUEsTUFDaEQ7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLGFBQVMsU0FBUyxPQUFPLFNBQVMsUUFBUSxPQUFPLFVBQVU7QUFDekQ7QUFBQSxRQUNFLE1BQU0sSUFBSSxNQUFNLEtBQUssQ0FBQyxPQUFPLElBQUksTUFBTTtBQUFBLFFBQ3ZDO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFDQSxZQUFNLElBQUksTUFBTSxFQUFHLFVBQVUsT0FBT0EsTUFBSztBQUN6QyxhQUFPLElBQUksTUFBTTtBQUFBLElBQ25CO0FBQUEsRUFDRjtBQUNBLGFBQVcsQ0FBQyxNQUFNLFFBQVEsS0FBSztBQUFBLElBQzdCLENBQUMsU0FBUyxNQUFNO0FBQUEsSUFDaEIsQ0FBQyxTQUFTLE1BQU07QUFBQSxJQUNoQixDQUFDLFdBQVcsY0FBYztBQUFBLElBQzFCLENBQUMsVUFBVSxRQUFRO0FBQUEsRUFDckIsR0FBWTtBQUNWLFVBQU0sTUFBTSxLQUFLLElBQUksR0FDbkIsT0FBTyxvQkFBSSxJQUFZO0FBQ3pCLFFBQUksQ0FBQyxJQUFLO0FBQ1YsV0FBTyxJQUFJLFVBQVUsV0FBVyxJQUFJLE9BQU8sUUFBUSxvQkFBb0IsdUJBQXVCO0FBQzlGLFFBQUksVUFBVSxRQUFRLENBQUMsUUFBUSxNQUFNO0FBQ25DO0FBQUEsUUFDRSxNQUFNLElBQUksTUFBTSxLQUFLLENBQUMsS0FBSyxJQUFJLE1BQU07QUFBQSxRQUNyQztBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBQ0EsTUFBQyxNQUFNLElBQUksTUFBTSxFQUFXLFFBQVEsSUFBSSxJQUFJLE9BQU8sQ0FBQztBQUNwRCxXQUFLLElBQUksTUFBTTtBQUFBLElBQ2pCLENBQUM7QUFBQSxFQUNIO0FBQ0EsT0FBSyxLQUFLLGNBQWMsS0FBSztBQUM3QixPQUFLLEtBQUssb0JBQW9CLElBQUk7QUFDbEMsUUFBTSxTQUFxQyxDQUFDO0FBQzVDLGFBQVcsUUFBUSxNQUFNLE9BQU8sR0FBRztBQUNqQyxRQUNFLFVBQ0EsS0FBSyxNQUFNLFNBQVMsYUFDcEIsS0FBSyxNQUFNLFNBQVMsV0FDcEIsS0FBSyxZQUFZLFVBQ2pCLEtBQUssU0FBUyxVQUNkLEtBQUssU0FBUyxVQUNkLEtBQUssaUJBQWlCLFVBQ3RCLEtBQUssV0FBVztBQUVoQjtBQUNGLFdBQU8sSUFBSSxLQUFLLE9BQU8sS0FBSyxRQUFRLENBQUMsSUFBSTtBQUFBLEVBQzNDO0FBQ0EsU0FBTztBQUNUO0FBQ08sZ0JBQVMsbUJBQW1CLFVBQTBDO0FBQzNFLFFBQU0sVUFBVSxPQUFPLFFBQVEsU0FBUyxNQUFNLEdBQzVDLGVBQWUsSUFBSSxJQUFJLFFBQVEsSUFBSSxDQUFDLENBQUMsRUFBRSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQzFELFNBQU87QUFBQSxJQUNMLGVBQWU7QUFBQSxJQUNmLFlBQVksU0FBUztBQUFBLElBQ3JCLFVBQVUsU0FBUztBQUFBLElBQ25CLFlBQVksU0FBUztBQUFBLElBQ3JCLFlBQVksU0FBUztBQUFBLElBQ3JCLFFBQVEsUUFBUSxJQUFJLENBQUMsQ0FBQyxFQUFFLEtBQUssTUFBTSxLQUFLO0FBQUEsSUFDeEMsUUFBUSxTQUFTLFdBQ2QsSUFBSSxDQUFDLE9BQU8sU0FBUyxPQUFPLEtBQUssQ0FBQyxVQUFVLE1BQU0sT0FBTyxFQUFFLENBQUUsRUFDN0QsSUFBSSxDQUFDLE9BQU87QUFDWCxZQUFNLEVBQUUsVUFBVSxhQUFhLFdBQVcsY0FBYyxNQUFNLFNBQVMsT0FBTyxHQUFHLEtBQUssSUFDcEY7QUFDRixZQUFNLFVBQVUsb0JBQUksSUFBMEI7QUFDOUMsaUJBQVcsUUFBUSxPQUFPLE9BQU8sS0FBSyxHQUFHO0FBQ3ZDLGNBQU0sVUFBVSxHQUFHLEtBQUssTUFBTSxLQUFLLFFBQVEsRUFBRSxDQUFDLElBQUksS0FBSyxNQUFNLEtBQUssV0FBVyxFQUFFLENBQUM7QUFDaEYsWUFBSSxDQUFDLFFBQVEsSUFBSSxPQUFPLEVBQUcsU0FBUSxJQUFJLFNBQVMsQ0FBQyxDQUFDO0FBQ2xELGdCQUFRLElBQUksT0FBTyxFQUFHLEtBQUssSUFBSTtBQUFBLE1BQ2pDO0FBQ0EsYUFBTztBQUFBLFFBQ0wsR0FBRztBQUFBLFFBQ0gsTUFBTSxXQUFXLFVBQVUsV0FBVyxJQUFJO0FBQUEsUUFDMUMsU0FBUyxXQUFXLGFBQWEsY0FBYyxPQUFPO0FBQUEsUUFDdEQsUUFBUSxDQUFDLEdBQUcsT0FBTyxFQUNoQixJQUFJLENBQUMsQ0FBQyxTQUFTQyxNQUFLLE1BQU07QUFDekIsZ0JBQU0sQ0FBQyxLQUFLRixPQUFNLElBQUksUUFBUSxNQUFNLEdBQUcsRUFBRSxJQUFJLE1BQU07QUFDbkQsaUJBQU8sRUFBRSxLQUFLLFFBQUFBLFNBQVEsTUFBTSxnQkFBZ0JFLFFBQU8sWUFBWSxFQUFFO0FBQUEsUUFDbkUsQ0FBQyxFQUNBLEtBQUssQ0FBQyxHQUFHLE1BQU0sRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNO0FBQUEsTUFDeEQ7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNMO0FBQ0Y7QUFFTyxnQkFBUyxtQkFBbUIsT0FBa0M7QUFDbkUsb0JBQWtCLEtBQUs7QUFDdkIsTUFBSSxTQUFTLE9BQU8sVUFBVSxZQUFZLENBQUMsTUFBTSxRQUFRLEtBQUssR0FBRztBQUMvRCxVQUFNLFlBQVk7QUFDbEIsUUFDRSxPQUFPLFVBQVUsa0JBQWtCLFlBQ25DLE9BQU8sY0FBYyxVQUFVLGFBQWEsS0FDNUMsT0FBTyxVQUFVLGVBQWUsWUFDaEMsTUFBTSxRQUFRLFVBQVUsTUFBTSxLQUM5QixNQUFNLFFBQVEsVUFBVSxNQUFNLEdBQzlCO0FBQ0E7QUFBQSxRQUNFLFVBQVUsa0JBQWtCO0FBQUEsUUFDNUI7QUFBQSxRQUNBLG1CQUFtQixVQUFVLGFBQWE7QUFBQSxNQUM1QztBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsUUFBTSxTQUFTLG1CQUFtQixVQUFVLEtBQUs7QUFDakQsU0FBTyxPQUFPLFNBQVMsb0JBQW9CLGtEQUFrRDtBQUM3RixRQUFNLE9BQU8sT0FBTztBQUNwQixTQUFPLGlCQUFpQjtBQUFBLElBQ3RCLEdBQUc7QUFBQSxJQUNILFlBQVksS0FBSyxPQUFPLElBQUksQ0FBQyxPQUFPLEdBQUcsRUFBRTtBQUFBLElBQ3pDLFFBQVEsT0FBTyxZQUFZLEtBQUssT0FBTyxJQUFJLENBQUMsT0FBTyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksS0FBSyxDQUFDLENBQUM7QUFBQSxJQUMxRSxRQUFRLEtBQUssT0FBTyxJQUFJLENBQUMsUUFBUTtBQUFBLE1BQy9CLEdBQUc7QUFBQSxNQUNILFVBQVUsV0FBVyxHQUFHLE1BQU0sT0FBTyxJQUFJO0FBQUEsTUFDekMsYUFBYSxXQUFXLEdBQUcsU0FBUyxPQUFPLE9BQU87QUFBQSxNQUNsRCxXQUFXLEdBQUcsS0FBSztBQUFBLE1BQ25CLGNBQWMsR0FBRyxRQUFRO0FBQUEsTUFDekIsTUFBTSxHQUFHLEtBQUssUUFBUSxDQUFDO0FBQUEsTUFDdkIsU0FBUyxHQUFHLFFBQVEsUUFBUSxDQUFDO0FBQUEsTUFDN0IsT0FBTyxDQUFDO0FBQUEsSUFDVixFQUFFO0FBQUEsRUFDSixDQUFDO0FBQ0g7QUFFTyxnQkFBUyxtQkFBbUIsT0FBa0M7QUFDbkUsUUFBTSxPQUFPO0FBQ2IsUUFBTSxXQUFXLG1CQUFtQjtBQUFBLElBQ2xDLEdBQUc7QUFBQSxJQUNILFFBQVEsS0FBSyxRQUFRLElBQUksQ0FBQyxRQUFRLEVBQUUsR0FBRyxJQUFJLFFBQVEsQ0FBQyxFQUFFLEVBQUU7QUFBQSxFQUMxRCxDQUFDO0FBQ0QsUUFBTSxTQUFTLE9BQU8sS0FBSyxTQUFTLE1BQU07QUFDMUMsV0FBUyxJQUFJLEdBQUcsSUFBSSxLQUFLLE9BQU8sUUFBUSxLQUFLO0FBQzNDLFVBQU0sS0FBSyxTQUFTLE9BQU8sQ0FBQyxHQUMxQixPQUFPLElBQUksSUFBSSxHQUFHLFFBQVEsR0FDMUIsVUFBVSxJQUFJLElBQUksR0FBRyxXQUFXLEdBQ2hDLE9BQU8sb0JBQUksSUFBWTtBQUN6QixlQUFXLFNBQVMsS0FBSyxPQUFPLENBQUMsRUFBRSxRQUFRO0FBQ3pDLGFBQU8sU0FBUyxPQUFPLFVBQVUsVUFBVSxvQkFBb0Isb0JBQW9CO0FBQ25GLFlBQU0sVUFBVSxHQUFHLE1BQU0sR0FBRyxJQUFJLE1BQU0sTUFBTTtBQUM1QyxhQUFPLENBQUMsS0FBSyxJQUFJLE9BQU8sR0FBRyxvQkFBb0IsaUJBQWlCO0FBQ2hFLFdBQUssSUFBSSxPQUFPO0FBQ2hCLGFBQU8sT0FBTyxHQUFHLE9BQU8sZ0JBQWdCLE9BQU8sUUFBUSxNQUFNLE9BQU8sQ0FBQztBQUFBLElBQ3ZFO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUVPLGdCQUFTLG1CQUNkLFVBQXFFLENBQUMsR0FDeEQ7QUFDZCxTQUFPLG1CQUFtQixlQUFlLE9BQU8sQ0FBQztBQUNuRDtBQUVPLGlCQUFVLDBCQUNmLE9BQ0EsWUFDbUU7QUFDbkU7QUFBQSxJQUNFLFNBQVMsT0FBTyxVQUFVLFlBQVksTUFBTSxRQUFTLE1BQXVCLE1BQU07QUFBQSxJQUNsRjtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPO0FBQ2IsUUFBTSxXQUFXLG1CQUFtQjtBQUFBLElBQ2xDLEdBQUc7QUFBQSxJQUNILFFBQVEsS0FBSyxPQUFPLElBQUksQ0FBQyxRQUFRLEVBQUUsR0FBRyxJQUFJLFFBQVEsQ0FBQyxFQUFFLEVBQUU7QUFBQSxFQUN6RCxDQUFDO0FBQ0QsZUFBYSxJQUFJO0FBQ2pCLFFBQU0sU0FBUyxPQUFPLEtBQUssU0FBUyxNQUFNO0FBQzFDLFdBQVMsSUFBSSxHQUFHLElBQUksS0FBSyxPQUFPLFFBQVEsS0FBSztBQUMzQyxVQUFNLEtBQUssU0FBUyxPQUFPLENBQUMsR0FDMUIsT0FBTyxJQUFJLElBQUksR0FBRyxRQUFRLEdBQzFCLFVBQVUsSUFBSSxJQUFJLEdBQUcsV0FBVyxHQUNoQyxPQUFPLG9CQUFJLElBQVk7QUFDekIsV0FBTyxNQUFNLFFBQVEsS0FBSyxPQUFPLENBQUMsRUFBRSxNQUFNLEdBQUcsb0JBQW9CLGdCQUFnQjtBQUNqRixlQUFXLFNBQVMsS0FBSyxPQUFPLENBQUMsRUFBRSxRQUFRO0FBQ3pDLGFBQU8sU0FBUyxPQUFPLFVBQVUsVUFBVSxvQkFBb0Isb0JBQW9CO0FBQ25GLFlBQU0sVUFBVSxHQUFHLE1BQU0sR0FBRyxJQUFJLE1BQU0sTUFBTTtBQUM1QyxhQUFPLENBQUMsS0FBSyxJQUFJLE9BQU8sR0FBRyxvQkFBb0IsZ0JBQWdCO0FBQy9ELFdBQUssSUFBSSxPQUFPO0FBQ2hCLHdCQUFrQixLQUFLO0FBQ3ZCLHNCQUFnQixPQUFPLFFBQVEsTUFBTSxPQUFPO0FBQzVDLFlBQU0sRUFBRSxZQUFZLEdBQUcsTUFBTTtBQUFBLElBQy9CO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUVPLGdCQUFTLHFCQUFxQixPQUE4QjtBQUNqRSxRQUFNLFFBQVEsMEJBQTBCLEtBQUs7QUFDN0MsV0FBUyxPQUFPLE1BQU0sS0FBSyxLQUFLLE9BQU8sTUFBTSxLQUFLLEdBQUc7QUFDbkQsUUFBSSxLQUFLLEtBQU0sUUFBTyxLQUFLO0FBQUEsRUFDN0I7QUFDRjsiLCJuYW1lcyI6WyJjb2x1bW4iLCJpbmRleCIsImNlbGxzIl19
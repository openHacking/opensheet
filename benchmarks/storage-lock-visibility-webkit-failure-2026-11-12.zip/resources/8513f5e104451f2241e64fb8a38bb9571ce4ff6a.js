import { Engine } from "/@fs/Volumes/github/private/opensheet/packages/core/src/engine.ts";
import { encodeWorkbookFile } from "/@fs/Volumes/github/private/opensheet/packages/core/src/file-codec.ts";
import { Database } from "/@fs/Volumes/github/private/opensheet/packages/core/src/storage.ts";
export function serveWorker(scope) {
  let engine;
  let queue = Promise.resolve();
  let operationTiming = false;
  let activeMethod = "";
  let waitingTasks = 0;
  let compactTimer;
  let compactQueued = false;
  const requests = /* @__PURE__ */ new Map();
  const cancelledRequests = /* @__PURE__ */ new Set();
  let activeRequest;
  function scheduleCompact(delay) {
    clearTimeout(compactTimer);
    compactTimer = setTimeout(() => {
      compactTimer = void 0;
      if (compactQueued) return;
      compactQueued = true;
      const traced = operationTiming;
      if (traced) waitingTasks++;
      queue = queue.then(async () => {
        if (traced) {
          waitingTasks--;
          activeMethod = "compact";
        }
        let again = false;
        try {
          const storage = await engine?.compact(1);
          if (storage) scope.postMessage({ storage });
          again = !!engine?.hasPendingCompaction;
        } catch {
        } finally {
          compactQueued = false;
          if (traced) activeMethod = "";
        }
        if (again) scheduleCompact(100);
      });
    }, delay);
  }
  scope.onmessage = (event) => {
    const { id, method, args, metadataId } = event.data;
    clearTimeout(compactTimer);
    compactTimer = void 0;
    if (method === "cancel") {
      engine?.cancel();
      return;
    }
    if (method === "cancelRequest") {
      const target = args[0];
      if (requests.get(target) === "search" || requests.get(target) === "navigateData") {
        if (activeRequest === target) engine?.cancel();
        else cancelledRequests.add(target);
      }
      return;
    }
    requests.set(id, method);
    const queuedAt = operationTiming ? performance.now() : void 0;
    const activeAtArrival = queuedAt === void 0 ? "" : activeMethod;
    const queuedAhead = queuedAt === void 0 ? 0 : waitingTasks;
    if (queuedAt !== void 0) waitingTasks++;
    queue = queue.then(async () => {
      if (queuedAt !== void 0) {
        waitingTasks--;
        activeMethod = method;
      }
      const startedAt = queuedAt === void 0 ? void 0 : performance.now();
      const readTiming = startedAt !== void 0 && method === "read" ? {
        cacheHits: 0,
        cacheMisses: 0,
        absentPages: 0,
        storageMs: 0,
        decodeMs: 0,
        inflateMs: 0,
        pageDecodeMs: 0
      } : void 0;
      const timing = () => startedAt === void 0 || queuedAt === void 0 ? void 0 : {
        queueMs: startedAt - queuedAt,
        executionMs: performance.now() - startedAt,
        activeAtArrival,
        queuedAhead,
        ...readTiming ? { read: readTiming } : {}
      };
      try {
        activeRequest = id;
        if (cancelledRequests.delete(id))
          throw Object.assign(new Error("Operation cancelled"), { code: "ABORTED" });
        let result;
        if (method === "open") {
          const [bookId, snapshot, options] = args;
          operationTiming = !!options.operationTiming;
          engine = new Engine(
            await Database.open(options.database),
            bookId,
            options.cacheBytes,
            (progress) => scope.postMessage({ progress, requestId: id })
          );
          result = {
            view: await engine.open(snapshot, options.budgetBytes, options.preserveOrphans),
            writer: engine.isWriter
          };
        } else {
          if (!engine) throw new Error("Worker is not initialized");
          if (method !== "close") engine.begin();
          switch (method) {
            case "exportIndex":
              result = engine.exportIndex(args[0], args[1], args[2], args[3]);
              break;
            case "exportStyles":
              result = engine.exportStyles(args[0]);
              break;
            case "exportBlock":
              result = await engine.exportBlock(args[0], args[1]);
              break;
            case "readCells":
              result = await engine.readCells(args[0], args[1], args[2]);
              break;
            case "navigateData":
              result = await engine.navigateData(args[0], args[1], args[2], args[3], args[4]);
              break;
            case "scanCells":
              result = await engine.scanCells(args[0], args[1]);
              break;
            case "read":
              result = await engine.read(
                args[0],
                args[1],
                args[2],
                true,
                readTiming
              );
              break;
            case "execute":
              result = await engine.execute(args[0], args[1]);
              break;
            case "history":
              result = await engine.history(args[0]);
              break;
            case "generate":
              result = await engine.generate(args[0], args[1]);
              break;
            case "importBinary":
              result = await engine.importBinary(args[0]);
              break;
            case "importJSON":
              result = await engine.importJSON(args[0]);
              break;
            case "replace":
              result = await engine.replace(args[0], args[1]);
              break;
            case "search":
              result = await engine.search(args[0], args[1], args[2], args[3], args[4]);
              break;
            case "compact":
              result = await engine.compact(args[0]);
              break;
            case "stats": {
              const view = engine.view();
              result = { bytes: view.bytes, cacheBytes: view.cacheBytes, budgetBytes: view.budget };
              break;
            }
            case "tryAcquireWriteLock":
              result = await engine.tryAcquireWriteLock();
              break;
            case "reload":
              result = await engine.reload();
              break;
            case "reloadIfChanged":
              result = await engine.reloadIfChanged();
              break;
            case "headExists":
              result = await engine.headExists();
              break;
            case "clear":
              result = await engine.clear();
              break;
            case "close":
              engine.close();
              result = null;
              break;
            default:
              throw new Error(`Unknown worker method: ${method}`);
          }
        }
        if (result && typeof result === "object" && ("view" in result || "snapshot" in result)) {
          const container = result, view = container.view ?? container;
          if (view.snapshot) {
            const snapshot = view.snapshot;
            delete view.snapshot;
            if (metadataId !== view.metadataId) {
              view.file = encodeWorkbookFile(snapshot);
              view.styleIds = Object.keys(snapshot.styles);
            }
          }
        }
        scope.postMessage({ id, result, ...startedAt === void 0 ? {} : { timing: timing() } });
        if (method !== "close" && method !== "clear") scheduleCompact(1e3);
        else {
          clearTimeout(compactTimer);
          compactTimer = void 0;
        }
      } catch (error) {
        scope.postMessage({
          id,
          ...startedAt === void 0 ? {} : { timing: timing() },
          error: {
            message: error instanceof Error ? error.message : String(error),
            code: typeof error.code === "string" ? error.code : error.name
          }
        });
      } finally {
        requests.delete(id);
        cancelledRequests.delete(id);
        activeRequest = void 0;
        if (startedAt !== void 0) activeMethod = "";
      }
    });
  };
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndvcmtlci1ydW50aW1lLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEVuZ2luZSB9IGZyb20gJy4vZW5naW5lLmpzJztcbmltcG9ydCB7IGVuY29kZVdvcmtib29rRmlsZSB9IGZyb20gJy4vZmlsZS1jb2RlYy5qcyc7XG5pbXBvcnQgeyBEYXRhYmFzZSB9IGZyb20gJy4vc3RvcmFnZS5qcyc7XG5pbXBvcnQgdHlwZSB7IENvbW1hbmQsIFJlY3QgfSBmcm9tICcuL3R5cGVzLmpzJztcbmV4cG9ydCB0eXBlIE1lc3NhZ2UgPSB7IGlkOiBudW1iZXI7IG1ldGhvZDogc3RyaW5nOyBhcmdzOiBhbnlbXTsgbWV0YWRhdGFJZD86IHN0cmluZyB9O1xuZXhwb3J0IGZ1bmN0aW9uIHNlcnZlV29ya2VyKHNjb3BlOiB7XG4gIG9ubWVzc2FnZTogKChldmVudDogTWVzc2FnZUV2ZW50PE1lc3NhZ2U+KSA9PiB2b2lkKSB8IG51bGw7XG4gIHBvc3RNZXNzYWdlKHZhbHVlOiB1bmtub3duKTogdm9pZDtcbn0pIHtcbiAgbGV0IGVuZ2luZTogRW5naW5lIHwgdW5kZWZpbmVkO1xuICBsZXQgcXVldWUgPSBQcm9taXNlLnJlc29sdmUoKTtcbiAgbGV0IG9wZXJhdGlvblRpbWluZyA9IGZhbHNlO1xuICBsZXQgYWN0aXZlTWV0aG9kID0gJyc7XG4gIGxldCB3YWl0aW5nVGFza3MgPSAwO1xuICBsZXQgY29tcGFjdFRpbWVyOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRUaW1lb3V0PiB8IHVuZGVmaW5lZDtcbiAgbGV0IGNvbXBhY3RRdWV1ZWQgPSBmYWxzZTtcbiAgY29uc3QgcmVxdWVzdHMgPSBuZXcgTWFwPG51bWJlciwgc3RyaW5nPigpO1xuICBjb25zdCBjYW5jZWxsZWRSZXF1ZXN0cyA9IG5ldyBTZXQ8bnVtYmVyPigpO1xuICBsZXQgYWN0aXZlUmVxdWVzdDogbnVtYmVyIHwgdW5kZWZpbmVkO1xuICBmdW5jdGlvbiBzY2hlZHVsZUNvbXBhY3QoZGVsYXk6IG51bWJlcikge1xuICAgIGNsZWFyVGltZW91dChjb21wYWN0VGltZXIpO1xuICAgIGNvbXBhY3RUaW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgY29tcGFjdFRpbWVyID0gdW5kZWZpbmVkO1xuICAgICAgaWYgKGNvbXBhY3RRdWV1ZWQpIHJldHVybjtcbiAgICAgIGNvbXBhY3RRdWV1ZWQgPSB0cnVlO1xuICAgICAgY29uc3QgdHJhY2VkID0gb3BlcmF0aW9uVGltaW5nO1xuICAgICAgaWYgKHRyYWNlZCkgd2FpdGluZ1Rhc2tzKys7XG4gICAgICBxdWV1ZSA9IHF1ZXVlLnRoZW4oYXN5bmMgKCkgPT4ge1xuICAgICAgICBpZiAodHJhY2VkKSB7XG4gICAgICAgICAgd2FpdGluZ1Rhc2tzLS07XG4gICAgICAgICAgYWN0aXZlTWV0aG9kID0gJ2NvbXBhY3QnO1xuICAgICAgICB9XG4gICAgICAgIGxldCBhZ2FpbiA9IGZhbHNlO1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IHN0b3JhZ2UgPSBhd2FpdCBlbmdpbmU/LmNvbXBhY3QoMSk7XG4gICAgICAgICAgaWYgKHN0b3JhZ2UpIHNjb3BlLnBvc3RNZXNzYWdlKHsgc3RvcmFnZSB9KTtcbiAgICAgICAgICBhZ2FpbiA9ICEhZW5naW5lPy5oYXNQZW5kaW5nQ29tcGFjdGlvbjtcbiAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgLyogS2VlcCByYXcgcmVjb3JkcyBpZiBjb21wcmVzc2lvbiBmYWlscy4gKi9cbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICBjb21wYWN0UXVldWVkID0gZmFsc2U7XG4gICAgICAgICAgaWYgKHRyYWNlZCkgYWN0aXZlTWV0aG9kID0gJyc7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGFnYWluKSBzY2hlZHVsZUNvbXBhY3QoMTAwKTtcbiAgICAgIH0pO1xuICAgIH0sIGRlbGF5KTtcbiAgfVxuICBzY29wZS5vbm1lc3NhZ2UgPSAoZXZlbnQpID0+IHtcbiAgICBjb25zdCB7IGlkLCBtZXRob2QsIGFyZ3MsIG1ldGFkYXRhSWQgfSA9IGV2ZW50LmRhdGE7XG4gICAgY2xlYXJUaW1lb3V0KGNvbXBhY3RUaW1lcik7XG4gICAgY29tcGFjdFRpbWVyID0gdW5kZWZpbmVkO1xuICAgIGlmIChtZXRob2QgPT09ICdjYW5jZWwnKSB7XG4gICAgICBlbmdpbmU/LmNhbmNlbCgpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAobWV0aG9kID09PSAnY2FuY2VsUmVxdWVzdCcpIHtcbiAgICAgIGNvbnN0IHRhcmdldCA9IGFyZ3NbMF07XG4gICAgICBpZiAocmVxdWVzdHMuZ2V0KHRhcmdldCkgPT09ICdzZWFyY2gnIHx8IHJlcXVlc3RzLmdldCh0YXJnZXQpID09PSAnbmF2aWdhdGVEYXRhJykge1xuICAgICAgICBpZiAoYWN0aXZlUmVxdWVzdCA9PT0gdGFyZ2V0KSBlbmdpbmU/LmNhbmNlbCgpO1xuICAgICAgICBlbHNlIGNhbmNlbGxlZFJlcXVlc3RzLmFkZCh0YXJnZXQpO1xuICAgICAgfVxuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICByZXF1ZXN0cy5zZXQoaWQsIG1ldGhvZCk7XG4gICAgY29uc3QgcXVldWVkQXQgPSBvcGVyYXRpb25UaW1pbmcgPyBwZXJmb3JtYW5jZS5ub3coKSA6IHVuZGVmaW5lZDtcbiAgICBjb25zdCBhY3RpdmVBdEFycml2YWwgPSBxdWV1ZWRBdCA9PT0gdW5kZWZpbmVkID8gJycgOiBhY3RpdmVNZXRob2Q7XG4gICAgY29uc3QgcXVldWVkQWhlYWQgPSBxdWV1ZWRBdCA9PT0gdW5kZWZpbmVkID8gMCA6IHdhaXRpbmdUYXNrcztcbiAgICBpZiAocXVldWVkQXQgIT09IHVuZGVmaW5lZCkgd2FpdGluZ1Rhc2tzKys7XG4gICAgcXVldWUgPSBxdWV1ZS50aGVuKGFzeW5jICgpID0+IHtcbiAgICAgIGlmIChxdWV1ZWRBdCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHdhaXRpbmdUYXNrcy0tO1xuICAgICAgICBhY3RpdmVNZXRob2QgPSBtZXRob2Q7XG4gICAgICB9XG4gICAgICBjb25zdCBzdGFydGVkQXQgPSBxdWV1ZWRBdCA9PT0gdW5kZWZpbmVkID8gdW5kZWZpbmVkIDogcGVyZm9ybWFuY2Uubm93KCk7XG4gICAgICBjb25zdCByZWFkVGltaW5nID1cbiAgICAgICAgc3RhcnRlZEF0ICE9PSB1bmRlZmluZWQgJiYgbWV0aG9kID09PSAncmVhZCdcbiAgICAgICAgICA/IHtcbiAgICAgICAgICAgICAgY2FjaGVIaXRzOiAwLFxuICAgICAgICAgICAgICBjYWNoZU1pc3NlczogMCxcbiAgICAgICAgICAgICAgYWJzZW50UGFnZXM6IDAsXG4gICAgICAgICAgICAgIHN0b3JhZ2VNczogMCxcbiAgICAgICAgICAgICAgZGVjb2RlTXM6IDAsXG4gICAgICAgICAgICAgIGluZmxhdGVNczogMCxcbiAgICAgICAgICAgICAgcGFnZURlY29kZU1zOiAwLFxuICAgICAgICAgICAgfVxuICAgICAgICAgIDogdW5kZWZpbmVkO1xuICAgICAgY29uc3QgdGltaW5nID0gKCkgPT5cbiAgICAgICAgc3RhcnRlZEF0ID09PSB1bmRlZmluZWQgfHwgcXVldWVkQXQgPT09IHVuZGVmaW5lZFxuICAgICAgICAgID8gdW5kZWZpbmVkXG4gICAgICAgICAgOiB7XG4gICAgICAgICAgICAgIHF1ZXVlTXM6IHN0YXJ0ZWRBdCAtIHF1ZXVlZEF0LFxuICAgICAgICAgICAgICBleGVjdXRpb25NczogcGVyZm9ybWFuY2Uubm93KCkgLSBzdGFydGVkQXQsXG4gICAgICAgICAgICAgIGFjdGl2ZUF0QXJyaXZhbCxcbiAgICAgICAgICAgICAgcXVldWVkQWhlYWQsXG4gICAgICAgICAgICAgIC4uLihyZWFkVGltaW5nID8geyByZWFkOiByZWFkVGltaW5nIH0gOiB7fSksXG4gICAgICAgICAgICB9O1xuICAgICAgdHJ5IHtcbiAgICAgICAgYWN0aXZlUmVxdWVzdCA9IGlkO1xuICAgICAgICBpZiAoY2FuY2VsbGVkUmVxdWVzdHMuZGVsZXRlKGlkKSlcbiAgICAgICAgICB0aHJvdyBPYmplY3QuYXNzaWduKG5ldyBFcnJvcignT3BlcmF0aW9uIGNhbmNlbGxlZCcpLCB7IGNvZGU6ICdBQk9SVEVEJyB9KTtcbiAgICAgICAgbGV0IHJlc3VsdDogdW5rbm93bjtcbiAgICAgICAgaWYgKG1ldGhvZCA9PT0gJ29wZW4nKSB7XG4gICAgICAgICAgY29uc3QgW2Jvb2tJZCwgc25hcHNob3QsIG9wdGlvbnNdID0gYXJncyBhcyBbXG4gICAgICAgICAgICBzdHJpbmcsXG4gICAgICAgICAgICBpbXBvcnQoJy4vZmlsZS1jb2RlYy5qcycpLldvcmtib29rRmlsZSB8IHVuZGVmaW5lZCxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgZGF0YWJhc2U/OiBzdHJpbmc7XG4gICAgICAgICAgICAgIGJ1ZGdldEJ5dGVzPzogbnVtYmVyO1xuICAgICAgICAgICAgICBjYWNoZUJ5dGVzPzogbnVtYmVyO1xuICAgICAgICAgICAgICBwcmVzZXJ2ZU9ycGhhbnM/OiBib29sZWFuO1xuICAgICAgICAgICAgICBvcGVyYXRpb25UaW1pbmc/OiBib29sZWFuO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdO1xuICAgICAgICAgIG9wZXJhdGlvblRpbWluZyA9ICEhb3B0aW9ucy5vcGVyYXRpb25UaW1pbmc7XG4gICAgICAgICAgZW5naW5lID0gbmV3IEVuZ2luZShcbiAgICAgICAgICAgIGF3YWl0IERhdGFiYXNlLm9wZW4ob3B0aW9ucy5kYXRhYmFzZSksXG4gICAgICAgICAgICBib29rSWQsXG4gICAgICAgICAgICBvcHRpb25zLmNhY2hlQnl0ZXMsXG4gICAgICAgICAgICAocHJvZ3Jlc3MpID0+IHNjb3BlLnBvc3RNZXNzYWdlKHsgcHJvZ3Jlc3MsIHJlcXVlc3RJZDogaWQgfSksXG4gICAgICAgICAgKTtcbiAgICAgICAgICByZXN1bHQgPSB7XG4gICAgICAgICAgICB2aWV3OiBhd2FpdCBlbmdpbmUub3BlbihzbmFwc2hvdCwgb3B0aW9ucy5idWRnZXRCeXRlcywgb3B0aW9ucy5wcmVzZXJ2ZU9ycGhhbnMpLFxuICAgICAgICAgICAgd3JpdGVyOiBlbmdpbmUuaXNXcml0ZXIsXG4gICAgICAgICAgfTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBpZiAoIWVuZ2luZSkgdGhyb3cgbmV3IEVycm9yKCdXb3JrZXIgaXMgbm90IGluaXRpYWxpemVkJyk7XG4gICAgICAgICAgaWYgKG1ldGhvZCAhPT0gJ2Nsb3NlJykgZW5naW5lLmJlZ2luKCk7XG4gICAgICAgICAgc3dpdGNoIChtZXRob2QpIHtcbiAgICAgICAgICAgIGNhc2UgJ2V4cG9ydEluZGV4JzpcbiAgICAgICAgICAgICAgcmVzdWx0ID0gZW5naW5lLmV4cG9ydEluZGV4KGFyZ3NbMF0sIGFyZ3NbMV0sIGFyZ3NbMl0sIGFyZ3NbM10pO1xuICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ2V4cG9ydFN0eWxlcyc6XG4gICAgICAgICAgICAgIHJlc3VsdCA9IGVuZ2luZS5leHBvcnRTdHlsZXMoYXJnc1swXSk7XG4gICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnZXhwb3J0QmxvY2snOlxuICAgICAgICAgICAgICByZXN1bHQgPSBhd2FpdCBlbmdpbmUuZXhwb3J0QmxvY2soYXJnc1swXSwgYXJnc1sxXSk7XG4gICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAncmVhZENlbGxzJzpcbiAgICAgICAgICAgICAgcmVzdWx0ID0gYXdhaXQgZW5naW5lLnJlYWRDZWxscyhhcmdzWzBdLCBhcmdzWzFdLCBhcmdzWzJdKTtcbiAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICduYXZpZ2F0ZURhdGEnOlxuICAgICAgICAgICAgICByZXN1bHQgPSBhd2FpdCBlbmdpbmUubmF2aWdhdGVEYXRhKGFyZ3NbMF0sIGFyZ3NbMV0sIGFyZ3NbMl0sIGFyZ3NbM10sIGFyZ3NbNF0pO1xuICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ3NjYW5DZWxscyc6XG4gICAgICAgICAgICAgIHJlc3VsdCA9IGF3YWl0IGVuZ2luZS5zY2FuQ2VsbHMoYXJnc1swXSwgYXJnc1sxXSk7XG4gICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAncmVhZCc6XG4gICAgICAgICAgICAgIHJlc3VsdCA9IGF3YWl0IGVuZ2luZS5yZWFkKFxuICAgICAgICAgICAgICAgIGFyZ3NbMF0gYXMgc3RyaW5nLFxuICAgICAgICAgICAgICAgIGFyZ3NbMV0gYXMgUmVjdCxcbiAgICAgICAgICAgICAgICBhcmdzWzJdLFxuICAgICAgICAgICAgICAgIHRydWUsXG4gICAgICAgICAgICAgICAgcmVhZFRpbWluZyxcbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdleGVjdXRlJzpcbiAgICAgICAgICAgICAgcmVzdWx0ID0gYXdhaXQgZW5naW5lLmV4ZWN1dGUoYXJnc1swXSBhcyBDb21tYW5kW10sIGFyZ3NbMV0pO1xuICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ2hpc3RvcnknOlxuICAgICAgICAgICAgICByZXN1bHQgPSBhd2FpdCBlbmdpbmUuaGlzdG9yeShhcmdzWzBdKTtcbiAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdnZW5lcmF0ZSc6XG4gICAgICAgICAgICAgIHJlc3VsdCA9IGF3YWl0IGVuZ2luZS5nZW5lcmF0ZShhcmdzWzBdLCBhcmdzWzFdKTtcbiAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdpbXBvcnRCaW5hcnknOlxuICAgICAgICAgICAgICByZXN1bHQgPSBhd2FpdCBlbmdpbmUuaW1wb3J0QmluYXJ5KGFyZ3NbMF0pO1xuICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ2ltcG9ydEpTT04nOlxuICAgICAgICAgICAgICByZXN1bHQgPSBhd2FpdCBlbmdpbmUuaW1wb3J0SlNPTihhcmdzWzBdKTtcbiAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdyZXBsYWNlJzpcbiAgICAgICAgICAgICAgcmVzdWx0ID0gYXdhaXQgZW5naW5lLnJlcGxhY2UoYXJnc1swXSwgYXJnc1sxXSk7XG4gICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnc2VhcmNoJzpcbiAgICAgICAgICAgICAgcmVzdWx0ID0gYXdhaXQgZW5naW5lLnNlYXJjaChhcmdzWzBdLCBhcmdzWzFdLCBhcmdzWzJdLCBhcmdzWzNdLCBhcmdzWzRdKTtcbiAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdjb21wYWN0JzpcbiAgICAgICAgICAgICAgcmVzdWx0ID0gYXdhaXQgZW5naW5lLmNvbXBhY3QoYXJnc1swXSk7XG4gICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnc3RhdHMnOiB7XG4gICAgICAgICAgICAgIGNvbnN0IHZpZXcgPSBlbmdpbmUudmlldygpO1xuICAgICAgICAgICAgICByZXN1bHQgPSB7IGJ5dGVzOiB2aWV3LmJ5dGVzLCBjYWNoZUJ5dGVzOiB2aWV3LmNhY2hlQnl0ZXMsIGJ1ZGdldEJ5dGVzOiB2aWV3LmJ1ZGdldCB9O1xuICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgJ3RyeUFjcXVpcmVXcml0ZUxvY2snOlxuICAgICAgICAgICAgICByZXN1bHQgPSBhd2FpdCBlbmdpbmUudHJ5QWNxdWlyZVdyaXRlTG9jaygpO1xuICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ3JlbG9hZCc6XG4gICAgICAgICAgICAgIHJlc3VsdCA9IGF3YWl0IGVuZ2luZS5yZWxvYWQoKTtcbiAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdyZWxvYWRJZkNoYW5nZWQnOlxuICAgICAgICAgICAgICByZXN1bHQgPSBhd2FpdCBlbmdpbmUucmVsb2FkSWZDaGFuZ2VkKCk7XG4gICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnaGVhZEV4aXN0cyc6XG4gICAgICAgICAgICAgIHJlc3VsdCA9IGF3YWl0IGVuZ2luZS5oZWFkRXhpc3RzKCk7XG4gICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnY2xlYXInOlxuICAgICAgICAgICAgICByZXN1bHQgPSBhd2FpdCBlbmdpbmUuY2xlYXIoKTtcbiAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdjbG9zZSc6XG4gICAgICAgICAgICAgIGVuZ2luZS5jbG9zZSgpO1xuICAgICAgICAgICAgICByZXN1bHQgPSBudWxsO1xuICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVW5rbm93biB3b3JrZXIgbWV0aG9kOiAke21ldGhvZH1gKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHJlc3VsdCAmJiB0eXBlb2YgcmVzdWx0ID09PSAnb2JqZWN0JyAmJiAoJ3ZpZXcnIGluIHJlc3VsdCB8fCAnc25hcHNob3QnIGluIHJlc3VsdCkpIHtcbiAgICAgICAgICBjb25zdCBjb250YWluZXIgPSByZXN1bHQgYXMgYW55LFxuICAgICAgICAgICAgdmlldyA9IGNvbnRhaW5lci52aWV3ID8/IGNvbnRhaW5lcjtcbiAgICAgICAgICBpZiAodmlldy5zbmFwc2hvdCkge1xuICAgICAgICAgICAgY29uc3Qgc25hcHNob3QgPSB2aWV3LnNuYXBzaG90O1xuICAgICAgICAgICAgZGVsZXRlIHZpZXcuc25hcHNob3Q7XG4gICAgICAgICAgICBpZiAobWV0YWRhdGFJZCAhPT0gdmlldy5tZXRhZGF0YUlkKSB7XG4gICAgICAgICAgICAgIHZpZXcuZmlsZSA9IGVuY29kZVdvcmtib29rRmlsZShzbmFwc2hvdCk7XG4gICAgICAgICAgICAgIHZpZXcuc3R5bGVJZHMgPSBPYmplY3Qua2V5cyhzbmFwc2hvdC5zdHlsZXMpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBzY29wZS5wb3N0TWVzc2FnZSh7IGlkLCByZXN1bHQsIC4uLihzdGFydGVkQXQgPT09IHVuZGVmaW5lZCA/IHt9IDogeyB0aW1pbmc6IHRpbWluZygpIH0pIH0pO1xuICAgICAgICBpZiAobWV0aG9kICE9PSAnY2xvc2UnICYmIG1ldGhvZCAhPT0gJ2NsZWFyJykgc2NoZWR1bGVDb21wYWN0KDEwMDApO1xuICAgICAgICBlbHNlIHtcbiAgICAgICAgICBjbGVhclRpbWVvdXQoY29tcGFjdFRpbWVyKTtcbiAgICAgICAgICBjb21wYWN0VGltZXIgPSB1bmRlZmluZWQ7XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHNjb3BlLnBvc3RNZXNzYWdlKHtcbiAgICAgICAgICBpZCxcbiAgICAgICAgICAuLi4oc3RhcnRlZEF0ID09PSB1bmRlZmluZWQgPyB7fSA6IHsgdGltaW5nOiB0aW1pbmcoKSB9KSxcbiAgICAgICAgICBlcnJvcjoge1xuICAgICAgICAgICAgbWVzc2FnZTogZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBTdHJpbmcoZXJyb3IpLFxuICAgICAgICAgICAgY29kZTpcbiAgICAgICAgICAgICAgdHlwZW9mIChlcnJvciBhcyB7IGNvZGU/OiB1bmtub3duIH0pLmNvZGUgPT09ICdzdHJpbmcnXG4gICAgICAgICAgICAgICAgPyAoZXJyb3IgYXMgeyBjb2RlOiBzdHJpbmcgfSkuY29kZVxuICAgICAgICAgICAgICAgIDogKGVycm9yIGFzIEVycm9yKS5uYW1lLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgcmVxdWVzdHMuZGVsZXRlKGlkKTtcbiAgICAgICAgY2FuY2VsbGVkUmVxdWVzdHMuZGVsZXRlKGlkKTtcbiAgICAgICAgYWN0aXZlUmVxdWVzdCA9IHVuZGVmaW5lZDtcbiAgICAgICAgaWYgKHN0YXJ0ZWRBdCAhPT0gdW5kZWZpbmVkKSBhY3RpdmVNZXRob2QgPSAnJztcbiAgICAgIH1cbiAgICB9KTtcbiAgfTtcbn1cbiJdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsMEJBQTBCO0FBQ25DLFNBQVMsZ0JBQWdCO0FBR2xCLGdCQUFTLFlBQVksT0FHekI7QUFDRCxNQUFJO0FBQ0osTUFBSSxRQUFRLFFBQVEsUUFBUTtBQUM1QixNQUFJLGtCQUFrQjtBQUN0QixNQUFJLGVBQWU7QUFDbkIsTUFBSSxlQUFlO0FBQ25CLE1BQUk7QUFDSixNQUFJLGdCQUFnQjtBQUNwQixRQUFNLFdBQVcsb0JBQUksSUFBb0I7QUFDekMsUUFBTSxvQkFBb0Isb0JBQUksSUFBWTtBQUMxQyxNQUFJO0FBQ0osV0FBUyxnQkFBZ0IsT0FBZTtBQUN0QyxpQkFBYSxZQUFZO0FBQ3pCLG1CQUFlLFdBQVcsTUFBTTtBQUM5QixxQkFBZTtBQUNmLFVBQUksY0FBZTtBQUNuQixzQkFBZ0I7QUFDaEIsWUFBTSxTQUFTO0FBQ2YsVUFBSSxPQUFRO0FBQ1osY0FBUSxNQUFNLEtBQUssWUFBWTtBQUM3QixZQUFJLFFBQVE7QUFDVjtBQUNBLHlCQUFlO0FBQUEsUUFDakI7QUFDQSxZQUFJLFFBQVE7QUFDWixZQUFJO0FBQ0YsZ0JBQU0sVUFBVSxNQUFNLFFBQVEsUUFBUSxDQUFDO0FBQ3ZDLGNBQUksUUFBUyxPQUFNLFlBQVksRUFBRSxRQUFRLENBQUM7QUFDMUMsa0JBQVEsQ0FBQyxDQUFDLFFBQVE7QUFBQSxRQUNwQixRQUFRO0FBQUEsUUFFUixVQUFFO0FBQ0EsMEJBQWdCO0FBQ2hCLGNBQUksT0FBUSxnQkFBZTtBQUFBLFFBQzdCO0FBQ0EsWUFBSSxNQUFPLGlCQUFnQixHQUFHO0FBQUEsTUFDaEMsQ0FBQztBQUFBLElBQ0gsR0FBRyxLQUFLO0FBQUEsRUFDVjtBQUNBLFFBQU0sWUFBWSxDQUFDLFVBQVU7QUFDM0IsVUFBTSxFQUFFLElBQUksUUFBUSxNQUFNLFdBQVcsSUFBSSxNQUFNO0FBQy9DLGlCQUFhLFlBQVk7QUFDekIsbUJBQWU7QUFDZixRQUFJLFdBQVcsVUFBVTtBQUN2QixjQUFRLE9BQU87QUFDZjtBQUFBLElBQ0Y7QUFDQSxRQUFJLFdBQVcsaUJBQWlCO0FBQzlCLFlBQU0sU0FBUyxLQUFLLENBQUM7QUFDckIsVUFBSSxTQUFTLElBQUksTUFBTSxNQUFNLFlBQVksU0FBUyxJQUFJLE1BQU0sTUFBTSxnQkFBZ0I7QUFDaEYsWUFBSSxrQkFBa0IsT0FBUSxTQUFRLE9BQU87QUFBQSxZQUN4QyxtQkFBa0IsSUFBSSxNQUFNO0FBQUEsTUFDbkM7QUFDQTtBQUFBLElBQ0Y7QUFDQSxhQUFTLElBQUksSUFBSSxNQUFNO0FBQ3ZCLFVBQU0sV0FBVyxrQkFBa0IsWUFBWSxJQUFJLElBQUk7QUFDdkQsVUFBTSxrQkFBa0IsYUFBYSxTQUFZLEtBQUs7QUFDdEQsVUFBTSxjQUFjLGFBQWEsU0FBWSxJQUFJO0FBQ2pELFFBQUksYUFBYSxPQUFXO0FBQzVCLFlBQVEsTUFBTSxLQUFLLFlBQVk7QUFDN0IsVUFBSSxhQUFhLFFBQVc7QUFDMUI7QUFDQSx1QkFBZTtBQUFBLE1BQ2pCO0FBQ0EsWUFBTSxZQUFZLGFBQWEsU0FBWSxTQUFZLFlBQVksSUFBSTtBQUN2RSxZQUFNLGFBQ0osY0FBYyxVQUFhLFdBQVcsU0FDbEM7QUFBQSxRQUNFLFdBQVc7QUFBQSxRQUNYLGFBQWE7QUFBQSxRQUNiLGFBQWE7QUFBQSxRQUNiLFdBQVc7QUFBQSxRQUNYLFVBQVU7QUFBQSxRQUNWLFdBQVc7QUFBQSxRQUNYLGNBQWM7QUFBQSxNQUNoQixJQUNBO0FBQ04sWUFBTSxTQUFTLE1BQ2IsY0FBYyxVQUFhLGFBQWEsU0FDcEMsU0FDQTtBQUFBLFFBQ0UsU0FBUyxZQUFZO0FBQUEsUUFDckIsYUFBYSxZQUFZLElBQUksSUFBSTtBQUFBLFFBQ2pDO0FBQUEsUUFDQTtBQUFBLFFBQ0EsR0FBSSxhQUFhLEVBQUUsTUFBTSxXQUFXLElBQUksQ0FBQztBQUFBLE1BQzNDO0FBQ04sVUFBSTtBQUNGLHdCQUFnQjtBQUNoQixZQUFJLGtCQUFrQixPQUFPLEVBQUU7QUFDN0IsZ0JBQU0sT0FBTyxPQUFPLElBQUksTUFBTSxxQkFBcUIsR0FBRyxFQUFFLE1BQU0sVUFBVSxDQUFDO0FBQzNFLFlBQUk7QUFDSixZQUFJLFdBQVcsUUFBUTtBQUNyQixnQkFBTSxDQUFDLFFBQVEsVUFBVSxPQUFPLElBQUk7QUFXcEMsNEJBQWtCLENBQUMsQ0FBQyxRQUFRO0FBQzVCLG1CQUFTLElBQUk7QUFBQSxZQUNYLE1BQU0sU0FBUyxLQUFLLFFBQVEsUUFBUTtBQUFBLFlBQ3BDO0FBQUEsWUFDQSxRQUFRO0FBQUEsWUFDUixDQUFDLGFBQWEsTUFBTSxZQUFZLEVBQUUsVUFBVSxXQUFXLEdBQUcsQ0FBQztBQUFBLFVBQzdEO0FBQ0EsbUJBQVM7QUFBQSxZQUNQLE1BQU0sTUFBTSxPQUFPLEtBQUssVUFBVSxRQUFRLGFBQWEsUUFBUSxlQUFlO0FBQUEsWUFDOUUsUUFBUSxPQUFPO0FBQUEsVUFDakI7QUFBQSxRQUNGLE9BQU87QUFDTCxjQUFJLENBQUMsT0FBUSxPQUFNLElBQUksTUFBTSwyQkFBMkI7QUFDeEQsY0FBSSxXQUFXLFFBQVMsUUFBTyxNQUFNO0FBQ3JDLGtCQUFRLFFBQVE7QUFBQSxZQUNkLEtBQUs7QUFDSCx1QkFBUyxPQUFPLFlBQVksS0FBSyxDQUFDLEdBQUcsS0FBSyxDQUFDLEdBQUcsS0FBSyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUM7QUFDOUQ7QUFBQSxZQUNGLEtBQUs7QUFDSCx1QkFBUyxPQUFPLGFBQWEsS0FBSyxDQUFDLENBQUM7QUFDcEM7QUFBQSxZQUNGLEtBQUs7QUFDSCx1QkFBUyxNQUFNLE9BQU8sWUFBWSxLQUFLLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQztBQUNsRDtBQUFBLFlBQ0YsS0FBSztBQUNILHVCQUFTLE1BQU0sT0FBTyxVQUFVLEtBQUssQ0FBQyxHQUFHLEtBQUssQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDO0FBQ3pEO0FBQUEsWUFDRixLQUFLO0FBQ0gsdUJBQVMsTUFBTSxPQUFPLGFBQWEsS0FBSyxDQUFDLEdBQUcsS0FBSyxDQUFDLEdBQUcsS0FBSyxDQUFDLEdBQUcsS0FBSyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUM7QUFDOUU7QUFBQSxZQUNGLEtBQUs7QUFDSCx1QkFBUyxNQUFNLE9BQU8sVUFBVSxLQUFLLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQztBQUNoRDtBQUFBLFlBQ0YsS0FBSztBQUNILHVCQUFTLE1BQU0sT0FBTztBQUFBLGdCQUNwQixLQUFLLENBQUM7QUFBQSxnQkFDTixLQUFLLENBQUM7QUFBQSxnQkFDTixLQUFLLENBQUM7QUFBQSxnQkFDTjtBQUFBLGdCQUNBO0FBQUEsY0FDRjtBQUNBO0FBQUEsWUFDRixLQUFLO0FBQ0gsdUJBQVMsTUFBTSxPQUFPLFFBQVEsS0FBSyxDQUFDLEdBQWdCLEtBQUssQ0FBQyxDQUFDO0FBQzNEO0FBQUEsWUFDRixLQUFLO0FBQ0gsdUJBQVMsTUFBTSxPQUFPLFFBQVEsS0FBSyxDQUFDLENBQUM7QUFDckM7QUFBQSxZQUNGLEtBQUs7QUFDSCx1QkFBUyxNQUFNLE9BQU8sU0FBUyxLQUFLLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQztBQUMvQztBQUFBLFlBQ0YsS0FBSztBQUNILHVCQUFTLE1BQU0sT0FBTyxhQUFhLEtBQUssQ0FBQyxDQUFDO0FBQzFDO0FBQUEsWUFDRixLQUFLO0FBQ0gsdUJBQVMsTUFBTSxPQUFPLFdBQVcsS0FBSyxDQUFDLENBQUM7QUFDeEM7QUFBQSxZQUNGLEtBQUs7QUFDSCx1QkFBUyxNQUFNLE9BQU8sUUFBUSxLQUFLLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQztBQUM5QztBQUFBLFlBQ0YsS0FBSztBQUNILHVCQUFTLE1BQU0sT0FBTyxPQUFPLEtBQUssQ0FBQyxHQUFHLEtBQUssQ0FBQyxHQUFHLEtBQUssQ0FBQyxHQUFHLEtBQUssQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDO0FBQ3hFO0FBQUEsWUFDRixLQUFLO0FBQ0gsdUJBQVMsTUFBTSxPQUFPLFFBQVEsS0FBSyxDQUFDLENBQUM7QUFDckM7QUFBQSxZQUNGLEtBQUssU0FBUztBQUNaLG9CQUFNLE9BQU8sT0FBTyxLQUFLO0FBQ3pCLHVCQUFTLEVBQUUsT0FBTyxLQUFLLE9BQU8sWUFBWSxLQUFLLFlBQVksYUFBYSxLQUFLLE9BQU87QUFDcEY7QUFBQSxZQUNGO0FBQUEsWUFDQSxLQUFLO0FBQ0gsdUJBQVMsTUFBTSxPQUFPLG9CQUFvQjtBQUMxQztBQUFBLFlBQ0YsS0FBSztBQUNILHVCQUFTLE1BQU0sT0FBTyxPQUFPO0FBQzdCO0FBQUEsWUFDRixLQUFLO0FBQ0gsdUJBQVMsTUFBTSxPQUFPLGdCQUFnQjtBQUN0QztBQUFBLFlBQ0YsS0FBSztBQUNILHVCQUFTLE1BQU0sT0FBTyxXQUFXO0FBQ2pDO0FBQUEsWUFDRixLQUFLO0FBQ0gsdUJBQVMsTUFBTSxPQUFPLE1BQU07QUFDNUI7QUFBQSxZQUNGLEtBQUs7QUFDSCxxQkFBTyxNQUFNO0FBQ2IsdUJBQVM7QUFDVDtBQUFBLFlBQ0Y7QUFDRSxvQkFBTSxJQUFJLE1BQU0sMEJBQTBCLE1BQU0sRUFBRTtBQUFBLFVBQ3REO0FBQUEsUUFDRjtBQUNBLFlBQUksVUFBVSxPQUFPLFdBQVcsYUFBYSxVQUFVLFVBQVUsY0FBYyxTQUFTO0FBQ3RGLGdCQUFNLFlBQVksUUFDaEIsT0FBTyxVQUFVLFFBQVE7QUFDM0IsY0FBSSxLQUFLLFVBQVU7QUFDakIsa0JBQU0sV0FBVyxLQUFLO0FBQ3RCLG1CQUFPLEtBQUs7QUFDWixnQkFBSSxlQUFlLEtBQUssWUFBWTtBQUNsQyxtQkFBSyxPQUFPLG1CQUFtQixRQUFRO0FBQ3ZDLG1CQUFLLFdBQVcsT0FBTyxLQUFLLFNBQVMsTUFBTTtBQUFBLFlBQzdDO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFDQSxjQUFNLFlBQVksRUFBRSxJQUFJLFFBQVEsR0FBSSxjQUFjLFNBQVksQ0FBQyxJQUFJLEVBQUUsUUFBUSxPQUFPLEVBQUUsRUFBRyxDQUFDO0FBQzFGLFlBQUksV0FBVyxXQUFXLFdBQVcsUUFBUyxpQkFBZ0IsR0FBSTtBQUFBLGFBQzdEO0FBQ0gsdUJBQWEsWUFBWTtBQUN6Qix5QkFBZTtBQUFBLFFBQ2pCO0FBQUEsTUFDRixTQUFTLE9BQU87QUFDZCxjQUFNLFlBQVk7QUFBQSxVQUNoQjtBQUFBLFVBQ0EsR0FBSSxjQUFjLFNBQVksQ0FBQyxJQUFJLEVBQUUsUUFBUSxPQUFPLEVBQUU7QUFBQSxVQUN0RCxPQUFPO0FBQUEsWUFDTCxTQUFTLGlCQUFpQixRQUFRLE1BQU0sVUFBVSxPQUFPLEtBQUs7QUFBQSxZQUM5RCxNQUNFLE9BQVEsTUFBNkIsU0FBUyxXQUN6QyxNQUEyQixPQUMzQixNQUFnQjtBQUFBLFVBQ3pCO0FBQUEsUUFDRixDQUFDO0FBQUEsTUFDSCxVQUFFO0FBQ0EsaUJBQVMsT0FBTyxFQUFFO0FBQ2xCLDBCQUFrQixPQUFPLEVBQUU7QUFDM0Isd0JBQWdCO0FBQ2hCLFlBQUksY0FBYyxPQUFXLGdCQUFlO0FBQUEsTUFDOUM7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBQ0Y7IiwibmFtZXMiOltdfQ==
import { validateRect } from "/@fs/Volumes/github/private/opensheet/packages/core/src/address.ts";
import { validateValidationEntries } from "/@fs/Volumes/github/private/opensheet/packages/core/src/validation-model.ts";
import { assert } from "/@fs/Volumes/github/private/opensheet/packages/core/src/types.ts";
import { verificationYield } from "/@fs/Volumes/github/private/opensheet/packages/core/src/verification-yield.ts";
const MAX_RANGES = 65536;
const MAX_CANDIDATES = 65536;
const MAX_WORK = 1e6;
export async function validationCandidates(inputRules, inputRanges, dimensions, signal) {
  signal?.throwIfAborted();
  assert(inputRanges.length <= MAX_RANGES, "LIMIT_EXCEEDED", "Too many validation ranges");
  const { rows, columns } = dimensions;
  const rules = validateValidationEntries(inputRules, rows, columns);
  const ranges = inputRanges.map((range) => {
    validateRect(range);
    assert(
      range.endRow <= rows && range.endColumn <= columns,
      "INVALID_RANGE",
      "Range exceeds sheet dimensions"
    );
    return { ...range };
  });
  assert(
    rules.length * ranges.length <= MAX_WORK,
    "LIMIT_EXCEEDED",
    "Validation candidate work exceeded"
  );
  const checkpoint = verificationYield(signal);
  const positions = /* @__PURE__ */ new Map();
  let work = rules.length * ranges.length;
  let scanned = 0;
  for (const range of ranges) {
    for (const { range: rule } of rules) {
      if (++scanned % 1024 === 0) await checkpoint();
      const startRow = Math.max(range.startRow, rule.startRow);
      const endRow = Math.min(range.endRow, rule.endRow);
      const startColumn = Math.max(range.startColumn, rule.startColumn);
      const endColumn = Math.min(range.endColumn, rule.endColumn);
      for (let row = startRow; row < endRow; row++) {
        for (let column = startColumn; column < endColumn; column++) {
          assert(++work <= MAX_WORK, "LIMIT_EXCEEDED", "Validation candidate work exceeded");
          if (++scanned % 1024 === 0) await checkpoint();
          const key = row * columns + column;
          if (!positions.has(key)) {
            assert(
              positions.size < MAX_CANDIDATES,
              "LIMIT_EXCEEDED",
              "Too many validation candidates"
            );
            positions.set(key, { row, column });
          }
        }
      }
    }
  }
  signal?.throwIfAborted();
  return {
    rules,
    positions: [...positions.values()].sort((a, b) => a.row - b.row || a.column - b.column)
  };
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInZhbGlkYXRpb24tY2FuZGlkYXRlcy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB2YWxpZGF0ZVJlY3QgfSBmcm9tICcuL2FkZHJlc3MuanMnO1xuaW1wb3J0IHsgdmFsaWRhdGVWYWxpZGF0aW9uRW50cmllcywgdHlwZSBWYWxpZGF0aW9uRW50cnkgfSBmcm9tICcuL3ZhbGlkYXRpb24tbW9kZWwuanMnO1xuaW1wb3J0IHsgYXNzZXJ0LCB0eXBlIFJlY3QgfSBmcm9tICcuL3R5cGVzLmpzJztcbmltcG9ydCB7IHZlcmlmaWNhdGlvbllpZWxkIH0gZnJvbSAnLi92ZXJpZmljYXRpb24teWllbGQuanMnO1xuXG5jb25zdCBNQVhfUkFOR0VTID0gNjU1MzY7XG5jb25zdCBNQVhfQ0FORElEQVRFUyA9IDY1NTM2O1xuY29uc3QgTUFYX1dPUksgPSAxXzAwMF8wMDA7XG5cbi8qKiBDb2xsZWN0IGRpcmVjdCBpbnRlcnNlY3Rpb25zIG9ubHk7IGNhbGxlcnMgbXVzdCBzZXBhcmF0ZWx5IGluY2x1ZGUgZm9ybXVsYSBkZXBlbmRlbnRzLiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHZhbGlkYXRpb25DYW5kaWRhdGVzKFxuICBpbnB1dFJ1bGVzOiByZWFkb25seSBWYWxpZGF0aW9uRW50cnlbXSxcbiAgaW5wdXRSYW5nZXM6IHJlYWRvbmx5IFJlY3RbXSxcbiAgZGltZW5zaW9uczogeyByb3dzOiBudW1iZXI7IGNvbHVtbnM6IG51bWJlciB9LFxuICBzaWduYWw/OiBBYm9ydFNpZ25hbCxcbikge1xuICBzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG4gIGFzc2VydChpbnB1dFJhbmdlcy5sZW5ndGggPD0gTUFYX1JBTkdFUywgJ0xJTUlUX0VYQ0VFREVEJywgJ1RvbyBtYW55IHZhbGlkYXRpb24gcmFuZ2VzJyk7XG4gIGNvbnN0IHsgcm93cywgY29sdW1ucyB9ID0gZGltZW5zaW9ucztcbiAgY29uc3QgcnVsZXMgPSB2YWxpZGF0ZVZhbGlkYXRpb25FbnRyaWVzKGlucHV0UnVsZXMsIHJvd3MsIGNvbHVtbnMpO1xuICBjb25zdCByYW5nZXMgPSBpbnB1dFJhbmdlcy5tYXAoKHJhbmdlKSA9PiB7XG4gICAgdmFsaWRhdGVSZWN0KHJhbmdlKTtcbiAgICBhc3NlcnQoXG4gICAgICByYW5nZS5lbmRSb3cgPD0gcm93cyAmJiByYW5nZS5lbmRDb2x1bW4gPD0gY29sdW1ucyxcbiAgICAgICdJTlZBTElEX1JBTkdFJyxcbiAgICAgICdSYW5nZSBleGNlZWRzIHNoZWV0IGRpbWVuc2lvbnMnLFxuICAgICk7XG4gICAgcmV0dXJuIHsgLi4ucmFuZ2UgfTtcbiAgfSk7XG4gIGFzc2VydChcbiAgICBydWxlcy5sZW5ndGggKiByYW5nZXMubGVuZ3RoIDw9IE1BWF9XT1JLLFxuICAgICdMSU1JVF9FWENFRURFRCcsXG4gICAgJ1ZhbGlkYXRpb24gY2FuZGlkYXRlIHdvcmsgZXhjZWVkZWQnLFxuICApO1xuICBjb25zdCBjaGVja3BvaW50ID0gdmVyaWZpY2F0aW9uWWllbGQoc2lnbmFsKTtcbiAgY29uc3QgcG9zaXRpb25zID0gbmV3IE1hcDxudW1iZXIsIHsgcm93OiBudW1iZXI7IGNvbHVtbjogbnVtYmVyIH0+KCk7XG4gIGxldCB3b3JrID0gcnVsZXMubGVuZ3RoICogcmFuZ2VzLmxlbmd0aDtcbiAgbGV0IHNjYW5uZWQgPSAwO1xuICBmb3IgKGNvbnN0IHJhbmdlIG9mIHJhbmdlcykge1xuICAgIGZvciAoY29uc3QgeyByYW5nZTogcnVsZSB9IG9mIHJ1bGVzKSB7XG4gICAgICBpZiAoKytzY2FubmVkICUgMTAyNCA9PT0gMCkgYXdhaXQgY2hlY2twb2ludCgpO1xuICAgICAgY29uc3Qgc3RhcnRSb3cgPSBNYXRoLm1heChyYW5nZS5zdGFydFJvdywgcnVsZS5zdGFydFJvdyk7XG4gICAgICBjb25zdCBlbmRSb3cgPSBNYXRoLm1pbihyYW5nZS5lbmRSb3csIHJ1bGUuZW5kUm93KTtcbiAgICAgIGNvbnN0IHN0YXJ0Q29sdW1uID0gTWF0aC5tYXgocmFuZ2Uuc3RhcnRDb2x1bW4sIHJ1bGUuc3RhcnRDb2x1bW4pO1xuICAgICAgY29uc3QgZW5kQ29sdW1uID0gTWF0aC5taW4ocmFuZ2UuZW5kQ29sdW1uLCBydWxlLmVuZENvbHVtbik7XG4gICAgICBmb3IgKGxldCByb3cgPSBzdGFydFJvdzsgcm93IDwgZW5kUm93OyByb3crKykge1xuICAgICAgICBmb3IgKGxldCBjb2x1bW4gPSBzdGFydENvbHVtbjsgY29sdW1uIDwgZW5kQ29sdW1uOyBjb2x1bW4rKykge1xuICAgICAgICAgIGFzc2VydCgrK3dvcmsgPD0gTUFYX1dPUkssICdMSU1JVF9FWENFRURFRCcsICdWYWxpZGF0aW9uIGNhbmRpZGF0ZSB3b3JrIGV4Y2VlZGVkJyk7XG4gICAgICAgICAgaWYgKCsrc2Nhbm5lZCAlIDEwMjQgPT09IDApIGF3YWl0IGNoZWNrcG9pbnQoKTtcbiAgICAgICAgICBjb25zdCBrZXkgPSByb3cgKiBjb2x1bW5zICsgY29sdW1uO1xuICAgICAgICAgIGlmICghcG9zaXRpb25zLmhhcyhrZXkpKSB7XG4gICAgICAgICAgICBhc3NlcnQoXG4gICAgICAgICAgICAgIHBvc2l0aW9ucy5zaXplIDwgTUFYX0NBTkRJREFURVMsXG4gICAgICAgICAgICAgICdMSU1JVF9FWENFRURFRCcsXG4gICAgICAgICAgICAgICdUb28gbWFueSB2YWxpZGF0aW9uIGNhbmRpZGF0ZXMnLFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIHBvc2l0aW9ucy5zZXQoa2V5LCB7IHJvdywgY29sdW1uIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuICBzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG4gIHJldHVybiB7XG4gICAgcnVsZXMsXG4gICAgcG9zaXRpb25zOiBbLi4ucG9zaXRpb25zLnZhbHVlcygpXS5zb3J0KChhLCBiKSA9PiBhLnJvdyAtIGIucm93IHx8IGEuY29sdW1uIC0gYi5jb2x1bW4pLFxuICB9O1xufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLG9CQUFvQjtBQUM3QixTQUFTLGlDQUF1RDtBQUNoRSxTQUFTLGNBQXlCO0FBQ2xDLFNBQVMseUJBQXlCO0FBRWxDLE1BQU0sYUFBYTtBQUNuQixNQUFNLGlCQUFpQjtBQUN2QixNQUFNLFdBQVc7QUFHakIsc0JBQXNCLHFCQUNwQixZQUNBLGFBQ0EsWUFDQSxRQUNBO0FBQ0EsVUFBUSxlQUFlO0FBQ3ZCLFNBQU8sWUFBWSxVQUFVLFlBQVksa0JBQWtCLDRCQUE0QjtBQUN2RixRQUFNLEVBQUUsTUFBTSxRQUFRLElBQUk7QUFDMUIsUUFBTSxRQUFRLDBCQUEwQixZQUFZLE1BQU0sT0FBTztBQUNqRSxRQUFNLFNBQVMsWUFBWSxJQUFJLENBQUMsVUFBVTtBQUN4QyxpQkFBYSxLQUFLO0FBQ2xCO0FBQUEsTUFDRSxNQUFNLFVBQVUsUUFBUSxNQUFNLGFBQWE7QUFBQSxNQUMzQztBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsV0FBTyxFQUFFLEdBQUcsTUFBTTtBQUFBLEVBQ3BCLENBQUM7QUFDRDtBQUFBLElBQ0UsTUFBTSxTQUFTLE9BQU8sVUFBVTtBQUFBLElBQ2hDO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDQSxRQUFNLGFBQWEsa0JBQWtCLE1BQU07QUFDM0MsUUFBTSxZQUFZLG9CQUFJLElBQTZDO0FBQ25FLE1BQUksT0FBTyxNQUFNLFNBQVMsT0FBTztBQUNqQyxNQUFJLFVBQVU7QUFDZCxhQUFXLFNBQVMsUUFBUTtBQUMxQixlQUFXLEVBQUUsT0FBTyxLQUFLLEtBQUssT0FBTztBQUNuQyxVQUFJLEVBQUUsVUFBVSxTQUFTLEVBQUcsT0FBTSxXQUFXO0FBQzdDLFlBQU0sV0FBVyxLQUFLLElBQUksTUFBTSxVQUFVLEtBQUssUUFBUTtBQUN2RCxZQUFNLFNBQVMsS0FBSyxJQUFJLE1BQU0sUUFBUSxLQUFLLE1BQU07QUFDakQsWUFBTSxjQUFjLEtBQUssSUFBSSxNQUFNLGFBQWEsS0FBSyxXQUFXO0FBQ2hFLFlBQU0sWUFBWSxLQUFLLElBQUksTUFBTSxXQUFXLEtBQUssU0FBUztBQUMxRCxlQUFTLE1BQU0sVUFBVSxNQUFNLFFBQVEsT0FBTztBQUM1QyxpQkFBUyxTQUFTLGFBQWEsU0FBUyxXQUFXLFVBQVU7QUFDM0QsaUJBQU8sRUFBRSxRQUFRLFVBQVUsa0JBQWtCLG9DQUFvQztBQUNqRixjQUFJLEVBQUUsVUFBVSxTQUFTLEVBQUcsT0FBTSxXQUFXO0FBQzdDLGdCQUFNLE1BQU0sTUFBTSxVQUFVO0FBQzVCLGNBQUksQ0FBQyxVQUFVLElBQUksR0FBRyxHQUFHO0FBQ3ZCO0FBQUEsY0FDRSxVQUFVLE9BQU87QUFBQSxjQUNqQjtBQUFBLGNBQ0E7QUFBQSxZQUNGO0FBQ0Esc0JBQVUsSUFBSSxLQUFLLEVBQUUsS0FBSyxPQUFPLENBQUM7QUFBQSxVQUNwQztBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxVQUFRLGVBQWU7QUFDdkIsU0FBTztBQUFBLElBQ0w7QUFBQSxJQUNBLFdBQVcsQ0FBQyxHQUFHLFVBQVUsT0FBTyxDQUFDLEVBQUUsS0FBSyxDQUFDLEdBQUcsTUFBTSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU07QUFBQSxFQUN4RjtBQUNGOyIsIm5hbWVzIjpbXX0=
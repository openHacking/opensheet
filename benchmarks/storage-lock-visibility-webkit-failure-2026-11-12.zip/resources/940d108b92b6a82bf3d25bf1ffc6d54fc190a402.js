import {
  offsetFormula,
  parseFormula,
  printFormula,
  transformReferences
} from "/@fs/Volumes/github/private/opensheet/packages/formula/src/index.ts";
import { contains, intersects } from "/@fs/Volumes/github/private/opensheet/packages/core/src/address.ts";
import { transformDeletedFormulaRange } from "/@fs/Volumes/github/private/opensheet/packages/core/src/deleted-formula-range.ts";
import { checkBounds } from "/@fs/Volumes/github/private/opensheet/packages/core/src/model.ts";
import {
  assert,
  LIMITS,
  key
} from "/@fs/Volumes/github/private/opensheet/packages/core/src/types.ts";
export function offsetCellFormula(expression, rows, columns) {
  const result = offsetFormula(expression, rows, columns);
  assert(result.length <= LIMITS.text, "LIMIT_EXCEEDED", "Moved formula exceeds the text limit");
  return result;
}
export function sheetFor(s, id) {
  const sh = s.sheets.find((sh2) => sh2.id === id);
  assert(sh, "INVALID_ARGUMENT", "Sheet no longer exists");
  return sh;
}
export function styleId(s, style) {
  const value = JSON.stringify(Object.fromEntries(Object.entries(style).sort()));
  let hash = 2166136261;
  for (const c of value) hash = Math.imul(hash ^ c.charCodeAt(0), 16777619);
  let id = `style_${(hash >>> 0).toString(16)}`;
  while (s.styles[id] && JSON.stringify(Object.fromEntries(Object.entries(s.styles[id]).sort())) !== value)
    id += "_";
  s.styles[id] = style;
  return id;
}
export function applyPastedCell(s, target, item) {
  if (item.input !== void 0) {
    target.input = item.input;
    delete target.cached;
  }
  if (item.style !== void 0) {
    delete target.numberFormat;
    if (Object.keys(item.style).length) target.styleId = styleId(s, item.style);
    else delete target.styleId;
  }
  if (item.note !== void 0) {
    if (item.note === null) delete target.note;
    else target.note = item.note;
  }
  if (item.link !== void 0) {
    if (item.link === null) delete target.link;
    else target.link = { ...item.link };
  }
}
export function cell(sh, row, col) {
  const rowId = sh.rowOrder[row], columnId = sh.columnOrder[col], k = key(rowId, columnId);
  return sh.cells[k] ?? (sh.cells[k] = { rowId, columnId, input: { type: "blank" } });
}
export function iterate(sh, r, fn) {
  checkBounds(sh, r);
  for (let row = r.startRow; row < r.endRow; row++)
    for (let col = r.startColumn; col < r.endColumn; col++) fn(row, col);
}
export function transformAll(s, fn, sourceSheet, rangeTransform, skip) {
  const transform = createCellFormulaTransformer(fn, rangeTransform);
  for (const sh of s.sheets)
    transform(
      sh.cells,
      sourceSheet ? sh.name : void 0,
      true,
      skip && ((cell2) => skip(sh, cell2))
    );
  for (const sh of s.sheets)
    transform(
      sh.cells,
      sourceSheet ? sh.name : void 0,
      false,
      skip && ((cell2) => skip(sh, cell2))
    );
}
export function createCellFormulaTransformer(fn, rangeTransform) {
  const bySheet = /* @__PURE__ */ new Map();
  let remaining = 256 * 1024;
  return (cells, localSheet, validateOnly = false, skip) => {
    let cache = bySheet.get(localSheet);
    for (const c of Object.values(cells))
      if (c.input.type === "formula" && !skip?.(c)) {
        const original = c.input.expression;
        let rewritten = cache?.get(original);
        try {
          if (rewritten === void 0) {
            const ast = parseFormula(original);
            rewritten = printFormula(
              transformReferences(
                ast,
                (r) => fn({ ...r, sheet: r.sheet ?? localSheet }),
                rangeTransform ? (start, end) => rangeTransform(start, end, localSheet) : void 0
              )
            );
            const cost = 96 + 2 * (original.length + rewritten.length + (localSheet?.length ?? 0));
            if (cost <= remaining) {
              remaining -= cost;
              if (!cache) bySheet.set(localSheet, cache = /* @__PURE__ */ new Map());
              cache.set(original, rewritten);
            }
          }
        } catch {
          assert(
            false,
            "UNSUPPORTED_FEATURE",
            "A formula cannot safely be rewritten; remove it or work on a converted copy"
          );
        }
        assert(
          rewritten.length <= LIMITS.text,
          "LIMIT_EXCEEDED",
          "Rewritten formula exceeds the text limit"
        );
        if (!validateOnly) {
          c.input.expression = rewritten;
          delete c.cached;
        }
      }
  };
}
export function structuralRangeReferences(command, sheetName) {
  if (command.type !== "core.axis.delete") return void 0;
  const payload = command.payload;
  const coordinate = payload.axis === "row" ? "row" : "column";
  const source = sheetName.toLowerCase();
  const transform = structuralReferences(command, sheetName);
  return (start, end, localSheet) => {
    const startSheet = (start.sheet ?? localSheet)?.toLowerCase();
    const endSheet = (end.sheet ?? localSheet)?.toLowerCase();
    if (startSheet !== source || endSheet !== source) {
      const a = transform({ ...start, sheet: start.sheet ?? localSheet });
      const b = transform({ ...end, sheet: end.sheet ?? localSheet });
      return a && b ? [a, b] : null;
    }
    const range = transformDeletedFormulaRange(
      start,
      end,
      coordinate,
      payload.index,
      payload.count
    );
    return range && [
      { ...range[0], sheet: range[0].sheet ?? localSheet },
      { ...range[1], sheet: range[1].sheet ?? localSheet }
    ];
  };
}
export function structuralReferences(command, sheetName) {
  const name = sheetName.toLowerCase();
  const payload = command.payload;
  return (ref) => {
    if (ref.sheet?.toLowerCase() !== name) return ref;
    if (command.type === "core.sheet.remove") return null;
    if (command.type === "core.sheet.rename") return { ...ref, sheet: payload.name };
    const coordinate = payload.axis === "row" ? "row" : "column";
    const at = ref[coordinate];
    if (at < payload.index) return ref;
    if (command.type === "core.axis.insert")
      return { ...ref, [coordinate]: at + payload.ids.length };
    return at < payload.index + payload.count ? null : { ...ref, [coordinate]: at - payload.count };
  };
}
export function guardMerges(sh, r) {
  for (const m of sh.merges)
    assert(
      !intersects(m, r) || contains(r, m),
      "INVALID_RANGE",
      "Operation cuts through a merged cell"
    );
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhlbHBlcnMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgb2Zmc2V0Rm9ybXVsYSxcbiAgcGFyc2VGb3JtdWxhLFxuICBwcmludEZvcm11bGEsXG4gIHRyYW5zZm9ybVJlZmVyZW5jZXMsXG59IGZyb20gJ0BvcGVuc2hlZXRqcy9mb3JtdWxhJztcbmltcG9ydCB7IGNvbnRhaW5zLCBpbnRlcnNlY3RzIH0gZnJvbSAnLi4vYWRkcmVzcy5qcyc7XG5pbXBvcnQgeyB0cmFuc2Zvcm1EZWxldGVkRm9ybXVsYVJhbmdlIH0gZnJvbSAnLi4vZGVsZXRlZC1mb3JtdWxhLXJhbmdlLmpzJztcbmltcG9ydCB7IGNoZWNrQm91bmRzIH0gZnJvbSAnLi4vbW9kZWwuanMnO1xuaW1wb3J0IHtcbiAgYXNzZXJ0LFxuICBMSU1JVFMsXG4gIGtleSxcbiAgdHlwZSBDZWxsUmVjb3JkLFxuICB0eXBlIENlbGxJbnB1dCxcbiAgdHlwZSBDZWxsU3R5bGUsXG4gIHR5cGUgQ29tbWFuZCxcbiAgdHlwZSBSZWN0LFxuICB0eXBlIFNoZWV0U25hcHNob3QsXG4gIHR5cGUgV29ya2Jvb2tTbmFwc2hvdCxcbn0gZnJvbSAnLi4vdHlwZXMuanMnO1xuZXhwb3J0IGZ1bmN0aW9uIG9mZnNldENlbGxGb3JtdWxhKGV4cHJlc3Npb246IHN0cmluZywgcm93czogbnVtYmVyLCBjb2x1bW5zOiBudW1iZXIpOiBzdHJpbmcge1xuICBjb25zdCByZXN1bHQgPSBvZmZzZXRGb3JtdWxhKGV4cHJlc3Npb24sIHJvd3MsIGNvbHVtbnMpO1xuICBhc3NlcnQocmVzdWx0Lmxlbmd0aCA8PSBMSU1JVFMudGV4dCwgJ0xJTUlUX0VYQ0VFREVEJywgJ01vdmVkIGZvcm11bGEgZXhjZWVkcyB0aGUgdGV4dCBsaW1pdCcpO1xuICByZXR1cm4gcmVzdWx0O1xufVxuZXhwb3J0IGZ1bmN0aW9uIHNoZWV0Rm9yKHM6IFdvcmtib29rU25hcHNob3QsIGlkOiBzdHJpbmcpIHtcbiAgY29uc3Qgc2ggPSBzLnNoZWV0cy5maW5kKChzaCkgPT4gc2guaWQgPT09IGlkKTtcbiAgYXNzZXJ0KHNoLCAnSU5WQUxJRF9BUkdVTUVOVCcsICdTaGVldCBubyBsb25nZXIgZXhpc3RzJyk7XG4gIHJldHVybiBzaDtcbn1cbmV4cG9ydCBmdW5jdGlvbiBzdHlsZUlkKHM6IFdvcmtib29rU25hcHNob3QsIHN0eWxlOiBDZWxsU3R5bGUpOiBzdHJpbmcge1xuICBjb25zdCB2YWx1ZSA9IEpTT04uc3RyaW5naWZ5KE9iamVjdC5mcm9tRW50cmllcyhPYmplY3QuZW50cmllcyhzdHlsZSkuc29ydCgpKSk7XG4gIGxldCBoYXNoID0gMjE2NjEzNjI2MTtcbiAgZm9yIChjb25zdCBjIG9mIHZhbHVlKSBoYXNoID0gTWF0aC5pbXVsKGhhc2ggXiBjLmNoYXJDb2RlQXQoMCksIDE2Nzc3NjE5KTtcbiAgbGV0IGlkID0gYHN0eWxlXyR7KGhhc2ggPj4+IDApLnRvU3RyaW5nKDE2KX1gO1xuICB3aGlsZSAoXG4gICAgcy5zdHlsZXNbaWRdICYmXG4gICAgSlNPTi5zdHJpbmdpZnkoT2JqZWN0LmZyb21FbnRyaWVzKE9iamVjdC5lbnRyaWVzKHMuc3R5bGVzW2lkXSkuc29ydCgpKSkgIT09IHZhbHVlXG4gIClcbiAgICBpZCArPSAnXyc7XG4gIHMuc3R5bGVzW2lkXSA9IHN0eWxlO1xuICByZXR1cm4gaWQ7XG59XG5leHBvcnQgdHlwZSBQYXN0ZUNlbGwgPSB7XG4gIHJvdzogbnVtYmVyO1xuICBjb2x1bW46IG51bWJlcjtcbiAgaW5wdXQ/OiBDZWxsSW5wdXQ7XG4gIHN0eWxlPzogQ2VsbFN0eWxlO1xuICBub3RlPzogc3RyaW5nIHwgbnVsbDtcbiAgbGluaz86IENlbGxSZWNvcmRbJ2xpbmsnXSB8IG51bGw7XG59O1xuZXhwb3J0IGZ1bmN0aW9uIGFwcGx5UGFzdGVkQ2VsbChzOiBXb3JrYm9va1NuYXBzaG90LCB0YXJnZXQ6IENlbGxSZWNvcmQsIGl0ZW06IFBhc3RlQ2VsbCk6IHZvaWQge1xuICBpZiAoaXRlbS5pbnB1dCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgdGFyZ2V0LmlucHV0ID0gaXRlbS5pbnB1dDtcbiAgICBkZWxldGUgdGFyZ2V0LmNhY2hlZDtcbiAgfVxuICBpZiAoaXRlbS5zdHlsZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgZGVsZXRlIHRhcmdldC5udW1iZXJGb3JtYXQ7XG4gICAgaWYgKE9iamVjdC5rZXlzKGl0ZW0uc3R5bGUpLmxlbmd0aCkgdGFyZ2V0LnN0eWxlSWQgPSBzdHlsZUlkKHMsIGl0ZW0uc3R5bGUpO1xuICAgIGVsc2UgZGVsZXRlIHRhcmdldC5zdHlsZUlkO1xuICB9XG4gIGlmIChpdGVtLm5vdGUgIT09IHVuZGVmaW5lZCkge1xuICAgIGlmIChpdGVtLm5vdGUgPT09IG51bGwpIGRlbGV0ZSB0YXJnZXQubm90ZTtcbiAgICBlbHNlIHRhcmdldC5ub3RlID0gaXRlbS5ub3RlO1xuICB9XG4gIGlmIChpdGVtLmxpbmsgIT09IHVuZGVmaW5lZCkge1xuICAgIGlmIChpdGVtLmxpbmsgPT09IG51bGwpIGRlbGV0ZSB0YXJnZXQubGluaztcbiAgICBlbHNlIHRhcmdldC5saW5rID0geyAuLi5pdGVtLmxpbmsgfTtcbiAgfVxufVxuZXhwb3J0IGZ1bmN0aW9uIGNlbGwoc2g6IFNoZWV0U25hcHNob3QsIHJvdzogbnVtYmVyLCBjb2w6IG51bWJlcik6IENlbGxSZWNvcmQge1xuICBjb25zdCByb3dJZCA9IHNoLnJvd09yZGVyW3Jvd10sXG4gICAgY29sdW1uSWQgPSBzaC5jb2x1bW5PcmRlcltjb2xdLFxuICAgIGsgPSBrZXkocm93SWQsIGNvbHVtbklkKTtcbiAgcmV0dXJuIHNoLmNlbGxzW2tdID8/IChzaC5jZWxsc1trXSA9IHsgcm93SWQsIGNvbHVtbklkLCBpbnB1dDogeyB0eXBlOiAnYmxhbmsnIH0gfSk7XG59XG5leHBvcnQgZnVuY3Rpb24gaXRlcmF0ZShzaDogU2hlZXRTbmFwc2hvdCwgcjogUmVjdCwgZm46IChyOiBudW1iZXIsIGM6IG51bWJlcikgPT4gdm9pZCkge1xuICBjaGVja0JvdW5kcyhzaCwgcik7XG4gIGZvciAobGV0IHJvdyA9IHIuc3RhcnRSb3c7IHJvdyA8IHIuZW5kUm93OyByb3crKylcbiAgICBmb3IgKGxldCBjb2wgPSByLnN0YXJ0Q29sdW1uOyBjb2wgPCByLmVuZENvbHVtbjsgY29sKyspIGZuKHJvdywgY29sKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiB0cmFuc2Zvcm1BbGwoXG4gIHM6IFdvcmtib29rU25hcHNob3QsXG4gIGZuOiBQYXJhbWV0ZXJzPHR5cGVvZiB0cmFuc2Zvcm1SZWZlcmVuY2VzPlsxXSxcbiAgc291cmNlU2hlZXQ/OiBzdHJpbmcsXG4gIHJhbmdlVHJhbnNmb3JtPzogU3RydWN0dXJhbFJhbmdlVHJhbnNmb3JtLFxuICBza2lwPzogKHNoZWV0OiBTaGVldFNuYXBzaG90LCBjZWxsOiBDZWxsUmVjb3JkKSA9PiBib29sZWFuLFxuKSB7XG4gIGNvbnN0IHRyYW5zZm9ybSA9IGNyZWF0ZUNlbGxGb3JtdWxhVHJhbnNmb3JtZXIoZm4sIHJhbmdlVHJhbnNmb3JtKTtcbiAgZm9yIChjb25zdCBzaCBvZiBzLnNoZWV0cylcbiAgICB0cmFuc2Zvcm0oXG4gICAgICBzaC5jZWxscyxcbiAgICAgIHNvdXJjZVNoZWV0ID8gc2gubmFtZSA6IHVuZGVmaW5lZCxcbiAgICAgIHRydWUsXG4gICAgICBza2lwICYmICgoY2VsbCkgPT4gc2tpcChzaCwgY2VsbCkpLFxuICAgICk7XG4gIGZvciAoY29uc3Qgc2ggb2Ygcy5zaGVldHMpXG4gICAgdHJhbnNmb3JtKFxuICAgICAgc2guY2VsbHMsXG4gICAgICBzb3VyY2VTaGVldCA/IHNoLm5hbWUgOiB1bmRlZmluZWQsXG4gICAgICBmYWxzZSxcbiAgICAgIHNraXAgJiYgKChjZWxsKSA9PiBza2lwKHNoLCBjZWxsKSksXG4gICAgKTtcbn1cblxudHlwZSBSZWZlcmVuY2UgPSBFeHRyYWN0PFJldHVyblR5cGU8dHlwZW9mIHBhcnNlRm9ybXVsYT4sIHsga2luZDogJ3JlZicgfT47XG50eXBlIFN0cnVjdHVyYWxSYW5nZVRyYW5zZm9ybSA9IChcbiAgc3RhcnQ6IFJlZmVyZW5jZSxcbiAgZW5kOiBSZWZlcmVuY2UsXG4gIGxvY2FsU2hlZXQ/OiBzdHJpbmcsXG4pID0+IFtSZWZlcmVuY2UsIFJlZmVyZW5jZV0gfCBudWxsO1xuXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlQ2VsbEZvcm11bGFUcmFuc2Zvcm1lcihcbiAgZm46IFBhcmFtZXRlcnM8dHlwZW9mIHRyYW5zZm9ybVJlZmVyZW5jZXM+WzFdLFxuICByYW5nZVRyYW5zZm9ybT86IFN0cnVjdHVyYWxSYW5nZVRyYW5zZm9ybSxcbikge1xuICBjb25zdCBieVNoZWV0ID0gbmV3IE1hcDxzdHJpbmcgfCB1bmRlZmluZWQsIE1hcDxzdHJpbmcsIHN0cmluZz4+KCk7XG4gIGxldCByZW1haW5pbmcgPSAyNTYgKiAxMDI0O1xuICByZXR1cm4gKFxuICAgIGNlbGxzOiBSZWNvcmQ8c3RyaW5nLCBDZWxsUmVjb3JkPixcbiAgICBsb2NhbFNoZWV0Pzogc3RyaW5nLFxuICAgIHZhbGlkYXRlT25seSA9IGZhbHNlLFxuICAgIHNraXA/OiAoY2VsbDogQ2VsbFJlY29yZCkgPT4gYm9vbGVhbixcbiAgKSA9PiB7XG4gICAgbGV0IGNhY2hlID0gYnlTaGVldC5nZXQobG9jYWxTaGVldCk7XG4gICAgZm9yIChjb25zdCBjIG9mIE9iamVjdC52YWx1ZXMoY2VsbHMpKVxuICAgICAgaWYgKGMuaW5wdXQudHlwZSA9PT0gJ2Zvcm11bGEnICYmICFza2lwPy4oYykpIHtcbiAgICAgICAgY29uc3Qgb3JpZ2luYWwgPSBjLmlucHV0LmV4cHJlc3Npb247XG4gICAgICAgIGxldCByZXdyaXR0ZW4gPSBjYWNoZT8uZ2V0KG9yaWdpbmFsKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBpZiAocmV3cml0dGVuID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIGNvbnN0IGFzdCA9IHBhcnNlRm9ybXVsYShvcmlnaW5hbCk7XG4gICAgICAgICAgICByZXdyaXR0ZW4gPSBwcmludEZvcm11bGEoXG4gICAgICAgICAgICAgIHRyYW5zZm9ybVJlZmVyZW5jZXMoXG4gICAgICAgICAgICAgICAgYXN0LFxuICAgICAgICAgICAgICAgIChyKSA9PiBmbih7IC4uLnIsIHNoZWV0OiByLnNoZWV0ID8/IGxvY2FsU2hlZXQgfSksXG4gICAgICAgICAgICAgICAgcmFuZ2VUcmFuc2Zvcm0gPyAoc3RhcnQsIGVuZCkgPT4gcmFuZ2VUcmFuc2Zvcm0oc3RhcnQsIGVuZCwgbG9jYWxTaGVldCkgOiB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICksXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgY29uc3QgY29zdCA9IDk2ICsgMiAqIChvcmlnaW5hbC5sZW5ndGggKyByZXdyaXR0ZW4ubGVuZ3RoICsgKGxvY2FsU2hlZXQ/Lmxlbmd0aCA/PyAwKSk7XG4gICAgICAgICAgICBpZiAoY29zdCA8PSByZW1haW5pbmcpIHtcbiAgICAgICAgICAgICAgcmVtYWluaW5nIC09IGNvc3Q7XG4gICAgICAgICAgICAgIGlmICghY2FjaGUpIGJ5U2hlZXQuc2V0KGxvY2FsU2hlZXQsIChjYWNoZSA9IG5ldyBNYXAoKSkpO1xuICAgICAgICAgICAgICBjYWNoZS5zZXQob3JpZ2luYWwsIHJld3JpdHRlbik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICBhc3NlcnQoXG4gICAgICAgICAgICBmYWxzZSxcbiAgICAgICAgICAgICdVTlNVUFBPUlRFRF9GRUFUVVJFJyxcbiAgICAgICAgICAgICdBIGZvcm11bGEgY2Fubm90IHNhZmVseSBiZSByZXdyaXR0ZW47IHJlbW92ZSBpdCBvciB3b3JrIG9uIGEgY29udmVydGVkIGNvcHknLFxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgICAgYXNzZXJ0KFxuICAgICAgICAgIHJld3JpdHRlbi5sZW5ndGggPD0gTElNSVRTLnRleHQsXG4gICAgICAgICAgJ0xJTUlUX0VYQ0VFREVEJyxcbiAgICAgICAgICAnUmV3cml0dGVuIGZvcm11bGEgZXhjZWVkcyB0aGUgdGV4dCBsaW1pdCcsXG4gICAgICAgICk7XG4gICAgICAgIGlmICghdmFsaWRhdGVPbmx5KSB7XG4gICAgICAgICAgYy5pbnB1dC5leHByZXNzaW9uID0gcmV3cml0dGVuO1xuICAgICAgICAgIGRlbGV0ZSBjLmNhY2hlZDtcbiAgICAgICAgfVxuICAgICAgfVxuICB9O1xufVxuXG4vKiogU2hyaW5rIGEgcmFuZ2UgYXJvdW5kIGEgZGVsZXRlZCBzcGFuLCBwcmVzZXJ2aW5nIGVuZHBvaW50IG9yZGVyIGFuZCBhbmNob3JpbmcuICovXG5leHBvcnQgZnVuY3Rpb24gc3RydWN0dXJhbFJhbmdlUmVmZXJlbmNlcyhcbiAgY29tbWFuZDogQ29tbWFuZCxcbiAgc2hlZXROYW1lOiBzdHJpbmcsXG4pOiBTdHJ1Y3R1cmFsUmFuZ2VUcmFuc2Zvcm0gfCB1bmRlZmluZWQge1xuICBpZiAoY29tbWFuZC50eXBlICE9PSAnY29yZS5heGlzLmRlbGV0ZScpIHJldHVybiB1bmRlZmluZWQ7XG4gIGNvbnN0IHBheWxvYWQgPSBjb21tYW5kLnBheWxvYWQgYXMgeyBheGlzOiAncm93JyB8ICdjb2x1bW4nOyBpbmRleDogbnVtYmVyOyBjb3VudDogbnVtYmVyIH07XG4gIGNvbnN0IGNvb3JkaW5hdGUgPSBwYXlsb2FkLmF4aXMgPT09ICdyb3cnID8gJ3JvdycgOiAnY29sdW1uJztcbiAgY29uc3Qgc291cmNlID0gc2hlZXROYW1lLnRvTG93ZXJDYXNlKCk7XG4gIGNvbnN0IHRyYW5zZm9ybSA9IHN0cnVjdHVyYWxSZWZlcmVuY2VzKGNvbW1hbmQsIHNoZWV0TmFtZSk7XG4gIHJldHVybiAoc3RhcnQsIGVuZCwgbG9jYWxTaGVldCkgPT4ge1xuICAgIGNvbnN0IHN0YXJ0U2hlZXQgPSAoc3RhcnQuc2hlZXQgPz8gbG9jYWxTaGVldCk/LnRvTG93ZXJDYXNlKCk7XG4gICAgY29uc3QgZW5kU2hlZXQgPSAoZW5kLnNoZWV0ID8/IGxvY2FsU2hlZXQpPy50b0xvd2VyQ2FzZSgpO1xuICAgIGlmIChzdGFydFNoZWV0ICE9PSBzb3VyY2UgfHwgZW5kU2hlZXQgIT09IHNvdXJjZSkge1xuICAgICAgY29uc3QgYSA9IHRyYW5zZm9ybSh7IC4uLnN0YXJ0LCBzaGVldDogc3RhcnQuc2hlZXQgPz8gbG9jYWxTaGVldCB9KTtcbiAgICAgIGNvbnN0IGIgPSB0cmFuc2Zvcm0oeyAuLi5lbmQsIHNoZWV0OiBlbmQuc2hlZXQgPz8gbG9jYWxTaGVldCB9KTtcbiAgICAgIHJldHVybiBhICYmIGIgPyBbYSwgYl0gOiBudWxsO1xuICAgIH1cbiAgICBjb25zdCByYW5nZSA9IHRyYW5zZm9ybURlbGV0ZWRGb3JtdWxhUmFuZ2UoXG4gICAgICBzdGFydCxcbiAgICAgIGVuZCxcbiAgICAgIGNvb3JkaW5hdGUsXG4gICAgICBwYXlsb2FkLmluZGV4LFxuICAgICAgcGF5bG9hZC5jb3VudCxcbiAgICApO1xuICAgIHJldHVybiAoXG4gICAgICByYW5nZSAmJiBbXG4gICAgICAgIHsgLi4ucmFuZ2VbMF0sIHNoZWV0OiByYW5nZVswXS5zaGVldCA/PyBsb2NhbFNoZWV0IH0sXG4gICAgICAgIHsgLi4ucmFuZ2VbMV0sIHNoZWV0OiByYW5nZVsxXS5zaGVldCA/PyBsb2NhbFNoZWV0IH0sXG4gICAgICBdXG4gICAgKTtcbiAgfTtcbn1cblxuLyoqIFNoYXJlZCBieSB0aGUgc25hcHNob3QgcmVkdWNlciBhbmQgdGhlIHBhZ2VkIGVuZ2luZSBhZnRlciBjb21tYW5kIHZhbGlkYXRpb24uICovXG5leHBvcnQgZnVuY3Rpb24gc3RydWN0dXJhbFJlZmVyZW5jZXMoXG4gIGNvbW1hbmQ6IENvbW1hbmQsXG4gIHNoZWV0TmFtZTogc3RyaW5nLFxuKTogUGFyYW1ldGVyczx0eXBlb2YgdHJhbnNmb3JtUmVmZXJlbmNlcz5bMV0ge1xuICBjb25zdCBuYW1lID0gc2hlZXROYW1lLnRvTG93ZXJDYXNlKCk7XG4gIGNvbnN0IHBheWxvYWQgPSBjb21tYW5kLnBheWxvYWQgYXMgYW55O1xuICByZXR1cm4gKHJlZikgPT4ge1xuICAgIGlmIChyZWYuc2hlZXQ/LnRvTG93ZXJDYXNlKCkgIT09IG5hbWUpIHJldHVybiByZWY7XG4gICAgaWYgKGNvbW1hbmQudHlwZSA9PT0gJ2NvcmUuc2hlZXQucmVtb3ZlJykgcmV0dXJuIG51bGw7XG4gICAgaWYgKGNvbW1hbmQudHlwZSA9PT0gJ2NvcmUuc2hlZXQucmVuYW1lJykgcmV0dXJuIHsgLi4ucmVmLCBzaGVldDogcGF5bG9hZC5uYW1lIH07XG4gICAgY29uc3QgY29vcmRpbmF0ZSA9IHBheWxvYWQuYXhpcyA9PT0gJ3JvdycgPyAncm93JyA6ICdjb2x1bW4nO1xuICAgIGNvbnN0IGF0ID0gcmVmW2Nvb3JkaW5hdGVdO1xuICAgIGlmIChhdCA8IHBheWxvYWQuaW5kZXgpIHJldHVybiByZWY7XG4gICAgaWYgKGNvbW1hbmQudHlwZSA9PT0gJ2NvcmUuYXhpcy5pbnNlcnQnKVxuICAgICAgcmV0dXJuIHsgLi4ucmVmLCBbY29vcmRpbmF0ZV06IGF0ICsgcGF5bG9hZC5pZHMubGVuZ3RoIH07XG4gICAgcmV0dXJuIGF0IDwgcGF5bG9hZC5pbmRleCArIHBheWxvYWQuY291bnQgPyBudWxsIDogeyAuLi5yZWYsIFtjb29yZGluYXRlXTogYXQgLSBwYXlsb2FkLmNvdW50IH07XG4gIH07XG59XG5leHBvcnQgZnVuY3Rpb24gZ3VhcmRNZXJnZXMoc2g6IFNoZWV0U25hcHNob3QsIHI6IFJlY3QpIHtcbiAgZm9yIChjb25zdCBtIG9mIHNoLm1lcmdlcylcbiAgICBhc3NlcnQoXG4gICAgICAhaW50ZXJzZWN0cyhtLCByKSB8fCBjb250YWlucyhyLCBtKSxcbiAgICAgICdJTlZBTElEX1JBTkdFJyxcbiAgICAgICdPcGVyYXRpb24gY3V0cyB0aHJvdWdoIGEgbWVyZ2VkIGNlbGwnLFxuICAgICk7XG59XG4iXSwibWFwcGluZ3MiOiJBQUFBO0FBQUEsRUFDRTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLE9BQ0s7QUFDUCxTQUFTLFVBQVUsa0JBQWtCO0FBQ3JDLFNBQVMsb0NBQW9DO0FBQzdDLFNBQVMsbUJBQW1CO0FBQzVCO0FBQUEsRUFDRTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsT0FRSztBQUNBLGdCQUFTLGtCQUFrQixZQUFvQixNQUFjLFNBQXlCO0FBQzNGLFFBQU0sU0FBUyxjQUFjLFlBQVksTUFBTSxPQUFPO0FBQ3RELFNBQU8sT0FBTyxVQUFVLE9BQU8sTUFBTSxrQkFBa0Isc0NBQXNDO0FBQzdGLFNBQU87QUFDVDtBQUNPLGdCQUFTLFNBQVMsR0FBcUIsSUFBWTtBQUN4RCxRQUFNLEtBQUssRUFBRSxPQUFPLEtBQUssQ0FBQ0EsUUFBT0EsSUFBRyxPQUFPLEVBQUU7QUFDN0MsU0FBTyxJQUFJLG9CQUFvQix3QkFBd0I7QUFDdkQsU0FBTztBQUNUO0FBQ08sZ0JBQVMsUUFBUSxHQUFxQixPQUEwQjtBQUNyRSxRQUFNLFFBQVEsS0FBSyxVQUFVLE9BQU8sWUFBWSxPQUFPLFFBQVEsS0FBSyxFQUFFLEtBQUssQ0FBQyxDQUFDO0FBQzdFLE1BQUksT0FBTztBQUNYLGFBQVcsS0FBSyxNQUFPLFFBQU8sS0FBSyxLQUFLLE9BQU8sRUFBRSxXQUFXLENBQUMsR0FBRyxRQUFRO0FBQ3hFLE1BQUksS0FBSyxVQUFVLFNBQVMsR0FBRyxTQUFTLEVBQUUsQ0FBQztBQUMzQyxTQUNFLEVBQUUsT0FBTyxFQUFFLEtBQ1gsS0FBSyxVQUFVLE9BQU8sWUFBWSxPQUFPLFFBQVEsRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDLE1BQU07QUFFNUUsVUFBTTtBQUNSLElBQUUsT0FBTyxFQUFFLElBQUk7QUFDZixTQUFPO0FBQ1Q7QUFTTyxnQkFBUyxnQkFBZ0IsR0FBcUIsUUFBb0IsTUFBdUI7QUFDOUYsTUFBSSxLQUFLLFVBQVUsUUFBVztBQUM1QixXQUFPLFFBQVEsS0FBSztBQUNwQixXQUFPLE9BQU87QUFBQSxFQUNoQjtBQUNBLE1BQUksS0FBSyxVQUFVLFFBQVc7QUFDNUIsV0FBTyxPQUFPO0FBQ2QsUUFBSSxPQUFPLEtBQUssS0FBSyxLQUFLLEVBQUUsT0FBUSxRQUFPLFVBQVUsUUFBUSxHQUFHLEtBQUssS0FBSztBQUFBLFFBQ3JFLFFBQU8sT0FBTztBQUFBLEVBQ3JCO0FBQ0EsTUFBSSxLQUFLLFNBQVMsUUFBVztBQUMzQixRQUFJLEtBQUssU0FBUyxLQUFNLFFBQU8sT0FBTztBQUFBLFFBQ2pDLFFBQU8sT0FBTyxLQUFLO0FBQUEsRUFDMUI7QUFDQSxNQUFJLEtBQUssU0FBUyxRQUFXO0FBQzNCLFFBQUksS0FBSyxTQUFTLEtBQU0sUUFBTyxPQUFPO0FBQUEsUUFDakMsUUFBTyxPQUFPLEVBQUUsR0FBRyxLQUFLLEtBQUs7QUFBQSxFQUNwQztBQUNGO0FBQ08sZ0JBQVMsS0FBSyxJQUFtQixLQUFhLEtBQXlCO0FBQzVFLFFBQU0sUUFBUSxHQUFHLFNBQVMsR0FBRyxHQUMzQixXQUFXLEdBQUcsWUFBWSxHQUFHLEdBQzdCLElBQUksSUFBSSxPQUFPLFFBQVE7QUFDekIsU0FBTyxHQUFHLE1BQU0sQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLElBQUksRUFBRSxPQUFPLFVBQVUsT0FBTyxFQUFFLE1BQU0sUUFBUSxFQUFFO0FBQ25GO0FBQ08sZ0JBQVMsUUFBUSxJQUFtQixHQUFTLElBQW9DO0FBQ3RGLGNBQVksSUFBSSxDQUFDO0FBQ2pCLFdBQVMsTUFBTSxFQUFFLFVBQVUsTUFBTSxFQUFFLFFBQVE7QUFDekMsYUFBUyxNQUFNLEVBQUUsYUFBYSxNQUFNLEVBQUUsV0FBVyxNQUFPLElBQUcsS0FBSyxHQUFHO0FBQ3ZFO0FBQ08sZ0JBQVMsYUFDZCxHQUNBLElBQ0EsYUFDQSxnQkFDQSxNQUNBO0FBQ0EsUUFBTSxZQUFZLDZCQUE2QixJQUFJLGNBQWM7QUFDakUsYUFBVyxNQUFNLEVBQUU7QUFDakI7QUFBQSxNQUNFLEdBQUc7QUFBQSxNQUNILGNBQWMsR0FBRyxPQUFPO0FBQUEsTUFDeEI7QUFBQSxNQUNBLFNBQVMsQ0FBQ0MsVUFBUyxLQUFLLElBQUlBLEtBQUk7QUFBQSxJQUNsQztBQUNGLGFBQVcsTUFBTSxFQUFFO0FBQ2pCO0FBQUEsTUFDRSxHQUFHO0FBQUEsTUFDSCxjQUFjLEdBQUcsT0FBTztBQUFBLE1BQ3hCO0FBQUEsTUFDQSxTQUFTLENBQUNBLFVBQVMsS0FBSyxJQUFJQSxLQUFJO0FBQUEsSUFDbEM7QUFDSjtBQVNPLGdCQUFTLDZCQUNkLElBQ0EsZ0JBQ0E7QUFDQSxRQUFNLFVBQVUsb0JBQUksSUFBNkM7QUFDakUsTUFBSSxZQUFZLE1BQU07QUFDdEIsU0FBTyxDQUNMLE9BQ0EsWUFDQSxlQUFlLE9BQ2YsU0FDRztBQUNILFFBQUksUUFBUSxRQUFRLElBQUksVUFBVTtBQUNsQyxlQUFXLEtBQUssT0FBTyxPQUFPLEtBQUs7QUFDakMsVUFBSSxFQUFFLE1BQU0sU0FBUyxhQUFhLENBQUMsT0FBTyxDQUFDLEdBQUc7QUFDNUMsY0FBTSxXQUFXLEVBQUUsTUFBTTtBQUN6QixZQUFJLFlBQVksT0FBTyxJQUFJLFFBQVE7QUFDbkMsWUFBSTtBQUNGLGNBQUksY0FBYyxRQUFXO0FBQzNCLGtCQUFNLE1BQU0sYUFBYSxRQUFRO0FBQ2pDLHdCQUFZO0FBQUEsY0FDVjtBQUFBLGdCQUNFO0FBQUEsZ0JBQ0EsQ0FBQyxNQUFNLEdBQUcsRUFBRSxHQUFHLEdBQUcsT0FBTyxFQUFFLFNBQVMsV0FBVyxDQUFDO0FBQUEsZ0JBQ2hELGlCQUFpQixDQUFDLE9BQU8sUUFBUSxlQUFlLE9BQU8sS0FBSyxVQUFVLElBQUk7QUFBQSxjQUM1RTtBQUFBLFlBQ0Y7QUFDQSxrQkFBTSxPQUFPLEtBQUssS0FBSyxTQUFTLFNBQVMsVUFBVSxVQUFVLFlBQVksVUFBVTtBQUNuRixnQkFBSSxRQUFRLFdBQVc7QUFDckIsMkJBQWE7QUFDYixrQkFBSSxDQUFDLE1BQU8sU0FBUSxJQUFJLFlBQWEsUUFBUSxvQkFBSSxJQUFJLENBQUU7QUFDdkQsb0JBQU0sSUFBSSxVQUFVLFNBQVM7QUFBQSxZQUMvQjtBQUFBLFVBQ0Y7QUFBQSxRQUNGLFFBQVE7QUFDTjtBQUFBLFlBQ0U7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQ0E7QUFBQSxVQUNFLFVBQVUsVUFBVSxPQUFPO0FBQUEsVUFDM0I7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUNBLFlBQUksQ0FBQyxjQUFjO0FBQ2pCLFlBQUUsTUFBTSxhQUFhO0FBQ3JCLGlCQUFPLEVBQUU7QUFBQSxRQUNYO0FBQUEsTUFDRjtBQUFBLEVBQ0o7QUFDRjtBQUdPLGdCQUFTLDBCQUNkLFNBQ0EsV0FDc0M7QUFDdEMsTUFBSSxRQUFRLFNBQVMsbUJBQW9CLFFBQU87QUFDaEQsUUFBTSxVQUFVLFFBQVE7QUFDeEIsUUFBTSxhQUFhLFFBQVEsU0FBUyxRQUFRLFFBQVE7QUFDcEQsUUFBTSxTQUFTLFVBQVUsWUFBWTtBQUNyQyxRQUFNLFlBQVkscUJBQXFCLFNBQVMsU0FBUztBQUN6RCxTQUFPLENBQUMsT0FBTyxLQUFLLGVBQWU7QUFDakMsVUFBTSxjQUFjLE1BQU0sU0FBUyxhQUFhLFlBQVk7QUFDNUQsVUFBTSxZQUFZLElBQUksU0FBUyxhQUFhLFlBQVk7QUFDeEQsUUFBSSxlQUFlLFVBQVUsYUFBYSxRQUFRO0FBQ2hELFlBQU0sSUFBSSxVQUFVLEVBQUUsR0FBRyxPQUFPLE9BQU8sTUFBTSxTQUFTLFdBQVcsQ0FBQztBQUNsRSxZQUFNLElBQUksVUFBVSxFQUFFLEdBQUcsS0FBSyxPQUFPLElBQUksU0FBUyxXQUFXLENBQUM7QUFDOUQsYUFBTyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSTtBQUFBLElBQzNCO0FBQ0EsVUFBTSxRQUFRO0FBQUEsTUFDWjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQSxRQUFRO0FBQUEsTUFDUixRQUFRO0FBQUEsSUFDVjtBQUNBLFdBQ0UsU0FBUztBQUFBLE1BQ1AsRUFBRSxHQUFHLE1BQU0sQ0FBQyxHQUFHLE9BQU8sTUFBTSxDQUFDLEVBQUUsU0FBUyxXQUFXO0FBQUEsTUFDbkQsRUFBRSxHQUFHLE1BQU0sQ0FBQyxHQUFHLE9BQU8sTUFBTSxDQUFDLEVBQUUsU0FBUyxXQUFXO0FBQUEsSUFDckQ7QUFBQSxFQUVKO0FBQ0Y7QUFHTyxnQkFBUyxxQkFDZCxTQUNBLFdBQzJDO0FBQzNDLFFBQU0sT0FBTyxVQUFVLFlBQVk7QUFDbkMsUUFBTSxVQUFVLFFBQVE7QUFDeEIsU0FBTyxDQUFDLFFBQVE7QUFDZCxRQUFJLElBQUksT0FBTyxZQUFZLE1BQU0sS0FBTSxRQUFPO0FBQzlDLFFBQUksUUFBUSxTQUFTLG9CQUFxQixRQUFPO0FBQ2pELFFBQUksUUFBUSxTQUFTLG9CQUFxQixRQUFPLEVBQUUsR0FBRyxLQUFLLE9BQU8sUUFBUSxLQUFLO0FBQy9FLFVBQU0sYUFBYSxRQUFRLFNBQVMsUUFBUSxRQUFRO0FBQ3BELFVBQU0sS0FBSyxJQUFJLFVBQVU7QUFDekIsUUFBSSxLQUFLLFFBQVEsTUFBTyxRQUFPO0FBQy9CLFFBQUksUUFBUSxTQUFTO0FBQ25CLGFBQU8sRUFBRSxHQUFHLEtBQUssQ0FBQyxVQUFVLEdBQUcsS0FBSyxRQUFRLElBQUksT0FBTztBQUN6RCxXQUFPLEtBQUssUUFBUSxRQUFRLFFBQVEsUUFBUSxPQUFPLEVBQUUsR0FBRyxLQUFLLENBQUMsVUFBVSxHQUFHLEtBQUssUUFBUSxNQUFNO0FBQUEsRUFDaEc7QUFDRjtBQUNPLGdCQUFTLFlBQVksSUFBbUIsR0FBUztBQUN0RCxhQUFXLEtBQUssR0FBRztBQUNqQjtBQUFBLE1BQ0UsQ0FBQyxXQUFXLEdBQUcsQ0FBQyxLQUFLLFNBQVMsR0FBRyxDQUFDO0FBQUEsTUFDbEM7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNKOyIsIm5hbWVzIjpbInNoIiwiY2VsbCJdfQ==
export function isSafeLinkTarget(target) {
  if (!target || target.length > 4096 || /[\u0000-\u0020\u007f\\]/.test(target)) return false;
  try {
    const url = new URL(target);
    if (url.protocol === "mailto:") return /^mailto:/i.test(target) && url.pathname.length > 0;
    return /^https?:\/\//i.test(target) && (url.protocol === "http:" || url.protocol === "https:") && !!url.hostname;
  } catch {
    return false;
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxpbmtzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qKiBFeHBsaWNpdCBleHRlcm5hbC1saW5rIHByb2ZpbGUgdXNlZCBmb3IgcGVyc2lzdGVkIG1ldGFkYXRhIGFuZCB1c2VyIG5hdmlnYXRpb24uICovXG5leHBvcnQgZnVuY3Rpb24gaXNTYWZlTGlua1RhcmdldCh0YXJnZXQ6IHN0cmluZyk6IGJvb2xlYW4ge1xuICBpZiAoIXRhcmdldCB8fCB0YXJnZXQubGVuZ3RoID4gNDA5NiB8fCAvW1xcdTAwMDAtXFx1MDAyMFxcdTAwN2ZcXFxcXS8udGVzdCh0YXJnZXQpKSByZXR1cm4gZmFsc2U7XG4gIHRyeSB7XG4gICAgY29uc3QgdXJsID0gbmV3IFVSTCh0YXJnZXQpO1xuICAgIGlmICh1cmwucHJvdG9jb2wgPT09ICdtYWlsdG86JykgcmV0dXJuIC9ebWFpbHRvOi9pLnRlc3QodGFyZ2V0KSAmJiB1cmwucGF0aG5hbWUubGVuZ3RoID4gMDtcbiAgICByZXR1cm4gKFxuICAgICAgL15odHRwcz86XFwvXFwvL2kudGVzdCh0YXJnZXQpICYmXG4gICAgICAodXJsLnByb3RvY29sID09PSAnaHR0cDonIHx8IHVybC5wcm90b2NvbCA9PT0gJ2h0dHBzOicpICYmXG4gICAgICAhIXVybC5ob3N0bmFtZVxuICAgICk7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxufVxuIl0sIm1hcHBpbmdzIjoiQUFDTyxnQkFBUyxpQkFBaUIsUUFBeUI7QUFDeEQsTUFBSSxDQUFDLFVBQVUsT0FBTyxTQUFTLFFBQVEsMEJBQTBCLEtBQUssTUFBTSxFQUFHLFFBQU87QUFDdEYsTUFBSTtBQUNGLFVBQU0sTUFBTSxJQUFJLElBQUksTUFBTTtBQUMxQixRQUFJLElBQUksYUFBYSxVQUFXLFFBQU8sWUFBWSxLQUFLLE1BQU0sS0FBSyxJQUFJLFNBQVMsU0FBUztBQUN6RixXQUNFLGdCQUFnQixLQUFLLE1BQU0sTUFDMUIsSUFBSSxhQUFhLFdBQVcsSUFBSSxhQUFhLGFBQzlDLENBQUMsQ0FBQyxJQUFJO0FBQUEsRUFFVixRQUFRO0FBQ04sV0FBTztBQUFBLEVBQ1Q7QUFDRjsiLCJuYW1lcyI6W119
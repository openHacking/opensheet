const definitionsInput = [
  [
    "ROUNDUP",
    2,
    2,
    "ROUNDUP(number, digits)",
    "scalar",
    "Round away from zero on the shortest decimal representation; digits truncate toward zero."
  ],
  [
    "ROUNDDOWN",
    2,
    2,
    "ROUNDDOWN(number, digits)",
    "scalar",
    "Round toward zero on the shortest decimal representation; digits truncate toward zero."
  ],
  [
    "INT",
    1,
    1,
    "INT(number)",
    "scalar",
    "Floor to the nearest integer, including negative numbers."
  ],
  [
    "MOD",
    2,
    2,
    "MOD(number, divisor)",
    "scalar",
    "Remainder with divisor sign; zero divisor returns DIV/0."
  ],
  ["IFNA", 2, 2, "IFNA(value, fallback)", "lazy", "Evaluate fallback only for the NA error."],
  [
    "IFS",
    2,
    254,
    "IFS(test, value, ...)",
    "lazy",
    "Evaluate pairs in order and return the first matching scalar value; no match returns NA."
  ],
  [
    "DATE",
    3,
    3,
    "DATE(year, month, day)",
    "scalar",
    "Construct a serial in the workbook date system, normalizing month/day overflow."
  ],
  ["YEAR", 1, 1, "YEAR(serial)", "scalar", "Gregorian year in the workbook date system."],
  ["MONTH", 1, 1, "MONTH(serial)", "scalar", "Month number in the workbook date system."],
  [
    "DAY",
    1,
    1,
    "DAY(serial)",
    "scalar",
    "Day of month, including the 1900 compatibility leap day."
  ],
  [
    "DAYS",
    2,
    2,
    "DAYS(end, start)",
    "scalar",
    "Subtract date serials; ISO date text is supported, ambiguous locale text is not."
  ],
  [
    "SUMIF",
    2,
    3,
    "SUMIF(range, criterion, [sumRange])",
    "conditional",
    "Sum matching numeric cells; optional value range extends from its top-left."
  ],
  [
    "SUMIFS",
    3,
    255,
    "SUMIFS(sumRange, criteriaRange, criterion, ...)",
    "conditional",
    "Sum numeric cells matching every criterion; shapes must agree."
  ],
  [
    "COUNTIF",
    2,
    2,
    "COUNTIF(range, criterion)",
    "conditional",
    "Count matching cells with case-insensitive criteria and escaped wildcards."
  ],
  [
    "COUNTIFS",
    2,
    254,
    "COUNTIFS(criteriaRange, criterion, ...)",
    "conditional",
    "Count cells matching every criterion; shapes must agree."
  ],
  [
    "AVERAGEIF",
    2,
    3,
    "AVERAGEIF(range, criterion, [averageRange])",
    "conditional",
    "Average matching numeric cells; no numeric matches returns DIV/0."
  ],
  [
    "AVERAGEIFS",
    3,
    255,
    "AVERAGEIFS(averageRange, criteriaRange, criterion, ...)",
    "conditional",
    "Average numeric cells matching every criterion; shapes must agree."
  ],
  [
    "INDEX",
    2,
    3,
    "INDEX(range, row, [column])",
    "lookup",
    "Return one cell; positive scalar indices only."
  ],
  [
    "MATCH",
    2,
    3,
    "MATCH(value, vector, [matchType])",
    "lookup",
    "Exact/wildcard or ordered approximate match; default match type is 1."
  ],
  [
    "VLOOKUP",
    3,
    4,
    "VLOOKUP(value, table, column, [approximate])",
    "lookup",
    "Exact/wildcard or ordered approximate match; approximate is the default."
  ],
  [
    "XLOOKUP",
    3,
    6,
    "XLOOKUP(value, vector, results, [missing], [matchMode], [searchMode])",
    "lookup",
    "Scalar result; exact/nearest/wildcard matching and linear or sorted binary search."
  ],
  ["TRUE", 0, 0, "TRUE()", "scalar", "Return the logical value true."],
  ["FALSE", 0, 0, "FALSE()", "scalar", "Return the logical value false."],
  [
    "LEFT",
    1,
    2,
    "LEFT(text, [count])",
    "scalar",
    "Leading Unicode code points; count defaults to 1."
  ],
  [
    "RIGHT",
    1,
    2,
    "RIGHT(text, [count])",
    "scalar",
    "Trailing Unicode code points; count defaults to 1."
  ],
  [
    "MID",
    3,
    3,
    "MID(text, start, count)",
    "scalar",
    "Unicode code-point substring from a 1-based position."
  ],
  ["LEN", 1, 1, "LEN(text)", "scalar", "Count Unicode code points, not grapheme clusters."],
  [
    "TRIM",
    1,
    1,
    "TRIM(text)",
    "scalar",
    "Remove leading/trailing ASCII spaces and collapse repeated ASCII spaces."
  ],
  ["UPPER", 1, 1, "UPPER(text)", "scalar", "Locale-independent Unicode uppercase."],
  ["LOWER", 1, 1, "LOWER(text)", "scalar", "Locale-independent Unicode lowercase."],
  [
    "CONCAT",
    1,
    253,
    "CONCAT(text, ...)",
    "text",
    "Concatenate scalars/ranges in row-major order; 32767 UTF-16 code-unit output limit."
  ],
  [
    "TEXTJOIN",
    3,
    254,
    "TEXTJOIN(delimiter, ignoreEmpty, text, ...)",
    "text",
    "Join scalar/range text with a scalar delimiter; at most 252 text arguments."
  ],
  ["SUM", 1, 255, "SUM(value, ...)", "aggregate", "Sum numeric values."],
  ["AVERAGE", 1, 255, "AVERAGE(value, ...)", "aggregate", "Mean of numeric values."],
  ["MIN", 1, 255, "MIN(value, ...)", "aggregate", "Smallest numeric value, or zero."],
  ["MAX", 1, 255, "MAX(value, ...)", "aggregate", "Largest numeric value, or zero."],
  [
    "COUNT",
    1,
    255,
    "COUNT(value, ...)",
    "aggregate",
    "Count numbers; direct logical and numeric text arguments also count."
  ],
  [
    "COUNTA",
    1,
    255,
    "COUNTA(value, ...)",
    "aggregate",
    "Count nonblank values, including empty text and errors."
  ],
  [
    "IF",
    2,
    3,
    "IF(test, whenTrue, [whenFalse])",
    "lazy",
    "Evaluate only the selected branch; omitted false branch returns false."
  ],
  ["IFERROR", 2, 2, "IFERROR(value, fallback)", "lazy", "Evaluate fallback only for an error."],
  [
    "AND",
    1,
    255,
    "AND(value, ...)",
    "aggregate",
    "All logical values must be true; referenced text and blanks are ignored."
  ],
  [
    "OR",
    1,
    255,
    "OR(value, ...)",
    "aggregate",
    "At least one logical value must be true; referenced text and blanks are ignored."
  ],
  ["NOT", 1, 1, "NOT(value)", "scalar", "Invert a logical value."],
  [
    "ROUND",
    2,
    2,
    "ROUND(number, digits)",
    "scalar",
    "Round halfway away from zero; digits truncate toward zero."
  ],
  ["ABS", 1, 1, "ABS(number)", "scalar", "Absolute numeric value."]
];
export const functionDefinitions = Object.freeze(
  definitionsInput.map(
    ([name, minArgs, maxArgs, signature, evaluation, description]) => Object.freeze({ name, minArgs, maxArgs, signature, evaluation, description })
  )
);
const definitions = new Map(functionDefinitions.map((definition) => [definition.name, definition]));
export const supportedFunctions = Object.freeze(
  functionDefinitions.map(({ name }) => name)
);
export function functionDefinition(name) {
  return definitions.get(name);
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZ1bmN0aW9ucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgaW50ZXJmYWNlIEZ1bmN0aW9uRGVmaW5pdGlvbiB7XG4gIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcbiAgcmVhZG9ubHkgbWluQXJnczogbnVtYmVyO1xuICByZWFkb25seSBtYXhBcmdzOiBudW1iZXI7XG4gIHJlYWRvbmx5IHNpZ25hdHVyZTogc3RyaW5nO1xuICByZWFkb25seSBldmFsdWF0aW9uOiAnc2NhbGFyJyB8ICdhZ2dyZWdhdGUnIHwgJ2xhenknIHwgJ3RleHQnIHwgJ2NvbmRpdGlvbmFsJyB8ICdsb29rdXAnO1xuICByZWFkb25seSBkZXNjcmlwdGlvbjogc3RyaW5nO1xufVxuXG4vKiogU2hhcmVkIHJ1bnRpbWUvaGVscCBjb250cmFjdC4gQ29lcmNpb24gZGV0YWlscyBhbmQgZXhjbHVzaW9ucyBsaXZlIGluIGRvY3MvZm9ybXVsYXMubWQuICovXG5jb25zdCBkZWZpbml0aW9uc0lucHV0OiBSZWFkb25seUFycmF5PFxuICByZWFkb25seSBbc3RyaW5nLCBudW1iZXIsIG51bWJlciwgc3RyaW5nLCBGdW5jdGlvbkRlZmluaXRpb25bJ2V2YWx1YXRpb24nXSwgc3RyaW5nXVxuPiA9IFtcbiAgW1xuICAgICdST1VORFVQJyxcbiAgICAyLFxuICAgIDIsXG4gICAgJ1JPVU5EVVAobnVtYmVyLCBkaWdpdHMpJyxcbiAgICAnc2NhbGFyJyxcbiAgICAnUm91bmQgYXdheSBmcm9tIHplcm8gb24gdGhlIHNob3J0ZXN0IGRlY2ltYWwgcmVwcmVzZW50YXRpb247IGRpZ2l0cyB0cnVuY2F0ZSB0b3dhcmQgemVyby4nLFxuICBdLFxuICBbXG4gICAgJ1JPVU5ERE9XTicsXG4gICAgMixcbiAgICAyLFxuICAgICdST1VORERPV04obnVtYmVyLCBkaWdpdHMpJyxcbiAgICAnc2NhbGFyJyxcbiAgICAnUm91bmQgdG93YXJkIHplcm8gb24gdGhlIHNob3J0ZXN0IGRlY2ltYWwgcmVwcmVzZW50YXRpb247IGRpZ2l0cyB0cnVuY2F0ZSB0b3dhcmQgemVyby4nLFxuICBdLFxuICBbXG4gICAgJ0lOVCcsXG4gICAgMSxcbiAgICAxLFxuICAgICdJTlQobnVtYmVyKScsXG4gICAgJ3NjYWxhcicsXG4gICAgJ0Zsb29yIHRvIHRoZSBuZWFyZXN0IGludGVnZXIsIGluY2x1ZGluZyBuZWdhdGl2ZSBudW1iZXJzLicsXG4gIF0sXG4gIFtcbiAgICAnTU9EJyxcbiAgICAyLFxuICAgIDIsXG4gICAgJ01PRChudW1iZXIsIGRpdmlzb3IpJyxcbiAgICAnc2NhbGFyJyxcbiAgICAnUmVtYWluZGVyIHdpdGggZGl2aXNvciBzaWduOyB6ZXJvIGRpdmlzb3IgcmV0dXJucyBESVYvMC4nLFxuICBdLFxuICBbJ0lGTkEnLCAyLCAyLCAnSUZOQSh2YWx1ZSwgZmFsbGJhY2spJywgJ2xhenknLCAnRXZhbHVhdGUgZmFsbGJhY2sgb25seSBmb3IgdGhlIE5BIGVycm9yLiddLFxuICBbXG4gICAgJ0lGUycsXG4gICAgMixcbiAgICAyNTQsXG4gICAgJ0lGUyh0ZXN0LCB2YWx1ZSwgLi4uKScsXG4gICAgJ2xhenknLFxuICAgICdFdmFsdWF0ZSBwYWlycyBpbiBvcmRlciBhbmQgcmV0dXJuIHRoZSBmaXJzdCBtYXRjaGluZyBzY2FsYXIgdmFsdWU7IG5vIG1hdGNoIHJldHVybnMgTkEuJyxcbiAgXSxcbiAgW1xuICAgICdEQVRFJyxcbiAgICAzLFxuICAgIDMsXG4gICAgJ0RBVEUoeWVhciwgbW9udGgsIGRheSknLFxuICAgICdzY2FsYXInLFxuICAgICdDb25zdHJ1Y3QgYSBzZXJpYWwgaW4gdGhlIHdvcmtib29rIGRhdGUgc3lzdGVtLCBub3JtYWxpemluZyBtb250aC9kYXkgb3ZlcmZsb3cuJyxcbiAgXSxcbiAgWydZRUFSJywgMSwgMSwgJ1lFQVIoc2VyaWFsKScsICdzY2FsYXInLCAnR3JlZ29yaWFuIHllYXIgaW4gdGhlIHdvcmtib29rIGRhdGUgc3lzdGVtLiddLFxuICBbJ01PTlRIJywgMSwgMSwgJ01PTlRIKHNlcmlhbCknLCAnc2NhbGFyJywgJ01vbnRoIG51bWJlciBpbiB0aGUgd29ya2Jvb2sgZGF0ZSBzeXN0ZW0uJ10sXG4gIFtcbiAgICAnREFZJyxcbiAgICAxLFxuICAgIDEsXG4gICAgJ0RBWShzZXJpYWwpJyxcbiAgICAnc2NhbGFyJyxcbiAgICAnRGF5IG9mIG1vbnRoLCBpbmNsdWRpbmcgdGhlIDE5MDAgY29tcGF0aWJpbGl0eSBsZWFwIGRheS4nLFxuICBdLFxuICBbXG4gICAgJ0RBWVMnLFxuICAgIDIsXG4gICAgMixcbiAgICAnREFZUyhlbmQsIHN0YXJ0KScsXG4gICAgJ3NjYWxhcicsXG4gICAgJ1N1YnRyYWN0IGRhdGUgc2VyaWFsczsgSVNPIGRhdGUgdGV4dCBpcyBzdXBwb3J0ZWQsIGFtYmlndW91cyBsb2NhbGUgdGV4dCBpcyBub3QuJyxcbiAgXSxcbiAgW1xuICAgICdTVU1JRicsXG4gICAgMixcbiAgICAzLFxuICAgICdTVU1JRihyYW5nZSwgY3JpdGVyaW9uLCBbc3VtUmFuZ2VdKScsXG4gICAgJ2NvbmRpdGlvbmFsJyxcbiAgICAnU3VtIG1hdGNoaW5nIG51bWVyaWMgY2VsbHM7IG9wdGlvbmFsIHZhbHVlIHJhbmdlIGV4dGVuZHMgZnJvbSBpdHMgdG9wLWxlZnQuJyxcbiAgXSxcbiAgW1xuICAgICdTVU1JRlMnLFxuICAgIDMsXG4gICAgMjU1LFxuICAgICdTVU1JRlMoc3VtUmFuZ2UsIGNyaXRlcmlhUmFuZ2UsIGNyaXRlcmlvbiwgLi4uKScsXG4gICAgJ2NvbmRpdGlvbmFsJyxcbiAgICAnU3VtIG51bWVyaWMgY2VsbHMgbWF0Y2hpbmcgZXZlcnkgY3JpdGVyaW9uOyBzaGFwZXMgbXVzdCBhZ3JlZS4nLFxuICBdLFxuICBbXG4gICAgJ0NPVU5USUYnLFxuICAgIDIsXG4gICAgMixcbiAgICAnQ09VTlRJRihyYW5nZSwgY3JpdGVyaW9uKScsXG4gICAgJ2NvbmRpdGlvbmFsJyxcbiAgICAnQ291bnQgbWF0Y2hpbmcgY2VsbHMgd2l0aCBjYXNlLWluc2Vuc2l0aXZlIGNyaXRlcmlhIGFuZCBlc2NhcGVkIHdpbGRjYXJkcy4nLFxuICBdLFxuICBbXG4gICAgJ0NPVU5USUZTJyxcbiAgICAyLFxuICAgIDI1NCxcbiAgICAnQ09VTlRJRlMoY3JpdGVyaWFSYW5nZSwgY3JpdGVyaW9uLCAuLi4pJyxcbiAgICAnY29uZGl0aW9uYWwnLFxuICAgICdDb3VudCBjZWxscyBtYXRjaGluZyBldmVyeSBjcml0ZXJpb247IHNoYXBlcyBtdXN0IGFncmVlLicsXG4gIF0sXG4gIFtcbiAgICAnQVZFUkFHRUlGJyxcbiAgICAyLFxuICAgIDMsXG4gICAgJ0FWRVJBR0VJRihyYW5nZSwgY3JpdGVyaW9uLCBbYXZlcmFnZVJhbmdlXSknLFxuICAgICdjb25kaXRpb25hbCcsXG4gICAgJ0F2ZXJhZ2UgbWF0Y2hpbmcgbnVtZXJpYyBjZWxsczsgbm8gbnVtZXJpYyBtYXRjaGVzIHJldHVybnMgRElWLzAuJyxcbiAgXSxcbiAgW1xuICAgICdBVkVSQUdFSUZTJyxcbiAgICAzLFxuICAgIDI1NSxcbiAgICAnQVZFUkFHRUlGUyhhdmVyYWdlUmFuZ2UsIGNyaXRlcmlhUmFuZ2UsIGNyaXRlcmlvbiwgLi4uKScsXG4gICAgJ2NvbmRpdGlvbmFsJyxcbiAgICAnQXZlcmFnZSBudW1lcmljIGNlbGxzIG1hdGNoaW5nIGV2ZXJ5IGNyaXRlcmlvbjsgc2hhcGVzIG11c3QgYWdyZWUuJyxcbiAgXSxcbiAgW1xuICAgICdJTkRFWCcsXG4gICAgMixcbiAgICAzLFxuICAgICdJTkRFWChyYW5nZSwgcm93LCBbY29sdW1uXSknLFxuICAgICdsb29rdXAnLFxuICAgICdSZXR1cm4gb25lIGNlbGw7IHBvc2l0aXZlIHNjYWxhciBpbmRpY2VzIG9ubHkuJyxcbiAgXSxcbiAgW1xuICAgICdNQVRDSCcsXG4gICAgMixcbiAgICAzLFxuICAgICdNQVRDSCh2YWx1ZSwgdmVjdG9yLCBbbWF0Y2hUeXBlXSknLFxuICAgICdsb29rdXAnLFxuICAgICdFeGFjdC93aWxkY2FyZCBvciBvcmRlcmVkIGFwcHJveGltYXRlIG1hdGNoOyBkZWZhdWx0IG1hdGNoIHR5cGUgaXMgMS4nLFxuICBdLFxuICBbXG4gICAgJ1ZMT09LVVAnLFxuICAgIDMsXG4gICAgNCxcbiAgICAnVkxPT0tVUCh2YWx1ZSwgdGFibGUsIGNvbHVtbiwgW2FwcHJveGltYXRlXSknLFxuICAgICdsb29rdXAnLFxuICAgICdFeGFjdC93aWxkY2FyZCBvciBvcmRlcmVkIGFwcHJveGltYXRlIG1hdGNoOyBhcHByb3hpbWF0ZSBpcyB0aGUgZGVmYXVsdC4nLFxuICBdLFxuICBbXG4gICAgJ1hMT09LVVAnLFxuICAgIDMsXG4gICAgNixcbiAgICAnWExPT0tVUCh2YWx1ZSwgdmVjdG9yLCByZXN1bHRzLCBbbWlzc2luZ10sIFttYXRjaE1vZGVdLCBbc2VhcmNoTW9kZV0pJyxcbiAgICAnbG9va3VwJyxcbiAgICAnU2NhbGFyIHJlc3VsdDsgZXhhY3QvbmVhcmVzdC93aWxkY2FyZCBtYXRjaGluZyBhbmQgbGluZWFyIG9yIHNvcnRlZCBiaW5hcnkgc2VhcmNoLicsXG4gIF0sXG4gIFsnVFJVRScsIDAsIDAsICdUUlVFKCknLCAnc2NhbGFyJywgJ1JldHVybiB0aGUgbG9naWNhbCB2YWx1ZSB0cnVlLiddLFxuICBbJ0ZBTFNFJywgMCwgMCwgJ0ZBTFNFKCknLCAnc2NhbGFyJywgJ1JldHVybiB0aGUgbG9naWNhbCB2YWx1ZSBmYWxzZS4nXSxcbiAgW1xuICAgICdMRUZUJyxcbiAgICAxLFxuICAgIDIsXG4gICAgJ0xFRlQodGV4dCwgW2NvdW50XSknLFxuICAgICdzY2FsYXInLFxuICAgICdMZWFkaW5nIFVuaWNvZGUgY29kZSBwb2ludHM7IGNvdW50IGRlZmF1bHRzIHRvIDEuJyxcbiAgXSxcbiAgW1xuICAgICdSSUdIVCcsXG4gICAgMSxcbiAgICAyLFxuICAgICdSSUdIVCh0ZXh0LCBbY291bnRdKScsXG4gICAgJ3NjYWxhcicsXG4gICAgJ1RyYWlsaW5nIFVuaWNvZGUgY29kZSBwb2ludHM7IGNvdW50IGRlZmF1bHRzIHRvIDEuJyxcbiAgXSxcbiAgW1xuICAgICdNSUQnLFxuICAgIDMsXG4gICAgMyxcbiAgICAnTUlEKHRleHQsIHN0YXJ0LCBjb3VudCknLFxuICAgICdzY2FsYXInLFxuICAgICdVbmljb2RlIGNvZGUtcG9pbnQgc3Vic3RyaW5nIGZyb20gYSAxLWJhc2VkIHBvc2l0aW9uLicsXG4gIF0sXG4gIFsnTEVOJywgMSwgMSwgJ0xFTih0ZXh0KScsICdzY2FsYXInLCAnQ291bnQgVW5pY29kZSBjb2RlIHBvaW50cywgbm90IGdyYXBoZW1lIGNsdXN0ZXJzLiddLFxuICBbXG4gICAgJ1RSSU0nLFxuICAgIDEsXG4gICAgMSxcbiAgICAnVFJJTSh0ZXh0KScsXG4gICAgJ3NjYWxhcicsXG4gICAgJ1JlbW92ZSBsZWFkaW5nL3RyYWlsaW5nIEFTQ0lJIHNwYWNlcyBhbmQgY29sbGFwc2UgcmVwZWF0ZWQgQVNDSUkgc3BhY2VzLicsXG4gIF0sXG4gIFsnVVBQRVInLCAxLCAxLCAnVVBQRVIodGV4dCknLCAnc2NhbGFyJywgJ0xvY2FsZS1pbmRlcGVuZGVudCBVbmljb2RlIHVwcGVyY2FzZS4nXSxcbiAgWydMT1dFUicsIDEsIDEsICdMT1dFUih0ZXh0KScsICdzY2FsYXInLCAnTG9jYWxlLWluZGVwZW5kZW50IFVuaWNvZGUgbG93ZXJjYXNlLiddLFxuICBbXG4gICAgJ0NPTkNBVCcsXG4gICAgMSxcbiAgICAyNTMsXG4gICAgJ0NPTkNBVCh0ZXh0LCAuLi4pJyxcbiAgICAndGV4dCcsXG4gICAgJ0NvbmNhdGVuYXRlIHNjYWxhcnMvcmFuZ2VzIGluIHJvdy1tYWpvciBvcmRlcjsgMzI3NjcgVVRGLTE2IGNvZGUtdW5pdCBvdXRwdXQgbGltaXQuJyxcbiAgXSxcbiAgW1xuICAgICdURVhUSk9JTicsXG4gICAgMyxcbiAgICAyNTQsXG4gICAgJ1RFWFRKT0lOKGRlbGltaXRlciwgaWdub3JlRW1wdHksIHRleHQsIC4uLiknLFxuICAgICd0ZXh0JyxcbiAgICAnSm9pbiBzY2FsYXIvcmFuZ2UgdGV4dCB3aXRoIGEgc2NhbGFyIGRlbGltaXRlcjsgYXQgbW9zdCAyNTIgdGV4dCBhcmd1bWVudHMuJyxcbiAgXSxcbiAgWydTVU0nLCAxLCAyNTUsICdTVU0odmFsdWUsIC4uLiknLCAnYWdncmVnYXRlJywgJ1N1bSBudW1lcmljIHZhbHVlcy4nXSxcbiAgWydBVkVSQUdFJywgMSwgMjU1LCAnQVZFUkFHRSh2YWx1ZSwgLi4uKScsICdhZ2dyZWdhdGUnLCAnTWVhbiBvZiBudW1lcmljIHZhbHVlcy4nXSxcbiAgWydNSU4nLCAxLCAyNTUsICdNSU4odmFsdWUsIC4uLiknLCAnYWdncmVnYXRlJywgJ1NtYWxsZXN0IG51bWVyaWMgdmFsdWUsIG9yIHplcm8uJ10sXG4gIFsnTUFYJywgMSwgMjU1LCAnTUFYKHZhbHVlLCAuLi4pJywgJ2FnZ3JlZ2F0ZScsICdMYXJnZXN0IG51bWVyaWMgdmFsdWUsIG9yIHplcm8uJ10sXG4gIFtcbiAgICAnQ09VTlQnLFxuICAgIDEsXG4gICAgMjU1LFxuICAgICdDT1VOVCh2YWx1ZSwgLi4uKScsXG4gICAgJ2FnZ3JlZ2F0ZScsXG4gICAgJ0NvdW50IG51bWJlcnM7IGRpcmVjdCBsb2dpY2FsIGFuZCBudW1lcmljIHRleHQgYXJndW1lbnRzIGFsc28gY291bnQuJyxcbiAgXSxcbiAgW1xuICAgICdDT1VOVEEnLFxuICAgIDEsXG4gICAgMjU1LFxuICAgICdDT1VOVEEodmFsdWUsIC4uLiknLFxuICAgICdhZ2dyZWdhdGUnLFxuICAgICdDb3VudCBub25ibGFuayB2YWx1ZXMsIGluY2x1ZGluZyBlbXB0eSB0ZXh0IGFuZCBlcnJvcnMuJyxcbiAgXSxcbiAgW1xuICAgICdJRicsXG4gICAgMixcbiAgICAzLFxuICAgICdJRih0ZXN0LCB3aGVuVHJ1ZSwgW3doZW5GYWxzZV0pJyxcbiAgICAnbGF6eScsXG4gICAgJ0V2YWx1YXRlIG9ubHkgdGhlIHNlbGVjdGVkIGJyYW5jaDsgb21pdHRlZCBmYWxzZSBicmFuY2ggcmV0dXJucyBmYWxzZS4nLFxuICBdLFxuICBbJ0lGRVJST1InLCAyLCAyLCAnSUZFUlJPUih2YWx1ZSwgZmFsbGJhY2spJywgJ2xhenknLCAnRXZhbHVhdGUgZmFsbGJhY2sgb25seSBmb3IgYW4gZXJyb3IuJ10sXG4gIFtcbiAgICAnQU5EJyxcbiAgICAxLFxuICAgIDI1NSxcbiAgICAnQU5EKHZhbHVlLCAuLi4pJyxcbiAgICAnYWdncmVnYXRlJyxcbiAgICAnQWxsIGxvZ2ljYWwgdmFsdWVzIG11c3QgYmUgdHJ1ZTsgcmVmZXJlbmNlZCB0ZXh0IGFuZCBibGFua3MgYXJlIGlnbm9yZWQuJyxcbiAgXSxcbiAgW1xuICAgICdPUicsXG4gICAgMSxcbiAgICAyNTUsXG4gICAgJ09SKHZhbHVlLCAuLi4pJyxcbiAgICAnYWdncmVnYXRlJyxcbiAgICAnQXQgbGVhc3Qgb25lIGxvZ2ljYWwgdmFsdWUgbXVzdCBiZSB0cnVlOyByZWZlcmVuY2VkIHRleHQgYW5kIGJsYW5rcyBhcmUgaWdub3JlZC4nLFxuICBdLFxuICBbJ05PVCcsIDEsIDEsICdOT1QodmFsdWUpJywgJ3NjYWxhcicsICdJbnZlcnQgYSBsb2dpY2FsIHZhbHVlLiddLFxuICBbXG4gICAgJ1JPVU5EJyxcbiAgICAyLFxuICAgIDIsXG4gICAgJ1JPVU5EKG51bWJlciwgZGlnaXRzKScsXG4gICAgJ3NjYWxhcicsXG4gICAgJ1JvdW5kIGhhbGZ3YXkgYXdheSBmcm9tIHplcm87IGRpZ2l0cyB0cnVuY2F0ZSB0b3dhcmQgemVyby4nLFxuICBdLFxuICBbJ0FCUycsIDEsIDEsICdBQlMobnVtYmVyKScsICdzY2FsYXInLCAnQWJzb2x1dGUgbnVtZXJpYyB2YWx1ZS4nXSxcbl07XG5leHBvcnQgY29uc3QgZnVuY3Rpb25EZWZpbml0aW9uczogcmVhZG9ubHkgRnVuY3Rpb25EZWZpbml0aW9uW10gPSBPYmplY3QuZnJlZXplKFxuICBkZWZpbml0aW9uc0lucHV0Lm1hcCgoW25hbWUsIG1pbkFyZ3MsIG1heEFyZ3MsIHNpZ25hdHVyZSwgZXZhbHVhdGlvbiwgZGVzY3JpcHRpb25dKSA9PlxuICAgIE9iamVjdC5mcmVlemUoeyBuYW1lLCBtaW5BcmdzLCBtYXhBcmdzLCBzaWduYXR1cmUsIGV2YWx1YXRpb24sIGRlc2NyaXB0aW9uIH0pLFxuICApLFxuKTtcbmNvbnN0IGRlZmluaXRpb25zID0gbmV3IE1hcChmdW5jdGlvbkRlZmluaXRpb25zLm1hcCgoZGVmaW5pdGlvbikgPT4gW2RlZmluaXRpb24ubmFtZSwgZGVmaW5pdGlvbl0pKTtcbmV4cG9ydCBjb25zdCBzdXBwb3J0ZWRGdW5jdGlvbnM6IHJlYWRvbmx5IHN0cmluZ1tdID0gT2JqZWN0LmZyZWV6ZShcbiAgZnVuY3Rpb25EZWZpbml0aW9ucy5tYXAoKHsgbmFtZSB9KSA9PiBuYW1lKSxcbik7XG5leHBvcnQgZnVuY3Rpb24gZnVuY3Rpb25EZWZpbml0aW9uKG5hbWU6IHN0cmluZyk6IEZ1bmN0aW9uRGVmaW5pdGlvbiB8IHVuZGVmaW5lZCB7XG4gIHJldHVybiBkZWZpbml0aW9ucy5nZXQobmFtZSk7XG59XG4iXSwibWFwcGluZ3MiOiJBQVVBLE1BQU0sbUJBRUY7QUFBQSxFQUNGO0FBQUEsSUFDRTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUFBLEVBQ0E7QUFBQSxJQUNFO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQUEsRUFDQTtBQUFBLElBQ0U7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFBQSxFQUNBO0FBQUEsSUFDRTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUFBLEVBQ0EsQ0FBQyxRQUFRLEdBQUcsR0FBRyx5QkFBeUIsUUFBUSwwQ0FBMEM7QUFBQSxFQUMxRjtBQUFBLElBQ0U7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFBQSxFQUNBO0FBQUEsSUFDRTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUFBLEVBQ0EsQ0FBQyxRQUFRLEdBQUcsR0FBRyxnQkFBZ0IsVUFBVSw2Q0FBNkM7QUFBQSxFQUN0RixDQUFDLFNBQVMsR0FBRyxHQUFHLGlCQUFpQixVQUFVLDJDQUEyQztBQUFBLEVBQ3RGO0FBQUEsSUFDRTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUFBLEVBQ0E7QUFBQSxJQUNFO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQUEsRUFDQTtBQUFBLElBQ0U7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFBQSxFQUNBO0FBQUEsSUFDRTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUFBLEVBQ0E7QUFBQSxJQUNFO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQUEsRUFDQTtBQUFBLElBQ0U7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFBQSxFQUNBO0FBQUEsSUFDRTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUFBLEVBQ0E7QUFBQSxJQUNFO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQUEsRUFDQTtBQUFBLElBQ0U7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFBQSxFQUNBO0FBQUEsSUFDRTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUFBLEVBQ0E7QUFBQSxJQUNFO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQUEsRUFDQTtBQUFBLElBQ0U7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFBQSxFQUNBLENBQUMsUUFBUSxHQUFHLEdBQUcsVUFBVSxVQUFVLGdDQUFnQztBQUFBLEVBQ25FLENBQUMsU0FBUyxHQUFHLEdBQUcsV0FBVyxVQUFVLGlDQUFpQztBQUFBLEVBQ3RFO0FBQUEsSUFDRTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUFBLEVBQ0E7QUFBQSxJQUNFO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQUEsRUFDQTtBQUFBLElBQ0U7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFBQSxFQUNBLENBQUMsT0FBTyxHQUFHLEdBQUcsYUFBYSxVQUFVLG1EQUFtRDtBQUFBLEVBQ3hGO0FBQUEsSUFDRTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUFBLEVBQ0EsQ0FBQyxTQUFTLEdBQUcsR0FBRyxlQUFlLFVBQVUsdUNBQXVDO0FBQUEsRUFDaEYsQ0FBQyxTQUFTLEdBQUcsR0FBRyxlQUFlLFVBQVUsdUNBQXVDO0FBQUEsRUFDaEY7QUFBQSxJQUNFO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQUEsRUFDQTtBQUFBLElBQ0U7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFBQSxFQUNBLENBQUMsT0FBTyxHQUFHLEtBQUssbUJBQW1CLGFBQWEscUJBQXFCO0FBQUEsRUFDckUsQ0FBQyxXQUFXLEdBQUcsS0FBSyx1QkFBdUIsYUFBYSx5QkFBeUI7QUFBQSxFQUNqRixDQUFDLE9BQU8sR0FBRyxLQUFLLG1CQUFtQixhQUFhLGtDQUFrQztBQUFBLEVBQ2xGLENBQUMsT0FBTyxHQUFHLEtBQUssbUJBQW1CLGFBQWEsaUNBQWlDO0FBQUEsRUFDakY7QUFBQSxJQUNFO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQUEsRUFDQTtBQUFBLElBQ0U7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFBQSxFQUNBO0FBQUEsSUFDRTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUFBLEVBQ0EsQ0FBQyxXQUFXLEdBQUcsR0FBRyw0QkFBNEIsUUFBUSxzQ0FBc0M7QUFBQSxFQUM1RjtBQUFBLElBQ0U7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFBQSxFQUNBO0FBQUEsSUFDRTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUFBLEVBQ0EsQ0FBQyxPQUFPLEdBQUcsR0FBRyxjQUFjLFVBQVUseUJBQXlCO0FBQUEsRUFDL0Q7QUFBQSxJQUNFO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQUEsRUFDQSxDQUFDLE9BQU8sR0FBRyxHQUFHLGVBQWUsVUFBVSx5QkFBeUI7QUFDbEU7QUFDTyxhQUFNLHNCQUFxRCxPQUFPO0FBQUEsRUFDdkUsaUJBQWlCO0FBQUEsSUFBSSxDQUFDLENBQUMsTUFBTSxTQUFTLFNBQVMsV0FBVyxZQUFZLFdBQVcsTUFDL0UsT0FBTyxPQUFPLEVBQUUsTUFBTSxTQUFTLFNBQVMsV0FBVyxZQUFZLFlBQVksQ0FBQztBQUFBLEVBQzlFO0FBQ0Y7QUFDQSxNQUFNLGNBQWMsSUFBSSxJQUFJLG9CQUFvQixJQUFJLENBQUMsZUFBZSxDQUFDLFdBQVcsTUFBTSxVQUFVLENBQUMsQ0FBQztBQUMzRixhQUFNLHFCQUF3QyxPQUFPO0FBQUEsRUFDMUQsb0JBQW9CLElBQUksQ0FBQyxFQUFFLEtBQUssTUFBTSxJQUFJO0FBQzVDO0FBQ08sZ0JBQVMsbUJBQW1CLE1BQThDO0FBQy9FLFNBQU8sWUFBWSxJQUFJLElBQUk7QUFDN0I7IiwibmFtZXMiOltdfQ==
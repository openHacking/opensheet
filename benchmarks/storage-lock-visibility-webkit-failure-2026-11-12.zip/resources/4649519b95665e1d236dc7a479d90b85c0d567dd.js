import { z } from "/@fs/Volumes/github/private/opensheet/node_modules/.vite/deps/zod.js?v=c95e703c";
import { parseFormula } from "/@fs/Volumes/github/private/opensheet/packages/formula/src/index.ts";
import {
  assert,
  LIMITS,
  rectSchema,
  styleSchema
} from "/@fs/Volumes/github/private/opensheet/packages/core/src/types.ts";
import { transformValidationRange } from "/@fs/Volumes/github/private/opensheet/packages/core/src/validation-range.ts";
import {
  rewriteValidationSheetReferences,
  transformValidationEntries
} from "/@fs/Volumes/github/private/opensheet/packages/core/src/validation-model.ts";
import { abortable, verificationYield } from "/@fs/Volumes/github/private/opensheet/packages/core/src/verification-yield.ts";
const numeric = z.object({
  kind: z.literal("number"),
  operator: z.enum(["eq", "neq", "lt", "lte", "gt", "gte", "between", "notBetween"]),
  first: z.number().finite(),
  second: z.number().finite().optional()
}).strict().superRefine((value, context) => {
  const pair = value.operator === "between" || value.operator === "notBetween";
  if (pair !== (value.second !== void 0) || pair && value.second !== void 0 && value.first > value.second)
    context.addIssue({ code: "custom", message: "Invalid comparison bounds" });
});
const textual = z.object({
  kind: z.literal("text"),
  operator: z.enum(["equals", "notEquals", "contains", "notContains", "startsWith", "endsWith"]),
  value: z.string().max(4096),
  caseSensitive: z.boolean()
}).strict();
const formula = z.object({ kind: z.literal("formula"), expression: z.string().min(1).max(4096) }).strict();
const visualStyle = styleSchema.pick({ bold: true, italic: true, underline: true, color: true, background: true }).strict();
const ruleSchema = z.object({
  id: z.string().min(1).max(100).regex(/^[\w-]+$/).refine((id) => !["__proto__", "constructor", "prototype"].includes(id)),
  range: rectSchema.strict(),
  condition: z.union([numeric, textual, formula]),
  style: visualStyle,
  stopIfTrue: z.boolean()
}).strict();
const MAX_RULES = 1024;
const MAX_TEXT = 1e6;
export function validateConditionalRules(input, rows, columns) {
  assert(
    Number.isInteger(rows) && rows > 0 && rows <= LIMITS.rows && Number.isInteger(columns) && columns > 0 && columns <= LIMITS.columns,
    "INVALID_ARGUMENT",
    "Invalid conditional formatting dimensions"
  );
  assert(
    Array.isArray(input) && input.length <= MAX_RULES,
    "LIMIT_EXCEEDED",
    "Too many conditional formatting rules"
  );
  const seen = /* @__PURE__ */ new Set();
  const validated = [];
  const expressions = /* @__PURE__ */ new Set();
  let text = 0;
  for (const item of input) {
    const parsed = ruleSchema.safeParse(item);
    assert(parsed.success, "INVALID_ARGUMENT", "Invalid conditional formatting rule");
    const rule = parsed.data;
    assert(!seen.has(rule.id), "INVALID_ARGUMENT", "Duplicate conditional formatting rule");
    seen.add(rule.id);
    assert(
      rule.range.startRow < rule.range.endRow && rule.range.startColumn < rule.range.endColumn && rule.range.endRow <= rows && rule.range.endColumn <= columns,
      "INVALID_ARGUMENT",
      "Invalid conditional formatting range"
    );
    assert(
      Object.keys(rule.style).length > 0 && Object.values(rule.style).every((value) => value !== void 0),
      "INVALID_ARGUMENT",
      "Conditional formatting style must not be empty"
    );
    if (rule.condition.kind === "text") text += rule.condition.value.length;
    if (rule.condition.kind === "formula") {
      text += rule.condition.expression.length;
      if (!expressions.has(rule.condition.expression)) {
        try {
          parseFormula(rule.condition.expression);
        } catch {
          assert(false, "INVALID_ARGUMENT", "Invalid conditional formatting formula");
        }
        expressions.add(rule.condition.expression);
      }
    }
    assert(text <= MAX_TEXT, "LIMIT_EXCEEDED", "Conditional formatting text budget exceeded");
    validated.push(rule);
  }
  return structuredClone(validated);
}
function matches(rule, value) {
  const condition = rule.condition;
  assert(
    condition.kind !== "formula",
    "UNSUPPORTED_FEATURE",
    "Conditional formatting formula reader required"
  );
  if (condition.kind === "number") {
    if (typeof value !== "number" || !Number.isFinite(value)) return false;
    switch (condition.operator) {
      case "eq":
        return value === condition.first;
      case "neq":
        return value !== condition.first;
      case "lt":
        return value < condition.first;
      case "lte":
        return value <= condition.first;
      case "gt":
        return value > condition.first;
      case "gte":
        return value >= condition.first;
      case "between":
        return value >= condition.first && value <= condition.second;
      case "notBetween":
        return value < condition.first || value > condition.second;
    }
  }
  if (typeof value !== "string") return false;
  const left = condition.caseSensitive ? value : value.toLowerCase();
  const right = condition.caseSensitive ? condition.value : condition.value.toLowerCase();
  switch (condition.operator) {
    case "equals":
      return left === right;
    case "notEquals":
      return left !== right;
    case "contains":
      return left.includes(right);
    case "notContains":
      return !left.includes(right);
    case "startsWith":
      return left.startsWith(right);
    case "endsWith":
      return left.endsWith(right);
  }
}
function applyVisual(overlay, style) {
  if (overlay.bold === void 0 && style.bold !== void 0) overlay.bold = style.bold;
  if (overlay.italic === void 0 && style.italic !== void 0) overlay.italic = style.italic;
  if (overlay.underline === void 0 && style.underline !== void 0)
    overlay.underline = style.underline;
  if (overlay.color === void 0 && style.color !== void 0) overlay.color = style.color;
  if (overlay.background === void 0 && style.background !== void 0)
    overlay.background = style.background;
}
export function conditionalStyle(rules, row, column, value, base) {
  assert(
    !(value && typeof value === "object" && value.error === "#LIMIT!"),
    "LIMIT_EXCEEDED",
    "Conditional formatting calculation exceeded its work budget"
  );
  assert(
    typeof value !== "string" || value.length <= LIMITS.text,
    "LIMIT_EXCEEDED",
    "Conditional formatting value exceeds text budget"
  );
  assert(
    Number.isInteger(row) && row >= 0 && row < LIMITS.rows && Number.isInteger(column) && column >= 0 && column < LIMITS.columns,
    "INVALID_ARGUMENT",
    "Invalid conditional formatting cell"
  );
  const overlay = {};
  for (const rule of rules) {
    const range = rule.range;
    if (row < range.startRow || row >= range.endRow || column < range.startColumn || column >= range.endColumn || !matches(rule, value))
      continue;
    applyVisual(overlay, rule.style);
    if (rule.stopIfTrue) break;
  }
  return { ...base, ...overlay };
}
export function conditionalViewport(rules, cells) {
  checkViewportWork(rules, cells);
  assert(
    !rules.some((rule) => rule.condition.kind === "formula"),
    "UNSUPPORTED_FEATURE",
    "Conditional formatting formula reader required"
  );
  return cells.map((cell) => conditionalStyle(rules, cell.row, cell.column, cell.value, cell.base));
}
function checkViewportWork(rules, cells) {
  assert(
    Array.isArray(rules) && rules.length <= MAX_RULES && Array.isArray(cells) && cells.length <= 1e4 && rules.length * cells.length <= 1e6,
    "LIMIT_EXCEEDED",
    "Conditional formatting viewport exceeds work budget"
  );
  let textRules = 0;
  let ruleText = 0;
  for (const rule of rules) {
    if (rule.condition.kind === "text") {
      textRules++;
      ruleText += rule.condition.value.length;
    } else if (rule.condition.kind === "formula") ruleText += rule.condition.expression.length;
  }
  let valueText = 0;
  for (const cell of cells) {
    assert(
      !(cell.value && typeof cell.value === "object" && cell.value.error === "#LIMIT!"),
      "LIMIT_EXCEEDED",
      "Conditional formatting calculation exceeded its work budget"
    );
    if (typeof cell.value !== "string") continue;
    assert(
      cell.value.length <= LIMITS.text,
      "LIMIT_EXCEEDED",
      "Conditional formatting value exceeds text budget"
    );
    valueText += cell.value.length;
    assert(
      valueText <= 1e7,
      "LIMIT_EXCEEDED",
      "Conditional formatting viewport exceeds text work budget"
    );
  }
  assert(
    ruleText * cells.length + valueText * textRules <= 1e7,
    "LIMIT_EXCEEDED",
    "Conditional formatting viewport exceeds text work budget"
  );
}
export async function conditionalViewportWithFormulas(input, inputCells, evaluate, signal) {
  signal?.throwIfAborted();
  assert(
    Array.isArray(inputCells) && inputCells.length <= 1e4,
    "LIMIT_EXCEEDED",
    "Conditional formatting viewport exceeds work budget"
  );
  const rules = validateConditionalRules(input, LIMITS.rows, LIMITS.columns);
  checkViewportWork(rules, inputCells);
  signal?.throwIfAborted();
  const cells = structuredClone(inputCells);
  checkViewportWork(rules, cells);
  const checkpoint = verificationYield(signal);
  const results = [];
  let checks = 0;
  for (const cell of cells) {
    assert(
      Number.isInteger(cell.row) && cell.row >= 0 && cell.row < LIMITS.rows && Number.isInteger(cell.column) && cell.column >= 0 && cell.column < LIMITS.columns,
      "INVALID_ARGUMENT",
      "Invalid conditional formatting cell"
    );
    const overlay = {};
    for (const rule of rules) {
      if (++checks % 1024 === 0) await checkpoint();
      signal?.throwIfAborted();
      const range = rule.range;
      if (cell.row < range.startRow || cell.row >= range.endRow || cell.column < range.startColumn || cell.column >= range.endColumn)
        continue;
      let matched;
      if (rule.condition.kind === "formula") {
        assert(
          typeof evaluate === "function",
          "UNSUPPORTED_FEATURE",
          "Conditional formatting formula reader required"
        );
        const result = await abortable(
          evaluate({
            row: cell.row,
            column: cell.column,
            expression: rule.condition.expression,
            rowOffset: cell.row - range.startRow,
            columnOffset: cell.column - range.startColumn
          }),
          signal
        );
        signal?.throwIfAborted();
        assert(
          !(result && typeof result === "object" && result.error === "#LIMIT!"),
          "LIMIT_EXCEEDED",
          "Conditional formatting calculation exceeded its work budget"
        );
        matched = result === true;
      } else matched = matches(rule, cell.value);
      if (!matched) continue;
      applyVisual(overlay, rule.style);
      if (rule.stopIfTrue) break;
    }
    results.push({ ...cell.base, ...overlay });
  }
  return results;
}
export function transformConditionalRules(input, rows, columns, axis, operation, index, count, sheetName, editedSheet) {
  const rules = validateConditionalRules(input, rows, columns);
  if (rules.some((rule) => rule.condition.kind === "formula") || editedSheet) {
    const entries = rules.map((rule) => ({
      id: rule.id,
      range: rule.range,
      rule: rule.condition.kind === "formula" ? {
        kind: "formula",
        expression: rule.condition.expression,
        allowBlank: false,
        policy: "reject"
      } : { kind: "number", operator: "eq", first: 0, allowBlank: false, policy: "reject" }
    }));
    const transformed2 = transformValidationEntries(
      entries,
      rows,
      columns,
      axis,
      operation,
      index,
      count,
      sheetName,
      editedSheet
    );
    const byId = new Map(rules.map((rule) => [rule.id, rule]));
    const output = transformed2.map((entry) => {
      const original = byId.get(entry.id);
      return {
        ...original,
        range: entry.range,
        condition: original.condition.kind === "formula" && entry.rule.kind === "formula" ? { kind: "formula", expression: entry.rule.expression } : original.condition
      };
    });
    const local = !editedSheet || sheetName?.toLowerCase() === editedSheet.name.toLowerCase();
    const delta2 = local ? operation === "insert" ? count : -count : 0;
    return validateConditionalRules(
      output,
      rows + (axis === "row" ? delta2 : 0),
      columns + (axis === "column" ? delta2 : 0)
    );
  }
  const axisLength = axis === "row" ? rows : columns;
  transformValidationRange(
    { startRow: 0, endRow: 1, startColumn: 0, endColumn: 1 },
    axis,
    operation,
    index,
    count,
    axisLength
  );
  const transformed = rules.flatMap((rule) => {
    const range = transformValidationRange(
      rule.range,
      axis,
      operation,
      index,
      count,
      axisLength
    );
    return range ? [{ ...rule, range }] : [];
  });
  const delta = operation === "insert" ? count : -count;
  return validateConditionalRules(
    transformed,
    rows + (axis === "row" ? delta : 0),
    columns + (axis === "column" ? delta : 0)
  );
}
export function rewriteConditionalSheetReferences(input, rows, columns, oldName, newName) {
  const rules = validateConditionalRules(input, rows, columns);
  const entries = rules.flatMap(
    (rule) => rule.condition.kind === "formula" ? [
      {
        id: rule.id,
        range: rule.range,
        rule: {
          kind: "formula",
          expression: rule.condition.expression,
          allowBlank: false,
          policy: "reject"
        }
      }
    ] : []
  );
  const rewritten = rewriteValidationSheetReferences(entries, rows, columns, oldName, newName);
  const expressions = new Map(rewritten.map((entry) => [entry.id, entry.rule]));
  for (const rule of rules) {
    if (rule.condition.kind !== "formula") continue;
    const rewrittenRule = expressions.get(rule.id);
    assert(rewrittenRule?.kind === "formula", "INVALID_ARGUMENT", "Missing rewritten formula");
    rule.condition.expression = rewrittenRule.expression;
  }
  return validateConditionalRules(rules, rows, columns);
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbmRpdGlvbmFsLWZvcm1hdC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB6IH0gZnJvbSAnem9kJztcbmltcG9ydCB7IHBhcnNlRm9ybXVsYSB9IGZyb20gJ0BvcGVuc2hlZXRqcy9mb3JtdWxhJztcbmltcG9ydCB7XG4gIGFzc2VydCxcbiAgTElNSVRTLFxuICByZWN0U2NoZW1hLFxuICBzdHlsZVNjaGVtYSxcbiAgdHlwZSBDZWxsU3R5bGUsXG4gIHR5cGUgQ2VsbFZhbHVlLFxuICB0eXBlIFJlY3QsXG59IGZyb20gJy4vdHlwZXMuanMnO1xuaW1wb3J0IHsgdHJhbnNmb3JtVmFsaWRhdGlvblJhbmdlIH0gZnJvbSAnLi92YWxpZGF0aW9uLXJhbmdlLmpzJztcbmltcG9ydCB7XG4gIHJld3JpdGVWYWxpZGF0aW9uU2hlZXRSZWZlcmVuY2VzLFxuICB0cmFuc2Zvcm1WYWxpZGF0aW9uRW50cmllcyxcbn0gZnJvbSAnLi92YWxpZGF0aW9uLW1vZGVsLmpzJztcbmltcG9ydCB7IGFib3J0YWJsZSwgdmVyaWZpY2F0aW9uWWllbGQgfSBmcm9tICcuL3ZlcmlmaWNhdGlvbi15aWVsZC5qcyc7XG5cbi8vIEludGVybmFsIG1vZGVsIG9ubHkuIEEgcGVyc2lzdGVkIHNjaGVtYSwgY29tbWFuZHMsIGNhbGN1bGF0ZWQtdmFsdWUgcGx1bWJpbmcgYW5kIFVJXG4vLyBhcmUgcHJlcmVxdWlzaXRlcyBiZWZvcmUgY29uZGl0aW9uYWwgZm9ybWF0dGluZyBjYW4gYmUgZXhwb3NlZCBhcyBhIGZlYXR1cmUuXG5jb25zdCBudW1lcmljID0gelxuICAub2JqZWN0KHtcbiAgICBraW5kOiB6LmxpdGVyYWwoJ251bWJlcicpLFxuICAgIG9wZXJhdG9yOiB6LmVudW0oWydlcScsICduZXEnLCAnbHQnLCAnbHRlJywgJ2d0JywgJ2d0ZScsICdiZXR3ZWVuJywgJ25vdEJldHdlZW4nXSksXG4gICAgZmlyc3Q6IHoubnVtYmVyKCkuZmluaXRlKCksXG4gICAgc2Vjb25kOiB6Lm51bWJlcigpLmZpbml0ZSgpLm9wdGlvbmFsKCksXG4gIH0pXG4gIC5zdHJpY3QoKVxuICAuc3VwZXJSZWZpbmUoKHZhbHVlLCBjb250ZXh0KSA9PiB7XG4gICAgY29uc3QgcGFpciA9IHZhbHVlLm9wZXJhdG9yID09PSAnYmV0d2VlbicgfHwgdmFsdWUub3BlcmF0b3IgPT09ICdub3RCZXR3ZWVuJztcbiAgICBpZiAoXG4gICAgICBwYWlyICE9PSAodmFsdWUuc2Vjb25kICE9PSB1bmRlZmluZWQpIHx8XG4gICAgICAocGFpciAmJiB2YWx1ZS5zZWNvbmQgIT09IHVuZGVmaW5lZCAmJiB2YWx1ZS5maXJzdCA+IHZhbHVlLnNlY29uZClcbiAgICApXG4gICAgICBjb250ZXh0LmFkZElzc3VlKHsgY29kZTogJ2N1c3RvbScsIG1lc3NhZ2U6ICdJbnZhbGlkIGNvbXBhcmlzb24gYm91bmRzJyB9KTtcbiAgfSk7XG5jb25zdCB0ZXh0dWFsID0gelxuICAub2JqZWN0KHtcbiAgICBraW5kOiB6LmxpdGVyYWwoJ3RleHQnKSxcbiAgICBvcGVyYXRvcjogei5lbnVtKFsnZXF1YWxzJywgJ25vdEVxdWFscycsICdjb250YWlucycsICdub3RDb250YWlucycsICdzdGFydHNXaXRoJywgJ2VuZHNXaXRoJ10pLFxuICAgIHZhbHVlOiB6LnN0cmluZygpLm1heCg0MDk2KSxcbiAgICBjYXNlU2Vuc2l0aXZlOiB6LmJvb2xlYW4oKSxcbiAgfSlcbiAgLnN0cmljdCgpO1xuY29uc3QgZm9ybXVsYSA9IHpcbiAgLm9iamVjdCh7IGtpbmQ6IHoubGl0ZXJhbCgnZm9ybXVsYScpLCBleHByZXNzaW9uOiB6LnN0cmluZygpLm1pbigxKS5tYXgoNDA5NikgfSlcbiAgLnN0cmljdCgpO1xuY29uc3QgdmlzdWFsU3R5bGUgPSBzdHlsZVNjaGVtYVxuICAucGljayh7IGJvbGQ6IHRydWUsIGl0YWxpYzogdHJ1ZSwgdW5kZXJsaW5lOiB0cnVlLCBjb2xvcjogdHJ1ZSwgYmFja2dyb3VuZDogdHJ1ZSB9KVxuICAuc3RyaWN0KCk7XG5jb25zdCBydWxlU2NoZW1hID0gelxuICAub2JqZWN0KHtcbiAgICBpZDogelxuICAgICAgLnN0cmluZygpXG4gICAgICAubWluKDEpXG4gICAgICAubWF4KDEwMClcbiAgICAgIC5yZWdleCgvXltcXHctXSskLylcbiAgICAgIC5yZWZpbmUoKGlkKSA9PiAhWydfX3Byb3RvX18nLCAnY29uc3RydWN0b3InLCAncHJvdG90eXBlJ10uaW5jbHVkZXMoaWQpKSxcbiAgICByYW5nZTogcmVjdFNjaGVtYS5zdHJpY3QoKSxcbiAgICBjb25kaXRpb246IHoudW5pb24oW251bWVyaWMsIHRleHR1YWwsIGZvcm11bGFdKSxcbiAgICBzdHlsZTogdmlzdWFsU3R5bGUsXG4gICAgc3RvcElmVHJ1ZTogei5ib29sZWFuKCksXG4gIH0pXG4gIC5zdHJpY3QoKTtcbmV4cG9ydCB0eXBlIENvbmRpdGlvbmFsUnVsZSA9IHouaW5mZXI8dHlwZW9mIHJ1bGVTY2hlbWE+O1xuY29uc3QgTUFYX1JVTEVTID0gMTAyNDtcbmNvbnN0IE1BWF9URVhUID0gMV8wMDBfMDAwO1xuXG4vKiogVmFsaWRhdGUgYW5kIGRldGFjaCBydWxlczsgYXJyYXkgb3JkZXIgaXMgcHJpb3JpdHksIGhpZ2hlc3QgZmlyc3QuICovXG5leHBvcnQgZnVuY3Rpb24gdmFsaWRhdGVDb25kaXRpb25hbFJ1bGVzKFxuICBpbnB1dDogdW5rbm93bixcbiAgcm93czogbnVtYmVyLFxuICBjb2x1bW5zOiBudW1iZXIsXG4pOiBDb25kaXRpb25hbFJ1bGVbXSB7XG4gIGFzc2VydChcbiAgICBOdW1iZXIuaXNJbnRlZ2VyKHJvd3MpICYmXG4gICAgICByb3dzID4gMCAmJlxuICAgICAgcm93cyA8PSBMSU1JVFMucm93cyAmJlxuICAgICAgTnVtYmVyLmlzSW50ZWdlcihjb2x1bW5zKSAmJlxuICAgICAgY29sdW1ucyA+IDAgJiZcbiAgICAgIGNvbHVtbnMgPD0gTElNSVRTLmNvbHVtbnMsXG4gICAgJ0lOVkFMSURfQVJHVU1FTlQnLFxuICAgICdJbnZhbGlkIGNvbmRpdGlvbmFsIGZvcm1hdHRpbmcgZGltZW5zaW9ucycsXG4gICk7XG4gIGFzc2VydChcbiAgICBBcnJheS5pc0FycmF5KGlucHV0KSAmJiBpbnB1dC5sZW5ndGggPD0gTUFYX1JVTEVTLFxuICAgICdMSU1JVF9FWENFRURFRCcsXG4gICAgJ1RvbyBtYW55IGNvbmRpdGlvbmFsIGZvcm1hdHRpbmcgcnVsZXMnLFxuICApO1xuICBjb25zdCBzZWVuID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGNvbnN0IHZhbGlkYXRlZDogQ29uZGl0aW9uYWxSdWxlW10gPSBbXTtcbiAgY29uc3QgZXhwcmVzc2lvbnMgPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgbGV0IHRleHQgPSAwO1xuICBmb3IgKGNvbnN0IGl0ZW0gb2YgaW5wdXQpIHtcbiAgICBjb25zdCBwYXJzZWQgPSBydWxlU2NoZW1hLnNhZmVQYXJzZShpdGVtKTtcbiAgICBhc3NlcnQocGFyc2VkLnN1Y2Nlc3MsICdJTlZBTElEX0FSR1VNRU5UJywgJ0ludmFsaWQgY29uZGl0aW9uYWwgZm9ybWF0dGluZyBydWxlJyk7XG4gICAgY29uc3QgcnVsZSA9IHBhcnNlZC5kYXRhO1xuICAgIGFzc2VydCghc2Vlbi5oYXMocnVsZS5pZCksICdJTlZBTElEX0FSR1VNRU5UJywgJ0R1cGxpY2F0ZSBjb25kaXRpb25hbCBmb3JtYXR0aW5nIHJ1bGUnKTtcbiAgICBzZWVuLmFkZChydWxlLmlkKTtcbiAgICBhc3NlcnQoXG4gICAgICBydWxlLnJhbmdlLnN0YXJ0Um93IDwgcnVsZS5yYW5nZS5lbmRSb3cgJiZcbiAgICAgICAgcnVsZS5yYW5nZS5zdGFydENvbHVtbiA8IHJ1bGUucmFuZ2UuZW5kQ29sdW1uICYmXG4gICAgICAgIHJ1bGUucmFuZ2UuZW5kUm93IDw9IHJvd3MgJiZcbiAgICAgICAgcnVsZS5yYW5nZS5lbmRDb2x1bW4gPD0gY29sdW1ucyxcbiAgICAgICdJTlZBTElEX0FSR1VNRU5UJyxcbiAgICAgICdJbnZhbGlkIGNvbmRpdGlvbmFsIGZvcm1hdHRpbmcgcmFuZ2UnLFxuICAgICk7XG4gICAgYXNzZXJ0KFxuICAgICAgT2JqZWN0LmtleXMocnVsZS5zdHlsZSkubGVuZ3RoID4gMCAmJlxuICAgICAgICBPYmplY3QudmFsdWVzKHJ1bGUuc3R5bGUpLmV2ZXJ5KCh2YWx1ZSkgPT4gdmFsdWUgIT09IHVuZGVmaW5lZCksXG4gICAgICAnSU5WQUxJRF9BUkdVTUVOVCcsXG4gICAgICAnQ29uZGl0aW9uYWwgZm9ybWF0dGluZyBzdHlsZSBtdXN0IG5vdCBiZSBlbXB0eScsXG4gICAgKTtcbiAgICBpZiAocnVsZS5jb25kaXRpb24ua2luZCA9PT0gJ3RleHQnKSB0ZXh0ICs9IHJ1bGUuY29uZGl0aW9uLnZhbHVlLmxlbmd0aDtcbiAgICBpZiAocnVsZS5jb25kaXRpb24ua2luZCA9PT0gJ2Zvcm11bGEnKSB7XG4gICAgICB0ZXh0ICs9IHJ1bGUuY29uZGl0aW9uLmV4cHJlc3Npb24ubGVuZ3RoO1xuICAgICAgaWYgKCFleHByZXNzaW9ucy5oYXMocnVsZS5jb25kaXRpb24uZXhwcmVzc2lvbikpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBwYXJzZUZvcm11bGEocnVsZS5jb25kaXRpb24uZXhwcmVzc2lvbik7XG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgIGFzc2VydChmYWxzZSwgJ0lOVkFMSURfQVJHVU1FTlQnLCAnSW52YWxpZCBjb25kaXRpb25hbCBmb3JtYXR0aW5nIGZvcm11bGEnKTtcbiAgICAgICAgfVxuICAgICAgICBleHByZXNzaW9ucy5hZGQocnVsZS5jb25kaXRpb24uZXhwcmVzc2lvbik7XG4gICAgICB9XG4gICAgfVxuICAgIGFzc2VydCh0ZXh0IDw9IE1BWF9URVhULCAnTElNSVRfRVhDRUVERUQnLCAnQ29uZGl0aW9uYWwgZm9ybWF0dGluZyB0ZXh0IGJ1ZGdldCBleGNlZWRlZCcpO1xuICAgIHZhbGlkYXRlZC5wdXNoKHJ1bGUpO1xuICB9XG4gIHJldHVybiBzdHJ1Y3R1cmVkQ2xvbmUodmFsaWRhdGVkKTtcbn1cblxuZnVuY3Rpb24gbWF0Y2hlcyhydWxlOiBDb25kaXRpb25hbFJ1bGUsIHZhbHVlOiBDZWxsVmFsdWUpOiBib29sZWFuIHtcbiAgY29uc3QgY29uZGl0aW9uID0gcnVsZS5jb25kaXRpb247XG4gIGFzc2VydChcbiAgICBjb25kaXRpb24ua2luZCAhPT0gJ2Zvcm11bGEnLFxuICAgICdVTlNVUFBPUlRFRF9GRUFUVVJFJyxcbiAgICAnQ29uZGl0aW9uYWwgZm9ybWF0dGluZyBmb3JtdWxhIHJlYWRlciByZXF1aXJlZCcsXG4gICk7XG4gIGlmIChjb25kaXRpb24ua2luZCA9PT0gJ251bWJlcicpIHtcbiAgICBpZiAodHlwZW9mIHZhbHVlICE9PSAnbnVtYmVyJyB8fCAhTnVtYmVyLmlzRmluaXRlKHZhbHVlKSkgcmV0dXJuIGZhbHNlO1xuICAgIHN3aXRjaCAoY29uZGl0aW9uLm9wZXJhdG9yKSB7XG4gICAgICBjYXNlICdlcSc6XG4gICAgICAgIHJldHVybiB2YWx1ZSA9PT0gY29uZGl0aW9uLmZpcnN0O1xuICAgICAgY2FzZSAnbmVxJzpcbiAgICAgICAgcmV0dXJuIHZhbHVlICE9PSBjb25kaXRpb24uZmlyc3Q7XG4gICAgICBjYXNlICdsdCc6XG4gICAgICAgIHJldHVybiB2YWx1ZSA8IGNvbmRpdGlvbi5maXJzdDtcbiAgICAgIGNhc2UgJ2x0ZSc6XG4gICAgICAgIHJldHVybiB2YWx1ZSA8PSBjb25kaXRpb24uZmlyc3Q7XG4gICAgICBjYXNlICdndCc6XG4gICAgICAgIHJldHVybiB2YWx1ZSA+IGNvbmRpdGlvbi5maXJzdDtcbiAgICAgIGNhc2UgJ2d0ZSc6XG4gICAgICAgIHJldHVybiB2YWx1ZSA+PSBjb25kaXRpb24uZmlyc3Q7XG4gICAgICBjYXNlICdiZXR3ZWVuJzpcbiAgICAgICAgcmV0dXJuIHZhbHVlID49IGNvbmRpdGlvbi5maXJzdCAmJiB2YWx1ZSA8PSBjb25kaXRpb24uc2Vjb25kITtcbiAgICAgIGNhc2UgJ25vdEJldHdlZW4nOlxuICAgICAgICByZXR1cm4gdmFsdWUgPCBjb25kaXRpb24uZmlyc3QgfHwgdmFsdWUgPiBjb25kaXRpb24uc2Vjb25kITtcbiAgICB9XG4gIH1cbiAgaWYgKHR5cGVvZiB2YWx1ZSAhPT0gJ3N0cmluZycpIHJldHVybiBmYWxzZTtcbiAgY29uc3QgbGVmdCA9IGNvbmRpdGlvbi5jYXNlU2Vuc2l0aXZlID8gdmFsdWUgOiB2YWx1ZS50b0xvd2VyQ2FzZSgpO1xuICBjb25zdCByaWdodCA9IGNvbmRpdGlvbi5jYXNlU2Vuc2l0aXZlID8gY29uZGl0aW9uLnZhbHVlIDogY29uZGl0aW9uLnZhbHVlLnRvTG93ZXJDYXNlKCk7XG4gIHN3aXRjaCAoY29uZGl0aW9uLm9wZXJhdG9yKSB7XG4gICAgY2FzZSAnZXF1YWxzJzpcbiAgICAgIHJldHVybiBsZWZ0ID09PSByaWdodDtcbiAgICBjYXNlICdub3RFcXVhbHMnOlxuICAgICAgcmV0dXJuIGxlZnQgIT09IHJpZ2h0O1xuICAgIGNhc2UgJ2NvbnRhaW5zJzpcbiAgICAgIHJldHVybiBsZWZ0LmluY2x1ZGVzKHJpZ2h0KTtcbiAgICBjYXNlICdub3RDb250YWlucyc6XG4gICAgICByZXR1cm4gIWxlZnQuaW5jbHVkZXMocmlnaHQpO1xuICAgIGNhc2UgJ3N0YXJ0c1dpdGgnOlxuICAgICAgcmV0dXJuIGxlZnQuc3RhcnRzV2l0aChyaWdodCk7XG4gICAgY2FzZSAnZW5kc1dpdGgnOlxuICAgICAgcmV0dXJuIGxlZnQuZW5kc1dpdGgocmlnaHQpO1xuICB9XG59XG5cbmZ1bmN0aW9uIGFwcGx5VmlzdWFsKG92ZXJsYXk6IENlbGxTdHlsZSwgc3R5bGU6IENvbmRpdGlvbmFsUnVsZVsnc3R5bGUnXSkge1xuICBpZiAob3ZlcmxheS5ib2xkID09PSB1bmRlZmluZWQgJiYgc3R5bGUuYm9sZCAhPT0gdW5kZWZpbmVkKSBvdmVybGF5LmJvbGQgPSBzdHlsZS5ib2xkO1xuICBpZiAob3ZlcmxheS5pdGFsaWMgPT09IHVuZGVmaW5lZCAmJiBzdHlsZS5pdGFsaWMgIT09IHVuZGVmaW5lZCkgb3ZlcmxheS5pdGFsaWMgPSBzdHlsZS5pdGFsaWM7XG4gIGlmIChvdmVybGF5LnVuZGVybGluZSA9PT0gdW5kZWZpbmVkICYmIHN0eWxlLnVuZGVybGluZSAhPT0gdW5kZWZpbmVkKVxuICAgIG92ZXJsYXkudW5kZXJsaW5lID0gc3R5bGUudW5kZXJsaW5lO1xuICBpZiAob3ZlcmxheS5jb2xvciA9PT0gdW5kZWZpbmVkICYmIHN0eWxlLmNvbG9yICE9PSB1bmRlZmluZWQpIG92ZXJsYXkuY29sb3IgPSBzdHlsZS5jb2xvcjtcbiAgaWYgKG92ZXJsYXkuYmFja2dyb3VuZCA9PT0gdW5kZWZpbmVkICYmIHN0eWxlLmJhY2tncm91bmQgIT09IHVuZGVmaW5lZClcbiAgICBvdmVybGF5LmJhY2tncm91bmQgPSBzdHlsZS5iYWNrZ3JvdW5kO1xufVxuXG4vKiogUmVzb2x2ZSBvbmx5IHZpc3VhbCBvdmVycmlkZXMgd2l0aG91dCBtdXRhdGluZyB0aGUgYmFzZSBzdHlsZSBvciBydWxlcy4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjb25kaXRpb25hbFN0eWxlKFxuICBydWxlczogcmVhZG9ubHkgQ29uZGl0aW9uYWxSdWxlW10sXG4gIHJvdzogbnVtYmVyLFxuICBjb2x1bW46IG51bWJlcixcbiAgdmFsdWU6IENlbGxWYWx1ZSxcbiAgYmFzZTogQ2VsbFN0eWxlLFxuKTogQ2VsbFN0eWxlIHtcbiAgYXNzZXJ0KFxuICAgICEodmFsdWUgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZS5lcnJvciA9PT0gJyNMSU1JVCEnKSxcbiAgICAnTElNSVRfRVhDRUVERUQnLFxuICAgICdDb25kaXRpb25hbCBmb3JtYXR0aW5nIGNhbGN1bGF0aW9uIGV4Y2VlZGVkIGl0cyB3b3JrIGJ1ZGdldCcsXG4gICk7XG4gIGFzc2VydChcbiAgICB0eXBlb2YgdmFsdWUgIT09ICdzdHJpbmcnIHx8IHZhbHVlLmxlbmd0aCA8PSBMSU1JVFMudGV4dCxcbiAgICAnTElNSVRfRVhDRUVERUQnLFxuICAgICdDb25kaXRpb25hbCBmb3JtYXR0aW5nIHZhbHVlIGV4Y2VlZHMgdGV4dCBidWRnZXQnLFxuICApO1xuICBhc3NlcnQoXG4gICAgTnVtYmVyLmlzSW50ZWdlcihyb3cpICYmXG4gICAgICByb3cgPj0gMCAmJlxuICAgICAgcm93IDwgTElNSVRTLnJvd3MgJiZcbiAgICAgIE51bWJlci5pc0ludGVnZXIoY29sdW1uKSAmJlxuICAgICAgY29sdW1uID49IDAgJiZcbiAgICAgIGNvbHVtbiA8IExJTUlUUy5jb2x1bW5zLFxuICAgICdJTlZBTElEX0FSR1VNRU5UJyxcbiAgICAnSW52YWxpZCBjb25kaXRpb25hbCBmb3JtYXR0aW5nIGNlbGwnLFxuICApO1xuICBjb25zdCBvdmVybGF5OiBDZWxsU3R5bGUgPSB7fTtcbiAgZm9yIChjb25zdCBydWxlIG9mIHJ1bGVzKSB7XG4gICAgY29uc3QgcmFuZ2UgPSBydWxlLnJhbmdlO1xuICAgIGlmIChcbiAgICAgIHJvdyA8IHJhbmdlLnN0YXJ0Um93IHx8XG4gICAgICByb3cgPj0gcmFuZ2UuZW5kUm93IHx8XG4gICAgICBjb2x1bW4gPCByYW5nZS5zdGFydENvbHVtbiB8fFxuICAgICAgY29sdW1uID49IHJhbmdlLmVuZENvbHVtbiB8fFxuICAgICAgIW1hdGNoZXMocnVsZSwgdmFsdWUpXG4gICAgKVxuICAgICAgY29udGludWU7XG4gICAgYXBwbHlWaXN1YWwob3ZlcmxheSwgcnVsZS5zdHlsZSk7XG4gICAgaWYgKHJ1bGUuc3RvcElmVHJ1ZSkgYnJlYWs7XG4gIH1cbiAgcmV0dXJuIHsgLi4uYmFzZSwgLi4ub3ZlcmxheSB9O1xufVxuXG4vKiogRXZhbHVhdGUgYSBib3VuZGVkIHNldCBvZiBhbHJlYWR5LWxvYWRlZCBjZWxsczsgY2FsbGVycyBzdXBwbHkgY2FsY3VsYXRlZCB2YWx1ZXMuICovXG5leHBvcnQgZnVuY3Rpb24gY29uZGl0aW9uYWxWaWV3cG9ydChcbiAgcnVsZXM6IHJlYWRvbmx5IENvbmRpdGlvbmFsUnVsZVtdLFxuICBjZWxsczogcmVhZG9ubHkgeyByb3c6IG51bWJlcjsgY29sdW1uOiBudW1iZXI7IHZhbHVlOiBDZWxsVmFsdWU7IGJhc2U6IENlbGxTdHlsZSB9W10sXG4pOiBDZWxsU3R5bGVbXSB7XG4gIGNoZWNrVmlld3BvcnRXb3JrKHJ1bGVzLCBjZWxscyk7XG4gIGFzc2VydChcbiAgICAhcnVsZXMuc29tZSgocnVsZSkgPT4gcnVsZS5jb25kaXRpb24ua2luZCA9PT0gJ2Zvcm11bGEnKSxcbiAgICAnVU5TVVBQT1JURURfRkVBVFVSRScsXG4gICAgJ0NvbmRpdGlvbmFsIGZvcm1hdHRpbmcgZm9ybXVsYSByZWFkZXIgcmVxdWlyZWQnLFxuICApO1xuICByZXR1cm4gY2VsbHMubWFwKChjZWxsKSA9PiBjb25kaXRpb25hbFN0eWxlKHJ1bGVzLCBjZWxsLnJvdywgY2VsbC5jb2x1bW4sIGNlbGwudmFsdWUsIGNlbGwuYmFzZSkpO1xufVxuXG50eXBlIFZpZXdDZWxsID0geyByb3c6IG51bWJlcjsgY29sdW1uOiBudW1iZXI7IHZhbHVlOiBDZWxsVmFsdWU7IGJhc2U6IENlbGxTdHlsZSB9O1xudHlwZSBGb3JtdWxhUmVxdWVzdCA9IHtcbiAgcm93OiBudW1iZXI7XG4gIGNvbHVtbjogbnVtYmVyO1xuICBleHByZXNzaW9uOiBzdHJpbmc7XG4gIHJvd09mZnNldDogbnVtYmVyO1xuICBjb2x1bW5PZmZzZXQ6IG51bWJlcjtcbn07XG5cbmZ1bmN0aW9uIGNoZWNrVmlld3BvcnRXb3JrKHJ1bGVzOiByZWFkb25seSBDb25kaXRpb25hbFJ1bGVbXSwgY2VsbHM6IHJlYWRvbmx5IFZpZXdDZWxsW10pIHtcbiAgYXNzZXJ0KFxuICAgIEFycmF5LmlzQXJyYXkocnVsZXMpICYmXG4gICAgICBydWxlcy5sZW5ndGggPD0gTUFYX1JVTEVTICYmXG4gICAgICBBcnJheS5pc0FycmF5KGNlbGxzKSAmJlxuICAgICAgY2VsbHMubGVuZ3RoIDw9IDEwXzAwMCAmJlxuICAgICAgcnVsZXMubGVuZ3RoICogY2VsbHMubGVuZ3RoIDw9IDFfMDAwXzAwMCxcbiAgICAnTElNSVRfRVhDRUVERUQnLFxuICAgICdDb25kaXRpb25hbCBmb3JtYXR0aW5nIHZpZXdwb3J0IGV4Y2VlZHMgd29yayBidWRnZXQnLFxuICApO1xuICBsZXQgdGV4dFJ1bGVzID0gMDtcbiAgbGV0IHJ1bGVUZXh0ID0gMDtcbiAgZm9yIChjb25zdCBydWxlIG9mIHJ1bGVzKSB7XG4gICAgaWYgKHJ1bGUuY29uZGl0aW9uLmtpbmQgPT09ICd0ZXh0Jykge1xuICAgICAgdGV4dFJ1bGVzKys7XG4gICAgICBydWxlVGV4dCArPSBydWxlLmNvbmRpdGlvbi52YWx1ZS5sZW5ndGg7XG4gICAgfSBlbHNlIGlmIChydWxlLmNvbmRpdGlvbi5raW5kID09PSAnZm9ybXVsYScpIHJ1bGVUZXh0ICs9IHJ1bGUuY29uZGl0aW9uLmV4cHJlc3Npb24ubGVuZ3RoO1xuICB9XG4gIGxldCB2YWx1ZVRleHQgPSAwO1xuICBmb3IgKGNvbnN0IGNlbGwgb2YgY2VsbHMpIHtcbiAgICBhc3NlcnQoXG4gICAgICAhKGNlbGwudmFsdWUgJiYgdHlwZW9mIGNlbGwudmFsdWUgPT09ICdvYmplY3QnICYmIGNlbGwudmFsdWUuZXJyb3IgPT09ICcjTElNSVQhJyksXG4gICAgICAnTElNSVRfRVhDRUVERUQnLFxuICAgICAgJ0NvbmRpdGlvbmFsIGZvcm1hdHRpbmcgY2FsY3VsYXRpb24gZXhjZWVkZWQgaXRzIHdvcmsgYnVkZ2V0JyxcbiAgICApO1xuICAgIGlmICh0eXBlb2YgY2VsbC52YWx1ZSAhPT0gJ3N0cmluZycpIGNvbnRpbnVlO1xuICAgIGFzc2VydChcbiAgICAgIGNlbGwudmFsdWUubGVuZ3RoIDw9IExJTUlUUy50ZXh0LFxuICAgICAgJ0xJTUlUX0VYQ0VFREVEJyxcbiAgICAgICdDb25kaXRpb25hbCBmb3JtYXR0aW5nIHZhbHVlIGV4Y2VlZHMgdGV4dCBidWRnZXQnLFxuICAgICk7XG4gICAgdmFsdWVUZXh0ICs9IGNlbGwudmFsdWUubGVuZ3RoO1xuICAgIGFzc2VydChcbiAgICAgIHZhbHVlVGV4dCA8PSAxMF8wMDBfMDAwLFxuICAgICAgJ0xJTUlUX0VYQ0VFREVEJyxcbiAgICAgICdDb25kaXRpb25hbCBmb3JtYXR0aW5nIHZpZXdwb3J0IGV4Y2VlZHMgdGV4dCB3b3JrIGJ1ZGdldCcsXG4gICAgKTtcbiAgfVxuICBhc3NlcnQoXG4gICAgcnVsZVRleHQgKiBjZWxscy5sZW5ndGggKyB2YWx1ZVRleHQgKiB0ZXh0UnVsZXMgPD0gMTBfMDAwXzAwMCxcbiAgICAnTElNSVRfRVhDRUVERUQnLFxuICAgICdDb25kaXRpb25hbCBmb3JtYXR0aW5nIHZpZXdwb3J0IGV4Y2VlZHMgdGV4dCB3b3JrIGJ1ZGdldCcsXG4gICk7XG59XG5cbi8qKiBDYWxjdWxhdGUgYWdhaW5zdCBhIGNhbGxlci1vd25lZCBpbW11dGFibGUgcmV2aXNpb24uIE5vIHBhcnRpYWwgcmVzdWx0IGlzIHJldHVybmVkIG9uIGZhaWx1cmUuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY29uZGl0aW9uYWxWaWV3cG9ydFdpdGhGb3JtdWxhcyhcbiAgaW5wdXQ6IHJlYWRvbmx5IENvbmRpdGlvbmFsUnVsZVtdLFxuICBpbnB1dENlbGxzOiByZWFkb25seSBWaWV3Q2VsbFtdLFxuICBldmFsdWF0ZTogKHJlcXVlc3Q6IEZvcm11bGFSZXF1ZXN0KSA9PiBQcm9taXNlPENlbGxWYWx1ZT4sXG4gIHNpZ25hbD86IEFib3J0U2lnbmFsLFxuKTogUHJvbWlzZTxDZWxsU3R5bGVbXT4ge1xuICBzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG4gIGFzc2VydChcbiAgICBBcnJheS5pc0FycmF5KGlucHV0Q2VsbHMpICYmIGlucHV0Q2VsbHMubGVuZ3RoIDw9IDEwXzAwMCxcbiAgICAnTElNSVRfRVhDRUVERUQnLFxuICAgICdDb25kaXRpb25hbCBmb3JtYXR0aW5nIHZpZXdwb3J0IGV4Y2VlZHMgd29yayBidWRnZXQnLFxuICApO1xuICBjb25zdCBydWxlcyA9IHZhbGlkYXRlQ29uZGl0aW9uYWxSdWxlcyhpbnB1dCwgTElNSVRTLnJvd3MsIExJTUlUUy5jb2x1bW5zKTtcbiAgY2hlY2tWaWV3cG9ydFdvcmsocnVsZXMsIGlucHV0Q2VsbHMpO1xuICBzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG4gIGNvbnN0IGNlbGxzID0gc3RydWN0dXJlZENsb25lKGlucHV0Q2VsbHMpO1xuICBjaGVja1ZpZXdwb3J0V29yayhydWxlcywgY2VsbHMpO1xuICBjb25zdCBjaGVja3BvaW50ID0gdmVyaWZpY2F0aW9uWWllbGQoc2lnbmFsKTtcbiAgY29uc3QgcmVzdWx0czogQ2VsbFN0eWxlW10gPSBbXTtcbiAgbGV0IGNoZWNrcyA9IDA7XG4gIGZvciAoY29uc3QgY2VsbCBvZiBjZWxscykge1xuICAgIGFzc2VydChcbiAgICAgIE51bWJlci5pc0ludGVnZXIoY2VsbC5yb3cpICYmXG4gICAgICAgIGNlbGwucm93ID49IDAgJiZcbiAgICAgICAgY2VsbC5yb3cgPCBMSU1JVFMucm93cyAmJlxuICAgICAgICBOdW1iZXIuaXNJbnRlZ2VyKGNlbGwuY29sdW1uKSAmJlxuICAgICAgICBjZWxsLmNvbHVtbiA+PSAwICYmXG4gICAgICAgIGNlbGwuY29sdW1uIDwgTElNSVRTLmNvbHVtbnMsXG4gICAgICAnSU5WQUxJRF9BUkdVTUVOVCcsXG4gICAgICAnSW52YWxpZCBjb25kaXRpb25hbCBmb3JtYXR0aW5nIGNlbGwnLFxuICAgICk7XG4gICAgY29uc3Qgb3ZlcmxheTogQ2VsbFN0eWxlID0ge307XG4gICAgZm9yIChjb25zdCBydWxlIG9mIHJ1bGVzKSB7XG4gICAgICBpZiAoKytjaGVja3MgJSAxMDI0ID09PSAwKSBhd2FpdCBjaGVja3BvaW50KCk7XG4gICAgICBzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG4gICAgICBjb25zdCByYW5nZSA9IHJ1bGUucmFuZ2U7XG4gICAgICBpZiAoXG4gICAgICAgIGNlbGwucm93IDwgcmFuZ2Uuc3RhcnRSb3cgfHxcbiAgICAgICAgY2VsbC5yb3cgPj0gcmFuZ2UuZW5kUm93IHx8XG4gICAgICAgIGNlbGwuY29sdW1uIDwgcmFuZ2Uuc3RhcnRDb2x1bW4gfHxcbiAgICAgICAgY2VsbC5jb2x1bW4gPj0gcmFuZ2UuZW5kQ29sdW1uXG4gICAgICApXG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgbGV0IG1hdGNoZWQ6IGJvb2xlYW47XG4gICAgICBpZiAocnVsZS5jb25kaXRpb24ua2luZCA9PT0gJ2Zvcm11bGEnKSB7XG4gICAgICAgIGFzc2VydChcbiAgICAgICAgICB0eXBlb2YgZXZhbHVhdGUgPT09ICdmdW5jdGlvbicsXG4gICAgICAgICAgJ1VOU1VQUE9SVEVEX0ZFQVRVUkUnLFxuICAgICAgICAgICdDb25kaXRpb25hbCBmb3JtYXR0aW5nIGZvcm11bGEgcmVhZGVyIHJlcXVpcmVkJyxcbiAgICAgICAgKTtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgYWJvcnRhYmxlKFxuICAgICAgICAgIGV2YWx1YXRlKHtcbiAgICAgICAgICAgIHJvdzogY2VsbC5yb3csXG4gICAgICAgICAgICBjb2x1bW46IGNlbGwuY29sdW1uLFxuICAgICAgICAgICAgZXhwcmVzc2lvbjogcnVsZS5jb25kaXRpb24uZXhwcmVzc2lvbixcbiAgICAgICAgICAgIHJvd09mZnNldDogY2VsbC5yb3cgLSByYW5nZS5zdGFydFJvdyxcbiAgICAgICAgICAgIGNvbHVtbk9mZnNldDogY2VsbC5jb2x1bW4gLSByYW5nZS5zdGFydENvbHVtbixcbiAgICAgICAgICB9KSxcbiAgICAgICAgICBzaWduYWwsXG4gICAgICAgICk7XG4gICAgICAgIHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcbiAgICAgICAgYXNzZXJ0KFxuICAgICAgICAgICEocmVzdWx0ICYmIHR5cGVvZiByZXN1bHQgPT09ICdvYmplY3QnICYmIHJlc3VsdC5lcnJvciA9PT0gJyNMSU1JVCEnKSxcbiAgICAgICAgICAnTElNSVRfRVhDRUVERUQnLFxuICAgICAgICAgICdDb25kaXRpb25hbCBmb3JtYXR0aW5nIGNhbGN1bGF0aW9uIGV4Y2VlZGVkIGl0cyB3b3JrIGJ1ZGdldCcsXG4gICAgICAgICk7XG4gICAgICAgIG1hdGNoZWQgPSByZXN1bHQgPT09IHRydWU7XG4gICAgICB9IGVsc2UgbWF0Y2hlZCA9IG1hdGNoZXMocnVsZSwgY2VsbC52YWx1ZSk7XG4gICAgICBpZiAoIW1hdGNoZWQpIGNvbnRpbnVlO1xuICAgICAgYXBwbHlWaXN1YWwob3ZlcmxheSwgcnVsZS5zdHlsZSk7XG4gICAgICBpZiAocnVsZS5zdG9wSWZUcnVlKSBicmVhaztcbiAgICB9XG4gICAgcmVzdWx0cy5wdXNoKHsgLi4uY2VsbC5iYXNlLCAuLi5vdmVybGF5IH0pO1xuICB9XG4gIHJldHVybiByZXN1bHRzO1xufVxuXG4vKiogQWRqdXN0IHJhbmdlcyBmb3IgYSBzdHJ1Y3R1cmFsIGVkaXQ7IGRlbGV0ZWQgcmFuZ2VzIGFyZSByZW1vdmVkLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRyYW5zZm9ybUNvbmRpdGlvbmFsUnVsZXMoXG4gIGlucHV0OiB1bmtub3duLFxuICByb3dzOiBudW1iZXIsXG4gIGNvbHVtbnM6IG51bWJlcixcbiAgYXhpczogJ3JvdycgfCAnY29sdW1uJyxcbiAgb3BlcmF0aW9uOiAnaW5zZXJ0JyB8ICdkZWxldGUnLFxuICBpbmRleDogbnVtYmVyLFxuICBjb3VudDogbnVtYmVyLFxuICBzaGVldE5hbWU/OiBzdHJpbmcsXG4gIGVkaXRlZFNoZWV0PzogeyBuYW1lOiBzdHJpbmc7IGF4aXNMZW5ndGg6IG51bWJlciB9LFxuKTogQ29uZGl0aW9uYWxSdWxlW10ge1xuICBjb25zdCBydWxlcyA9IHZhbGlkYXRlQ29uZGl0aW9uYWxSdWxlcyhpbnB1dCwgcm93cywgY29sdW1ucyk7XG4gIGlmIChydWxlcy5zb21lKChydWxlKSA9PiBydWxlLmNvbmRpdGlvbi5raW5kID09PSAnZm9ybXVsYScpIHx8IGVkaXRlZFNoZWV0KSB7XG4gICAgY29uc3QgZW50cmllcyA9IHJ1bGVzLm1hcCgocnVsZSkgPT4gKHtcbiAgICAgIGlkOiBydWxlLmlkLFxuICAgICAgcmFuZ2U6IHJ1bGUucmFuZ2UsXG4gICAgICBydWxlOlxuICAgICAgICBydWxlLmNvbmRpdGlvbi5raW5kID09PSAnZm9ybXVsYSdcbiAgICAgICAgICA/IHtcbiAgICAgICAgICAgICAga2luZDogJ2Zvcm11bGEnLFxuICAgICAgICAgICAgICBleHByZXNzaW9uOiBydWxlLmNvbmRpdGlvbi5leHByZXNzaW9uLFxuICAgICAgICAgICAgICBhbGxvd0JsYW5rOiBmYWxzZSxcbiAgICAgICAgICAgICAgcG9saWN5OiAncmVqZWN0JyxcbiAgICAgICAgICAgIH1cbiAgICAgICAgICA6IHsga2luZDogJ251bWJlcicsIG9wZXJhdG9yOiAnZXEnLCBmaXJzdDogMCwgYWxsb3dCbGFuazogZmFsc2UsIHBvbGljeTogJ3JlamVjdCcgfSxcbiAgICB9KSk7XG4gICAgY29uc3QgdHJhbnNmb3JtZWQgPSB0cmFuc2Zvcm1WYWxpZGF0aW9uRW50cmllcyhcbiAgICAgIGVudHJpZXMsXG4gICAgICByb3dzLFxuICAgICAgY29sdW1ucyxcbiAgICAgIGF4aXMsXG4gICAgICBvcGVyYXRpb24sXG4gICAgICBpbmRleCxcbiAgICAgIGNvdW50LFxuICAgICAgc2hlZXROYW1lLFxuICAgICAgZWRpdGVkU2hlZXQsXG4gICAgKTtcbiAgICBjb25zdCBieUlkID0gbmV3IE1hcChydWxlcy5tYXAoKHJ1bGUpID0+IFtydWxlLmlkLCBydWxlXSkpO1xuICAgIGNvbnN0IG91dHB1dCA9IHRyYW5zZm9ybWVkLm1hcCgoZW50cnkpID0+IHtcbiAgICAgIGNvbnN0IG9yaWdpbmFsID0gYnlJZC5nZXQoZW50cnkuaWQpITtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIC4uLm9yaWdpbmFsLFxuICAgICAgICByYW5nZTogZW50cnkucmFuZ2UsXG4gICAgICAgIGNvbmRpdGlvbjpcbiAgICAgICAgICBvcmlnaW5hbC5jb25kaXRpb24ua2luZCA9PT0gJ2Zvcm11bGEnICYmIGVudHJ5LnJ1bGUua2luZCA9PT0gJ2Zvcm11bGEnXG4gICAgICAgICAgICA/IHsga2luZDogJ2Zvcm11bGEnIGFzIGNvbnN0LCBleHByZXNzaW9uOiBlbnRyeS5ydWxlLmV4cHJlc3Npb24gfVxuICAgICAgICAgICAgOiBvcmlnaW5hbC5jb25kaXRpb24sXG4gICAgICB9O1xuICAgIH0pO1xuICAgIGNvbnN0IGxvY2FsID0gIWVkaXRlZFNoZWV0IHx8IHNoZWV0TmFtZT8udG9Mb3dlckNhc2UoKSA9PT0gZWRpdGVkU2hlZXQubmFtZS50b0xvd2VyQ2FzZSgpO1xuICAgIGNvbnN0IGRlbHRhID0gbG9jYWwgPyAob3BlcmF0aW9uID09PSAnaW5zZXJ0JyA/IGNvdW50IDogLWNvdW50KSA6IDA7XG4gICAgcmV0dXJuIHZhbGlkYXRlQ29uZGl0aW9uYWxSdWxlcyhcbiAgICAgIG91dHB1dCxcbiAgICAgIHJvd3MgKyAoYXhpcyA9PT0gJ3JvdycgPyBkZWx0YSA6IDApLFxuICAgICAgY29sdW1ucyArIChheGlzID09PSAnY29sdW1uJyA/IGRlbHRhIDogMCksXG4gICAgKTtcbiAgfVxuICBjb25zdCBheGlzTGVuZ3RoID0gYXhpcyA9PT0gJ3JvdycgPyByb3dzIDogY29sdW1ucztcbiAgLy8gQ2hlY2sgdGhlIG9wZXJhdGlvbiBldmVuIGZvciBhbiBlbXB0eSBjb2xsZWN0aW9uLlxuICB0cmFuc2Zvcm1WYWxpZGF0aW9uUmFuZ2UoXG4gICAgeyBzdGFydFJvdzogMCwgZW5kUm93OiAxLCBzdGFydENvbHVtbjogMCwgZW5kQ29sdW1uOiAxIH0sXG4gICAgYXhpcyxcbiAgICBvcGVyYXRpb24sXG4gICAgaW5kZXgsXG4gICAgY291bnQsXG4gICAgYXhpc0xlbmd0aCxcbiAgKTtcbiAgY29uc3QgdHJhbnNmb3JtZWQgPSBydWxlcy5mbGF0TWFwKChydWxlKSA9PiB7XG4gICAgY29uc3QgcmFuZ2U6IFJlY3QgfCBudWxsID0gdHJhbnNmb3JtVmFsaWRhdGlvblJhbmdlKFxuICAgICAgcnVsZS5yYW5nZSxcbiAgICAgIGF4aXMsXG4gICAgICBvcGVyYXRpb24sXG4gICAgICBpbmRleCxcbiAgICAgIGNvdW50LFxuICAgICAgYXhpc0xlbmd0aCxcbiAgICApO1xuICAgIHJldHVybiByYW5nZSA/IFt7IC4uLnJ1bGUsIHJhbmdlIH1dIDogW107XG4gIH0pO1xuICBjb25zdCBkZWx0YSA9IG9wZXJhdGlvbiA9PT0gJ2luc2VydCcgPyBjb3VudCA6IC1jb3VudDtcbiAgcmV0dXJuIHZhbGlkYXRlQ29uZGl0aW9uYWxSdWxlcyhcbiAgICB0cmFuc2Zvcm1lZCxcbiAgICByb3dzICsgKGF4aXMgPT09ICdyb3cnID8gZGVsdGEgOiAwKSxcbiAgICBjb2x1bW5zICsgKGF4aXMgPT09ICdjb2x1bW4nID8gZGVsdGEgOiAwKSxcbiAgKTtcbn1cblxuLyoqIFJld3JpdGUgZXhwbGljaXQgd29ya3NoZWV0IHJlZmVyZW5jZXMgd2l0aG91dCBjaGFuZ2luZyBydWxlIG9yZGVyIG9yIHZpc3VhbCBzdHlsZXMuICovXG5leHBvcnQgZnVuY3Rpb24gcmV3cml0ZUNvbmRpdGlvbmFsU2hlZXRSZWZlcmVuY2VzKFxuICBpbnB1dDogdW5rbm93bixcbiAgcm93czogbnVtYmVyLFxuICBjb2x1bW5zOiBudW1iZXIsXG4gIG9sZE5hbWU6IHN0cmluZyxcbiAgbmV3TmFtZTogc3RyaW5nIHwgbnVsbCxcbik6IENvbmRpdGlvbmFsUnVsZVtdIHtcbiAgY29uc3QgcnVsZXMgPSB2YWxpZGF0ZUNvbmRpdGlvbmFsUnVsZXMoaW5wdXQsIHJvd3MsIGNvbHVtbnMpO1xuICBjb25zdCBlbnRyaWVzID0gcnVsZXMuZmxhdE1hcCgocnVsZSkgPT5cbiAgICBydWxlLmNvbmRpdGlvbi5raW5kID09PSAnZm9ybXVsYSdcbiAgICAgID8gW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiBydWxlLmlkLFxuICAgICAgICAgICAgcmFuZ2U6IHJ1bGUucmFuZ2UsXG4gICAgICAgICAgICBydWxlOiB7XG4gICAgICAgICAgICAgIGtpbmQ6ICdmb3JtdWxhJyxcbiAgICAgICAgICAgICAgZXhwcmVzc2lvbjogcnVsZS5jb25kaXRpb24uZXhwcmVzc2lvbixcbiAgICAgICAgICAgICAgYWxsb3dCbGFuazogZmFsc2UsXG4gICAgICAgICAgICAgIHBvbGljeTogJ3JlamVjdCcsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIF1cbiAgICAgIDogW10sXG4gICk7XG4gIGNvbnN0IHJld3JpdHRlbiA9IHJld3JpdGVWYWxpZGF0aW9uU2hlZXRSZWZlcmVuY2VzKGVudHJpZXMsIHJvd3MsIGNvbHVtbnMsIG9sZE5hbWUsIG5ld05hbWUpO1xuICBjb25zdCBleHByZXNzaW9ucyA9IG5ldyBNYXAocmV3cml0dGVuLm1hcCgoZW50cnkpID0+IFtlbnRyeS5pZCwgZW50cnkucnVsZV0pKTtcbiAgZm9yIChjb25zdCBydWxlIG9mIHJ1bGVzKSB7XG4gICAgaWYgKHJ1bGUuY29uZGl0aW9uLmtpbmQgIT09ICdmb3JtdWxhJykgY29udGludWU7XG4gICAgY29uc3QgcmV3cml0dGVuUnVsZSA9IGV4cHJlc3Npb25zLmdldChydWxlLmlkKTtcbiAgICBhc3NlcnQocmV3cml0dGVuUnVsZT8ua2luZCA9PT0gJ2Zvcm11bGEnLCAnSU5WQUxJRF9BUkdVTUVOVCcsICdNaXNzaW5nIHJld3JpdHRlbiBmb3JtdWxhJyk7XG4gICAgcnVsZS5jb25kaXRpb24uZXhwcmVzc2lvbiA9IHJld3JpdHRlblJ1bGUuZXhwcmVzc2lvbjtcbiAgfVxuICByZXR1cm4gdmFsaWRhdGVDb25kaXRpb25hbFJ1bGVzKHJ1bGVzLCByb3dzLCBjb2x1bW5zKTtcbn1cbiJdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxTQUFTO0FBQ2xCLFNBQVMsb0JBQW9CO0FBQzdCO0FBQUEsRUFDRTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLE9BSUs7QUFDUCxTQUFTLGdDQUFnQztBQUN6QztBQUFBLEVBQ0U7QUFBQSxFQUNBO0FBQUEsT0FDSztBQUNQLFNBQVMsV0FBVyx5QkFBeUI7QUFJN0MsTUFBTSxVQUFVLEVBQ2IsT0FBTztBQUFBLEVBQ04sTUFBTSxFQUFFLFFBQVEsUUFBUTtBQUFBLEVBQ3hCLFVBQVUsRUFBRSxLQUFLLENBQUMsTUFBTSxPQUFPLE1BQU0sT0FBTyxNQUFNLE9BQU8sV0FBVyxZQUFZLENBQUM7QUFBQSxFQUNqRixPQUFPLEVBQUUsT0FBTyxFQUFFLE9BQU87QUFBQSxFQUN6QixRQUFRLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxTQUFTO0FBQ3ZDLENBQUMsRUFDQSxPQUFPLEVBQ1AsWUFBWSxDQUFDLE9BQU8sWUFBWTtBQUMvQixRQUFNLE9BQU8sTUFBTSxhQUFhLGFBQWEsTUFBTSxhQUFhO0FBQ2hFLE1BQ0UsVUFBVSxNQUFNLFdBQVcsV0FDMUIsUUFBUSxNQUFNLFdBQVcsVUFBYSxNQUFNLFFBQVEsTUFBTTtBQUUzRCxZQUFRLFNBQVMsRUFBRSxNQUFNLFVBQVUsU0FBUyw0QkFBNEIsQ0FBQztBQUM3RSxDQUFDO0FBQ0gsTUFBTSxVQUFVLEVBQ2IsT0FBTztBQUFBLEVBQ04sTUFBTSxFQUFFLFFBQVEsTUFBTTtBQUFBLEVBQ3RCLFVBQVUsRUFBRSxLQUFLLENBQUMsVUFBVSxhQUFhLFlBQVksZUFBZSxjQUFjLFVBQVUsQ0FBQztBQUFBLEVBQzdGLE9BQU8sRUFBRSxPQUFPLEVBQUUsSUFBSSxJQUFJO0FBQUEsRUFDMUIsZUFBZSxFQUFFLFFBQVE7QUFDM0IsQ0FBQyxFQUNBLE9BQU87QUFDVixNQUFNLFVBQVUsRUFDYixPQUFPLEVBQUUsTUFBTSxFQUFFLFFBQVEsU0FBUyxHQUFHLFlBQVksRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxFQUM5RSxPQUFPO0FBQ1YsTUFBTSxjQUFjLFlBQ2pCLEtBQUssRUFBRSxNQUFNLE1BQU0sUUFBUSxNQUFNLFdBQVcsTUFBTSxPQUFPLE1BQU0sWUFBWSxLQUFLLENBQUMsRUFDakYsT0FBTztBQUNWLE1BQU0sYUFBYSxFQUNoQixPQUFPO0FBQUEsRUFDTixJQUFJLEVBQ0QsT0FBTyxFQUNQLElBQUksQ0FBQyxFQUNMLElBQUksR0FBRyxFQUNQLE1BQU0sVUFBVSxFQUNoQixPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsYUFBYSxlQUFlLFdBQVcsRUFBRSxTQUFTLEVBQUUsQ0FBQztBQUFBLEVBQ3pFLE9BQU8sV0FBVyxPQUFPO0FBQUEsRUFDekIsV0FBVyxFQUFFLE1BQU0sQ0FBQyxTQUFTLFNBQVMsT0FBTyxDQUFDO0FBQUEsRUFDOUMsT0FBTztBQUFBLEVBQ1AsWUFBWSxFQUFFLFFBQVE7QUFDeEIsQ0FBQyxFQUNBLE9BQU87QUFFVixNQUFNLFlBQVk7QUFDbEIsTUFBTSxXQUFXO0FBR1YsZ0JBQVMseUJBQ2QsT0FDQSxNQUNBLFNBQ21CO0FBQ25CO0FBQUEsSUFDRSxPQUFPLFVBQVUsSUFBSSxLQUNuQixPQUFPLEtBQ1AsUUFBUSxPQUFPLFFBQ2YsT0FBTyxVQUFVLE9BQU8sS0FDeEIsVUFBVSxLQUNWLFdBQVcsT0FBTztBQUFBLElBQ3BCO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDQTtBQUFBLElBQ0UsTUFBTSxRQUFRLEtBQUssS0FBSyxNQUFNLFVBQVU7QUFBQSxJQUN4QztBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPLG9CQUFJLElBQVk7QUFDN0IsUUFBTSxZQUErQixDQUFDO0FBQ3RDLFFBQU0sY0FBYyxvQkFBSSxJQUFZO0FBQ3BDLE1BQUksT0FBTztBQUNYLGFBQVcsUUFBUSxPQUFPO0FBQ3hCLFVBQU0sU0FBUyxXQUFXLFVBQVUsSUFBSTtBQUN4QyxXQUFPLE9BQU8sU0FBUyxvQkFBb0IscUNBQXFDO0FBQ2hGLFVBQU0sT0FBTyxPQUFPO0FBQ3BCLFdBQU8sQ0FBQyxLQUFLLElBQUksS0FBSyxFQUFFLEdBQUcsb0JBQW9CLHVDQUF1QztBQUN0RixTQUFLLElBQUksS0FBSyxFQUFFO0FBQ2hCO0FBQUEsTUFDRSxLQUFLLE1BQU0sV0FBVyxLQUFLLE1BQU0sVUFDL0IsS0FBSyxNQUFNLGNBQWMsS0FBSyxNQUFNLGFBQ3BDLEtBQUssTUFBTSxVQUFVLFFBQ3JCLEtBQUssTUFBTSxhQUFhO0FBQUEsTUFDMUI7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBO0FBQUEsTUFDRSxPQUFPLEtBQUssS0FBSyxLQUFLLEVBQUUsU0FBUyxLQUMvQixPQUFPLE9BQU8sS0FBSyxLQUFLLEVBQUUsTUFBTSxDQUFDLFVBQVUsVUFBVSxNQUFTO0FBQUEsTUFDaEU7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLFFBQUksS0FBSyxVQUFVLFNBQVMsT0FBUSxTQUFRLEtBQUssVUFBVSxNQUFNO0FBQ2pFLFFBQUksS0FBSyxVQUFVLFNBQVMsV0FBVztBQUNyQyxjQUFRLEtBQUssVUFBVSxXQUFXO0FBQ2xDLFVBQUksQ0FBQyxZQUFZLElBQUksS0FBSyxVQUFVLFVBQVUsR0FBRztBQUMvQyxZQUFJO0FBQ0YsdUJBQWEsS0FBSyxVQUFVLFVBQVU7QUFBQSxRQUN4QyxRQUFRO0FBQ04saUJBQU8sT0FBTyxvQkFBb0Isd0NBQXdDO0FBQUEsUUFDNUU7QUFDQSxvQkFBWSxJQUFJLEtBQUssVUFBVSxVQUFVO0FBQUEsTUFDM0M7QUFBQSxJQUNGO0FBQ0EsV0FBTyxRQUFRLFVBQVUsa0JBQWtCLDZDQUE2QztBQUN4RixjQUFVLEtBQUssSUFBSTtBQUFBLEVBQ3JCO0FBQ0EsU0FBTyxnQkFBZ0IsU0FBUztBQUNsQztBQUVBLFNBQVMsUUFBUSxNQUF1QixPQUEyQjtBQUNqRSxRQUFNLFlBQVksS0FBSztBQUN2QjtBQUFBLElBQ0UsVUFBVSxTQUFTO0FBQUEsSUFDbkI7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNBLE1BQUksVUFBVSxTQUFTLFVBQVU7QUFDL0IsUUFBSSxPQUFPLFVBQVUsWUFBWSxDQUFDLE9BQU8sU0FBUyxLQUFLLEVBQUcsUUFBTztBQUNqRSxZQUFRLFVBQVUsVUFBVTtBQUFBLE1BQzFCLEtBQUs7QUFDSCxlQUFPLFVBQVUsVUFBVTtBQUFBLE1BQzdCLEtBQUs7QUFDSCxlQUFPLFVBQVUsVUFBVTtBQUFBLE1BQzdCLEtBQUs7QUFDSCxlQUFPLFFBQVEsVUFBVTtBQUFBLE1BQzNCLEtBQUs7QUFDSCxlQUFPLFNBQVMsVUFBVTtBQUFBLE1BQzVCLEtBQUs7QUFDSCxlQUFPLFFBQVEsVUFBVTtBQUFBLE1BQzNCLEtBQUs7QUFDSCxlQUFPLFNBQVMsVUFBVTtBQUFBLE1BQzVCLEtBQUs7QUFDSCxlQUFPLFNBQVMsVUFBVSxTQUFTLFNBQVMsVUFBVTtBQUFBLE1BQ3hELEtBQUs7QUFDSCxlQUFPLFFBQVEsVUFBVSxTQUFTLFFBQVEsVUFBVTtBQUFBLElBQ3hEO0FBQUEsRUFDRjtBQUNBLE1BQUksT0FBTyxVQUFVLFNBQVUsUUFBTztBQUN0QyxRQUFNLE9BQU8sVUFBVSxnQkFBZ0IsUUFBUSxNQUFNLFlBQVk7QUFDakUsUUFBTSxRQUFRLFVBQVUsZ0JBQWdCLFVBQVUsUUFBUSxVQUFVLE1BQU0sWUFBWTtBQUN0RixVQUFRLFVBQVUsVUFBVTtBQUFBLElBQzFCLEtBQUs7QUFDSCxhQUFPLFNBQVM7QUFBQSxJQUNsQixLQUFLO0FBQ0gsYUFBTyxTQUFTO0FBQUEsSUFDbEIsS0FBSztBQUNILGFBQU8sS0FBSyxTQUFTLEtBQUs7QUFBQSxJQUM1QixLQUFLO0FBQ0gsYUFBTyxDQUFDLEtBQUssU0FBUyxLQUFLO0FBQUEsSUFDN0IsS0FBSztBQUNILGFBQU8sS0FBSyxXQUFXLEtBQUs7QUFBQSxJQUM5QixLQUFLO0FBQ0gsYUFBTyxLQUFLLFNBQVMsS0FBSztBQUFBLEVBQzlCO0FBQ0Y7QUFFQSxTQUFTLFlBQVksU0FBb0IsT0FBaUM7QUFDeEUsTUFBSSxRQUFRLFNBQVMsVUFBYSxNQUFNLFNBQVMsT0FBVyxTQUFRLE9BQU8sTUFBTTtBQUNqRixNQUFJLFFBQVEsV0FBVyxVQUFhLE1BQU0sV0FBVyxPQUFXLFNBQVEsU0FBUyxNQUFNO0FBQ3ZGLE1BQUksUUFBUSxjQUFjLFVBQWEsTUFBTSxjQUFjO0FBQ3pELFlBQVEsWUFBWSxNQUFNO0FBQzVCLE1BQUksUUFBUSxVQUFVLFVBQWEsTUFBTSxVQUFVLE9BQVcsU0FBUSxRQUFRLE1BQU07QUFDcEYsTUFBSSxRQUFRLGVBQWUsVUFBYSxNQUFNLGVBQWU7QUFDM0QsWUFBUSxhQUFhLE1BQU07QUFDL0I7QUFHTyxnQkFBUyxpQkFDZCxPQUNBLEtBQ0EsUUFDQSxPQUNBLE1BQ1c7QUFDWDtBQUFBLElBQ0UsRUFBRSxTQUFTLE9BQU8sVUFBVSxZQUFZLE1BQU0sVUFBVTtBQUFBLElBQ3hEO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDQTtBQUFBLElBQ0UsT0FBTyxVQUFVLFlBQVksTUFBTSxVQUFVLE9BQU87QUFBQSxJQUNwRDtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0E7QUFBQSxJQUNFLE9BQU8sVUFBVSxHQUFHLEtBQ2xCLE9BQU8sS0FDUCxNQUFNLE9BQU8sUUFDYixPQUFPLFVBQVUsTUFBTSxLQUN2QixVQUFVLEtBQ1YsU0FBUyxPQUFPO0FBQUEsSUFDbEI7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNBLFFBQU0sVUFBcUIsQ0FBQztBQUM1QixhQUFXLFFBQVEsT0FBTztBQUN4QixVQUFNLFFBQVEsS0FBSztBQUNuQixRQUNFLE1BQU0sTUFBTSxZQUNaLE9BQU8sTUFBTSxVQUNiLFNBQVMsTUFBTSxlQUNmLFVBQVUsTUFBTSxhQUNoQixDQUFDLFFBQVEsTUFBTSxLQUFLO0FBRXBCO0FBQ0YsZ0JBQVksU0FBUyxLQUFLLEtBQUs7QUFDL0IsUUFBSSxLQUFLLFdBQVk7QUFBQSxFQUN2QjtBQUNBLFNBQU8sRUFBRSxHQUFHLE1BQU0sR0FBRyxRQUFRO0FBQy9CO0FBR08sZ0JBQVMsb0JBQ2QsT0FDQSxPQUNhO0FBQ2Isb0JBQWtCLE9BQU8sS0FBSztBQUM5QjtBQUFBLElBQ0UsQ0FBQyxNQUFNLEtBQUssQ0FBQyxTQUFTLEtBQUssVUFBVSxTQUFTLFNBQVM7QUFBQSxJQUN2RDtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0EsU0FBTyxNQUFNLElBQUksQ0FBQyxTQUFTLGlCQUFpQixPQUFPLEtBQUssS0FBSyxLQUFLLFFBQVEsS0FBSyxPQUFPLEtBQUssSUFBSSxDQUFDO0FBQ2xHO0FBV0EsU0FBUyxrQkFBa0IsT0FBbUMsT0FBNEI7QUFDeEY7QUFBQSxJQUNFLE1BQU0sUUFBUSxLQUFLLEtBQ2pCLE1BQU0sVUFBVSxhQUNoQixNQUFNLFFBQVEsS0FBSyxLQUNuQixNQUFNLFVBQVUsT0FDaEIsTUFBTSxTQUFTLE1BQU0sVUFBVTtBQUFBLElBQ2pDO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDQSxNQUFJLFlBQVk7QUFDaEIsTUFBSSxXQUFXO0FBQ2YsYUFBVyxRQUFRLE9BQU87QUFDeEIsUUFBSSxLQUFLLFVBQVUsU0FBUyxRQUFRO0FBQ2xDO0FBQ0Esa0JBQVksS0FBSyxVQUFVLE1BQU07QUFBQSxJQUNuQyxXQUFXLEtBQUssVUFBVSxTQUFTLFVBQVcsYUFBWSxLQUFLLFVBQVUsV0FBVztBQUFBLEVBQ3RGO0FBQ0EsTUFBSSxZQUFZO0FBQ2hCLGFBQVcsUUFBUSxPQUFPO0FBQ3hCO0FBQUEsTUFDRSxFQUFFLEtBQUssU0FBUyxPQUFPLEtBQUssVUFBVSxZQUFZLEtBQUssTUFBTSxVQUFVO0FBQUEsTUFDdkU7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLFFBQUksT0FBTyxLQUFLLFVBQVUsU0FBVTtBQUNwQztBQUFBLE1BQ0UsS0FBSyxNQUFNLFVBQVUsT0FBTztBQUFBLE1BQzVCO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFDQSxpQkFBYSxLQUFLLE1BQU07QUFDeEI7QUFBQSxNQUNFLGFBQWE7QUFBQSxNQUNiO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0E7QUFBQSxJQUNFLFdBQVcsTUFBTSxTQUFTLFlBQVksYUFBYTtBQUFBLElBQ25EO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDRjtBQUdBLHNCQUFzQixnQ0FDcEIsT0FDQSxZQUNBLFVBQ0EsUUFDc0I7QUFDdEIsVUFBUSxlQUFlO0FBQ3ZCO0FBQUEsSUFDRSxNQUFNLFFBQVEsVUFBVSxLQUFLLFdBQVcsVUFBVTtBQUFBLElBQ2xEO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDQSxRQUFNLFFBQVEseUJBQXlCLE9BQU8sT0FBTyxNQUFNLE9BQU8sT0FBTztBQUN6RSxvQkFBa0IsT0FBTyxVQUFVO0FBQ25DLFVBQVEsZUFBZTtBQUN2QixRQUFNLFFBQVEsZ0JBQWdCLFVBQVU7QUFDeEMsb0JBQWtCLE9BQU8sS0FBSztBQUM5QixRQUFNLGFBQWEsa0JBQWtCLE1BQU07QUFDM0MsUUFBTSxVQUF1QixDQUFDO0FBQzlCLE1BQUksU0FBUztBQUNiLGFBQVcsUUFBUSxPQUFPO0FBQ3hCO0FBQUEsTUFDRSxPQUFPLFVBQVUsS0FBSyxHQUFHLEtBQ3ZCLEtBQUssT0FBTyxLQUNaLEtBQUssTUFBTSxPQUFPLFFBQ2xCLE9BQU8sVUFBVSxLQUFLLE1BQU0sS0FDNUIsS0FBSyxVQUFVLEtBQ2YsS0FBSyxTQUFTLE9BQU87QUFBQSxNQUN2QjtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsVUFBTSxVQUFxQixDQUFDO0FBQzVCLGVBQVcsUUFBUSxPQUFPO0FBQ3hCLFVBQUksRUFBRSxTQUFTLFNBQVMsRUFBRyxPQUFNLFdBQVc7QUFDNUMsY0FBUSxlQUFlO0FBQ3ZCLFlBQU0sUUFBUSxLQUFLO0FBQ25CLFVBQ0UsS0FBSyxNQUFNLE1BQU0sWUFDakIsS0FBSyxPQUFPLE1BQU0sVUFDbEIsS0FBSyxTQUFTLE1BQU0sZUFDcEIsS0FBSyxVQUFVLE1BQU07QUFFckI7QUFDRixVQUFJO0FBQ0osVUFBSSxLQUFLLFVBQVUsU0FBUyxXQUFXO0FBQ3JDO0FBQUEsVUFDRSxPQUFPLGFBQWE7QUFBQSxVQUNwQjtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQ0EsY0FBTSxTQUFTLE1BQU07QUFBQSxVQUNuQixTQUFTO0FBQUEsWUFDUCxLQUFLLEtBQUs7QUFBQSxZQUNWLFFBQVEsS0FBSztBQUFBLFlBQ2IsWUFBWSxLQUFLLFVBQVU7QUFBQSxZQUMzQixXQUFXLEtBQUssTUFBTSxNQUFNO0FBQUEsWUFDNUIsY0FBYyxLQUFLLFNBQVMsTUFBTTtBQUFBLFVBQ3BDLENBQUM7QUFBQSxVQUNEO0FBQUEsUUFDRjtBQUNBLGdCQUFRLGVBQWU7QUFDdkI7QUFBQSxVQUNFLEVBQUUsVUFBVSxPQUFPLFdBQVcsWUFBWSxPQUFPLFVBQVU7QUFBQSxVQUMzRDtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQ0Esa0JBQVUsV0FBVztBQUFBLE1BQ3ZCLE1BQU8sV0FBVSxRQUFRLE1BQU0sS0FBSyxLQUFLO0FBQ3pDLFVBQUksQ0FBQyxRQUFTO0FBQ2Qsa0JBQVksU0FBUyxLQUFLLEtBQUs7QUFDL0IsVUFBSSxLQUFLLFdBQVk7QUFBQSxJQUN2QjtBQUNBLFlBQVEsS0FBSyxFQUFFLEdBQUcsS0FBSyxNQUFNLEdBQUcsUUFBUSxDQUFDO0FBQUEsRUFDM0M7QUFDQSxTQUFPO0FBQ1Q7QUFHTyxnQkFBUywwQkFDZCxPQUNBLE1BQ0EsU0FDQSxNQUNBLFdBQ0EsT0FDQSxPQUNBLFdBQ0EsYUFDbUI7QUFDbkIsUUFBTSxRQUFRLHlCQUF5QixPQUFPLE1BQU0sT0FBTztBQUMzRCxNQUFJLE1BQU0sS0FBSyxDQUFDLFNBQVMsS0FBSyxVQUFVLFNBQVMsU0FBUyxLQUFLLGFBQWE7QUFDMUUsVUFBTSxVQUFVLE1BQU0sSUFBSSxDQUFDLFVBQVU7QUFBQSxNQUNuQyxJQUFJLEtBQUs7QUFBQSxNQUNULE9BQU8sS0FBSztBQUFBLE1BQ1osTUFDRSxLQUFLLFVBQVUsU0FBUyxZQUNwQjtBQUFBLFFBQ0UsTUFBTTtBQUFBLFFBQ04sWUFBWSxLQUFLLFVBQVU7QUFBQSxRQUMzQixZQUFZO0FBQUEsUUFDWixRQUFRO0FBQUEsTUFDVixJQUNBLEVBQUUsTUFBTSxVQUFVLFVBQVUsTUFBTSxPQUFPLEdBQUcsWUFBWSxPQUFPLFFBQVEsU0FBUztBQUFBLElBQ3hGLEVBQUU7QUFDRixVQUFNQSxlQUFjO0FBQUEsTUFDbEI7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFDQSxVQUFNLE9BQU8sSUFBSSxJQUFJLE1BQU0sSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLENBQUM7QUFDekQsVUFBTSxTQUFTQSxhQUFZLElBQUksQ0FBQyxVQUFVO0FBQ3hDLFlBQU0sV0FBVyxLQUFLLElBQUksTUFBTSxFQUFFO0FBQ2xDLGFBQU87QUFBQSxRQUNMLEdBQUc7QUFBQSxRQUNILE9BQU8sTUFBTTtBQUFBLFFBQ2IsV0FDRSxTQUFTLFVBQVUsU0FBUyxhQUFhLE1BQU0sS0FBSyxTQUFTLFlBQ3pELEVBQUUsTUFBTSxXQUFvQixZQUFZLE1BQU0sS0FBSyxXQUFXLElBQzlELFNBQVM7QUFBQSxNQUNqQjtBQUFBLElBQ0YsQ0FBQztBQUNELFVBQU0sUUFBUSxDQUFDLGVBQWUsV0FBVyxZQUFZLE1BQU0sWUFBWSxLQUFLLFlBQVk7QUFDeEYsVUFBTUMsU0FBUSxRQUFTLGNBQWMsV0FBVyxRQUFRLENBQUMsUUFBUztBQUNsRSxXQUFPO0FBQUEsTUFDTDtBQUFBLE1BQ0EsUUFBUSxTQUFTLFFBQVFBLFNBQVE7QUFBQSxNQUNqQyxXQUFXLFNBQVMsV0FBV0EsU0FBUTtBQUFBLElBQ3pDO0FBQUEsRUFDRjtBQUNBLFFBQU0sYUFBYSxTQUFTLFFBQVEsT0FBTztBQUUzQztBQUFBLElBQ0UsRUFBRSxVQUFVLEdBQUcsUUFBUSxHQUFHLGFBQWEsR0FBRyxXQUFXLEVBQUU7QUFBQSxJQUN2RDtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0EsUUFBTSxjQUFjLE1BQU0sUUFBUSxDQUFDLFNBQVM7QUFDMUMsVUFBTSxRQUFxQjtBQUFBLE1BQ3pCLEtBQUs7QUFBQSxNQUNMO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFDQSxXQUFPLFFBQVEsQ0FBQyxFQUFFLEdBQUcsTUFBTSxNQUFNLENBQUMsSUFBSSxDQUFDO0FBQUEsRUFDekMsQ0FBQztBQUNELFFBQU0sUUFBUSxjQUFjLFdBQVcsUUFBUSxDQUFDO0FBQ2hELFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQSxRQUFRLFNBQVMsUUFBUSxRQUFRO0FBQUEsSUFDakMsV0FBVyxTQUFTLFdBQVcsUUFBUTtBQUFBLEVBQ3pDO0FBQ0Y7QUFHTyxnQkFBUyxrQ0FDZCxPQUNBLE1BQ0EsU0FDQSxTQUNBLFNBQ21CO0FBQ25CLFFBQU0sUUFBUSx5QkFBeUIsT0FBTyxNQUFNLE9BQU87QUFDM0QsUUFBTSxVQUFVLE1BQU07QUFBQSxJQUFRLENBQUMsU0FDN0IsS0FBSyxVQUFVLFNBQVMsWUFDcEI7QUFBQSxNQUNFO0FBQUEsUUFDRSxJQUFJLEtBQUs7QUFBQSxRQUNULE9BQU8sS0FBSztBQUFBLFFBQ1osTUFBTTtBQUFBLFVBQ0osTUFBTTtBQUFBLFVBQ04sWUFBWSxLQUFLLFVBQVU7QUFBQSxVQUMzQixZQUFZO0FBQUEsVUFDWixRQUFRO0FBQUEsUUFDVjtBQUFBLE1BQ0Y7QUFBQSxJQUNGLElBQ0EsQ0FBQztBQUFBLEVBQ1A7QUFDQSxRQUFNLFlBQVksaUNBQWlDLFNBQVMsTUFBTSxTQUFTLFNBQVMsT0FBTztBQUMzRixRQUFNLGNBQWMsSUFBSSxJQUFJLFVBQVUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLElBQUksTUFBTSxJQUFJLENBQUMsQ0FBQztBQUM1RSxhQUFXLFFBQVEsT0FBTztBQUN4QixRQUFJLEtBQUssVUFBVSxTQUFTLFVBQVc7QUFDdkMsVUFBTSxnQkFBZ0IsWUFBWSxJQUFJLEtBQUssRUFBRTtBQUM3QyxXQUFPLGVBQWUsU0FBUyxXQUFXLG9CQUFvQiwyQkFBMkI7QUFDekYsU0FBSyxVQUFVLGFBQWEsY0FBYztBQUFBLEVBQzVDO0FBQ0EsU0FBTyx5QkFBeUIsT0FBTyxNQUFNLE9BQU87QUFDdEQ7IiwibmFtZXMiOlsidHJhbnNmb3JtZWQiLCJkZWx0YSJdfQ==
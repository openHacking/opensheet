import { assert, LIMITS } from "/@fs/Volumes/github/private/opensheet/packages/core/src/types.ts";
import {
  sheetFor,
  structuralRangeReferences,
  structuralReferences,
  transformAll
} from "/@fs/Volumes/github/private/opensheet/packages/core/src/commands/helpers.ts";
export function axisCommand(s, command) {
  const p = command.payload;
  const sh = sheetFor(s, p.sheetId);
  switch (command.type) {
    case "core.axis.insert":
    case "core.axis.delete": {
      const row = p.axis === "row", order = row ? sh.rowOrder : sh.columnOrder, insert = command.type === "core.axis.insert", count = insert ? p.ids.length : p.count;
      assert(
        p.index <= (insert ? order.length : order.length - count) && count > 0,
        "INVALID_RANGE",
        "Invalid structural range"
      );
      assert(
        insert ? order.length + count <= (row ? LIMITS.rows : LIMITS.columns) : order.length - count >= 1,
        "LIMIT_EXCEEDED",
        "Invalid sheet size"
      );
      if (insert) {
        const next = row ? "nextRowId" : "nextColumnId";
        assert(
          p.ids.every((id, i) => id === sh[next] + i) && sh[next] + count <= 4294967296,
          "INVALID_ARGUMENT",
          "Axis IDs must be allocated monotonically"
        );
      }
      if (insert)
        assert(
          (/* @__PURE__ */ new Set([...order, ...p.ids])).size === order.length + count,
          "INVALID_ARGUMENT",
          "Duplicate axis IDs"
        );
      const start = row ? "startRow" : "startColumn", end = row ? "endRow" : "endColumn";
      for (const m of sh.merges)
        assert(
          !(p.index < m[end] && p.index + (!insert ? count : 0) > m[start]),
          "INVALID_RANGE",
          "Unmerge cells before editing this axis"
        );
      const deleted = insert ? [] : order.slice(p.index, p.index + count);
      const removed = new Set(deleted);
      transformAll(
        s,
        structuralReferences(command, sh.name),
        sh.name,
        structuralRangeReferences(command, sh.name),
        insert ? void 0 : (sheet, cell) => sheet.id === sh.id && removed.has(row ? cell.rowId : cell.columnId)
      );
      if (insert) sh[row ? "nextRowId" : "nextColumnId"] += count;
      if (insert) {
        for (let i = 0; i < p.ids.length; i += 8192)
          order.splice(p.index + i, 0, ...p.ids.slice(i, i + 8192));
      } else {
        order.splice(p.index, count);
        for (const k of Object.keys(sh.cells))
          if (removed.has(row ? sh.cells[k].rowId : sh.cells[k].columnId)) delete sh.cells[k];
      }
      for (const id of deleted) delete (row ? sh.rows : sh.columns)[id];
      sh.merges.forEach((m) => {
        if (m[start] >= p.index) {
          m[start] += insert ? count : -count;
          m[end] += insert ? count : -count;
        }
      });
      const f = row ? "rows" : "columns";
      sh.freeze[f] = Math.min(
        order.length,
        sh.freeze[f] > p.index ? Math.max(p.index, sh.freeze[f] + (insert ? count : -count)) : sh.freeze[f]
      );
      if (sh.filter) {
        const filter = sh.filter;
        if (!row) {
          const removed2 = (column) => !insert && column >= p.index && column < p.index + count;
          const shifted = (column) => column >= p.index ? column + (insert ? count : -count) : column;
          if ("column" in filter) {
            if (removed2(filter.column)) sh.filter = null;
            else filter.column = shifted(filter.column);
          } else {
            filter.criteria = filter.criteria.filter((criterion) => !removed2(criterion.column));
            for (const criterion of filter.criteria) criterion.column = shifted(criterion.column);
            if (!filter.criteria.length) sh.filter = null;
          }
        } else if ("headerRows" in filter && p.index < filter.headerRows) {
          filter.headerRows = insert ? filter.headerRows + count : Math.max(p.index, filter.headerRows - count);
        }
      }
      break;
    }
    case "core.axis.resize": {
      const order = p.axis === "row" ? sh.rowOrder : sh.columnOrder;
      assert(p.index + p.count <= order.length, "INVALID_RANGE", "Unknown row/column");
      const meta = p.axis === "row" ? sh.rows : sh.columns;
      for (let i = p.index; i < p.index + p.count; i++) {
        const id = order[i];
        if (meta[id]?.size === p.size) continue;
        meta[id] = { ...meta[id], size: p.size };
      }
      break;
    }
    case "core.axis.visibility":
    case "core.axis.visibilityAll": {
      const order = p.axis === "row" ? sh.rowOrder : sh.columnOrder;
      const start = command.type === "core.axis.visibilityAll" ? 0 : p.index;
      const end = command.type === "core.axis.visibilityAll" ? order.length : p.index + p.count;
      assert(end <= order.length, "INVALID_RANGE", "Unknown row/column");
      const meta = p.axis === "row" ? sh.rows : sh.columns;
      for (let i = start; i < end; i++) {
        const id = order[i];
        if (!p.hidden && !meta[id]?.hidden) continue;
        if (p.hidden && meta[id]?.hidden) continue;
        meta[id] = { ...meta[id], hidden: p.hidden };
      }
      break;
    }
    case "core.axis.meta": {
      const order = p.axis === "row" ? sh.rowOrder : sh.columnOrder;
      assert(p.index < order.length, "INVALID_RANGE", "Unknown row/column");
      const meta = p.axis === "row" ? sh.rows : sh.columns;
      meta[order[p.index]] = {
        ...meta[order[p.index]],
        ...p.size !== void 0 ? { size: p.size } : {},
        ...p.hidden !== void 0 ? { hidden: p.hidden } : {}
      };
      break;
    }
    default:
      assert(false, "UNSUPPORTED_FEATURE", "Unknown command");
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImF4aXMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgYXNzZXJ0LCBMSU1JVFMsIHR5cGUgQ29tbWFuZCwgdHlwZSBXb3JrYm9va1NuYXBzaG90IH0gZnJvbSAnLi4vdHlwZXMuanMnO1xuaW1wb3J0IHtcbiAgc2hlZXRGb3IsXG4gIHN0cnVjdHVyYWxSYW5nZVJlZmVyZW5jZXMsXG4gIHN0cnVjdHVyYWxSZWZlcmVuY2VzLFxuICB0cmFuc2Zvcm1BbGwsXG59IGZyb20gJy4vaGVscGVycy5qcyc7XG5leHBvcnQgZnVuY3Rpb24gYXhpc0NvbW1hbmQoczogV29ya2Jvb2tTbmFwc2hvdCwgY29tbWFuZDogQ29tbWFuZCk6IHZvaWQge1xuICBjb25zdCBwID0gY29tbWFuZC5wYXlsb2FkIGFzIGFueTsgLy8gVmFsaWRhdGVkIGJlZm9yZSBkaXNwYXRjaC5cbiAgY29uc3Qgc2ggPSBzaGVldEZvcihzLCBwLnNoZWV0SWQpO1xuICBzd2l0Y2ggKGNvbW1hbmQudHlwZSkge1xuICAgIGNhc2UgJ2NvcmUuYXhpcy5pbnNlcnQnOlxuICAgIGNhc2UgJ2NvcmUuYXhpcy5kZWxldGUnOiB7XG4gICAgICBjb25zdCByb3cgPSBwLmF4aXMgPT09ICdyb3cnLFxuICAgICAgICBvcmRlciA9IHJvdyA/IHNoLnJvd09yZGVyIDogc2guY29sdW1uT3JkZXIsXG4gICAgICAgIGluc2VydCA9IGNvbW1hbmQudHlwZSA9PT0gJ2NvcmUuYXhpcy5pbnNlcnQnLFxuICAgICAgICBjb3VudCA9IGluc2VydCA/IHAuaWRzLmxlbmd0aCA6IHAuY291bnQ7XG4gICAgICBhc3NlcnQoXG4gICAgICAgIHAuaW5kZXggPD0gKGluc2VydCA/IG9yZGVyLmxlbmd0aCA6IG9yZGVyLmxlbmd0aCAtIGNvdW50KSAmJiBjb3VudCA+IDAsXG4gICAgICAgICdJTlZBTElEX1JBTkdFJyxcbiAgICAgICAgJ0ludmFsaWQgc3RydWN0dXJhbCByYW5nZScsXG4gICAgICApO1xuICAgICAgYXNzZXJ0KFxuICAgICAgICBpbnNlcnRcbiAgICAgICAgICA/IG9yZGVyLmxlbmd0aCArIGNvdW50IDw9IChyb3cgPyBMSU1JVFMucm93cyA6IExJTUlUUy5jb2x1bW5zKVxuICAgICAgICAgIDogb3JkZXIubGVuZ3RoIC0gY291bnQgPj0gMSxcbiAgICAgICAgJ0xJTUlUX0VYQ0VFREVEJyxcbiAgICAgICAgJ0ludmFsaWQgc2hlZXQgc2l6ZScsXG4gICAgICApO1xuICAgICAgaWYgKGluc2VydCkge1xuICAgICAgICBjb25zdCBuZXh0ID0gcm93ID8gJ25leHRSb3dJZCcgOiAnbmV4dENvbHVtbklkJztcbiAgICAgICAgYXNzZXJ0KFxuICAgICAgICAgIHAuaWRzLmV2ZXJ5KChpZDogbnVtYmVyLCBpOiBudW1iZXIpID0+IGlkID09PSBzaFtuZXh0XSArIGkpICYmXG4gICAgICAgICAgICBzaFtuZXh0XSArIGNvdW50IDw9IDB4MTAwMDAwMDAwLFxuICAgICAgICAgICdJTlZBTElEX0FSR1VNRU5UJyxcbiAgICAgICAgICAnQXhpcyBJRHMgbXVzdCBiZSBhbGxvY2F0ZWQgbW9ub3RvbmljYWxseScsXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBpZiAoaW5zZXJ0KVxuICAgICAgICBhc3NlcnQoXG4gICAgICAgICAgbmV3IFNldChbLi4ub3JkZXIsIC4uLnAuaWRzXSkuc2l6ZSA9PT0gb3JkZXIubGVuZ3RoICsgY291bnQsXG4gICAgICAgICAgJ0lOVkFMSURfQVJHVU1FTlQnLFxuICAgICAgICAgICdEdXBsaWNhdGUgYXhpcyBJRHMnLFxuICAgICAgICApO1xuICAgICAgY29uc3Qgc3RhcnQgPSByb3cgPyAnc3RhcnRSb3cnIDogJ3N0YXJ0Q29sdW1uJyxcbiAgICAgICAgZW5kID0gcm93ID8gJ2VuZFJvdycgOiAnZW5kQ29sdW1uJztcbiAgICAgIGZvciAoY29uc3QgbSBvZiBzaC5tZXJnZXMpXG4gICAgICAgIGFzc2VydChcbiAgICAgICAgICAhKHAuaW5kZXggPCBtW2VuZF0gJiYgcC5pbmRleCArICghaW5zZXJ0ID8gY291bnQgOiAwKSA+IG1bc3RhcnRdKSxcbiAgICAgICAgICAnSU5WQUxJRF9SQU5HRScsXG4gICAgICAgICAgJ1VubWVyZ2UgY2VsbHMgYmVmb3JlIGVkaXRpbmcgdGhpcyBheGlzJyxcbiAgICAgICAgKTtcbiAgICAgIGNvbnN0IGRlbGV0ZWQgPSBpbnNlcnQgPyBbXSA6IG9yZGVyLnNsaWNlKHAuaW5kZXgsIHAuaW5kZXggKyBjb3VudCk7XG4gICAgICBjb25zdCByZW1vdmVkID0gbmV3IFNldChkZWxldGVkKTtcbiAgICAgIHRyYW5zZm9ybUFsbChcbiAgICAgICAgcyxcbiAgICAgICAgc3RydWN0dXJhbFJlZmVyZW5jZXMoY29tbWFuZCwgc2gubmFtZSksXG4gICAgICAgIHNoLm5hbWUsXG4gICAgICAgIHN0cnVjdHVyYWxSYW5nZVJlZmVyZW5jZXMoY29tbWFuZCwgc2gubmFtZSksXG4gICAgICAgIGluc2VydFxuICAgICAgICAgID8gdW5kZWZpbmVkXG4gICAgICAgICAgOiAoc2hlZXQsIGNlbGwpID0+IHNoZWV0LmlkID09PSBzaC5pZCAmJiByZW1vdmVkLmhhcyhyb3cgPyBjZWxsLnJvd0lkIDogY2VsbC5jb2x1bW5JZCksXG4gICAgICApO1xuICAgICAgaWYgKGluc2VydCkgc2hbcm93ID8gJ25leHRSb3dJZCcgOiAnbmV4dENvbHVtbklkJ10gKz0gY291bnQ7XG4gICAgICBpZiAoaW5zZXJ0KSB7XG4gICAgICAgIC8vIEF2b2lkIGV4Y2VlZGluZyBlbmdpbmUtc3BlY2lmaWMgYXJndW1lbnQgbGltaXRzIGZvciBsYXJnZSBpbnNlcnRzLlxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHAuaWRzLmxlbmd0aDsgaSArPSA4MTkyKVxuICAgICAgICAgIG9yZGVyLnNwbGljZShwLmluZGV4ICsgaSwgMCwgLi4ucC5pZHMuc2xpY2UoaSwgaSArIDgxOTIpKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG9yZGVyLnNwbGljZShwLmluZGV4LCBjb3VudCk7XG4gICAgICAgIGZvciAoY29uc3QgayBvZiBPYmplY3Qua2V5cyhzaC5jZWxscykpXG4gICAgICAgICAgaWYgKHJlbW92ZWQuaGFzKHJvdyA/IHNoLmNlbGxzW2tdLnJvd0lkIDogc2guY2VsbHNba10uY29sdW1uSWQpKSBkZWxldGUgc2guY2VsbHNba107XG4gICAgICB9XG4gICAgICBmb3IgKGNvbnN0IGlkIG9mIGRlbGV0ZWQpIGRlbGV0ZSAocm93ID8gc2gucm93cyA6IHNoLmNvbHVtbnMpW2lkXTtcbiAgICAgIHNoLm1lcmdlcy5mb3JFYWNoKChtKSA9PiB7XG4gICAgICAgIGlmIChtW3N0YXJ0XSA+PSBwLmluZGV4KSB7XG4gICAgICAgICAgbVtzdGFydF0gKz0gaW5zZXJ0ID8gY291bnQgOiAtY291bnQ7XG4gICAgICAgICAgbVtlbmRdICs9IGluc2VydCA/IGNvdW50IDogLWNvdW50O1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIGNvbnN0IGYgPSByb3cgPyAncm93cycgOiAnY29sdW1ucyc7XG4gICAgICBzaC5mcmVlemVbZl0gPSBNYXRoLm1pbihcbiAgICAgICAgb3JkZXIubGVuZ3RoLFxuICAgICAgICBzaC5mcmVlemVbZl0gPiBwLmluZGV4XG4gICAgICAgICAgPyBNYXRoLm1heChwLmluZGV4LCBzaC5mcmVlemVbZl0gKyAoaW5zZXJ0ID8gY291bnQgOiAtY291bnQpKVxuICAgICAgICAgIDogc2guZnJlZXplW2ZdLFxuICAgICAgKTtcbiAgICAgIGlmIChzaC5maWx0ZXIpIHtcbiAgICAgICAgY29uc3QgZmlsdGVyID0gc2guZmlsdGVyO1xuICAgICAgICBpZiAoIXJvdykge1xuICAgICAgICAgIGNvbnN0IHJlbW92ZWQgPSAoY29sdW1uOiBudW1iZXIpID0+XG4gICAgICAgICAgICAhaW5zZXJ0ICYmIGNvbHVtbiA+PSBwLmluZGV4ICYmIGNvbHVtbiA8IHAuaW5kZXggKyBjb3VudDtcbiAgICAgICAgICBjb25zdCBzaGlmdGVkID0gKGNvbHVtbjogbnVtYmVyKSA9PlxuICAgICAgICAgICAgY29sdW1uID49IHAuaW5kZXggPyBjb2x1bW4gKyAoaW5zZXJ0ID8gY291bnQgOiAtY291bnQpIDogY29sdW1uO1xuICAgICAgICAgIGlmICgnY29sdW1uJyBpbiBmaWx0ZXIpIHtcbiAgICAgICAgICAgIGlmIChyZW1vdmVkKGZpbHRlci5jb2x1bW4pKSBzaC5maWx0ZXIgPSBudWxsO1xuICAgICAgICAgICAgZWxzZSBmaWx0ZXIuY29sdW1uID0gc2hpZnRlZChmaWx0ZXIuY29sdW1uKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgZmlsdGVyLmNyaXRlcmlhID0gZmlsdGVyLmNyaXRlcmlhLmZpbHRlcigoY3JpdGVyaW9uKSA9PiAhcmVtb3ZlZChjcml0ZXJpb24uY29sdW1uKSk7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IGNyaXRlcmlvbiBvZiBmaWx0ZXIuY3JpdGVyaWEpIGNyaXRlcmlvbi5jb2x1bW4gPSBzaGlmdGVkKGNyaXRlcmlvbi5jb2x1bW4pO1xuICAgICAgICAgICAgaWYgKCFmaWx0ZXIuY3JpdGVyaWEubGVuZ3RoKSBzaC5maWx0ZXIgPSBudWxsO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIGlmICgnaGVhZGVyUm93cycgaW4gZmlsdGVyICYmIHAuaW5kZXggPCBmaWx0ZXIuaGVhZGVyUm93cykge1xuICAgICAgICAgIGZpbHRlci5oZWFkZXJSb3dzID0gaW5zZXJ0XG4gICAgICAgICAgICA/IGZpbHRlci5oZWFkZXJSb3dzICsgY291bnRcbiAgICAgICAgICAgIDogTWF0aC5tYXgocC5pbmRleCwgZmlsdGVyLmhlYWRlclJvd3MgLSBjb3VudCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgICBjYXNlICdjb3JlLmF4aXMucmVzaXplJzoge1xuICAgICAgY29uc3Qgb3JkZXIgPSBwLmF4aXMgPT09ICdyb3cnID8gc2gucm93T3JkZXIgOiBzaC5jb2x1bW5PcmRlcjtcbiAgICAgIGFzc2VydChwLmluZGV4ICsgcC5jb3VudCA8PSBvcmRlci5sZW5ndGgsICdJTlZBTElEX1JBTkdFJywgJ1Vua25vd24gcm93L2NvbHVtbicpO1xuICAgICAgY29uc3QgbWV0YSA9IHAuYXhpcyA9PT0gJ3JvdycgPyBzaC5yb3dzIDogc2guY29sdW1ucztcbiAgICAgIGZvciAobGV0IGkgPSBwLmluZGV4OyBpIDwgcC5pbmRleCArIHAuY291bnQ7IGkrKykge1xuICAgICAgICBjb25zdCBpZCA9IG9yZGVyW2ldO1xuICAgICAgICBpZiAobWV0YVtpZF0/LnNpemUgPT09IHAuc2l6ZSkgY29udGludWU7XG4gICAgICAgIG1ldGFbaWRdID0geyAuLi5tZXRhW2lkXSwgc2l6ZTogcC5zaXplIH07XG4gICAgICB9XG4gICAgICBicmVhaztcbiAgICB9XG4gICAgY2FzZSAnY29yZS5heGlzLnZpc2liaWxpdHknOlxuICAgIGNhc2UgJ2NvcmUuYXhpcy52aXNpYmlsaXR5QWxsJzoge1xuICAgICAgY29uc3Qgb3JkZXIgPSBwLmF4aXMgPT09ICdyb3cnID8gc2gucm93T3JkZXIgOiBzaC5jb2x1bW5PcmRlcjtcbiAgICAgIGNvbnN0IHN0YXJ0ID0gY29tbWFuZC50eXBlID09PSAnY29yZS5heGlzLnZpc2liaWxpdHlBbGwnID8gMCA6IHAuaW5kZXg7XG4gICAgICBjb25zdCBlbmQgPSBjb21tYW5kLnR5cGUgPT09ICdjb3JlLmF4aXMudmlzaWJpbGl0eUFsbCcgPyBvcmRlci5sZW5ndGggOiBwLmluZGV4ICsgcC5jb3VudDtcbiAgICAgIGFzc2VydChlbmQgPD0gb3JkZXIubGVuZ3RoLCAnSU5WQUxJRF9SQU5HRScsICdVbmtub3duIHJvdy9jb2x1bW4nKTtcbiAgICAgIGNvbnN0IG1ldGEgPSBwLmF4aXMgPT09ICdyb3cnID8gc2gucm93cyA6IHNoLmNvbHVtbnM7XG4gICAgICBmb3IgKGxldCBpID0gc3RhcnQ7IGkgPCBlbmQ7IGkrKykge1xuICAgICAgICBjb25zdCBpZCA9IG9yZGVyW2ldO1xuICAgICAgICBpZiAoIXAuaGlkZGVuICYmICFtZXRhW2lkXT8uaGlkZGVuKSBjb250aW51ZTtcbiAgICAgICAgaWYgKHAuaGlkZGVuICYmIG1ldGFbaWRdPy5oaWRkZW4pIGNvbnRpbnVlO1xuICAgICAgICBtZXRhW2lkXSA9IHsgLi4ubWV0YVtpZF0sIGhpZGRlbjogcC5oaWRkZW4gfTtcbiAgICAgIH1cbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgICBjYXNlICdjb3JlLmF4aXMubWV0YSc6IHtcbiAgICAgIGNvbnN0IG9yZGVyID0gcC5heGlzID09PSAncm93JyA/IHNoLnJvd09yZGVyIDogc2guY29sdW1uT3JkZXI7XG4gICAgICBhc3NlcnQocC5pbmRleCA8IG9yZGVyLmxlbmd0aCwgJ0lOVkFMSURfUkFOR0UnLCAnVW5rbm93biByb3cvY29sdW1uJyk7XG4gICAgICBjb25zdCBtZXRhID0gcC5heGlzID09PSAncm93JyA/IHNoLnJvd3MgOiBzaC5jb2x1bW5zO1xuICAgICAgbWV0YVtvcmRlcltwLmluZGV4XV0gPSB7XG4gICAgICAgIC4uLm1ldGFbb3JkZXJbcC5pbmRleF1dLFxuICAgICAgICAuLi4ocC5zaXplICE9PSB1bmRlZmluZWQgPyB7IHNpemU6IHAuc2l6ZSB9IDoge30pLFxuICAgICAgICAuLi4ocC5oaWRkZW4gIT09IHVuZGVmaW5lZCA/IHsgaGlkZGVuOiBwLmhpZGRlbiB9IDoge30pLFxuICAgICAgfTtcbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgICBkZWZhdWx0OlxuICAgICAgYXNzZXJ0KGZhbHNlLCAnVU5TVVBQT1JURURfRkVBVFVSRScsICdVbmtub3duIGNvbW1hbmQnKTtcbiAgfVxufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLFFBQVEsY0FBbUQ7QUFDcEU7QUFBQSxFQUNFO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsT0FDSztBQUNBLGdCQUFTLFlBQVksR0FBcUIsU0FBd0I7QUFDdkUsUUFBTSxJQUFJLFFBQVE7QUFDbEIsUUFBTSxLQUFLLFNBQVMsR0FBRyxFQUFFLE9BQU87QUFDaEMsVUFBUSxRQUFRLE1BQU07QUFBQSxJQUNwQixLQUFLO0FBQUEsSUFDTCxLQUFLLG9CQUFvQjtBQUN2QixZQUFNLE1BQU0sRUFBRSxTQUFTLE9BQ3JCLFFBQVEsTUFBTSxHQUFHLFdBQVcsR0FBRyxhQUMvQixTQUFTLFFBQVEsU0FBUyxvQkFDMUIsUUFBUSxTQUFTLEVBQUUsSUFBSSxTQUFTLEVBQUU7QUFDcEM7QUFBQSxRQUNFLEVBQUUsVUFBVSxTQUFTLE1BQU0sU0FBUyxNQUFNLFNBQVMsVUFBVSxRQUFRO0FBQUEsUUFDckU7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUNBO0FBQUEsUUFDRSxTQUNJLE1BQU0sU0FBUyxVQUFVLE1BQU0sT0FBTyxPQUFPLE9BQU8sV0FDcEQsTUFBTSxTQUFTLFNBQVM7QUFBQSxRQUM1QjtBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBQ0EsVUFBSSxRQUFRO0FBQ1YsY0FBTSxPQUFPLE1BQU0sY0FBYztBQUNqQztBQUFBLFVBQ0UsRUFBRSxJQUFJLE1BQU0sQ0FBQyxJQUFZLE1BQWMsT0FBTyxHQUFHLElBQUksSUFBSSxDQUFDLEtBQ3hELEdBQUcsSUFBSSxJQUFJLFNBQVM7QUFBQSxVQUN0QjtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLFVBQUk7QUFDRjtBQUFBLFdBQ0Usb0JBQUksSUFBSSxDQUFDLEdBQUcsT0FBTyxHQUFHLEVBQUUsR0FBRyxDQUFDLEdBQUUsU0FBUyxNQUFNLFNBQVM7QUFBQSxVQUN0RDtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQ0YsWUFBTSxRQUFRLE1BQU0sYUFBYSxlQUMvQixNQUFNLE1BQU0sV0FBVztBQUN6QixpQkFBVyxLQUFLLEdBQUc7QUFDakI7QUFBQSxVQUNFLEVBQUUsRUFBRSxRQUFRLEVBQUUsR0FBRyxLQUFLLEVBQUUsU0FBUyxDQUFDLFNBQVMsUUFBUSxLQUFLLEVBQUUsS0FBSztBQUFBLFVBQy9EO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFDRixZQUFNLFVBQVUsU0FBUyxDQUFDLElBQUksTUFBTSxNQUFNLEVBQUUsT0FBTyxFQUFFLFFBQVEsS0FBSztBQUNsRSxZQUFNLFVBQVUsSUFBSSxJQUFJLE9BQU87QUFDL0I7QUFBQSxRQUNFO0FBQUEsUUFDQSxxQkFBcUIsU0FBUyxHQUFHLElBQUk7QUFBQSxRQUNyQyxHQUFHO0FBQUEsUUFDSCwwQkFBMEIsU0FBUyxHQUFHLElBQUk7QUFBQSxRQUMxQyxTQUNJLFNBQ0EsQ0FBQyxPQUFPLFNBQVMsTUFBTSxPQUFPLEdBQUcsTUFBTSxRQUFRLElBQUksTUFBTSxLQUFLLFFBQVEsS0FBSyxRQUFRO0FBQUEsTUFDekY7QUFDQSxVQUFJLE9BQVEsSUFBRyxNQUFNLGNBQWMsY0FBYyxLQUFLO0FBQ3RELFVBQUksUUFBUTtBQUVWLGlCQUFTLElBQUksR0FBRyxJQUFJLEVBQUUsSUFBSSxRQUFRLEtBQUs7QUFDckMsZ0JBQU0sT0FBTyxFQUFFLFFBQVEsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLE1BQU0sR0FBRyxJQUFJLElBQUksQ0FBQztBQUFBLE1BQzVELE9BQU87QUFDTCxjQUFNLE9BQU8sRUFBRSxPQUFPLEtBQUs7QUFDM0IsbUJBQVcsS0FBSyxPQUFPLEtBQUssR0FBRyxLQUFLO0FBQ2xDLGNBQUksUUFBUSxJQUFJLE1BQU0sR0FBRyxNQUFNLENBQUMsRUFBRSxRQUFRLEdBQUcsTUFBTSxDQUFDLEVBQUUsUUFBUSxFQUFHLFFBQU8sR0FBRyxNQUFNLENBQUM7QUFBQSxNQUN0RjtBQUNBLGlCQUFXLE1BQU0sUUFBUyxTQUFRLE1BQU0sR0FBRyxPQUFPLEdBQUcsU0FBUyxFQUFFO0FBQ2hFLFNBQUcsT0FBTyxRQUFRLENBQUMsTUFBTTtBQUN2QixZQUFJLEVBQUUsS0FBSyxLQUFLLEVBQUUsT0FBTztBQUN2QixZQUFFLEtBQUssS0FBSyxTQUFTLFFBQVEsQ0FBQztBQUM5QixZQUFFLEdBQUcsS0FBSyxTQUFTLFFBQVEsQ0FBQztBQUFBLFFBQzlCO0FBQUEsTUFDRixDQUFDO0FBQ0QsWUFBTSxJQUFJLE1BQU0sU0FBUztBQUN6QixTQUFHLE9BQU8sQ0FBQyxJQUFJLEtBQUs7QUFBQSxRQUNsQixNQUFNO0FBQUEsUUFDTixHQUFHLE9BQU8sQ0FBQyxJQUFJLEVBQUUsUUFDYixLQUFLLElBQUksRUFBRSxPQUFPLEdBQUcsT0FBTyxDQUFDLEtBQUssU0FBUyxRQUFRLENBQUMsTUFBTSxJQUMxRCxHQUFHLE9BQU8sQ0FBQztBQUFBLE1BQ2pCO0FBQ0EsVUFBSSxHQUFHLFFBQVE7QUFDYixjQUFNLFNBQVMsR0FBRztBQUNsQixZQUFJLENBQUMsS0FBSztBQUNSLGdCQUFNQSxXQUFVLENBQUMsV0FDZixDQUFDLFVBQVUsVUFBVSxFQUFFLFNBQVMsU0FBUyxFQUFFLFFBQVE7QUFDckQsZ0JBQU0sVUFBVSxDQUFDLFdBQ2YsVUFBVSxFQUFFLFFBQVEsVUFBVSxTQUFTLFFBQVEsQ0FBQyxTQUFTO0FBQzNELGNBQUksWUFBWSxRQUFRO0FBQ3RCLGdCQUFJQSxTQUFRLE9BQU8sTUFBTSxFQUFHLElBQUcsU0FBUztBQUFBLGdCQUNuQyxRQUFPLFNBQVMsUUFBUSxPQUFPLE1BQU07QUFBQSxVQUM1QyxPQUFPO0FBQ0wsbUJBQU8sV0FBVyxPQUFPLFNBQVMsT0FBTyxDQUFDLGNBQWMsQ0FBQ0EsU0FBUSxVQUFVLE1BQU0sQ0FBQztBQUNsRix1QkFBVyxhQUFhLE9BQU8sU0FBVSxXQUFVLFNBQVMsUUFBUSxVQUFVLE1BQU07QUFDcEYsZ0JBQUksQ0FBQyxPQUFPLFNBQVMsT0FBUSxJQUFHLFNBQVM7QUFBQSxVQUMzQztBQUFBLFFBQ0YsV0FBVyxnQkFBZ0IsVUFBVSxFQUFFLFFBQVEsT0FBTyxZQUFZO0FBQ2hFLGlCQUFPLGFBQWEsU0FDaEIsT0FBTyxhQUFhLFFBQ3BCLEtBQUssSUFBSSxFQUFFLE9BQU8sT0FBTyxhQUFhLEtBQUs7QUFBQSxRQUNqRDtBQUFBLE1BQ0Y7QUFDQTtBQUFBLElBQ0Y7QUFBQSxJQUNBLEtBQUssb0JBQW9CO0FBQ3ZCLFlBQU0sUUFBUSxFQUFFLFNBQVMsUUFBUSxHQUFHLFdBQVcsR0FBRztBQUNsRCxhQUFPLEVBQUUsUUFBUSxFQUFFLFNBQVMsTUFBTSxRQUFRLGlCQUFpQixvQkFBb0I7QUFDL0UsWUFBTSxPQUFPLEVBQUUsU0FBUyxRQUFRLEdBQUcsT0FBTyxHQUFHO0FBQzdDLGVBQVMsSUFBSSxFQUFFLE9BQU8sSUFBSSxFQUFFLFFBQVEsRUFBRSxPQUFPLEtBQUs7QUFDaEQsY0FBTSxLQUFLLE1BQU0sQ0FBQztBQUNsQixZQUFJLEtBQUssRUFBRSxHQUFHLFNBQVMsRUFBRSxLQUFNO0FBQy9CLGFBQUssRUFBRSxJQUFJLEVBQUUsR0FBRyxLQUFLLEVBQUUsR0FBRyxNQUFNLEVBQUUsS0FBSztBQUFBLE1BQ3pDO0FBQ0E7QUFBQSxJQUNGO0FBQUEsSUFDQSxLQUFLO0FBQUEsSUFDTCxLQUFLLDJCQUEyQjtBQUM5QixZQUFNLFFBQVEsRUFBRSxTQUFTLFFBQVEsR0FBRyxXQUFXLEdBQUc7QUFDbEQsWUFBTSxRQUFRLFFBQVEsU0FBUyw0QkFBNEIsSUFBSSxFQUFFO0FBQ2pFLFlBQU0sTUFBTSxRQUFRLFNBQVMsNEJBQTRCLE1BQU0sU0FBUyxFQUFFLFFBQVEsRUFBRTtBQUNwRixhQUFPLE9BQU8sTUFBTSxRQUFRLGlCQUFpQixvQkFBb0I7QUFDakUsWUFBTSxPQUFPLEVBQUUsU0FBUyxRQUFRLEdBQUcsT0FBTyxHQUFHO0FBQzdDLGVBQVMsSUFBSSxPQUFPLElBQUksS0FBSyxLQUFLO0FBQ2hDLGNBQU0sS0FBSyxNQUFNLENBQUM7QUFDbEIsWUFBSSxDQUFDLEVBQUUsVUFBVSxDQUFDLEtBQUssRUFBRSxHQUFHLE9BQVE7QUFDcEMsWUFBSSxFQUFFLFVBQVUsS0FBSyxFQUFFLEdBQUcsT0FBUTtBQUNsQyxhQUFLLEVBQUUsSUFBSSxFQUFFLEdBQUcsS0FBSyxFQUFFLEdBQUcsUUFBUSxFQUFFLE9BQU87QUFBQSxNQUM3QztBQUNBO0FBQUEsSUFDRjtBQUFBLElBQ0EsS0FBSyxrQkFBa0I7QUFDckIsWUFBTSxRQUFRLEVBQUUsU0FBUyxRQUFRLEdBQUcsV0FBVyxHQUFHO0FBQ2xELGFBQU8sRUFBRSxRQUFRLE1BQU0sUUFBUSxpQkFBaUIsb0JBQW9CO0FBQ3BFLFlBQU0sT0FBTyxFQUFFLFNBQVMsUUFBUSxHQUFHLE9BQU8sR0FBRztBQUM3QyxXQUFLLE1BQU0sRUFBRSxLQUFLLENBQUMsSUFBSTtBQUFBLFFBQ3JCLEdBQUcsS0FBSyxNQUFNLEVBQUUsS0FBSyxDQUFDO0FBQUEsUUFDdEIsR0FBSSxFQUFFLFNBQVMsU0FBWSxFQUFFLE1BQU0sRUFBRSxLQUFLLElBQUksQ0FBQztBQUFBLFFBQy9DLEdBQUksRUFBRSxXQUFXLFNBQVksRUFBRSxRQUFRLEVBQUUsT0FBTyxJQUFJLENBQUM7QUFBQSxNQUN2RDtBQUNBO0FBQUEsSUFDRjtBQUFBLElBQ0E7QUFDRSxhQUFPLE9BQU8sdUJBQXVCLGlCQUFpQjtBQUFBLEVBQzFEO0FBQ0Y7IiwibmFtZXMiOlsicmVtb3ZlZCJdfQ==
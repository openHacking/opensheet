import { numericSeries } from "/@fs/Volumes/github/private/opensheet/packages/core/src/numeric-series.ts";
import { createTileOffsetter, tileCell, validatePasteTile } from "/@fs/Volumes/github/private/opensheet/packages/core/src/paste-tile.ts";
import { calendarSeries } from "/@fs/Volumes/github/private/opensheet/packages/core/src/calendar-series.ts";
import { FormulaCalculation } from "/@fs/Volumes/github/private/opensheet/packages/core/src/calculation.ts";
import { selectiveCopyCell } from "/@fs/Volumes/github/private/opensheet/packages/core/src/selective-copy.ts";
import { validateCommand } from "/@fs/Volumes/github/private/opensheet/packages/core/src/commands/schemas.ts";
import { intersects } from "/@fs/Volumes/github/private/opensheet/packages/core/src/address.ts";
import { checkBounds } from "/@fs/Volumes/github/private/opensheet/packages/core/src/model.ts";
import {
  assert,
  LIMITS,
  key
} from "/@fs/Volumes/github/private/opensheet/packages/core/src/types.ts";
import {
  applyPastedCell,
  cell,
  guardMerges,
  iterate,
  offsetCellFormula,
  sheetFor,
  styleId
} from "/@fs/Volumes/github/private/opensheet/packages/core/src/commands/helpers.ts";
function sameInput(a, b) {
  if (a === null || b === null) return a === b;
  if (a.type !== b.type) return false;
  switch (a.type) {
    case "blank":
      return true;
    case "formula":
      return b.type === "formula" && a.expression === b.expression;
    case "error":
      return b.type === "error" && a.code === b.code;
    case "number":
      return b.type === "number" && Object.is(a.value, b.value);
    default:
      return "value" in b && a.value === b.value;
  }
}
export function cellsCommand(s, command) {
  const p = command.payload;
  const sh = sheetFor(s, p.sheetId);
  switch (command.type) {
    case "core.cells.copySpecial": {
      const source = p.range;
      const target = p.target;
      checkBounds(sh, source);
      checkBounds(sh, target);
      const rows = source.endRow - source.startRow;
      const columns = source.endColumn - source.startColumn;
      assert(
        rows === target.endRow - target.startRow && columns === target.endColumn - target.startColumn,
        "INVALID_RANGE",
        "Copy ranges must have equal dimensions"
      );
      assert(rows * columns <= LIMITS.rangeCells, "LIMIT_EXCEEDED", "Copy exceeds the cell limit");
      assert(
        !sh.merges.some((merge) => intersects(merge, source) || intersects(merge, target)),
        "INVALID_RANGE",
        "Unmerge before copying"
      );
      const calculator = new FormulaCalculation(
        (id) => sheetFor(s, id),
        (name) => s.sheets.find((sheet) => sheet.name.toLowerCase() === name.toLowerCase())?.id,
        s.dateSystem
      );
      const items = [];
      let bytes = 0;
      for (let row = source.startRow; row < source.endRow; row++)
        for (let column = source.startColumn; column < source.endColumn; column++) {
          const original = sh.cells[key(sh.rowOrder[row], sh.columnOrder[column])];
          const style = original?.styleId ? s.styles[original.styleId] : {};
          const item = selectiveCopyCell(
            {
              row,
              column,
              ...p.mode === "values" ? { value: calculator.value(sh.id, row, column) } : {},
              ...p.mode === "formulas" ? { input: original?.input } : {},
              ...p.mode === "formats" ? { style, numberFormat: original?.numberFormat ?? style?.numberFormat } : {}
            },
            p.mode,
            target.startRow - source.startRow,
            target.startColumn - source.startColumn
          );
          bytes += JSON.stringify(item).length * 2;
          assert(bytes <= 32 * 1024 * 1024, "LIMIT_EXCEEDED", "Copy working set is too large");
          items.push(item);
        }
      const paste = validateCommand({
        type: "core.cells.paste",
        payload: { sheetId: sh.id, cells: items }
      });
      for (const item of paste.payload.cells)
        applyPastedCell(s, cell(sh, item.row, item.column), item);
      break;
    }
    case "core.cells.pasteTile": {
      const tile = p;
      let units = validatePasteTile(sh, tile);
      const charge = (extra) => {
        units += extra;
        assert(
          units <= 32 * 1024 * 1024,
          "LIMIT_EXCEEDED",
          "Expanded clipboard content is too large"
        );
      };
      const offset = createTileOffsetter();
      if (tile.cells.some((item) => item.source && item.input?.type === "formula"))
        iterate(sh, tile.range, (row, column) => {
          tileCell(tile, row, column, charge, offset);
        });
      iterate(sh, tile.range, (row, column) => {
        const item = tileCell(tile, row, column, () => {
        }, offset);
        applyPastedCell(s, cell(sh, row, column), item);
      });
      break;
    }
    case "core.cells.paste":
      for (const item of p.cells) {
        checkBounds(sh, {
          startRow: item.row,
          endRow: item.row + 1,
          startColumn: item.column,
          endColumn: item.column + 1
        });
        assert(
          !sh.merges.some(
            (m) => item.row >= m.startRow && item.row < m.endRow && item.column >= m.startColumn && item.column < m.endColumn
          ),
          "INVALID_RANGE",
          "Unmerge before pasting cell inputs or formats"
        );
      }
      for (const item of p.cells) applyPastedCell(s, cell(sh, item.row, item.column), item);
      break;
    case "core.cells.replace": {
      const growth = p.replacement.length - p.query.length;
      if (growth > 0) {
        for (const cell2 of Object.values(sh.cells))
          if (cell2.input.type === "string" && cell2.input.value.includes(p.query)) {
            const original = cell2.input.value;
            let length = original.length;
            let position = 0;
            while ((position = original.indexOf(p.query, position)) !== -1) {
              length += growth;
              assert(length <= LIMITS.text, "LIMIT_EXCEEDED", "Replacement exceeds the text limit");
              position += p.query.length;
            }
          }
      }
      for (const cell2 of Object.values(sh.cells))
        if (cell2.input.type === "string" && cell2.input.value.includes(p.query)) {
          const original = cell2.input.value;
          const input = {
            type: "string",
            value: original.replaceAll(p.query, () => p.replacement)
          };
          cell2.input = input;
        }
      break;
    }
    case "core.cells.fillSeries": {
      checkBounds(sh, p.range);
      assert(
        !sh.merges.some((m) => intersects(m, p.range)),
        "INVALID_RANGE",
        "Unmerge before filling a series"
      );
      const count = p.axis === "row" ? p.range.endRow - p.range.startRow : p.range.endColumn - p.range.startColumn;
      const values = p.calendar ? calendarSeries(p.start, p.step, count, p.calendar, s.dateSystem) : numericSeries(p.start, p.step, count);
      iterate(sh, p.range, (r, c) => {
        const target = cell(sh, r, c);
        target.input = {
          type: "number",
          value: values[p.axis === "row" ? r - p.range.startRow : c - p.range.startColumn]
        };
        delete target.cached;
      });
      break;
    }
    case "core.cells.copy":
    case "core.cells.fillDown": {
      const source = p.range;
      const target = command.type === "core.cells.fillDown" ? p.range : p.target;
      checkBounds(sh, source);
      checkBounds(sh, target);
      assert(
        !sh.merges.some((m) => intersects(m, source) || intersects(m, target)),
        "INVALID_RANGE",
        "Unmerge before copying or filling"
      );
      const fill = command.type === "core.cells.fillDown";
      assert(
        fill || source.endRow - source.startRow === target.endRow - target.startRow && source.endColumn - source.startColumn === target.endColumn - target.startColumn,
        "INVALID_RANGE",
        "Copy ranges must have equal dimensions"
      );
      const original = /* @__PURE__ */ new Map();
      let hasFormula = false;
      const snapshotRange = fill ? { ...source, endRow: source.startRow + 1 } : source;
      iterate(sh, snapshotRange, (r, c) => {
        const value = sh.cells[key(sh.rowOrder[r], sh.columnOrder[c])];
        if (value) {
          original.set(`${r}:${c}`, structuredClone(value));
          hasFormula ||= value.input.type === "formula";
        }
      });
      if (hasFormula)
        iterate(sh, target, (r, c) => {
          if (fill && r === source.startRow) return;
          const sr = fill ? source.startRow : source.startRow + r - target.startRow;
          const sc = source.startColumn + c - target.startColumn;
          const stored = original.get(`${sr}:${sc}`);
          if (stored?.input.type === "formula")
            offsetCellFormula(stored.input.expression, r - sr, c - sc);
        });
      iterate(sh, target, (r, c) => {
        if (fill && r === source.startRow) return;
        const sr = fill ? source.startRow : source.startRow + r - target.startRow;
        const sc = source.startColumn + c - target.startColumn;
        const stored = original.get(`${sr}:${sc}`);
        const k = key(sh.rowOrder[r], sh.columnOrder[c]);
        if (!stored) {
          delete sh.cells[k];
          return;
        }
        const value = structuredClone(stored);
        value.rowId = sh.rowOrder[r];
        value.columnId = sh.columnOrder[c];
        if (value.input.type === "formula")
          value.input.expression = offsetCellFormula(value.input.expression, r - sr, c - sc);
        delete value.cached;
        sh.cells[k] = value;
      });
      break;
    }
    case "core.cells.set":
      for (const x of p.cells) {
        checkBounds(sh, {
          startRow: x.row,
          startColumn: x.column,
          endRow: x.row + 1,
          endColumn: x.column + 1
        });
        assert(
          !x.expected || sh.rowOrder[x.row] === x.expected.rowId && sh.columnOrder[x.column] === x.expected.columnId,
          "REVISION_CONFLICT",
          "Cell position changed; select it again before editing"
        );
        if (x.expected?.input !== void 0) {
          const current = sh.cells[key(sh.rowOrder[x.row], sh.columnOrder[x.column])]?.input ?? null;
          assert(
            sameInput(current, x.expected.input),
            "REVISION_CONFLICT",
            "Cell content changed; review the draft before saving"
          );
        }
        const m = sh.merges.find(
          (m2) => x.row >= m2.startRow && x.row < m2.endRow && x.column >= m2.startColumn && x.column < m2.endColumn
        );
        assert(
          !m || x.row === m.startRow && x.column === m.startColumn,
          "INVALID_RANGE",
          "Cannot write a covered merged cell"
        );
      }
      for (const x of p.cells) {
        const target = cell(sh, x.row, x.column);
        target.input = x.input;
        delete target.cached;
      }
      break;
    case "core.cells.annotation":
      checkBounds(sh, p.range);
      for (const merge of sh.merges) {
        const startRow = Math.max(p.range.startRow, merge.startRow);
        const endRow = Math.min(p.range.endRow, merge.endRow);
        const startColumn = Math.max(p.range.startColumn, merge.startColumn);
        const endColumn = Math.min(p.range.endColumn, merge.endColumn);
        assert(
          startRow >= endRow || startColumn >= endColumn || startRow === merge.startRow && startColumn === merge.startColumn && endRow === startRow + 1 && endColumn === startColumn + 1,
          "INVALID_RANGE",
          "Cannot annotate a covered merged cell"
        );
      }
      iterate(sh, p.range, (r, c) => {
        if (!sh.cells[key(sh.rowOrder[r], sh.columnOrder[c])] && p.note == null && p.link == null)
          return;
        const target = cell(sh, r, c);
        if (p.note !== void 0) {
          if (p.note === null) delete target.note;
          else target.note = p.note;
        }
        if (p.link !== void 0) {
          if (p.link === null) delete target.link;
          else target.link = { ...p.link };
        }
      });
      break;
    case "core.cells.style":
      guardMerges(sh, p.range);
      iterate(sh, p.range, (r, c) => {
        const x = cell(sh, r, c);
        x.styleId = styleId(s, { ...x.styleId ? s.styles[x.styleId] : {}, ...p.style });
        if (p.style.numberFormat !== void 0) delete x.numberFormat;
      });
      break;
    case "core.cells.clear":
      guardMerges(sh, p.range);
      iterate(sh, p.range, (r, c) => {
        const k = key(sh.rowOrder[r], sh.columnOrder[c]);
        if (p.all) delete sh.cells[k];
        else if (sh.cells[k]) {
          sh.cells[k].input = { type: "blank" };
          delete sh.cells[k].cached;
        }
      });
      break;
    case "core.cells.merge": {
      checkBounds(sh, p.range);
      assert(
        !sh.merges.some((m) => intersects(m, p.range)),
        "INVALID_RANGE",
        "Overlapping merged cells"
      );
      const covered = [];
      iterate(sh, p.range, (r, c) => {
        if (r === p.range.startRow && c === p.range.startColumn) return;
        const x = sh.cells[key(sh.rowOrder[r], sh.columnOrder[c])];
        assert(
          !x || x.input.type === "blank" || p.discardCoveredValues,
          "INVALID_ARGUMENT",
          "Merge would discard values"
        );
        if (x) covered.push(x);
      });
      for (const x of covered) {
        x.input = { type: "blank" };
        delete x.cached;
      }
      sh.merges.push(p.range);
      break;
    }
    case "core.cells.unmerge":
      checkBounds(sh, p.range);
      sh.merges = sh.merges.filter((m) => !intersects(m, p.range));
      break;
    default:
      assert(false, "UNSUPPORTED_FEATURE", "Unknown command");
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNlbGxzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IG51bWVyaWNTZXJpZXMgfSBmcm9tICcuLi9udW1lcmljLXNlcmllcy5qcyc7XG5pbXBvcnQgeyBjcmVhdGVUaWxlT2Zmc2V0dGVyLCB0aWxlQ2VsbCwgdmFsaWRhdGVQYXN0ZVRpbGUsIHR5cGUgUGFzdGVUaWxlIH0gZnJvbSAnLi4vcGFzdGUtdGlsZS5qcyc7XG5pbXBvcnQgeyBjYWxlbmRhclNlcmllcyB9IGZyb20gJy4uL2NhbGVuZGFyLXNlcmllcy5qcyc7XG5pbXBvcnQgeyBGb3JtdWxhQ2FsY3VsYXRpb24gfSBmcm9tICcuLi9jYWxjdWxhdGlvbi5qcyc7XG5pbXBvcnQgeyBzZWxlY3RpdmVDb3B5Q2VsbCB9IGZyb20gJy4uL3NlbGVjdGl2ZS1jb3B5LmpzJztcbmltcG9ydCB7IHZhbGlkYXRlQ29tbWFuZCB9IGZyb20gJy4vc2NoZW1hcy5qcyc7XG5pbXBvcnQgeyBpbnRlcnNlY3RzIH0gZnJvbSAnLi4vYWRkcmVzcy5qcyc7XG5pbXBvcnQgeyBjaGVja0JvdW5kcyB9IGZyb20gJy4uL21vZGVsLmpzJztcbmltcG9ydCB7XG4gIGFzc2VydCxcbiAgTElNSVRTLFxuICBrZXksXG4gIHR5cGUgQ2VsbElucHV0LFxuICB0eXBlIENlbGxSZWNvcmQsXG4gIHR5cGUgQ29tbWFuZCxcbiAgdHlwZSBSZWN0LFxuICB0eXBlIFdvcmtib29rU25hcHNob3QsXG59IGZyb20gJy4uL3R5cGVzLmpzJztcbmltcG9ydCB7XG4gIGFwcGx5UGFzdGVkQ2VsbCxcbiAgY2VsbCxcbiAgZ3VhcmRNZXJnZXMsXG4gIGl0ZXJhdGUsXG4gIG9mZnNldENlbGxGb3JtdWxhLFxuICBzaGVldEZvcixcbiAgc3R5bGVJZCxcbn0gZnJvbSAnLi9oZWxwZXJzLmpzJztcbmZ1bmN0aW9uIHNhbWVJbnB1dChhOiBDZWxsSW5wdXQgfCBudWxsLCBiOiBDZWxsSW5wdXQgfCBudWxsKTogYm9vbGVhbiB7XG4gIGlmIChhID09PSBudWxsIHx8IGIgPT09IG51bGwpIHJldHVybiBhID09PSBiO1xuICBpZiAoYS50eXBlICE9PSBiLnR5cGUpIHJldHVybiBmYWxzZTtcbiAgc3dpdGNoIChhLnR5cGUpIHtcbiAgICBjYXNlICdibGFuayc6XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICBjYXNlICdmb3JtdWxhJzpcbiAgICAgIHJldHVybiBiLnR5cGUgPT09ICdmb3JtdWxhJyAmJiBhLmV4cHJlc3Npb24gPT09IGIuZXhwcmVzc2lvbjtcbiAgICBjYXNlICdlcnJvcic6XG4gICAgICByZXR1cm4gYi50eXBlID09PSAnZXJyb3InICYmIGEuY29kZSA9PT0gYi5jb2RlO1xuICAgIGNhc2UgJ251bWJlcic6XG4gICAgICByZXR1cm4gYi50eXBlID09PSAnbnVtYmVyJyAmJiBPYmplY3QuaXMoYS52YWx1ZSwgYi52YWx1ZSk7XG4gICAgZGVmYXVsdDpcbiAgICAgIHJldHVybiAndmFsdWUnIGluIGIgJiYgYS52YWx1ZSA9PT0gYi52YWx1ZTtcbiAgfVxufVxuZXhwb3J0IGZ1bmN0aW9uIGNlbGxzQ29tbWFuZChzOiBXb3JrYm9va1NuYXBzaG90LCBjb21tYW5kOiBDb21tYW5kKTogdm9pZCB7XG4gIGNvbnN0IHAgPSBjb21tYW5kLnBheWxvYWQgYXMgYW55OyAvLyBWYWxpZGF0ZWQgYmVmb3JlIGRpc3BhdGNoLlxuICBjb25zdCBzaCA9IHNoZWV0Rm9yKHMsIHAuc2hlZXRJZCk7XG4gIHN3aXRjaCAoY29tbWFuZC50eXBlKSB7XG4gICAgY2FzZSAnY29yZS5jZWxscy5jb3B5U3BlY2lhbCc6IHtcbiAgICAgIGNvbnN0IHNvdXJjZSA9IHAucmFuZ2UgYXMgUmVjdDtcbiAgICAgIGNvbnN0IHRhcmdldCA9IHAudGFyZ2V0IGFzIFJlY3Q7XG4gICAgICBjaGVja0JvdW5kcyhzaCwgc291cmNlKTtcbiAgICAgIGNoZWNrQm91bmRzKHNoLCB0YXJnZXQpO1xuICAgICAgY29uc3Qgcm93cyA9IHNvdXJjZS5lbmRSb3cgLSBzb3VyY2Uuc3RhcnRSb3c7XG4gICAgICBjb25zdCBjb2x1bW5zID0gc291cmNlLmVuZENvbHVtbiAtIHNvdXJjZS5zdGFydENvbHVtbjtcbiAgICAgIGFzc2VydChcbiAgICAgICAgcm93cyA9PT0gdGFyZ2V0LmVuZFJvdyAtIHRhcmdldC5zdGFydFJvdyAmJlxuICAgICAgICAgIGNvbHVtbnMgPT09IHRhcmdldC5lbmRDb2x1bW4gLSB0YXJnZXQuc3RhcnRDb2x1bW4sXG4gICAgICAgICdJTlZBTElEX1JBTkdFJyxcbiAgICAgICAgJ0NvcHkgcmFuZ2VzIG11c3QgaGF2ZSBlcXVhbCBkaW1lbnNpb25zJyxcbiAgICAgICk7XG4gICAgICBhc3NlcnQocm93cyAqIGNvbHVtbnMgPD0gTElNSVRTLnJhbmdlQ2VsbHMsICdMSU1JVF9FWENFRURFRCcsICdDb3B5IGV4Y2VlZHMgdGhlIGNlbGwgbGltaXQnKTtcbiAgICAgIGFzc2VydChcbiAgICAgICAgIXNoLm1lcmdlcy5zb21lKChtZXJnZSkgPT4gaW50ZXJzZWN0cyhtZXJnZSwgc291cmNlKSB8fCBpbnRlcnNlY3RzKG1lcmdlLCB0YXJnZXQpKSxcbiAgICAgICAgJ0lOVkFMSURfUkFOR0UnLFxuICAgICAgICAnVW5tZXJnZSBiZWZvcmUgY29weWluZycsXG4gICAgICApO1xuICAgICAgY29uc3QgY2FsY3VsYXRvciA9IG5ldyBGb3JtdWxhQ2FsY3VsYXRpb24oXG4gICAgICAgIChpZCkgPT4gc2hlZXRGb3IocywgaWQpLFxuICAgICAgICAobmFtZSkgPT4gcy5zaGVldHMuZmluZCgoc2hlZXQpID0+IHNoZWV0Lm5hbWUudG9Mb3dlckNhc2UoKSA9PT0gbmFtZS50b0xvd2VyQ2FzZSgpKT8uaWQsXG4gICAgICAgIHMuZGF0ZVN5c3RlbSxcbiAgICAgICk7XG4gICAgICBjb25zdCBpdGVtcyA9IFtdO1xuICAgICAgbGV0IGJ5dGVzID0gMDtcbiAgICAgIGZvciAobGV0IHJvdyA9IHNvdXJjZS5zdGFydFJvdzsgcm93IDwgc291cmNlLmVuZFJvdzsgcm93KyspXG4gICAgICAgIGZvciAobGV0IGNvbHVtbiA9IHNvdXJjZS5zdGFydENvbHVtbjsgY29sdW1uIDwgc291cmNlLmVuZENvbHVtbjsgY29sdW1uKyspIHtcbiAgICAgICAgICBjb25zdCBvcmlnaW5hbCA9IHNoLmNlbGxzW2tleShzaC5yb3dPcmRlcltyb3ddLCBzaC5jb2x1bW5PcmRlcltjb2x1bW5dKV07XG4gICAgICAgICAgY29uc3Qgc3R5bGUgPSBvcmlnaW5hbD8uc3R5bGVJZCA/IHMuc3R5bGVzW29yaWdpbmFsLnN0eWxlSWRdIDoge307XG4gICAgICAgICAgY29uc3QgaXRlbSA9IHNlbGVjdGl2ZUNvcHlDZWxsKFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICByb3csXG4gICAgICAgICAgICAgIGNvbHVtbixcbiAgICAgICAgICAgICAgLi4uKHAubW9kZSA9PT0gJ3ZhbHVlcycgPyB7IHZhbHVlOiBjYWxjdWxhdG9yLnZhbHVlKHNoLmlkLCByb3csIGNvbHVtbikgfSA6IHt9KSxcbiAgICAgICAgICAgICAgLi4uKHAubW9kZSA9PT0gJ2Zvcm11bGFzJyA/IHsgaW5wdXQ6IG9yaWdpbmFsPy5pbnB1dCB9IDoge30pLFxuICAgICAgICAgICAgICAuLi4ocC5tb2RlID09PSAnZm9ybWF0cydcbiAgICAgICAgICAgICAgICA/IHsgc3R5bGUsIG51bWJlckZvcm1hdDogb3JpZ2luYWw/Lm51bWJlckZvcm1hdCA/PyBzdHlsZT8ubnVtYmVyRm9ybWF0IH1cbiAgICAgICAgICAgICAgICA6IHt9KSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBwLm1vZGUsXG4gICAgICAgICAgICB0YXJnZXQuc3RhcnRSb3cgLSBzb3VyY2Uuc3RhcnRSb3csXG4gICAgICAgICAgICB0YXJnZXQuc3RhcnRDb2x1bW4gLSBzb3VyY2Uuc3RhcnRDb2x1bW4sXG4gICAgICAgICAgKTtcbiAgICAgICAgICBieXRlcyArPSBKU09OLnN0cmluZ2lmeShpdGVtKS5sZW5ndGggKiAyO1xuICAgICAgICAgIGFzc2VydChieXRlcyA8PSAzMiAqIDEwMjQgKiAxMDI0LCAnTElNSVRfRVhDRUVERUQnLCAnQ29weSB3b3JraW5nIHNldCBpcyB0b28gbGFyZ2UnKTtcbiAgICAgICAgICBpdGVtcy5wdXNoKGl0ZW0pO1xuICAgICAgICB9XG4gICAgICBjb25zdCBwYXN0ZSA9IHZhbGlkYXRlQ29tbWFuZCh7XG4gICAgICAgIHR5cGU6ICdjb3JlLmNlbGxzLnBhc3RlJyxcbiAgICAgICAgcGF5bG9hZDogeyBzaGVldElkOiBzaC5pZCwgY2VsbHM6IGl0ZW1zIH0sXG4gICAgICB9KTtcbiAgICAgIGZvciAoY29uc3QgaXRlbSBvZiBwYXN0ZS5wYXlsb2FkLmNlbGxzIGFzIHR5cGVvZiBpdGVtcylcbiAgICAgICAgYXBwbHlQYXN0ZWRDZWxsKHMsIGNlbGwoc2gsIGl0ZW0ucm93LCBpdGVtLmNvbHVtbiksIGl0ZW0pO1xuICAgICAgYnJlYWs7XG4gICAgfVxuICAgIGNhc2UgJ2NvcmUuY2VsbHMucGFzdGVUaWxlJzoge1xuICAgICAgY29uc3QgdGlsZSA9IHAgYXMgUGFzdGVUaWxlO1xuICAgICAgbGV0IHVuaXRzID0gdmFsaWRhdGVQYXN0ZVRpbGUoc2gsIHRpbGUpO1xuICAgICAgY29uc3QgY2hhcmdlID0gKGV4dHJhOiBudW1iZXIpID0+IHtcbiAgICAgICAgdW5pdHMgKz0gZXh0cmE7XG4gICAgICAgIGFzc2VydChcbiAgICAgICAgICB1bml0cyA8PSAzMiAqIDEwMjQgKiAxMDI0LFxuICAgICAgICAgICdMSU1JVF9FWENFRURFRCcsXG4gICAgICAgICAgJ0V4cGFuZGVkIGNsaXBib2FyZCBjb250ZW50IGlzIHRvbyBsYXJnZScsXG4gICAgICAgICk7XG4gICAgICB9O1xuICAgICAgY29uc3Qgb2Zmc2V0ID0gY3JlYXRlVGlsZU9mZnNldHRlcigpO1xuICAgICAgLy8gUmVsb2NhdGlvbiBjYW4gZ3JvdyBhIGZvcm11bGEgb3IgZXhjZWVkIHRoZSB0b3RhbCBjbGlwYm9hcmQgYnVkZ2V0LlxuICAgICAgLy8gQ2hlY2sgZXZlcnkgZGVzdGluYXRpb24gYmVmb3JlIGNyZWF0aW5nIG9yIGNoYW5naW5nIGFueSBjZWxsLlxuICAgICAgaWYgKHRpbGUuY2VsbHMuc29tZSgoaXRlbSkgPT4gaXRlbS5zb3VyY2UgJiYgaXRlbS5pbnB1dD8udHlwZSA9PT0gJ2Zvcm11bGEnKSlcbiAgICAgICAgaXRlcmF0ZShzaCwgdGlsZS5yYW5nZSwgKHJvdywgY29sdW1uKSA9PiB7XG4gICAgICAgICAgdGlsZUNlbGwodGlsZSwgcm93LCBjb2x1bW4sIGNoYXJnZSwgb2Zmc2V0KTtcbiAgICAgICAgfSk7XG4gICAgICBpdGVyYXRlKHNoLCB0aWxlLnJhbmdlLCAocm93LCBjb2x1bW4pID0+IHtcbiAgICAgICAgY29uc3QgaXRlbSA9IHRpbGVDZWxsKHRpbGUsIHJvdywgY29sdW1uLCAoKSA9PiB7fSwgb2Zmc2V0KTtcbiAgICAgICAgYXBwbHlQYXN0ZWRDZWxsKHMsIGNlbGwoc2gsIHJvdywgY29sdW1uKSwgaXRlbSk7XG4gICAgICB9KTtcbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgICBjYXNlICdjb3JlLmNlbGxzLnBhc3RlJzpcbiAgICAgIGZvciAoY29uc3QgaXRlbSBvZiBwLmNlbGxzKSB7XG4gICAgICAgIGNoZWNrQm91bmRzKHNoLCB7XG4gICAgICAgICAgc3RhcnRSb3c6IGl0ZW0ucm93LFxuICAgICAgICAgIGVuZFJvdzogaXRlbS5yb3cgKyAxLFxuICAgICAgICAgIHN0YXJ0Q29sdW1uOiBpdGVtLmNvbHVtbixcbiAgICAgICAgICBlbmRDb2x1bW46IGl0ZW0uY29sdW1uICsgMSxcbiAgICAgICAgfSk7XG4gICAgICAgIGFzc2VydChcbiAgICAgICAgICAhc2gubWVyZ2VzLnNvbWUoXG4gICAgICAgICAgICAobSkgPT5cbiAgICAgICAgICAgICAgaXRlbS5yb3cgPj0gbS5zdGFydFJvdyAmJlxuICAgICAgICAgICAgICBpdGVtLnJvdyA8IG0uZW5kUm93ICYmXG4gICAgICAgICAgICAgIGl0ZW0uY29sdW1uID49IG0uc3RhcnRDb2x1bW4gJiZcbiAgICAgICAgICAgICAgaXRlbS5jb2x1bW4gPCBtLmVuZENvbHVtbixcbiAgICAgICAgICApLFxuICAgICAgICAgICdJTlZBTElEX1JBTkdFJyxcbiAgICAgICAgICAnVW5tZXJnZSBiZWZvcmUgcGFzdGluZyBjZWxsIGlucHV0cyBvciBmb3JtYXRzJyxcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIGZvciAoY29uc3QgaXRlbSBvZiBwLmNlbGxzKSBhcHBseVBhc3RlZENlbGwocywgY2VsbChzaCwgaXRlbS5yb3csIGl0ZW0uY29sdW1uKSwgaXRlbSk7XG4gICAgICBicmVhaztcbiAgICBjYXNlICdjb3JlLmNlbGxzLnJlcGxhY2UnOiB7XG4gICAgICBjb25zdCBncm93dGggPSBwLnJlcGxhY2VtZW50Lmxlbmd0aCAtIHAucXVlcnkubGVuZ3RoO1xuICAgICAgaWYgKGdyb3d0aCA+IDApXG4gICAgICAgIGZvciAoY29uc3QgY2VsbCBvZiBPYmplY3QudmFsdWVzKHNoLmNlbGxzKSlcbiAgICAgICAgICBpZiAoY2VsbC5pbnB1dC50eXBlID09PSAnc3RyaW5nJyAmJiBjZWxsLmlucHV0LnZhbHVlLmluY2x1ZGVzKHAucXVlcnkpKSB7XG4gICAgICAgICAgICBjb25zdCBvcmlnaW5hbCA9IGNlbGwuaW5wdXQudmFsdWU7XG4gICAgICAgICAgICBsZXQgbGVuZ3RoID0gb3JpZ2luYWwubGVuZ3RoO1xuICAgICAgICAgICAgbGV0IHBvc2l0aW9uID0gMDtcbiAgICAgICAgICAgIHdoaWxlICgocG9zaXRpb24gPSBvcmlnaW5hbC5pbmRleE9mKHAucXVlcnksIHBvc2l0aW9uKSkgIT09IC0xKSB7XG4gICAgICAgICAgICAgIGxlbmd0aCArPSBncm93dGg7XG4gICAgICAgICAgICAgIGFzc2VydChsZW5ndGggPD0gTElNSVRTLnRleHQsICdMSU1JVF9FWENFRURFRCcsICdSZXBsYWNlbWVudCBleGNlZWRzIHRoZSB0ZXh0IGxpbWl0Jyk7XG4gICAgICAgICAgICAgIHBvc2l0aW9uICs9IHAucXVlcnkubGVuZ3RoO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgIGZvciAoY29uc3QgY2VsbCBvZiBPYmplY3QudmFsdWVzKHNoLmNlbGxzKSlcbiAgICAgICAgaWYgKGNlbGwuaW5wdXQudHlwZSA9PT0gJ3N0cmluZycgJiYgY2VsbC5pbnB1dC52YWx1ZS5pbmNsdWRlcyhwLnF1ZXJ5KSkge1xuICAgICAgICAgIGNvbnN0IG9yaWdpbmFsID0gY2VsbC5pbnB1dC52YWx1ZTtcbiAgICAgICAgICBjb25zdCBpbnB1dCA9IHtcbiAgICAgICAgICAgIHR5cGU6ICdzdHJpbmcnLFxuICAgICAgICAgICAgdmFsdWU6IG9yaWdpbmFsLnJlcGxhY2VBbGwocC5xdWVyeSwgKCkgPT4gcC5yZXBsYWNlbWVudCksXG4gICAgICAgICAgfTtcbiAgICAgICAgICBjZWxsLmlucHV0ID0gaW5wdXQgYXMgdHlwZW9mIGNlbGwuaW5wdXQ7XG4gICAgICAgIH1cbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgICBjYXNlICdjb3JlLmNlbGxzLmZpbGxTZXJpZXMnOiB7XG4gICAgICBjaGVja0JvdW5kcyhzaCwgcC5yYW5nZSk7XG4gICAgICBhc3NlcnQoXG4gICAgICAgICFzaC5tZXJnZXMuc29tZSgobSkgPT4gaW50ZXJzZWN0cyhtLCBwLnJhbmdlKSksXG4gICAgICAgICdJTlZBTElEX1JBTkdFJyxcbiAgICAgICAgJ1VubWVyZ2UgYmVmb3JlIGZpbGxpbmcgYSBzZXJpZXMnLFxuICAgICAgKTtcbiAgICAgIGNvbnN0IGNvdW50ID1cbiAgICAgICAgcC5heGlzID09PSAncm93J1xuICAgICAgICAgID8gcC5yYW5nZS5lbmRSb3cgLSBwLnJhbmdlLnN0YXJ0Um93XG4gICAgICAgICAgOiBwLnJhbmdlLmVuZENvbHVtbiAtIHAucmFuZ2Uuc3RhcnRDb2x1bW47XG4gICAgICBjb25zdCB2YWx1ZXMgPSBwLmNhbGVuZGFyXG4gICAgICAgID8gY2FsZW5kYXJTZXJpZXMocC5zdGFydCwgcC5zdGVwLCBjb3VudCwgcC5jYWxlbmRhciwgcy5kYXRlU3lzdGVtKVxuICAgICAgICA6IG51bWVyaWNTZXJpZXMocC5zdGFydCwgcC5zdGVwLCBjb3VudCk7XG4gICAgICBpdGVyYXRlKHNoLCBwLnJhbmdlLCAociwgYykgPT4ge1xuICAgICAgICBjb25zdCB0YXJnZXQgPSBjZWxsKHNoLCByLCBjKTtcbiAgICAgICAgdGFyZ2V0LmlucHV0ID0ge1xuICAgICAgICAgIHR5cGU6ICdudW1iZXInLFxuICAgICAgICAgIHZhbHVlOiB2YWx1ZXNbcC5heGlzID09PSAncm93JyA/IHIgLSBwLnJhbmdlLnN0YXJ0Um93IDogYyAtIHAucmFuZ2Uuc3RhcnRDb2x1bW5dLFxuICAgICAgICB9O1xuICAgICAgICBkZWxldGUgdGFyZ2V0LmNhY2hlZDtcbiAgICAgIH0pO1xuICAgICAgYnJlYWs7XG4gICAgfVxuICAgIGNhc2UgJ2NvcmUuY2VsbHMuY29weSc6XG4gICAgY2FzZSAnY29yZS5jZWxscy5maWxsRG93bic6IHtcbiAgICAgIGNvbnN0IHNvdXJjZSA9IHAucmFuZ2UgYXMgUmVjdDtcbiAgICAgIGNvbnN0IHRhcmdldCA9IChjb21tYW5kLnR5cGUgPT09ICdjb3JlLmNlbGxzLmZpbGxEb3duJyA/IHAucmFuZ2UgOiBwLnRhcmdldCkgYXMgUmVjdDtcbiAgICAgIGNoZWNrQm91bmRzKHNoLCBzb3VyY2UpO1xuICAgICAgY2hlY2tCb3VuZHMoc2gsIHRhcmdldCk7XG4gICAgICBhc3NlcnQoXG4gICAgICAgICFzaC5tZXJnZXMuc29tZSgobSkgPT4gaW50ZXJzZWN0cyhtLCBzb3VyY2UpIHx8IGludGVyc2VjdHMobSwgdGFyZ2V0KSksXG4gICAgICAgICdJTlZBTElEX1JBTkdFJyxcbiAgICAgICAgJ1VubWVyZ2UgYmVmb3JlIGNvcHlpbmcgb3IgZmlsbGluZycsXG4gICAgICApO1xuICAgICAgY29uc3QgZmlsbCA9IGNvbW1hbmQudHlwZSA9PT0gJ2NvcmUuY2VsbHMuZmlsbERvd24nO1xuICAgICAgYXNzZXJ0KFxuICAgICAgICBmaWxsIHx8XG4gICAgICAgICAgKHNvdXJjZS5lbmRSb3cgLSBzb3VyY2Uuc3RhcnRSb3cgPT09IHRhcmdldC5lbmRSb3cgLSB0YXJnZXQuc3RhcnRSb3cgJiZcbiAgICAgICAgICAgIHNvdXJjZS5lbmRDb2x1bW4gLSBzb3VyY2Uuc3RhcnRDb2x1bW4gPT09IHRhcmdldC5lbmRDb2x1bW4gLSB0YXJnZXQuc3RhcnRDb2x1bW4pLFxuICAgICAgICAnSU5WQUxJRF9SQU5HRScsXG4gICAgICAgICdDb3B5IHJhbmdlcyBtdXN0IGhhdmUgZXF1YWwgZGltZW5zaW9ucycsXG4gICAgICApO1xuICAgICAgY29uc3Qgb3JpZ2luYWwgPSBuZXcgTWFwPHN0cmluZywgQ2VsbFJlY29yZD4oKTtcbiAgICAgIGxldCBoYXNGb3JtdWxhID0gZmFsc2U7XG4gICAgICBjb25zdCBzbmFwc2hvdFJhbmdlID0gZmlsbCA/IHsgLi4uc291cmNlLCBlbmRSb3c6IHNvdXJjZS5zdGFydFJvdyArIDEgfSA6IHNvdXJjZTtcbiAgICAgIGl0ZXJhdGUoc2gsIHNuYXBzaG90UmFuZ2UsIChyLCBjKSA9PiB7XG4gICAgICAgIGNvbnN0IHZhbHVlID0gc2guY2VsbHNba2V5KHNoLnJvd09yZGVyW3JdLCBzaC5jb2x1bW5PcmRlcltjXSldO1xuICAgICAgICBpZiAodmFsdWUpIHtcbiAgICAgICAgICBvcmlnaW5hbC5zZXQoYCR7cn06JHtjfWAsIHN0cnVjdHVyZWRDbG9uZSh2YWx1ZSkpO1xuICAgICAgICAgIGhhc0Zvcm11bGEgfHw9IHZhbHVlLmlucHV0LnR5cGUgPT09ICdmb3JtdWxhJztcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICBpZiAoaGFzRm9ybXVsYSlcbiAgICAgICAgaXRlcmF0ZShzaCwgdGFyZ2V0LCAociwgYykgPT4ge1xuICAgICAgICAgIGlmIChmaWxsICYmIHIgPT09IHNvdXJjZS5zdGFydFJvdykgcmV0dXJuO1xuICAgICAgICAgIGNvbnN0IHNyID0gZmlsbCA/IHNvdXJjZS5zdGFydFJvdyA6IHNvdXJjZS5zdGFydFJvdyArIHIgLSB0YXJnZXQuc3RhcnRSb3c7XG4gICAgICAgICAgY29uc3Qgc2MgPSBzb3VyY2Uuc3RhcnRDb2x1bW4gKyBjIC0gdGFyZ2V0LnN0YXJ0Q29sdW1uO1xuICAgICAgICAgIGNvbnN0IHN0b3JlZCA9IG9yaWdpbmFsLmdldChgJHtzcn06JHtzY31gKTtcbiAgICAgICAgICBpZiAoc3RvcmVkPy5pbnB1dC50eXBlID09PSAnZm9ybXVsYScpXG4gICAgICAgICAgICBvZmZzZXRDZWxsRm9ybXVsYShzdG9yZWQuaW5wdXQuZXhwcmVzc2lvbiwgciAtIHNyLCBjIC0gc2MpO1xuICAgICAgICB9KTtcbiAgICAgIGl0ZXJhdGUoc2gsIHRhcmdldCwgKHIsIGMpID0+IHtcbiAgICAgICAgaWYgKGZpbGwgJiYgciA9PT0gc291cmNlLnN0YXJ0Um93KSByZXR1cm47XG4gICAgICAgIGNvbnN0IHNyID0gZmlsbCA/IHNvdXJjZS5zdGFydFJvdyA6IHNvdXJjZS5zdGFydFJvdyArIHIgLSB0YXJnZXQuc3RhcnRSb3c7XG4gICAgICAgIGNvbnN0IHNjID0gc291cmNlLnN0YXJ0Q29sdW1uICsgYyAtIHRhcmdldC5zdGFydENvbHVtbjtcbiAgICAgICAgY29uc3Qgc3RvcmVkID0gb3JpZ2luYWwuZ2V0KGAke3NyfToke3NjfWApO1xuICAgICAgICBjb25zdCBrID0ga2V5KHNoLnJvd09yZGVyW3JdLCBzaC5jb2x1bW5PcmRlcltjXSk7XG4gICAgICAgIGlmICghc3RvcmVkKSB7XG4gICAgICAgICAgZGVsZXRlIHNoLmNlbGxzW2tdO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB2YWx1ZSA9IHN0cnVjdHVyZWRDbG9uZShzdG9yZWQpIGFzIENlbGxSZWNvcmQ7XG4gICAgICAgIHZhbHVlLnJvd0lkID0gc2gucm93T3JkZXJbcl07XG4gICAgICAgIHZhbHVlLmNvbHVtbklkID0gc2guY29sdW1uT3JkZXJbY107XG4gICAgICAgIGlmICh2YWx1ZS5pbnB1dC50eXBlID09PSAnZm9ybXVsYScpXG4gICAgICAgICAgdmFsdWUuaW5wdXQuZXhwcmVzc2lvbiA9IG9mZnNldENlbGxGb3JtdWxhKHZhbHVlLmlucHV0LmV4cHJlc3Npb24sIHIgLSBzciwgYyAtIHNjKTtcbiAgICAgICAgZGVsZXRlIHZhbHVlLmNhY2hlZDtcbiAgICAgICAgc2guY2VsbHNba10gPSB2YWx1ZTtcbiAgICAgIH0pO1xuICAgICAgYnJlYWs7XG4gICAgfVxuICAgIGNhc2UgJ2NvcmUuY2VsbHMuc2V0JzpcbiAgICAgIGZvciAoY29uc3QgeCBvZiBwLmNlbGxzKSB7XG4gICAgICAgIGNoZWNrQm91bmRzKHNoLCB7XG4gICAgICAgICAgc3RhcnRSb3c6IHgucm93LFxuICAgICAgICAgIHN0YXJ0Q29sdW1uOiB4LmNvbHVtbixcbiAgICAgICAgICBlbmRSb3c6IHgucm93ICsgMSxcbiAgICAgICAgICBlbmRDb2x1bW46IHguY29sdW1uICsgMSxcbiAgICAgICAgfSk7XG4gICAgICAgIGFzc2VydChcbiAgICAgICAgICAheC5leHBlY3RlZCB8fFxuICAgICAgICAgICAgKHNoLnJvd09yZGVyW3gucm93XSA9PT0geC5leHBlY3RlZC5yb3dJZCAmJlxuICAgICAgICAgICAgICBzaC5jb2x1bW5PcmRlclt4LmNvbHVtbl0gPT09IHguZXhwZWN0ZWQuY29sdW1uSWQpLFxuICAgICAgICAgICdSRVZJU0lPTl9DT05GTElDVCcsXG4gICAgICAgICAgJ0NlbGwgcG9zaXRpb24gY2hhbmdlZDsgc2VsZWN0IGl0IGFnYWluIGJlZm9yZSBlZGl0aW5nJyxcbiAgICAgICAgKTtcbiAgICAgICAgaWYgKHguZXhwZWN0ZWQ/LmlucHV0ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICBjb25zdCBjdXJyZW50ID1cbiAgICAgICAgICAgIHNoLmNlbGxzW2tleShzaC5yb3dPcmRlclt4LnJvd10sIHNoLmNvbHVtbk9yZGVyW3guY29sdW1uXSldPy5pbnB1dCA/PyBudWxsO1xuICAgICAgICAgIGFzc2VydChcbiAgICAgICAgICAgIHNhbWVJbnB1dChjdXJyZW50LCB4LmV4cGVjdGVkLmlucHV0KSxcbiAgICAgICAgICAgICdSRVZJU0lPTl9DT05GTElDVCcsXG4gICAgICAgICAgICAnQ2VsbCBjb250ZW50IGNoYW5nZWQ7IHJldmlldyB0aGUgZHJhZnQgYmVmb3JlIHNhdmluZycsXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBtID0gc2gubWVyZ2VzLmZpbmQoXG4gICAgICAgICAgKG0pID0+XG4gICAgICAgICAgICB4LnJvdyA+PSBtLnN0YXJ0Um93ICYmXG4gICAgICAgICAgICB4LnJvdyA8IG0uZW5kUm93ICYmXG4gICAgICAgICAgICB4LmNvbHVtbiA+PSBtLnN0YXJ0Q29sdW1uICYmXG4gICAgICAgICAgICB4LmNvbHVtbiA8IG0uZW5kQ29sdW1uLFxuICAgICAgICApO1xuICAgICAgICBhc3NlcnQoXG4gICAgICAgICAgIW0gfHwgKHgucm93ID09PSBtLnN0YXJ0Um93ICYmIHguY29sdW1uID09PSBtLnN0YXJ0Q29sdW1uKSxcbiAgICAgICAgICAnSU5WQUxJRF9SQU5HRScsXG4gICAgICAgICAgJ0Nhbm5vdCB3cml0ZSBhIGNvdmVyZWQgbWVyZ2VkIGNlbGwnLFxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgLy8gUHJlY29uZGl0aW9ucyBkZXNjcmliZSB0aGUgc3RhdGUgYXQgdGhlIGJlZ2lubmluZyBvZiB0aGlzIGNvbW1hbmQsXG4gICAgICAvLyBpbmNsdWRpbmcgd2hlbiBtb3JlIHRoYW4gb25lIGVudHJ5IG5hbWVzIHRoZSBzYW1lIGNvb3JkaW5hdGUuXG4gICAgICBmb3IgKGNvbnN0IHggb2YgcC5jZWxscykge1xuICAgICAgICBjb25zdCB0YXJnZXQgPSBjZWxsKHNoLCB4LnJvdywgeC5jb2x1bW4pO1xuICAgICAgICB0YXJnZXQuaW5wdXQgPSB4LmlucHV0O1xuICAgICAgICBkZWxldGUgdGFyZ2V0LmNhY2hlZDtcbiAgICAgIH1cbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ2NvcmUuY2VsbHMuYW5ub3RhdGlvbic6XG4gICAgICBjaGVja0JvdW5kcyhzaCwgcC5yYW5nZSk7XG4gICAgICBmb3IgKGNvbnN0IG1lcmdlIG9mIHNoLm1lcmdlcykge1xuICAgICAgICBjb25zdCBzdGFydFJvdyA9IE1hdGgubWF4KHAucmFuZ2Uuc3RhcnRSb3csIG1lcmdlLnN0YXJ0Um93KTtcbiAgICAgICAgY29uc3QgZW5kUm93ID0gTWF0aC5taW4ocC5yYW5nZS5lbmRSb3csIG1lcmdlLmVuZFJvdyk7XG4gICAgICAgIGNvbnN0IHN0YXJ0Q29sdW1uID0gTWF0aC5tYXgocC5yYW5nZS5zdGFydENvbHVtbiwgbWVyZ2Uuc3RhcnRDb2x1bW4pO1xuICAgICAgICBjb25zdCBlbmRDb2x1bW4gPSBNYXRoLm1pbihwLnJhbmdlLmVuZENvbHVtbiwgbWVyZ2UuZW5kQ29sdW1uKTtcbiAgICAgICAgYXNzZXJ0KFxuICAgICAgICAgIHN0YXJ0Um93ID49IGVuZFJvdyB8fFxuICAgICAgICAgICAgc3RhcnRDb2x1bW4gPj0gZW5kQ29sdW1uIHx8XG4gICAgICAgICAgICAoc3RhcnRSb3cgPT09IG1lcmdlLnN0YXJ0Um93ICYmXG4gICAgICAgICAgICAgIHN0YXJ0Q29sdW1uID09PSBtZXJnZS5zdGFydENvbHVtbiAmJlxuICAgICAgICAgICAgICBlbmRSb3cgPT09IHN0YXJ0Um93ICsgMSAmJlxuICAgICAgICAgICAgICBlbmRDb2x1bW4gPT09IHN0YXJ0Q29sdW1uICsgMSksXG4gICAgICAgICAgJ0lOVkFMSURfUkFOR0UnLFxuICAgICAgICAgICdDYW5ub3QgYW5ub3RhdGUgYSBjb3ZlcmVkIG1lcmdlZCBjZWxsJyxcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIGl0ZXJhdGUoc2gsIHAucmFuZ2UsIChyLCBjKSA9PiB7XG4gICAgICAgIGlmICghc2guY2VsbHNba2V5KHNoLnJvd09yZGVyW3JdLCBzaC5jb2x1bW5PcmRlcltjXSldICYmIHAubm90ZSA9PSBudWxsICYmIHAubGluayA9PSBudWxsKVxuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgY29uc3QgdGFyZ2V0ID0gY2VsbChzaCwgciwgYyk7XG4gICAgICAgIGlmIChwLm5vdGUgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgIGlmIChwLm5vdGUgPT09IG51bGwpIGRlbGV0ZSB0YXJnZXQubm90ZTtcbiAgICAgICAgICBlbHNlIHRhcmdldC5ub3RlID0gcC5ub3RlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChwLmxpbmsgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgIGlmIChwLmxpbmsgPT09IG51bGwpIGRlbGV0ZSB0YXJnZXQubGluaztcbiAgICAgICAgICBlbHNlIHRhcmdldC5saW5rID0geyAuLi5wLmxpbmsgfTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICBicmVhaztcbiAgICBjYXNlICdjb3JlLmNlbGxzLnN0eWxlJzpcbiAgICAgIGd1YXJkTWVyZ2VzKHNoLCBwLnJhbmdlKTtcbiAgICAgIGl0ZXJhdGUoc2gsIHAucmFuZ2UsIChyLCBjKSA9PiB7XG4gICAgICAgIGNvbnN0IHggPSBjZWxsKHNoLCByLCBjKTtcbiAgICAgICAgeC5zdHlsZUlkID0gc3R5bGVJZChzLCB7IC4uLih4LnN0eWxlSWQgPyBzLnN0eWxlc1t4LnN0eWxlSWRdIDoge30pLCAuLi5wLnN0eWxlIH0pO1xuICAgICAgICAvLyBTdHlsZSBmb3JtYXRzIGxpdmUgaW4gdGhlIHNoYXJlZCBzdHlsZSB0YWJsZSwgbm90IGluIGV2ZXJ5IGNlbGwuXG4gICAgICAgIGlmIChwLnN0eWxlLm51bWJlckZvcm1hdCAhPT0gdW5kZWZpbmVkKSBkZWxldGUgeC5udW1iZXJGb3JtYXQ7XG4gICAgICB9KTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ2NvcmUuY2VsbHMuY2xlYXInOlxuICAgICAgZ3VhcmRNZXJnZXMoc2gsIHAucmFuZ2UpO1xuICAgICAgaXRlcmF0ZShzaCwgcC5yYW5nZSwgKHIsIGMpID0+IHtcbiAgICAgICAgY29uc3QgayA9IGtleShzaC5yb3dPcmRlcltyXSwgc2guY29sdW1uT3JkZXJbY10pO1xuICAgICAgICBpZiAocC5hbGwpIGRlbGV0ZSBzaC5jZWxsc1trXTtcbiAgICAgICAgZWxzZSBpZiAoc2guY2VsbHNba10pIHtcbiAgICAgICAgICBzaC5jZWxsc1trXS5pbnB1dCA9IHsgdHlwZTogJ2JsYW5rJyB9O1xuICAgICAgICAgIGRlbGV0ZSBzaC5jZWxsc1trXS5jYWNoZWQ7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnY29yZS5jZWxscy5tZXJnZSc6IHtcbiAgICAgIGNoZWNrQm91bmRzKHNoLCBwLnJhbmdlKTtcbiAgICAgIGFzc2VydChcbiAgICAgICAgIXNoLm1lcmdlcy5zb21lKChtKSA9PiBpbnRlcnNlY3RzKG0sIHAucmFuZ2UpKSxcbiAgICAgICAgJ0lOVkFMSURfUkFOR0UnLFxuICAgICAgICAnT3ZlcmxhcHBpbmcgbWVyZ2VkIGNlbGxzJyxcbiAgICAgICk7XG4gICAgICBjb25zdCBjb3ZlcmVkOiBDZWxsUmVjb3JkW10gPSBbXTtcbiAgICAgIGl0ZXJhdGUoc2gsIHAucmFuZ2UsIChyLCBjKSA9PiB7XG4gICAgICAgIGlmIChyID09PSBwLnJhbmdlLnN0YXJ0Um93ICYmIGMgPT09IHAucmFuZ2Uuc3RhcnRDb2x1bW4pIHJldHVybjtcbiAgICAgICAgY29uc3QgeCA9IHNoLmNlbGxzW2tleShzaC5yb3dPcmRlcltyXSwgc2guY29sdW1uT3JkZXJbY10pXTtcbiAgICAgICAgYXNzZXJ0KFxuICAgICAgICAgICF4IHx8IHguaW5wdXQudHlwZSA9PT0gJ2JsYW5rJyB8fCBwLmRpc2NhcmRDb3ZlcmVkVmFsdWVzLFxuICAgICAgICAgICdJTlZBTElEX0FSR1VNRU5UJyxcbiAgICAgICAgICAnTWVyZ2Ugd291bGQgZGlzY2FyZCB2YWx1ZXMnLFxuICAgICAgICApO1xuICAgICAgICBpZiAoeCkgY292ZXJlZC5wdXNoKHgpO1xuICAgICAgfSk7XG4gICAgICBmb3IgKGNvbnN0IHggb2YgY292ZXJlZCkge1xuICAgICAgICB4LmlucHV0ID0geyB0eXBlOiAnYmxhbmsnIH07XG4gICAgICAgIGRlbGV0ZSB4LmNhY2hlZDtcbiAgICAgIH1cbiAgICAgIHNoLm1lcmdlcy5wdXNoKHAucmFuZ2UpO1xuICAgICAgYnJlYWs7XG4gICAgfVxuICAgIGNhc2UgJ2NvcmUuY2VsbHMudW5tZXJnZSc6XG4gICAgICBjaGVja0JvdW5kcyhzaCwgcC5yYW5nZSk7XG4gICAgICBzaC5tZXJnZXMgPSBzaC5tZXJnZXMuZmlsdGVyKChtKSA9PiAhaW50ZXJzZWN0cyhtLCBwLnJhbmdlKSk7XG4gICAgICBicmVhaztcbiAgICBkZWZhdWx0OlxuICAgICAgYXNzZXJ0KGZhbHNlLCAnVU5TVVBQT1JURURfRkVBVFVSRScsICdVbmtub3duIGNvbW1hbmQnKTtcbiAgfVxufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLHFCQUFxQjtBQUM5QixTQUFTLHFCQUFxQixVQUFVLHlCQUF5QztBQUNqRixTQUFTLHNCQUFzQjtBQUMvQixTQUFTLDBCQUEwQjtBQUNuQyxTQUFTLHlCQUF5QjtBQUNsQyxTQUFTLHVCQUF1QjtBQUNoQyxTQUFTLGtCQUFrQjtBQUMzQixTQUFTLG1CQUFtQjtBQUM1QjtBQUFBLEVBQ0U7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLE9BTUs7QUFDUDtBQUFBLEVBQ0U7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxPQUNLO0FBQ1AsU0FBUyxVQUFVLEdBQXFCLEdBQThCO0FBQ3BFLE1BQUksTUFBTSxRQUFRLE1BQU0sS0FBTSxRQUFPLE1BQU07QUFDM0MsTUFBSSxFQUFFLFNBQVMsRUFBRSxLQUFNLFFBQU87QUFDOUIsVUFBUSxFQUFFLE1BQU07QUFBQSxJQUNkLEtBQUs7QUFDSCxhQUFPO0FBQUEsSUFDVCxLQUFLO0FBQ0gsYUFBTyxFQUFFLFNBQVMsYUFBYSxFQUFFLGVBQWUsRUFBRTtBQUFBLElBQ3BELEtBQUs7QUFDSCxhQUFPLEVBQUUsU0FBUyxXQUFXLEVBQUUsU0FBUyxFQUFFO0FBQUEsSUFDNUMsS0FBSztBQUNILGFBQU8sRUFBRSxTQUFTLFlBQVksT0FBTyxHQUFHLEVBQUUsT0FBTyxFQUFFLEtBQUs7QUFBQSxJQUMxRDtBQUNFLGFBQU8sV0FBVyxLQUFLLEVBQUUsVUFBVSxFQUFFO0FBQUEsRUFDekM7QUFDRjtBQUNPLGdCQUFTLGFBQWEsR0FBcUIsU0FBd0I7QUFDeEUsUUFBTSxJQUFJLFFBQVE7QUFDbEIsUUFBTSxLQUFLLFNBQVMsR0FBRyxFQUFFLE9BQU87QUFDaEMsVUFBUSxRQUFRLE1BQU07QUFBQSxJQUNwQixLQUFLLDBCQUEwQjtBQUM3QixZQUFNLFNBQVMsRUFBRTtBQUNqQixZQUFNLFNBQVMsRUFBRTtBQUNqQixrQkFBWSxJQUFJLE1BQU07QUFDdEIsa0JBQVksSUFBSSxNQUFNO0FBQ3RCLFlBQU0sT0FBTyxPQUFPLFNBQVMsT0FBTztBQUNwQyxZQUFNLFVBQVUsT0FBTyxZQUFZLE9BQU87QUFDMUM7QUFBQSxRQUNFLFNBQVMsT0FBTyxTQUFTLE9BQU8sWUFDOUIsWUFBWSxPQUFPLFlBQVksT0FBTztBQUFBLFFBQ3hDO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFDQSxhQUFPLE9BQU8sV0FBVyxPQUFPLFlBQVksa0JBQWtCLDZCQUE2QjtBQUMzRjtBQUFBLFFBQ0UsQ0FBQyxHQUFHLE9BQU8sS0FBSyxDQUFDLFVBQVUsV0FBVyxPQUFPLE1BQU0sS0FBSyxXQUFXLE9BQU8sTUFBTSxDQUFDO0FBQUEsUUFDakY7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUNBLFlBQU0sYUFBYSxJQUFJO0FBQUEsUUFDckIsQ0FBQyxPQUFPLFNBQVMsR0FBRyxFQUFFO0FBQUEsUUFDdEIsQ0FBQyxTQUFTLEVBQUUsT0FBTyxLQUFLLENBQUMsVUFBVSxNQUFNLEtBQUssWUFBWSxNQUFNLEtBQUssWUFBWSxDQUFDLEdBQUc7QUFBQSxRQUNyRixFQUFFO0FBQUEsTUFDSjtBQUNBLFlBQU0sUUFBUSxDQUFDO0FBQ2YsVUFBSSxRQUFRO0FBQ1osZUFBUyxNQUFNLE9BQU8sVUFBVSxNQUFNLE9BQU8sUUFBUTtBQUNuRCxpQkFBUyxTQUFTLE9BQU8sYUFBYSxTQUFTLE9BQU8sV0FBVyxVQUFVO0FBQ3pFLGdCQUFNLFdBQVcsR0FBRyxNQUFNLElBQUksR0FBRyxTQUFTLEdBQUcsR0FBRyxHQUFHLFlBQVksTUFBTSxDQUFDLENBQUM7QUFDdkUsZ0JBQU0sUUFBUSxVQUFVLFVBQVUsRUFBRSxPQUFPLFNBQVMsT0FBTyxJQUFJLENBQUM7QUFDaEUsZ0JBQU0sT0FBTztBQUFBLFlBQ1g7QUFBQSxjQUNFO0FBQUEsY0FDQTtBQUFBLGNBQ0EsR0FBSSxFQUFFLFNBQVMsV0FBVyxFQUFFLE9BQU8sV0FBVyxNQUFNLEdBQUcsSUFBSSxLQUFLLE1BQU0sRUFBRSxJQUFJLENBQUM7QUFBQSxjQUM3RSxHQUFJLEVBQUUsU0FBUyxhQUFhLEVBQUUsT0FBTyxVQUFVLE1BQU0sSUFBSSxDQUFDO0FBQUEsY0FDMUQsR0FBSSxFQUFFLFNBQVMsWUFDWCxFQUFFLE9BQU8sY0FBYyxVQUFVLGdCQUFnQixPQUFPLGFBQWEsSUFDckUsQ0FBQztBQUFBLFlBQ1A7QUFBQSxZQUNBLEVBQUU7QUFBQSxZQUNGLE9BQU8sV0FBVyxPQUFPO0FBQUEsWUFDekIsT0FBTyxjQUFjLE9BQU87QUFBQSxVQUM5QjtBQUNBLG1CQUFTLEtBQUssVUFBVSxJQUFJLEVBQUUsU0FBUztBQUN2QyxpQkFBTyxTQUFTLEtBQUssT0FBTyxNQUFNLGtCQUFrQiwrQkFBK0I7QUFDbkYsZ0JBQU0sS0FBSyxJQUFJO0FBQUEsUUFDakI7QUFDRixZQUFNLFFBQVEsZ0JBQWdCO0FBQUEsUUFDNUIsTUFBTTtBQUFBLFFBQ04sU0FBUyxFQUFFLFNBQVMsR0FBRyxJQUFJLE9BQU8sTUFBTTtBQUFBLE1BQzFDLENBQUM7QUFDRCxpQkFBVyxRQUFRLE1BQU0sUUFBUTtBQUMvQix3QkFBZ0IsR0FBRyxLQUFLLElBQUksS0FBSyxLQUFLLEtBQUssTUFBTSxHQUFHLElBQUk7QUFDMUQ7QUFBQSxJQUNGO0FBQUEsSUFDQSxLQUFLLHdCQUF3QjtBQUMzQixZQUFNLE9BQU87QUFDYixVQUFJLFFBQVEsa0JBQWtCLElBQUksSUFBSTtBQUN0QyxZQUFNLFNBQVMsQ0FBQyxVQUFrQjtBQUNoQyxpQkFBUztBQUNUO0FBQUEsVUFDRSxTQUFTLEtBQUssT0FBTztBQUFBLFVBQ3JCO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EsWUFBTSxTQUFTLG9CQUFvQjtBQUduQyxVQUFJLEtBQUssTUFBTSxLQUFLLENBQUMsU0FBUyxLQUFLLFVBQVUsS0FBSyxPQUFPLFNBQVMsU0FBUztBQUN6RSxnQkFBUSxJQUFJLEtBQUssT0FBTyxDQUFDLEtBQUssV0FBVztBQUN2QyxtQkFBUyxNQUFNLEtBQUssUUFBUSxRQUFRLE1BQU07QUFBQSxRQUM1QyxDQUFDO0FBQ0gsY0FBUSxJQUFJLEtBQUssT0FBTyxDQUFDLEtBQUssV0FBVztBQUN2QyxjQUFNLE9BQU8sU0FBUyxNQUFNLEtBQUssUUFBUSxNQUFNO0FBQUEsUUFBQyxHQUFHLE1BQU07QUFDekQsd0JBQWdCLEdBQUcsS0FBSyxJQUFJLEtBQUssTUFBTSxHQUFHLElBQUk7QUFBQSxNQUNoRCxDQUFDO0FBQ0Q7QUFBQSxJQUNGO0FBQUEsSUFDQSxLQUFLO0FBQ0gsaUJBQVcsUUFBUSxFQUFFLE9BQU87QUFDMUIsb0JBQVksSUFBSTtBQUFBLFVBQ2QsVUFBVSxLQUFLO0FBQUEsVUFDZixRQUFRLEtBQUssTUFBTTtBQUFBLFVBQ25CLGFBQWEsS0FBSztBQUFBLFVBQ2xCLFdBQVcsS0FBSyxTQUFTO0FBQUEsUUFDM0IsQ0FBQztBQUNEO0FBQUEsVUFDRSxDQUFDLEdBQUcsT0FBTztBQUFBLFlBQ1QsQ0FBQyxNQUNDLEtBQUssT0FBTyxFQUFFLFlBQ2QsS0FBSyxNQUFNLEVBQUUsVUFDYixLQUFLLFVBQVUsRUFBRSxlQUNqQixLQUFLLFNBQVMsRUFBRTtBQUFBLFVBQ3BCO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLGlCQUFXLFFBQVEsRUFBRSxNQUFPLGlCQUFnQixHQUFHLEtBQUssSUFBSSxLQUFLLEtBQUssS0FBSyxNQUFNLEdBQUcsSUFBSTtBQUNwRjtBQUFBLElBQ0YsS0FBSyxzQkFBc0I7QUFDekIsWUFBTSxTQUFTLEVBQUUsWUFBWSxTQUFTLEVBQUUsTUFBTTtBQUM5QyxVQUFJLFNBQVM7QUFDWCxtQkFBV0EsU0FBUSxPQUFPLE9BQU8sR0FBRyxLQUFLO0FBQ3ZDLGNBQUlBLE1BQUssTUFBTSxTQUFTLFlBQVlBLE1BQUssTUFBTSxNQUFNLFNBQVMsRUFBRSxLQUFLLEdBQUc7QUFDdEUsa0JBQU0sV0FBV0EsTUFBSyxNQUFNO0FBQzVCLGdCQUFJLFNBQVMsU0FBUztBQUN0QixnQkFBSSxXQUFXO0FBQ2Ysb0JBQVEsV0FBVyxTQUFTLFFBQVEsRUFBRSxPQUFPLFFBQVEsT0FBTyxJQUFJO0FBQzlELHdCQUFVO0FBQ1YscUJBQU8sVUFBVSxPQUFPLE1BQU0sa0JBQWtCLG9DQUFvQztBQUNwRiwwQkFBWSxFQUFFLE1BQU07QUFBQSxZQUN0QjtBQUFBLFVBQ0Y7QUFBQTtBQUNKLGlCQUFXQSxTQUFRLE9BQU8sT0FBTyxHQUFHLEtBQUs7QUFDdkMsWUFBSUEsTUFBSyxNQUFNLFNBQVMsWUFBWUEsTUFBSyxNQUFNLE1BQU0sU0FBUyxFQUFFLEtBQUssR0FBRztBQUN0RSxnQkFBTSxXQUFXQSxNQUFLLE1BQU07QUFDNUIsZ0JBQU0sUUFBUTtBQUFBLFlBQ1osTUFBTTtBQUFBLFlBQ04sT0FBTyxTQUFTLFdBQVcsRUFBRSxPQUFPLE1BQU0sRUFBRSxXQUFXO0FBQUEsVUFDekQ7QUFDQSxVQUFBQSxNQUFLLFFBQVE7QUFBQSxRQUNmO0FBQ0Y7QUFBQSxJQUNGO0FBQUEsSUFDQSxLQUFLLHlCQUF5QjtBQUM1QixrQkFBWSxJQUFJLEVBQUUsS0FBSztBQUN2QjtBQUFBLFFBQ0UsQ0FBQyxHQUFHLE9BQU8sS0FBSyxDQUFDLE1BQU0sV0FBVyxHQUFHLEVBQUUsS0FBSyxDQUFDO0FBQUEsUUFDN0M7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUNBLFlBQU0sUUFDSixFQUFFLFNBQVMsUUFDUCxFQUFFLE1BQU0sU0FBUyxFQUFFLE1BQU0sV0FDekIsRUFBRSxNQUFNLFlBQVksRUFBRSxNQUFNO0FBQ2xDLFlBQU0sU0FBUyxFQUFFLFdBQ2IsZUFBZSxFQUFFLE9BQU8sRUFBRSxNQUFNLE9BQU8sRUFBRSxVQUFVLEVBQUUsVUFBVSxJQUMvRCxjQUFjLEVBQUUsT0FBTyxFQUFFLE1BQU0sS0FBSztBQUN4QyxjQUFRLElBQUksRUFBRSxPQUFPLENBQUMsR0FBRyxNQUFNO0FBQzdCLGNBQU0sU0FBUyxLQUFLLElBQUksR0FBRyxDQUFDO0FBQzVCLGVBQU8sUUFBUTtBQUFBLFVBQ2IsTUFBTTtBQUFBLFVBQ04sT0FBTyxPQUFPLEVBQUUsU0FBUyxRQUFRLElBQUksRUFBRSxNQUFNLFdBQVcsSUFBSSxFQUFFLE1BQU0sV0FBVztBQUFBLFFBQ2pGO0FBQ0EsZUFBTyxPQUFPO0FBQUEsTUFDaEIsQ0FBQztBQUNEO0FBQUEsSUFDRjtBQUFBLElBQ0EsS0FBSztBQUFBLElBQ0wsS0FBSyx1QkFBdUI7QUFDMUIsWUFBTSxTQUFTLEVBQUU7QUFDakIsWUFBTSxTQUFVLFFBQVEsU0FBUyx3QkFBd0IsRUFBRSxRQUFRLEVBQUU7QUFDckUsa0JBQVksSUFBSSxNQUFNO0FBQ3RCLGtCQUFZLElBQUksTUFBTTtBQUN0QjtBQUFBLFFBQ0UsQ0FBQyxHQUFHLE9BQU8sS0FBSyxDQUFDLE1BQU0sV0FBVyxHQUFHLE1BQU0sS0FBSyxXQUFXLEdBQUcsTUFBTSxDQUFDO0FBQUEsUUFDckU7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUNBLFlBQU0sT0FBTyxRQUFRLFNBQVM7QUFDOUI7QUFBQSxRQUNFLFFBQ0csT0FBTyxTQUFTLE9BQU8sYUFBYSxPQUFPLFNBQVMsT0FBTyxZQUMxRCxPQUFPLFlBQVksT0FBTyxnQkFBZ0IsT0FBTyxZQUFZLE9BQU87QUFBQSxRQUN4RTtBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBQ0EsWUFBTSxXQUFXLG9CQUFJLElBQXdCO0FBQzdDLFVBQUksYUFBYTtBQUNqQixZQUFNLGdCQUFnQixPQUFPLEVBQUUsR0FBRyxRQUFRLFFBQVEsT0FBTyxXQUFXLEVBQUUsSUFBSTtBQUMxRSxjQUFRLElBQUksZUFBZSxDQUFDLEdBQUcsTUFBTTtBQUNuQyxjQUFNLFFBQVEsR0FBRyxNQUFNLElBQUksR0FBRyxTQUFTLENBQUMsR0FBRyxHQUFHLFlBQVksQ0FBQyxDQUFDLENBQUM7QUFDN0QsWUFBSSxPQUFPO0FBQ1QsbUJBQVMsSUFBSSxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksZ0JBQWdCLEtBQUssQ0FBQztBQUNoRCx5QkFBZSxNQUFNLE1BQU0sU0FBUztBQUFBLFFBQ3RDO0FBQUEsTUFDRixDQUFDO0FBQ0QsVUFBSTtBQUNGLGdCQUFRLElBQUksUUFBUSxDQUFDLEdBQUcsTUFBTTtBQUM1QixjQUFJLFFBQVEsTUFBTSxPQUFPLFNBQVU7QUFDbkMsZ0JBQU0sS0FBSyxPQUFPLE9BQU8sV0FBVyxPQUFPLFdBQVcsSUFBSSxPQUFPO0FBQ2pFLGdCQUFNLEtBQUssT0FBTyxjQUFjLElBQUksT0FBTztBQUMzQyxnQkFBTSxTQUFTLFNBQVMsSUFBSSxHQUFHLEVBQUUsSUFBSSxFQUFFLEVBQUU7QUFDekMsY0FBSSxRQUFRLE1BQU0sU0FBUztBQUN6Qiw4QkFBa0IsT0FBTyxNQUFNLFlBQVksSUFBSSxJQUFJLElBQUksRUFBRTtBQUFBLFFBQzdELENBQUM7QUFDSCxjQUFRLElBQUksUUFBUSxDQUFDLEdBQUcsTUFBTTtBQUM1QixZQUFJLFFBQVEsTUFBTSxPQUFPLFNBQVU7QUFDbkMsY0FBTSxLQUFLLE9BQU8sT0FBTyxXQUFXLE9BQU8sV0FBVyxJQUFJLE9BQU87QUFDakUsY0FBTSxLQUFLLE9BQU8sY0FBYyxJQUFJLE9BQU87QUFDM0MsY0FBTSxTQUFTLFNBQVMsSUFBSSxHQUFHLEVBQUUsSUFBSSxFQUFFLEVBQUU7QUFDekMsY0FBTSxJQUFJLElBQUksR0FBRyxTQUFTLENBQUMsR0FBRyxHQUFHLFlBQVksQ0FBQyxDQUFDO0FBQy9DLFlBQUksQ0FBQyxRQUFRO0FBQ1gsaUJBQU8sR0FBRyxNQUFNLENBQUM7QUFDakI7QUFBQSxRQUNGO0FBQ0EsY0FBTSxRQUFRLGdCQUFnQixNQUFNO0FBQ3BDLGNBQU0sUUFBUSxHQUFHLFNBQVMsQ0FBQztBQUMzQixjQUFNLFdBQVcsR0FBRyxZQUFZLENBQUM7QUFDakMsWUFBSSxNQUFNLE1BQU0sU0FBUztBQUN2QixnQkFBTSxNQUFNLGFBQWEsa0JBQWtCLE1BQU0sTUFBTSxZQUFZLElBQUksSUFBSSxJQUFJLEVBQUU7QUFDbkYsZUFBTyxNQUFNO0FBQ2IsV0FBRyxNQUFNLENBQUMsSUFBSTtBQUFBLE1BQ2hCLENBQUM7QUFDRDtBQUFBLElBQ0Y7QUFBQSxJQUNBLEtBQUs7QUFDSCxpQkFBVyxLQUFLLEVBQUUsT0FBTztBQUN2QixvQkFBWSxJQUFJO0FBQUEsVUFDZCxVQUFVLEVBQUU7QUFBQSxVQUNaLGFBQWEsRUFBRTtBQUFBLFVBQ2YsUUFBUSxFQUFFLE1BQU07QUFBQSxVQUNoQixXQUFXLEVBQUUsU0FBUztBQUFBLFFBQ3hCLENBQUM7QUFDRDtBQUFBLFVBQ0UsQ0FBQyxFQUFFLFlBQ0EsR0FBRyxTQUFTLEVBQUUsR0FBRyxNQUFNLEVBQUUsU0FBUyxTQUNqQyxHQUFHLFlBQVksRUFBRSxNQUFNLE1BQU0sRUFBRSxTQUFTO0FBQUEsVUFDNUM7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUNBLFlBQUksRUFBRSxVQUFVLFVBQVUsUUFBVztBQUNuQyxnQkFBTSxVQUNKLEdBQUcsTUFBTSxJQUFJLEdBQUcsU0FBUyxFQUFFLEdBQUcsR0FBRyxHQUFHLFlBQVksRUFBRSxNQUFNLENBQUMsQ0FBQyxHQUFHLFNBQVM7QUFDeEU7QUFBQSxZQUNFLFVBQVUsU0FBUyxFQUFFLFNBQVMsS0FBSztBQUFBLFlBQ25DO0FBQUEsWUFDQTtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQ0EsY0FBTSxJQUFJLEdBQUcsT0FBTztBQUFBLFVBQ2xCLENBQUNDLE9BQ0MsRUFBRSxPQUFPQSxHQUFFLFlBQ1gsRUFBRSxNQUFNQSxHQUFFLFVBQ1YsRUFBRSxVQUFVQSxHQUFFLGVBQ2QsRUFBRSxTQUFTQSxHQUFFO0FBQUEsUUFDakI7QUFDQTtBQUFBLFVBQ0UsQ0FBQyxLQUFNLEVBQUUsUUFBUSxFQUFFLFlBQVksRUFBRSxXQUFXLEVBQUU7QUFBQSxVQUM5QztBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUdBLGlCQUFXLEtBQUssRUFBRSxPQUFPO0FBQ3ZCLGNBQU0sU0FBUyxLQUFLLElBQUksRUFBRSxLQUFLLEVBQUUsTUFBTTtBQUN2QyxlQUFPLFFBQVEsRUFBRTtBQUNqQixlQUFPLE9BQU87QUFBQSxNQUNoQjtBQUNBO0FBQUEsSUFDRixLQUFLO0FBQ0gsa0JBQVksSUFBSSxFQUFFLEtBQUs7QUFDdkIsaUJBQVcsU0FBUyxHQUFHLFFBQVE7QUFDN0IsY0FBTSxXQUFXLEtBQUssSUFBSSxFQUFFLE1BQU0sVUFBVSxNQUFNLFFBQVE7QUFDMUQsY0FBTSxTQUFTLEtBQUssSUFBSSxFQUFFLE1BQU0sUUFBUSxNQUFNLE1BQU07QUFDcEQsY0FBTSxjQUFjLEtBQUssSUFBSSxFQUFFLE1BQU0sYUFBYSxNQUFNLFdBQVc7QUFDbkUsY0FBTSxZQUFZLEtBQUssSUFBSSxFQUFFLE1BQU0sV0FBVyxNQUFNLFNBQVM7QUFDN0Q7QUFBQSxVQUNFLFlBQVksVUFDVixlQUFlLGFBQ2QsYUFBYSxNQUFNLFlBQ2xCLGdCQUFnQixNQUFNLGVBQ3RCLFdBQVcsV0FBVyxLQUN0QixjQUFjLGNBQWM7QUFBQSxVQUNoQztBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLGNBQVEsSUFBSSxFQUFFLE9BQU8sQ0FBQyxHQUFHLE1BQU07QUFDN0IsWUFBSSxDQUFDLEdBQUcsTUFBTSxJQUFJLEdBQUcsU0FBUyxDQUFDLEdBQUcsR0FBRyxZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRSxRQUFRLFFBQVEsRUFBRSxRQUFRO0FBQ25GO0FBQ0YsY0FBTSxTQUFTLEtBQUssSUFBSSxHQUFHLENBQUM7QUFDNUIsWUFBSSxFQUFFLFNBQVMsUUFBVztBQUN4QixjQUFJLEVBQUUsU0FBUyxLQUFNLFFBQU8sT0FBTztBQUFBLGNBQzlCLFFBQU8sT0FBTyxFQUFFO0FBQUEsUUFDdkI7QUFDQSxZQUFJLEVBQUUsU0FBUyxRQUFXO0FBQ3hCLGNBQUksRUFBRSxTQUFTLEtBQU0sUUFBTyxPQUFPO0FBQUEsY0FDOUIsUUFBTyxPQUFPLEVBQUUsR0FBRyxFQUFFLEtBQUs7QUFBQSxRQUNqQztBQUFBLE1BQ0YsQ0FBQztBQUNEO0FBQUEsSUFDRixLQUFLO0FBQ0gsa0JBQVksSUFBSSxFQUFFLEtBQUs7QUFDdkIsY0FBUSxJQUFJLEVBQUUsT0FBTyxDQUFDLEdBQUcsTUFBTTtBQUM3QixjQUFNLElBQUksS0FBSyxJQUFJLEdBQUcsQ0FBQztBQUN2QixVQUFFLFVBQVUsUUFBUSxHQUFHLEVBQUUsR0FBSSxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUUsT0FBTyxJQUFJLENBQUMsR0FBSSxHQUFHLEVBQUUsTUFBTSxDQUFDO0FBRWhGLFlBQUksRUFBRSxNQUFNLGlCQUFpQixPQUFXLFFBQU8sRUFBRTtBQUFBLE1BQ25ELENBQUM7QUFDRDtBQUFBLElBQ0YsS0FBSztBQUNILGtCQUFZLElBQUksRUFBRSxLQUFLO0FBQ3ZCLGNBQVEsSUFBSSxFQUFFLE9BQU8sQ0FBQyxHQUFHLE1BQU07QUFDN0IsY0FBTSxJQUFJLElBQUksR0FBRyxTQUFTLENBQUMsR0FBRyxHQUFHLFlBQVksQ0FBQyxDQUFDO0FBQy9DLFlBQUksRUFBRSxJQUFLLFFBQU8sR0FBRyxNQUFNLENBQUM7QUFBQSxpQkFDbkIsR0FBRyxNQUFNLENBQUMsR0FBRztBQUNwQixhQUFHLE1BQU0sQ0FBQyxFQUFFLFFBQVEsRUFBRSxNQUFNLFFBQVE7QUFDcEMsaUJBQU8sR0FBRyxNQUFNLENBQUMsRUFBRTtBQUFBLFFBQ3JCO0FBQUEsTUFDRixDQUFDO0FBQ0Q7QUFBQSxJQUNGLEtBQUssb0JBQW9CO0FBQ3ZCLGtCQUFZLElBQUksRUFBRSxLQUFLO0FBQ3ZCO0FBQUEsUUFDRSxDQUFDLEdBQUcsT0FBTyxLQUFLLENBQUMsTUFBTSxXQUFXLEdBQUcsRUFBRSxLQUFLLENBQUM7QUFBQSxRQUM3QztBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBQ0EsWUFBTSxVQUF3QixDQUFDO0FBQy9CLGNBQVEsSUFBSSxFQUFFLE9BQU8sQ0FBQyxHQUFHLE1BQU07QUFDN0IsWUFBSSxNQUFNLEVBQUUsTUFBTSxZQUFZLE1BQU0sRUFBRSxNQUFNLFlBQWE7QUFDekQsY0FBTSxJQUFJLEdBQUcsTUFBTSxJQUFJLEdBQUcsU0FBUyxDQUFDLEdBQUcsR0FBRyxZQUFZLENBQUMsQ0FBQyxDQUFDO0FBQ3pEO0FBQUEsVUFDRSxDQUFDLEtBQUssRUFBRSxNQUFNLFNBQVMsV0FBVyxFQUFFO0FBQUEsVUFDcEM7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUNBLFlBQUksRUFBRyxTQUFRLEtBQUssQ0FBQztBQUFBLE1BQ3ZCLENBQUM7QUFDRCxpQkFBVyxLQUFLLFNBQVM7QUFDdkIsVUFBRSxRQUFRLEVBQUUsTUFBTSxRQUFRO0FBQzFCLGVBQU8sRUFBRTtBQUFBLE1BQ1g7QUFDQSxTQUFHLE9BQU8sS0FBSyxFQUFFLEtBQUs7QUFDdEI7QUFBQSxJQUNGO0FBQUEsSUFDQSxLQUFLO0FBQ0gsa0JBQVksSUFBSSxFQUFFLEtBQUs7QUFDdkIsU0FBRyxTQUFTLEdBQUcsT0FBTyxPQUFPLENBQUMsTUFBTSxDQUFDLFdBQVcsR0FBRyxFQUFFLEtBQUssQ0FBQztBQUMzRDtBQUFBLElBQ0Y7QUFDRSxhQUFPLE9BQU8sdUJBQXVCLGlCQUFpQjtBQUFBLEVBQzFEO0FBQ0Y7IiwibmFtZXMiOlsiY2VsbCIsIm0iXX0=
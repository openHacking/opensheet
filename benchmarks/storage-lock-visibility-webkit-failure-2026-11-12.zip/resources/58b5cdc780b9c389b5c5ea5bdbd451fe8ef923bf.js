import { z } from "/@fs/Volumes/github/private/opensheet/node_modules/.vite/deps/zod.js?v=c95e703c";
const comparison = z.enum(["eq", "neq", "lt", "lte", "gt", "gte", "between", "notBetween"]);
const operand = z.number().finite();
const common = {
  allowBlank: z.boolean(),
  policy: z.enum(["reject", "warn"])
};
const comparable = (kind) => z.object({
  ...common,
  kind: z.literal(kind),
  operator: comparison,
  first: operand,
  second: operand.optional()
}).strict().superRefine((rule, context) => {
  const needsSecond = rule.operator === "between" || rule.operator === "notBetween";
  if (needsSecond !== (rule.second !== void 0))
    context.addIssue({ code: "custom", message: "Range operators require exactly two bounds" });
  if (needsSecond && rule.second !== void 0 && rule.first > rule.second)
    context.addIssue({ code: "custom", message: "Lower bound must not exceed upper bound" });
  if (kind === "textLength" && (!Number.isInteger(rule.first) || rule.first < 0 || rule.second !== void 0 && (!Number.isInteger(rule.second) || rule.second < 0)))
    context.addIssue({
      code: "custom",
      message: "Text length bounds must be nonnegative integers"
    });
});
export const validationRuleSchema = z.union([
  comparable("number"),
  comparable("date"),
  comparable("textLength"),
  z.object({ ...common, kind: z.literal("formula"), expression: z.string().min(1).max(4096) }).strict(),
  z.object({
    ...common,
    kind: z.literal("list"),
    values: z.array(z.union([z.string().max(32768), z.number().finite(), z.boolean()])).min(1).max(1e3)
  }).strict().refine(
    (rule) => rule.values.reduce(
      (total, value) => total + (typeof value === "string" ? value.length : 0),
      0
    ) <= 32768,
    "List text exceeds the rule budget"
  )
]);
export function matchesValidationRule(rule, value) {
  if (rule.kind === "formula") return false;
  if (value === null || value === "") return rule.allowBlank;
  if (typeof value === "object") return false;
  if (rule.kind === "list") return rule.values.some((candidate) => candidate === value);
  const actual = rule.kind === "textLength" ? typeof value === "string" ? Array.from(value).length : void 0 : typeof value === "number" && Number.isFinite(value) ? value : void 0;
  if (actual === void 0) return false;
  switch (rule.operator) {
    case "eq":
      return actual === rule.first;
    case "neq":
      return actual !== rule.first;
    case "lt":
      return actual < rule.first;
    case "lte":
      return actual <= rule.first;
    case "gt":
      return actual > rule.first;
    case "gte":
      return actual >= rule.first;
    case "between":
      return actual >= rule.first && actual <= rule.second;
    case "notBetween":
      return actual < rule.first || actual > rule.second;
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInZhbGlkYXRpb24tcnVsZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB6IH0gZnJvbSAnem9kJztcbmltcG9ydCB0eXBlIHsgQ2VsbFZhbHVlIH0gZnJvbSAnLi90eXBlcy5qcyc7XG5cbi8vIEludGVybmFsIGJ1aWxkaW5nIGJsb2NrIG9ubHk6IG5vIHBlcnNpc3RlZCBzY2hlbWEgb3Igd3JpdGUgZW5mb3JjZW1lbnQgaXMgZXhwb3NlZCB5ZXQuXG5jb25zdCBjb21wYXJpc29uID0gei5lbnVtKFsnZXEnLCAnbmVxJywgJ2x0JywgJ2x0ZScsICdndCcsICdndGUnLCAnYmV0d2VlbicsICdub3RCZXR3ZWVuJ10pO1xuY29uc3Qgb3BlcmFuZCA9IHoubnVtYmVyKCkuZmluaXRlKCk7XG5jb25zdCBjb21tb24gPSB7XG4gIGFsbG93Qmxhbms6IHouYm9vbGVhbigpLFxuICBwb2xpY3k6IHouZW51bShbJ3JlamVjdCcsICd3YXJuJ10pLFxufTtcbmNvbnN0IGNvbXBhcmFibGUgPSAoa2luZDogJ251bWJlcicgfCAnZGF0ZScgfCAndGV4dExlbmd0aCcpID0+XG4gIHpcbiAgICAub2JqZWN0KHtcbiAgICAgIC4uLmNvbW1vbixcbiAgICAgIGtpbmQ6IHoubGl0ZXJhbChraW5kKSxcbiAgICAgIG9wZXJhdG9yOiBjb21wYXJpc29uLFxuICAgICAgZmlyc3Q6IG9wZXJhbmQsXG4gICAgICBzZWNvbmQ6IG9wZXJhbmQub3B0aW9uYWwoKSxcbiAgICB9KVxuICAgIC5zdHJpY3QoKVxuICAgIC5zdXBlclJlZmluZSgocnVsZSwgY29udGV4dCkgPT4ge1xuICAgICAgY29uc3QgbmVlZHNTZWNvbmQgPSBydWxlLm9wZXJhdG9yID09PSAnYmV0d2VlbicgfHwgcnVsZS5vcGVyYXRvciA9PT0gJ25vdEJldHdlZW4nO1xuICAgICAgaWYgKG5lZWRzU2Vjb25kICE9PSAocnVsZS5zZWNvbmQgIT09IHVuZGVmaW5lZCkpXG4gICAgICAgIGNvbnRleHQuYWRkSXNzdWUoeyBjb2RlOiAnY3VzdG9tJywgbWVzc2FnZTogJ1JhbmdlIG9wZXJhdG9ycyByZXF1aXJlIGV4YWN0bHkgdHdvIGJvdW5kcycgfSk7XG4gICAgICBpZiAobmVlZHNTZWNvbmQgJiYgcnVsZS5zZWNvbmQgIT09IHVuZGVmaW5lZCAmJiBydWxlLmZpcnN0ID4gcnVsZS5zZWNvbmQpXG4gICAgICAgIGNvbnRleHQuYWRkSXNzdWUoeyBjb2RlOiAnY3VzdG9tJywgbWVzc2FnZTogJ0xvd2VyIGJvdW5kIG11c3Qgbm90IGV4Y2VlZCB1cHBlciBib3VuZCcgfSk7XG4gICAgICBpZiAoXG4gICAgICAgIGtpbmQgPT09ICd0ZXh0TGVuZ3RoJyAmJlxuICAgICAgICAoIU51bWJlci5pc0ludGVnZXIocnVsZS5maXJzdCkgfHxcbiAgICAgICAgICBydWxlLmZpcnN0IDwgMCB8fFxuICAgICAgICAgIChydWxlLnNlY29uZCAhPT0gdW5kZWZpbmVkICYmICghTnVtYmVyLmlzSW50ZWdlcihydWxlLnNlY29uZCkgfHwgcnVsZS5zZWNvbmQgPCAwKSkpXG4gICAgICApXG4gICAgICAgIGNvbnRleHQuYWRkSXNzdWUoe1xuICAgICAgICAgIGNvZGU6ICdjdXN0b20nLFxuICAgICAgICAgIG1lc3NhZ2U6ICdUZXh0IGxlbmd0aCBib3VuZHMgbXVzdCBiZSBub25uZWdhdGl2ZSBpbnRlZ2VycycsXG4gICAgICAgIH0pO1xuICAgIH0pO1xuZXhwb3J0IGNvbnN0IHZhbGlkYXRpb25SdWxlU2NoZW1hID0gei51bmlvbihbXG4gIGNvbXBhcmFibGUoJ251bWJlcicpLFxuICBjb21wYXJhYmxlKCdkYXRlJyksXG4gIGNvbXBhcmFibGUoJ3RleHRMZW5ndGgnKSxcbiAgelxuICAgIC5vYmplY3QoeyAuLi5jb21tb24sIGtpbmQ6IHoubGl0ZXJhbCgnZm9ybXVsYScpLCBleHByZXNzaW9uOiB6LnN0cmluZygpLm1pbigxKS5tYXgoNDA5NikgfSlcbiAgICAuc3RyaWN0KCksXG4gIHpcbiAgICAub2JqZWN0KHtcbiAgICAgIC4uLmNvbW1vbixcbiAgICAgIGtpbmQ6IHoubGl0ZXJhbCgnbGlzdCcpLFxuICAgICAgdmFsdWVzOiB6XG4gICAgICAgIC5hcnJheSh6LnVuaW9uKFt6LnN0cmluZygpLm1heCgzMjc2OCksIHoubnVtYmVyKCkuZmluaXRlKCksIHouYm9vbGVhbigpXSkpXG4gICAgICAgIC5taW4oMSlcbiAgICAgICAgLm1heCgxMDAwKSxcbiAgICB9KVxuICAgIC5zdHJpY3QoKVxuICAgIC5yZWZpbmUoXG4gICAgICAocnVsZSkgPT5cbiAgICAgICAgcnVsZS52YWx1ZXMucmVkdWNlPG51bWJlcj4oXG4gICAgICAgICAgKHRvdGFsLCB2YWx1ZSkgPT4gdG90YWwgKyAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJyA/IHZhbHVlLmxlbmd0aCA6IDApLFxuICAgICAgICAgIDAsXG4gICAgICAgICkgPD0gMzI3NjgsXG4gICAgICAnTGlzdCB0ZXh0IGV4Y2VlZHMgdGhlIHJ1bGUgYnVkZ2V0JyxcbiAgICApLFxuXSk7XG5leHBvcnQgdHlwZSBWYWxpZGF0aW9uUnVsZSA9IHouaW5mZXI8dHlwZW9mIHZhbGlkYXRpb25SdWxlU2NoZW1hPjtcblxuLyoqIFR5cGVkIGNvbXBhcmlzb25zOyBjYWxsZXJzIG11c3Qgc3VwcGx5IGEgdmFsaWRhdGVkIHJ1bGUgYW5kIGNhbGN1bGF0ZWQgY2VsbCB2YWx1ZS4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtYXRjaGVzVmFsaWRhdGlvblJ1bGUocnVsZTogVmFsaWRhdGlvblJ1bGUsIHZhbHVlOiBDZWxsVmFsdWUpOiBib29sZWFuIHtcbiAgaWYgKHJ1bGUua2luZCA9PT0gJ2Zvcm11bGEnKSByZXR1cm4gZmFsc2U7XG4gIGlmICh2YWx1ZSA9PT0gbnVsbCB8fCB2YWx1ZSA9PT0gJycpIHJldHVybiBydWxlLmFsbG93Qmxhbms7XG4gIGlmICh0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnKSByZXR1cm4gZmFsc2U7XG4gIGlmIChydWxlLmtpbmQgPT09ICdsaXN0JykgcmV0dXJuIHJ1bGUudmFsdWVzLnNvbWUoKGNhbmRpZGF0ZSkgPT4gY2FuZGlkYXRlID09PSB2YWx1ZSk7XG4gIGNvbnN0IGFjdHVhbCA9XG4gICAgcnVsZS5raW5kID09PSAndGV4dExlbmd0aCdcbiAgICAgID8gdHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJ1xuICAgICAgICA/IEFycmF5LmZyb20odmFsdWUpLmxlbmd0aFxuICAgICAgICA6IHVuZGVmaW5lZFxuICAgICAgOiB0eXBlb2YgdmFsdWUgPT09ICdudW1iZXInICYmIE51bWJlci5pc0Zpbml0ZSh2YWx1ZSlcbiAgICAgICAgPyB2YWx1ZVxuICAgICAgICA6IHVuZGVmaW5lZDtcbiAgaWYgKGFjdHVhbCA9PT0gdW5kZWZpbmVkKSByZXR1cm4gZmFsc2U7XG4gIHN3aXRjaCAocnVsZS5vcGVyYXRvcikge1xuICAgIGNhc2UgJ2VxJzpcbiAgICAgIHJldHVybiBhY3R1YWwgPT09IHJ1bGUuZmlyc3Q7XG4gICAgY2FzZSAnbmVxJzpcbiAgICAgIHJldHVybiBhY3R1YWwgIT09IHJ1bGUuZmlyc3Q7XG4gICAgY2FzZSAnbHQnOlxuICAgICAgcmV0dXJuIGFjdHVhbCA8IHJ1bGUuZmlyc3Q7XG4gICAgY2FzZSAnbHRlJzpcbiAgICAgIHJldHVybiBhY3R1YWwgPD0gcnVsZS5maXJzdDtcbiAgICBjYXNlICdndCc6XG4gICAgICByZXR1cm4gYWN0dWFsID4gcnVsZS5maXJzdDtcbiAgICBjYXNlICdndGUnOlxuICAgICAgcmV0dXJuIGFjdHVhbCA+PSBydWxlLmZpcnN0O1xuICAgIGNhc2UgJ2JldHdlZW4nOlxuICAgICAgcmV0dXJuIGFjdHVhbCA+PSBydWxlLmZpcnN0ICYmIGFjdHVhbCA8PSBydWxlLnNlY29uZCE7XG4gICAgY2FzZSAnbm90QmV0d2Vlbic6XG4gICAgICByZXR1cm4gYWN0dWFsIDwgcnVsZS5maXJzdCB8fCBhY3R1YWwgPiBydWxlLnNlY29uZCE7XG4gIH1cbn1cbiJdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxTQUFTO0FBSWxCLE1BQU0sYUFBYSxFQUFFLEtBQUssQ0FBQyxNQUFNLE9BQU8sTUFBTSxPQUFPLE1BQU0sT0FBTyxXQUFXLFlBQVksQ0FBQztBQUMxRixNQUFNLFVBQVUsRUFBRSxPQUFPLEVBQUUsT0FBTztBQUNsQyxNQUFNLFNBQVM7QUFBQSxFQUNiLFlBQVksRUFBRSxRQUFRO0FBQUEsRUFDdEIsUUFBUSxFQUFFLEtBQUssQ0FBQyxVQUFVLE1BQU0sQ0FBQztBQUNuQztBQUNBLE1BQU0sYUFBYSxDQUFDLFNBQ2xCLEVBQ0csT0FBTztBQUFBLEVBQ04sR0FBRztBQUFBLEVBQ0gsTUFBTSxFQUFFLFFBQVEsSUFBSTtBQUFBLEVBQ3BCLFVBQVU7QUFBQSxFQUNWLE9BQU87QUFBQSxFQUNQLFFBQVEsUUFBUSxTQUFTO0FBQzNCLENBQUMsRUFDQSxPQUFPLEVBQ1AsWUFBWSxDQUFDLE1BQU0sWUFBWTtBQUM5QixRQUFNLGNBQWMsS0FBSyxhQUFhLGFBQWEsS0FBSyxhQUFhO0FBQ3JFLE1BQUksaUJBQWlCLEtBQUssV0FBVztBQUNuQyxZQUFRLFNBQVMsRUFBRSxNQUFNLFVBQVUsU0FBUyw2Q0FBNkMsQ0FBQztBQUM1RixNQUFJLGVBQWUsS0FBSyxXQUFXLFVBQWEsS0FBSyxRQUFRLEtBQUs7QUFDaEUsWUFBUSxTQUFTLEVBQUUsTUFBTSxVQUFVLFNBQVMsMENBQTBDLENBQUM7QUFDekYsTUFDRSxTQUFTLGlCQUNSLENBQUMsT0FBTyxVQUFVLEtBQUssS0FBSyxLQUMzQixLQUFLLFFBQVEsS0FDWixLQUFLLFdBQVcsV0FBYyxDQUFDLE9BQU8sVUFBVSxLQUFLLE1BQU0sS0FBSyxLQUFLLFNBQVM7QUFFakYsWUFBUSxTQUFTO0FBQUEsTUFDZixNQUFNO0FBQUEsTUFDTixTQUFTO0FBQUEsSUFDWCxDQUFDO0FBQ0wsQ0FBQztBQUNFLGFBQU0sdUJBQXVCLEVBQUUsTUFBTTtBQUFBLEVBQzFDLFdBQVcsUUFBUTtBQUFBLEVBQ25CLFdBQVcsTUFBTTtBQUFBLEVBQ2pCLFdBQVcsWUFBWTtBQUFBLEVBQ3ZCLEVBQ0csT0FBTyxFQUFFLEdBQUcsUUFBUSxNQUFNLEVBQUUsUUFBUSxTQUFTLEdBQUcsWUFBWSxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLEVBQ3pGLE9BQU87QUFBQSxFQUNWLEVBQ0csT0FBTztBQUFBLElBQ04sR0FBRztBQUFBLElBQ0gsTUFBTSxFQUFFLFFBQVEsTUFBTTtBQUFBLElBQ3RCLFFBQVEsRUFDTCxNQUFNLEVBQUUsTUFBTSxDQUFDLEVBQUUsT0FBTyxFQUFFLElBQUksS0FBSyxHQUFHLEVBQUUsT0FBTyxFQUFFLE9BQU8sR0FBRyxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFDeEUsSUFBSSxDQUFDLEVBQ0wsSUFBSSxHQUFJO0FBQUEsRUFDYixDQUFDLEVBQ0EsT0FBTyxFQUNQO0FBQUEsSUFDQyxDQUFDLFNBQ0MsS0FBSyxPQUFPO0FBQUEsTUFDVixDQUFDLE9BQU8sVUFBVSxTQUFTLE9BQU8sVUFBVSxXQUFXLE1BQU0sU0FBUztBQUFBLE1BQ3RFO0FBQUEsSUFDRixLQUFLO0FBQUEsSUFDUDtBQUFBLEVBQ0Y7QUFDSixDQUFDO0FBSU0sZ0JBQVMsc0JBQXNCLE1BQXNCLE9BQTJCO0FBQ3JGLE1BQUksS0FBSyxTQUFTLFVBQVcsUUFBTztBQUNwQyxNQUFJLFVBQVUsUUFBUSxVQUFVLEdBQUksUUFBTyxLQUFLO0FBQ2hELE1BQUksT0FBTyxVQUFVLFNBQVUsUUFBTztBQUN0QyxNQUFJLEtBQUssU0FBUyxPQUFRLFFBQU8sS0FBSyxPQUFPLEtBQUssQ0FBQyxjQUFjLGNBQWMsS0FBSztBQUNwRixRQUFNLFNBQ0osS0FBSyxTQUFTLGVBQ1YsT0FBTyxVQUFVLFdBQ2YsTUFBTSxLQUFLLEtBQUssRUFBRSxTQUNsQixTQUNGLE9BQU8sVUFBVSxZQUFZLE9BQU8sU0FBUyxLQUFLLElBQ2hELFFBQ0E7QUFDUixNQUFJLFdBQVcsT0FBVyxRQUFPO0FBQ2pDLFVBQVEsS0FBSyxVQUFVO0FBQUEsSUFDckIsS0FBSztBQUNILGFBQU8sV0FBVyxLQUFLO0FBQUEsSUFDekIsS0FBSztBQUNILGFBQU8sV0FBVyxLQUFLO0FBQUEsSUFDekIsS0FBSztBQUNILGFBQU8sU0FBUyxLQUFLO0FBQUEsSUFDdkIsS0FBSztBQUNILGFBQU8sVUFBVSxLQUFLO0FBQUEsSUFDeEIsS0FBSztBQUNILGFBQU8sU0FBUyxLQUFLO0FBQUEsSUFDdkIsS0FBSztBQUNILGFBQU8sVUFBVSxLQUFLO0FBQUEsSUFDeEIsS0FBSztBQUNILGFBQU8sVUFBVSxLQUFLLFNBQVMsVUFBVSxLQUFLO0FBQUEsSUFDaEQsS0FBSztBQUNILGFBQU8sU0FBUyxLQUFLLFNBQVMsU0FBUyxLQUFLO0FBQUEsRUFDaEQ7QUFDRjsiLCJuYW1lcyI6W119
import { assert, LIMITS, rectSchema } from "/@fs/Volumes/github/private/opensheet/packages/core/src/types.ts";
import { validationRuleSchema } from "/@fs/Volumes/github/private/opensheet/packages/core/src/validation-rule.ts";
import { transformValidationRange } from "/@fs/Volumes/github/private/opensheet/packages/core/src/validation-range.ts";
import { transformDeletedFormulaRange } from "/@fs/Volumes/github/private/opensheet/packages/core/src/deleted-formula-range.ts";
import {
  offsetFormula,
  parseFormula,
  printFormula,
  transformReferences
} from "/@fs/Volumes/github/private/opensheet/packages/formula/src/index.ts";
const MAX_RULES = 1024;
const MAX_METADATA_WORK = 1e6;
export function validateValidationEntries(input, rows, columns) {
  assert(
    Number.isInteger(rows) && rows > 0 && rows <= LIMITS.rows && Number.isInteger(columns) && columns > 0 && columns <= LIMITS.columns,
    "INVALID_ARGUMENT",
    "Invalid validation dimensions"
  );
  assert(
    Array.isArray(input) && input.length <= MAX_RULES,
    "LIMIT_EXCEEDED",
    "Too many validation rules"
  );
  const ids = /* @__PURE__ */ new Set();
  const parsedFormulas = /* @__PURE__ */ new Set();
  let work = input.length;
  for (const item of input) {
    assert(
      item && typeof item === "object" && !Array.isArray(item) && Object.keys(item).every((key) => ["id", "range", "rule"].includes(key)),
      "INVALID_ARGUMENT",
      "Invalid validation entry"
    );
    const { id, range, rule } = item;
    assert(
      typeof id === "string" && id.length > 0 && id.length <= 100 && !ids.has(id),
      "INVALID_ARGUMENT",
      "Invalid validation rule range or identity"
    );
    ids.add(id);
    assert(
      rectSchema.strict().safeParse(range).success && range.endRow > range.startRow && range.endColumn > range.startColumn && range.endRow <= rows && range.endColumn <= columns,
      "INVALID_ARGUMENT",
      "Invalid validation rule range or identity"
    );
    if (rule?.kind === "list" && Array.isArray(rule.values)) {
      assert(rule.values.length <= 1e3, "LIMIT_EXCEEDED", "Validation list exceeds item budget");
      for (const value of rule.values) {
        work += typeof value === "string" ? value.length + 1 : 1;
        assert(work <= MAX_METADATA_WORK, "LIMIT_EXCEEDED", "Validation work budget exceeded");
      }
    }
    if (rule?.kind === "formula" && typeof rule.expression === "string") {
      work += rule.expression.length;
      assert(work <= MAX_METADATA_WORK, "LIMIT_EXCEEDED", "Validation work budget exceeded");
    }
    assert(
      validationRuleSchema.safeParse(rule).success,
      "INVALID_ARGUMENT",
      "Invalid validation rule"
    );
    if (rule.kind === "formula" && !parsedFormulas.has(rule.expression)) {
      try {
        parseFormula(rule.expression);
      } catch {
        assert(false, "INVALID_ARGUMENT", "Invalid validation formula syntax");
      }
      parsedFormulas.add(rule.expression);
    }
  }
  return structuredClone(input);
}
export function rewriteValidationSheetReferences(input, rows, columns, oldName, newName) {
  assert(
    oldName && (newName === null || newName),
    "INVALID_ARGUMENT",
    "Missing validation sheet name"
  );
  const name = oldName.toLowerCase();
  const entries = validateValidationEntries(input, rows, columns);
  for (const { rule } of entries) {
    if (rule.kind !== "formula") continue;
    try {
      let changed = false;
      const ast = transformReferences(parseFormula(rule.expression), (ref) => {
        if (ref.sheet?.toLowerCase() !== name) return ref;
        changed = true;
        return newName === null ? null : { ...ref, sheet: newName };
      });
      if (changed) rule.expression = printFormula(ast);
    } catch {
      assert(false, "UNSUPPORTED_FEATURE", "Validation formula cannot safely be rewritten");
    }
  }
  return validateValidationEntries(entries, rows, columns);
}
export function transformValidationEntries(input, rows, columns, axis, operation, index, count, sheetName, editedSheet) {
  const entries = validateValidationEntries(input, rows, columns);
  assert(
    !editedSheet || sheetName && editedSheet.name,
    "INVALID_ARGUMENT",
    "Missing validation sheet name"
  );
  const targetName = (editedSheet?.name ?? sheetName)?.toLowerCase();
  const local = !editedSheet || sheetName?.toLowerCase() === targetName;
  const axisLength = local ? axis === "row" ? rows : columns : editedSheet.axisLength;
  const sample = { startRow: 0, endRow: 1, startColumn: 0, endColumn: 1 };
  transformValidationRange(sample, axis, operation, index, count, axisLength);
  const transformed = entries.flatMap((entry) => {
    const range = local ? transformValidationRange(entry.range, axis, operation, index, count, axisLength) : entry.range;
    if (!range) return [];
    if (entry.rule.kind !== "formula") return [{ ...entry, range }];
    assert(sheetName, "INVALID_ARGUMENT", "Validation formula rewrite requires a sheet name");
    const coordinate = axis === "row" ? "row" : "column";
    const origin = axis === "row" ? entry.range.startRow : entry.range.startColumn;
    const delta2 = local && operation === "delete" && origin >= index && origin < index + count ? index + count - origin : 0;
    let expression;
    try {
      const source = delta2 ? offsetFormula(
        entry.rule.expression,
        axis === "row" ? delta2 : 0,
        axis === "column" ? delta2 : 0
      ) : entry.rule.expression;
      let changed = delta2 !== 0;
      const rewriteReference = (ref) => {
        if ((ref.sheet ?? sheetName).toLowerCase() !== targetName) return ref;
        const position = ref[coordinate];
        if (position < index) return ref;
        changed = true;
        if (operation === "insert") return { ...ref, [coordinate]: position + count };
        return position < index + count ? null : { ...ref, [coordinate]: position - count };
      };
      const rewritten = transformReferences(
        parseFormula(source),
        rewriteReference,
        operation === "delete" ? (start, end) => {
          if ((start.sheet ?? sheetName).toLowerCase() !== targetName || (end.sheet ?? sheetName).toLowerCase() !== targetName) {
            const first = rewriteReference(start), last = rewriteReference(end);
            return first && last ? [first, last] : null;
          }
          const range2 = transformDeletedFormulaRange(start, end, axis, index, count);
          if (!range2 || range2[0][coordinate] !== start[coordinate] || range2[1][coordinate] !== end[coordinate])
            changed = true;
          return range2;
        } : void 0
      );
      expression = changed ? printFormula(rewritten) : source;
    } catch {
      assert(false, "UNSUPPORTED_FEATURE", "Validation formula cannot safely be rewritten");
    }
    return [{ ...entry, range, rule: { ...entry.rule, expression } }];
  });
  const delta = local ? operation === "insert" ? count : -count : 0;
  return validateValidationEntries(
    transformed,
    rows + (axis === "row" ? delta : 0),
    columns + (axis === "column" ? delta : 0)
  );
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInZhbGlkYXRpb24tbW9kZWwudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgYXNzZXJ0LCBMSU1JVFMsIHJlY3RTY2hlbWEsIHR5cGUgUmVjdCB9IGZyb20gJy4vdHlwZXMuanMnO1xuaW1wb3J0IHsgdmFsaWRhdGlvblJ1bGVTY2hlbWEsIHR5cGUgVmFsaWRhdGlvblJ1bGUgfSBmcm9tICcuL3ZhbGlkYXRpb24tcnVsZS5qcyc7XG5pbXBvcnQgeyB0cmFuc2Zvcm1WYWxpZGF0aW9uUmFuZ2UgfSBmcm9tICcuL3ZhbGlkYXRpb24tcmFuZ2UuanMnO1xuaW1wb3J0IHsgdHJhbnNmb3JtRGVsZXRlZEZvcm11bGFSYW5nZSB9IGZyb20gJy4vZGVsZXRlZC1mb3JtdWxhLXJhbmdlLmpzJztcbmltcG9ydCB7XG4gIG9mZnNldEZvcm11bGEsXG4gIHBhcnNlRm9ybXVsYSxcbiAgcHJpbnRGb3JtdWxhLFxuICB0cmFuc2Zvcm1SZWZlcmVuY2VzLFxufSBmcm9tICdAb3BlbnNoZWV0anMvZm9ybXVsYSc7XG5cbi8qKiBJbnRlcm5hbCBzdGFnZWQgbW9kZWwuIE1hbmRhdG9yeSB2YWxpZGF0aW9uIGlzIG5vdCB5ZXQgcGVyc2lzdGVkIG9yIGV4cG9zZWQuICovXG5leHBvcnQgdHlwZSBWYWxpZGF0aW9uRW50cnkgPSB7IGlkOiBzdHJpbmc7IHJhbmdlOiBSZWN0OyBydWxlOiBWYWxpZGF0aW9uUnVsZSB9O1xuY29uc3QgTUFYX1JVTEVTID0gMTAyNDtcbmNvbnN0IE1BWF9NRVRBREFUQV9XT1JLID0gMV8wMDBfMDAwO1xuXG5leHBvcnQgZnVuY3Rpb24gdmFsaWRhdGVWYWxpZGF0aW9uRW50cmllcyhcbiAgaW5wdXQ6IHVua25vd24sXG4gIHJvd3M6IG51bWJlcixcbiAgY29sdW1uczogbnVtYmVyLFxuKTogVmFsaWRhdGlvbkVudHJ5W10ge1xuICBhc3NlcnQoXG4gICAgTnVtYmVyLmlzSW50ZWdlcihyb3dzKSAmJlxuICAgICAgcm93cyA+IDAgJiZcbiAgICAgIHJvd3MgPD0gTElNSVRTLnJvd3MgJiZcbiAgICAgIE51bWJlci5pc0ludGVnZXIoY29sdW1ucykgJiZcbiAgICAgIGNvbHVtbnMgPiAwICYmXG4gICAgICBjb2x1bW5zIDw9IExJTUlUUy5jb2x1bW5zLFxuICAgICdJTlZBTElEX0FSR1VNRU5UJyxcbiAgICAnSW52YWxpZCB2YWxpZGF0aW9uIGRpbWVuc2lvbnMnLFxuICApO1xuICBhc3NlcnQoXG4gICAgQXJyYXkuaXNBcnJheShpbnB1dCkgJiYgaW5wdXQubGVuZ3RoIDw9IE1BWF9SVUxFUyxcbiAgICAnTElNSVRfRVhDRUVERUQnLFxuICAgICdUb28gbWFueSB2YWxpZGF0aW9uIHJ1bGVzJyxcbiAgKTtcbiAgY29uc3QgaWRzID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGNvbnN0IHBhcnNlZEZvcm11bGFzID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGxldCB3b3JrID0gaW5wdXQubGVuZ3RoO1xuICBmb3IgKGNvbnN0IGl0ZW0gb2YgaW5wdXQpIHtcbiAgICBhc3NlcnQoXG4gICAgICBpdGVtICYmXG4gICAgICAgIHR5cGVvZiBpdGVtID09PSAnb2JqZWN0JyAmJlxuICAgICAgICAhQXJyYXkuaXNBcnJheShpdGVtKSAmJlxuICAgICAgICBPYmplY3Qua2V5cyhpdGVtKS5ldmVyeSgoa2V5KSA9PiBbJ2lkJywgJ3JhbmdlJywgJ3J1bGUnXS5pbmNsdWRlcyhrZXkpKSxcbiAgICAgICdJTlZBTElEX0FSR1VNRU5UJyxcbiAgICAgICdJbnZhbGlkIHZhbGlkYXRpb24gZW50cnknLFxuICAgICk7XG4gICAgY29uc3QgeyBpZCwgcmFuZ2UsIHJ1bGUgfSA9IGl0ZW0gYXMgUmVjb3JkPHN0cmluZywgYW55PjtcbiAgICBhc3NlcnQoXG4gICAgICB0eXBlb2YgaWQgPT09ICdzdHJpbmcnICYmIGlkLmxlbmd0aCA+IDAgJiYgaWQubGVuZ3RoIDw9IDEwMCAmJiAhaWRzLmhhcyhpZCksXG4gICAgICAnSU5WQUxJRF9BUkdVTUVOVCcsXG4gICAgICAnSW52YWxpZCB2YWxpZGF0aW9uIHJ1bGUgcmFuZ2Ugb3IgaWRlbnRpdHknLFxuICAgICk7XG4gICAgaWRzLmFkZChpZCk7XG4gICAgYXNzZXJ0KFxuICAgICAgcmVjdFNjaGVtYS5zdHJpY3QoKS5zYWZlUGFyc2UocmFuZ2UpLnN1Y2Nlc3MgJiZcbiAgICAgICAgcmFuZ2UuZW5kUm93ID4gcmFuZ2Uuc3RhcnRSb3cgJiZcbiAgICAgICAgcmFuZ2UuZW5kQ29sdW1uID4gcmFuZ2Uuc3RhcnRDb2x1bW4gJiZcbiAgICAgICAgcmFuZ2UuZW5kUm93IDw9IHJvd3MgJiZcbiAgICAgICAgcmFuZ2UuZW5kQ29sdW1uIDw9IGNvbHVtbnMsXG4gICAgICAnSU5WQUxJRF9BUkdVTUVOVCcsXG4gICAgICAnSW52YWxpZCB2YWxpZGF0aW9uIHJ1bGUgcmFuZ2Ugb3IgaWRlbnRpdHknLFxuICAgICk7XG4gICAgaWYgKHJ1bGU/LmtpbmQgPT09ICdsaXN0JyAmJiBBcnJheS5pc0FycmF5KHJ1bGUudmFsdWVzKSkge1xuICAgICAgYXNzZXJ0KHJ1bGUudmFsdWVzLmxlbmd0aCA8PSAxMDAwLCAnTElNSVRfRVhDRUVERUQnLCAnVmFsaWRhdGlvbiBsaXN0IGV4Y2VlZHMgaXRlbSBidWRnZXQnKTtcbiAgICAgIGZvciAoY29uc3QgdmFsdWUgb2YgcnVsZS52YWx1ZXMpIHtcbiAgICAgICAgd29yayArPSB0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnID8gdmFsdWUubGVuZ3RoICsgMSA6IDE7XG4gICAgICAgIGFzc2VydCh3b3JrIDw9IE1BWF9NRVRBREFUQV9XT1JLLCAnTElNSVRfRVhDRUVERUQnLCAnVmFsaWRhdGlvbiB3b3JrIGJ1ZGdldCBleGNlZWRlZCcpO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAocnVsZT8ua2luZCA9PT0gJ2Zvcm11bGEnICYmIHR5cGVvZiBydWxlLmV4cHJlc3Npb24gPT09ICdzdHJpbmcnKSB7XG4gICAgICB3b3JrICs9IHJ1bGUuZXhwcmVzc2lvbi5sZW5ndGg7XG4gICAgICBhc3NlcnQod29yayA8PSBNQVhfTUVUQURBVEFfV09SSywgJ0xJTUlUX0VYQ0VFREVEJywgJ1ZhbGlkYXRpb24gd29yayBidWRnZXQgZXhjZWVkZWQnKTtcbiAgICB9XG4gICAgYXNzZXJ0KFxuICAgICAgdmFsaWRhdGlvblJ1bGVTY2hlbWEuc2FmZVBhcnNlKHJ1bGUpLnN1Y2Nlc3MsXG4gICAgICAnSU5WQUxJRF9BUkdVTUVOVCcsXG4gICAgICAnSW52YWxpZCB2YWxpZGF0aW9uIHJ1bGUnLFxuICAgICk7XG4gICAgaWYgKHJ1bGUua2luZCA9PT0gJ2Zvcm11bGEnICYmICFwYXJzZWRGb3JtdWxhcy5oYXMocnVsZS5leHByZXNzaW9uKSkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgcGFyc2VGb3JtdWxhKHJ1bGUuZXhwcmVzc2lvbik7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgYXNzZXJ0KGZhbHNlLCAnSU5WQUxJRF9BUkdVTUVOVCcsICdJbnZhbGlkIHZhbGlkYXRpb24gZm9ybXVsYSBzeW50YXgnKTtcbiAgICAgIH1cbiAgICAgIHBhcnNlZEZvcm11bGFzLmFkZChydWxlLmV4cHJlc3Npb24pO1xuICAgIH1cbiAgfVxuICByZXR1cm4gc3RydWN0dXJlZENsb25lKGlucHV0KSBhcyBWYWxpZGF0aW9uRW50cnlbXTtcbn1cblxuLyoqIFVwZGF0ZSBleHBsaWNpdCByZWZlcmVuY2VzIGFmdGVyIGEgd29ya3NoZWV0IHJlbmFtZSBvciByZW1vdmFsLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJld3JpdGVWYWxpZGF0aW9uU2hlZXRSZWZlcmVuY2VzKFxuICBpbnB1dDogdW5rbm93bixcbiAgcm93czogbnVtYmVyLFxuICBjb2x1bW5zOiBudW1iZXIsXG4gIG9sZE5hbWU6IHN0cmluZyxcbiAgbmV3TmFtZTogc3RyaW5nIHwgbnVsbCxcbik6IFZhbGlkYXRpb25FbnRyeVtdIHtcbiAgYXNzZXJ0KFxuICAgIG9sZE5hbWUgJiYgKG5ld05hbWUgPT09IG51bGwgfHwgbmV3TmFtZSksXG4gICAgJ0lOVkFMSURfQVJHVU1FTlQnLFxuICAgICdNaXNzaW5nIHZhbGlkYXRpb24gc2hlZXQgbmFtZScsXG4gICk7XG4gIGNvbnN0IG5hbWUgPSBvbGROYW1lLnRvTG93ZXJDYXNlKCk7XG4gIGNvbnN0IGVudHJpZXMgPSB2YWxpZGF0ZVZhbGlkYXRpb25FbnRyaWVzKGlucHV0LCByb3dzLCBjb2x1bW5zKTtcbiAgZm9yIChjb25zdCB7IHJ1bGUgfSBvZiBlbnRyaWVzKSB7XG4gICAgaWYgKHJ1bGUua2luZCAhPT0gJ2Zvcm11bGEnKSBjb250aW51ZTtcbiAgICB0cnkge1xuICAgICAgbGV0IGNoYW5nZWQgPSBmYWxzZTtcbiAgICAgIGNvbnN0IGFzdCA9IHRyYW5zZm9ybVJlZmVyZW5jZXMocGFyc2VGb3JtdWxhKHJ1bGUuZXhwcmVzc2lvbiksIChyZWYpID0+IHtcbiAgICAgICAgaWYgKHJlZi5zaGVldD8udG9Mb3dlckNhc2UoKSAhPT0gbmFtZSkgcmV0dXJuIHJlZjtcbiAgICAgICAgY2hhbmdlZCA9IHRydWU7XG4gICAgICAgIHJldHVybiBuZXdOYW1lID09PSBudWxsID8gbnVsbCA6IHsgLi4ucmVmLCBzaGVldDogbmV3TmFtZSB9O1xuICAgICAgfSk7XG4gICAgICBpZiAoY2hhbmdlZCkgcnVsZS5leHByZXNzaW9uID0gcHJpbnRGb3JtdWxhKGFzdCk7XG4gICAgfSBjYXRjaCB7XG4gICAgICBhc3NlcnQoZmFsc2UsICdVTlNVUFBPUlRFRF9GRUFUVVJFJywgJ1ZhbGlkYXRpb24gZm9ybXVsYSBjYW5ub3Qgc2FmZWx5IGJlIHJld3JpdHRlbicpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gdmFsaWRhdGVWYWxpZGF0aW9uRW50cmllcyhlbnRyaWVzLCByb3dzLCBjb2x1bW5zKTtcbn1cblxuLyoqIEFwcGx5IGluc2VydGlvbi9kZWxldGlvbiB0byBldmVyeSByYW5nZSB3aGlsZSByZXRhaW5pbmcgcnVsZSBpZGVudGl0eSBhbmQgb3JkZXIuICovXG5leHBvcnQgZnVuY3Rpb24gdHJhbnNmb3JtVmFsaWRhdGlvbkVudHJpZXMoXG4gIGlucHV0OiB1bmtub3duLFxuICByb3dzOiBudW1iZXIsXG4gIGNvbHVtbnM6IG51bWJlcixcbiAgYXhpczogJ3JvdycgfCAnY29sdW1uJyxcbiAgb3BlcmF0aW9uOiAnaW5zZXJ0JyB8ICdkZWxldGUnLFxuICBpbmRleDogbnVtYmVyLFxuICBjb3VudDogbnVtYmVyLFxuICBzaGVldE5hbWU/OiBzdHJpbmcsXG4gIGVkaXRlZFNoZWV0PzogeyBuYW1lOiBzdHJpbmc7IGF4aXNMZW5ndGg6IG51bWJlciB9LFxuKTogVmFsaWRhdGlvbkVudHJ5W10ge1xuICBjb25zdCBlbnRyaWVzID0gdmFsaWRhdGVWYWxpZGF0aW9uRW50cmllcyhpbnB1dCwgcm93cywgY29sdW1ucyk7XG4gIGFzc2VydChcbiAgICAhZWRpdGVkU2hlZXQgfHwgKHNoZWV0TmFtZSAmJiBlZGl0ZWRTaGVldC5uYW1lKSxcbiAgICAnSU5WQUxJRF9BUkdVTUVOVCcsXG4gICAgJ01pc3NpbmcgdmFsaWRhdGlvbiBzaGVldCBuYW1lJyxcbiAgKTtcbiAgY29uc3QgdGFyZ2V0TmFtZSA9IChlZGl0ZWRTaGVldD8ubmFtZSA/PyBzaGVldE5hbWUpPy50b0xvd2VyQ2FzZSgpO1xuICBjb25zdCBsb2NhbCA9ICFlZGl0ZWRTaGVldCB8fCBzaGVldE5hbWU/LnRvTG93ZXJDYXNlKCkgPT09IHRhcmdldE5hbWU7XG4gIGNvbnN0IGF4aXNMZW5ndGggPSBsb2NhbCA/IChheGlzID09PSAncm93JyA/IHJvd3MgOiBjb2x1bW5zKSA6IGVkaXRlZFNoZWV0IS5heGlzTGVuZ3RoO1xuICAvLyBWYWxpZGF0ZSB0aGUgb3BlcmF0aW9uIGV2ZW4gd2hlbiB0aGUgY29sbGVjdGlvbiBpcyBlbXB0eS5cbiAgY29uc3Qgc2FtcGxlOiBSZWN0ID0geyBzdGFydFJvdzogMCwgZW5kUm93OiAxLCBzdGFydENvbHVtbjogMCwgZW5kQ29sdW1uOiAxIH07XG4gIHRyYW5zZm9ybVZhbGlkYXRpb25SYW5nZShzYW1wbGUsIGF4aXMsIG9wZXJhdGlvbiwgaW5kZXgsIGNvdW50LCBheGlzTGVuZ3RoKTtcbiAgY29uc3QgdHJhbnNmb3JtZWQgPSBlbnRyaWVzLmZsYXRNYXAoKGVudHJ5KSA9PiB7XG4gICAgY29uc3QgcmFuZ2UgPSBsb2NhbFxuICAgICAgPyB0cmFuc2Zvcm1WYWxpZGF0aW9uUmFuZ2UoZW50cnkucmFuZ2UsIGF4aXMsIG9wZXJhdGlvbiwgaW5kZXgsIGNvdW50LCBheGlzTGVuZ3RoKVxuICAgICAgOiBlbnRyeS5yYW5nZTtcbiAgICBpZiAoIXJhbmdlKSByZXR1cm4gW107XG4gICAgaWYgKGVudHJ5LnJ1bGUua2luZCAhPT0gJ2Zvcm11bGEnKSByZXR1cm4gW3sgLi4uZW50cnksIHJhbmdlIH1dO1xuICAgIGFzc2VydChzaGVldE5hbWUsICdJTlZBTElEX0FSR1VNRU5UJywgJ1ZhbGlkYXRpb24gZm9ybXVsYSByZXdyaXRlIHJlcXVpcmVzIGEgc2hlZXQgbmFtZScpO1xuICAgIGNvbnN0IGNvb3JkaW5hdGUgPSBheGlzID09PSAncm93JyA/ICdyb3cnIDogJ2NvbHVtbic7XG4gICAgY29uc3Qgb3JpZ2luID0gYXhpcyA9PT0gJ3JvdycgPyBlbnRyeS5yYW5nZS5zdGFydFJvdyA6IGVudHJ5LnJhbmdlLnN0YXJ0Q29sdW1uO1xuICAgIC8vIFJlLWFuY2hvciB0byB0aGUgZmlyc3Qgc3Vydml2aW5nIG1lbWJlciBpZiB0aGUgb2xkIG9yaWdpbiB3YXMgcmVtb3ZlZC5cbiAgICBjb25zdCBkZWx0YSA9XG4gICAgICBsb2NhbCAmJiBvcGVyYXRpb24gPT09ICdkZWxldGUnICYmIG9yaWdpbiA+PSBpbmRleCAmJiBvcmlnaW4gPCBpbmRleCArIGNvdW50XG4gICAgICAgID8gaW5kZXggKyBjb3VudCAtIG9yaWdpblxuICAgICAgICA6IDA7XG4gICAgbGV0IGV4cHJlc3Npb246IHN0cmluZztcbiAgICB0cnkge1xuICAgICAgY29uc3Qgc291cmNlID0gZGVsdGFcbiAgICAgICAgPyBvZmZzZXRGb3JtdWxhKFxuICAgICAgICAgICAgZW50cnkucnVsZS5leHByZXNzaW9uLFxuICAgICAgICAgICAgYXhpcyA9PT0gJ3JvdycgPyBkZWx0YSA6IDAsXG4gICAgICAgICAgICBheGlzID09PSAnY29sdW1uJyA/IGRlbHRhIDogMCxcbiAgICAgICAgICApXG4gICAgICAgIDogZW50cnkucnVsZS5leHByZXNzaW9uO1xuICAgICAgbGV0IGNoYW5nZWQgPSBkZWx0YSAhPT0gMDtcbiAgICAgIGNvbnN0IHJld3JpdGVSZWZlcmVuY2U6IFBhcmFtZXRlcnM8dHlwZW9mIHRyYW5zZm9ybVJlZmVyZW5jZXM+WzFdID0gKHJlZikgPT4ge1xuICAgICAgICBpZiAoKHJlZi5zaGVldCA/PyBzaGVldE5hbWUpLnRvTG93ZXJDYXNlKCkgIT09IHRhcmdldE5hbWUpIHJldHVybiByZWY7XG4gICAgICAgIGNvbnN0IHBvc2l0aW9uID0gcmVmW2Nvb3JkaW5hdGVdO1xuICAgICAgICBpZiAocG9zaXRpb24gPCBpbmRleCkgcmV0dXJuIHJlZjtcbiAgICAgICAgY2hhbmdlZCA9IHRydWU7XG4gICAgICAgIGlmIChvcGVyYXRpb24gPT09ICdpbnNlcnQnKSByZXR1cm4geyAuLi5yZWYsIFtjb29yZGluYXRlXTogcG9zaXRpb24gKyBjb3VudCB9O1xuICAgICAgICByZXR1cm4gcG9zaXRpb24gPCBpbmRleCArIGNvdW50ID8gbnVsbCA6IHsgLi4ucmVmLCBbY29vcmRpbmF0ZV06IHBvc2l0aW9uIC0gY291bnQgfTtcbiAgICAgIH07XG4gICAgICBjb25zdCByZXdyaXR0ZW4gPSB0cmFuc2Zvcm1SZWZlcmVuY2VzKFxuICAgICAgICBwYXJzZUZvcm11bGEoc291cmNlKSxcbiAgICAgICAgcmV3cml0ZVJlZmVyZW5jZSxcbiAgICAgICAgb3BlcmF0aW9uID09PSAnZGVsZXRlJ1xuICAgICAgICAgID8gKHN0YXJ0LCBlbmQpID0+IHtcbiAgICAgICAgICAgICAgaWYgKFxuICAgICAgICAgICAgICAgIChzdGFydC5zaGVldCA/PyBzaGVldE5hbWUpLnRvTG93ZXJDYXNlKCkgIT09IHRhcmdldE5hbWUgfHxcbiAgICAgICAgICAgICAgICAoZW5kLnNoZWV0ID8/IHNoZWV0TmFtZSkudG9Mb3dlckNhc2UoKSAhPT0gdGFyZ2V0TmFtZVxuICAgICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICBjb25zdCBmaXJzdCA9IHJld3JpdGVSZWZlcmVuY2Uoc3RhcnQpLFxuICAgICAgICAgICAgICAgICAgbGFzdCA9IHJld3JpdGVSZWZlcmVuY2UoZW5kKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZmlyc3QgJiYgbGFzdCA/IFtmaXJzdCwgbGFzdF0gOiBudWxsO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGNvbnN0IHJhbmdlID0gdHJhbnNmb3JtRGVsZXRlZEZvcm11bGFSYW5nZShzdGFydCwgZW5kLCBheGlzLCBpbmRleCwgY291bnQpO1xuICAgICAgICAgICAgICBpZiAoXG4gICAgICAgICAgICAgICAgIXJhbmdlIHx8XG4gICAgICAgICAgICAgICAgcmFuZ2VbMF1bY29vcmRpbmF0ZV0gIT09IHN0YXJ0W2Nvb3JkaW5hdGVdIHx8XG4gICAgICAgICAgICAgICAgcmFuZ2VbMV1bY29vcmRpbmF0ZV0gIT09IGVuZFtjb29yZGluYXRlXVxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgY2hhbmdlZCA9IHRydWU7XG4gICAgICAgICAgICAgIHJldHVybiByYW5nZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICA6IHVuZGVmaW5lZCxcbiAgICAgICk7XG4gICAgICBleHByZXNzaW9uID0gY2hhbmdlZCA/IHByaW50Rm9ybXVsYShyZXdyaXR0ZW4pIDogc291cmNlO1xuICAgIH0gY2F0Y2gge1xuICAgICAgYXNzZXJ0KGZhbHNlLCAnVU5TVVBQT1JURURfRkVBVFVSRScsICdWYWxpZGF0aW9uIGZvcm11bGEgY2Fubm90IHNhZmVseSBiZSByZXdyaXR0ZW4nKTtcbiAgICB9XG4gICAgcmV0dXJuIFt7IC4uLmVudHJ5LCByYW5nZSwgcnVsZTogeyAuLi5lbnRyeS5ydWxlLCBleHByZXNzaW9uIH0gfV07XG4gIH0pO1xuICBjb25zdCBkZWx0YSA9IGxvY2FsID8gKG9wZXJhdGlvbiA9PT0gJ2luc2VydCcgPyBjb3VudCA6IC1jb3VudCkgOiAwO1xuICByZXR1cm4gdmFsaWRhdGVWYWxpZGF0aW9uRW50cmllcyhcbiAgICB0cmFuc2Zvcm1lZCxcbiAgICByb3dzICsgKGF4aXMgPT09ICdyb3cnID8gZGVsdGEgOiAwKSxcbiAgICBjb2x1bW5zICsgKGF4aXMgPT09ICdjb2x1bW4nID8gZGVsdGEgOiAwKSxcbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxRQUFRLFFBQVEsa0JBQTZCO0FBQ3RELFNBQVMsNEJBQWlEO0FBQzFELFNBQVMsZ0NBQWdDO0FBQ3pDLFNBQVMsb0NBQW9DO0FBQzdDO0FBQUEsRUFDRTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLE9BQ0s7QUFJUCxNQUFNLFlBQVk7QUFDbEIsTUFBTSxvQkFBb0I7QUFFbkIsZ0JBQVMsMEJBQ2QsT0FDQSxNQUNBLFNBQ21CO0FBQ25CO0FBQUEsSUFDRSxPQUFPLFVBQVUsSUFBSSxLQUNuQixPQUFPLEtBQ1AsUUFBUSxPQUFPLFFBQ2YsT0FBTyxVQUFVLE9BQU8sS0FDeEIsVUFBVSxLQUNWLFdBQVcsT0FBTztBQUFBLElBQ3BCO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDQTtBQUFBLElBQ0UsTUFBTSxRQUFRLEtBQUssS0FBSyxNQUFNLFVBQVU7QUFBQSxJQUN4QztBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0EsUUFBTSxNQUFNLG9CQUFJLElBQVk7QUFDNUIsUUFBTSxpQkFBaUIsb0JBQUksSUFBWTtBQUN2QyxNQUFJLE9BQU8sTUFBTTtBQUNqQixhQUFXLFFBQVEsT0FBTztBQUN4QjtBQUFBLE1BQ0UsUUFDRSxPQUFPLFNBQVMsWUFDaEIsQ0FBQyxNQUFNLFFBQVEsSUFBSSxLQUNuQixPQUFPLEtBQUssSUFBSSxFQUFFLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxTQUFTLE1BQU0sRUFBRSxTQUFTLEdBQUcsQ0FBQztBQUFBLE1BQ3hFO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFDQSxVQUFNLEVBQUUsSUFBSSxPQUFPLEtBQUssSUFBSTtBQUM1QjtBQUFBLE1BQ0UsT0FBTyxPQUFPLFlBQVksR0FBRyxTQUFTLEtBQUssR0FBRyxVQUFVLE9BQU8sQ0FBQyxJQUFJLElBQUksRUFBRTtBQUFBLE1BQzFFO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFDQSxRQUFJLElBQUksRUFBRTtBQUNWO0FBQUEsTUFDRSxXQUFXLE9BQU8sRUFBRSxVQUFVLEtBQUssRUFBRSxXQUNuQyxNQUFNLFNBQVMsTUFBTSxZQUNyQixNQUFNLFlBQVksTUFBTSxlQUN4QixNQUFNLFVBQVUsUUFDaEIsTUFBTSxhQUFhO0FBQUEsTUFDckI7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLFFBQUksTUFBTSxTQUFTLFVBQVUsTUFBTSxRQUFRLEtBQUssTUFBTSxHQUFHO0FBQ3ZELGFBQU8sS0FBSyxPQUFPLFVBQVUsS0FBTSxrQkFBa0IscUNBQXFDO0FBQzFGLGlCQUFXLFNBQVMsS0FBSyxRQUFRO0FBQy9CLGdCQUFRLE9BQU8sVUFBVSxXQUFXLE1BQU0sU0FBUyxJQUFJO0FBQ3ZELGVBQU8sUUFBUSxtQkFBbUIsa0JBQWtCLGlDQUFpQztBQUFBLE1BQ3ZGO0FBQUEsSUFDRjtBQUNBLFFBQUksTUFBTSxTQUFTLGFBQWEsT0FBTyxLQUFLLGVBQWUsVUFBVTtBQUNuRSxjQUFRLEtBQUssV0FBVztBQUN4QixhQUFPLFFBQVEsbUJBQW1CLGtCQUFrQixpQ0FBaUM7QUFBQSxJQUN2RjtBQUNBO0FBQUEsTUFDRSxxQkFBcUIsVUFBVSxJQUFJLEVBQUU7QUFBQSxNQUNyQztBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsUUFBSSxLQUFLLFNBQVMsYUFBYSxDQUFDLGVBQWUsSUFBSSxLQUFLLFVBQVUsR0FBRztBQUNuRSxVQUFJO0FBQ0YscUJBQWEsS0FBSyxVQUFVO0FBQUEsTUFDOUIsUUFBUTtBQUNOLGVBQU8sT0FBTyxvQkFBb0IsbUNBQW1DO0FBQUEsTUFDdkU7QUFDQSxxQkFBZSxJQUFJLEtBQUssVUFBVTtBQUFBLElBQ3BDO0FBQUEsRUFDRjtBQUNBLFNBQU8sZ0JBQWdCLEtBQUs7QUFDOUI7QUFHTyxnQkFBUyxpQ0FDZCxPQUNBLE1BQ0EsU0FDQSxTQUNBLFNBQ21CO0FBQ25CO0FBQUEsSUFDRSxZQUFZLFlBQVksUUFBUTtBQUFBLElBQ2hDO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sUUFBUSxZQUFZO0FBQ2pDLFFBQU0sVUFBVSwwQkFBMEIsT0FBTyxNQUFNLE9BQU87QUFDOUQsYUFBVyxFQUFFLEtBQUssS0FBSyxTQUFTO0FBQzlCLFFBQUksS0FBSyxTQUFTLFVBQVc7QUFDN0IsUUFBSTtBQUNGLFVBQUksVUFBVTtBQUNkLFlBQU0sTUFBTSxvQkFBb0IsYUFBYSxLQUFLLFVBQVUsR0FBRyxDQUFDLFFBQVE7QUFDdEUsWUFBSSxJQUFJLE9BQU8sWUFBWSxNQUFNLEtBQU0sUUFBTztBQUM5QyxrQkFBVTtBQUNWLGVBQU8sWUFBWSxPQUFPLE9BQU8sRUFBRSxHQUFHLEtBQUssT0FBTyxRQUFRO0FBQUEsTUFDNUQsQ0FBQztBQUNELFVBQUksUUFBUyxNQUFLLGFBQWEsYUFBYSxHQUFHO0FBQUEsSUFDakQsUUFBUTtBQUNOLGFBQU8sT0FBTyx1QkFBdUIsK0NBQStDO0FBQUEsSUFDdEY7QUFBQSxFQUNGO0FBQ0EsU0FBTywwQkFBMEIsU0FBUyxNQUFNLE9BQU87QUFDekQ7QUFHTyxnQkFBUywyQkFDZCxPQUNBLE1BQ0EsU0FDQSxNQUNBLFdBQ0EsT0FDQSxPQUNBLFdBQ0EsYUFDbUI7QUFDbkIsUUFBTSxVQUFVLDBCQUEwQixPQUFPLE1BQU0sT0FBTztBQUM5RDtBQUFBLElBQ0UsQ0FBQyxlQUFnQixhQUFhLFlBQVk7QUFBQSxJQUMxQztBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0EsUUFBTSxjQUFjLGFBQWEsUUFBUSxZQUFZLFlBQVk7QUFDakUsUUFBTSxRQUFRLENBQUMsZUFBZSxXQUFXLFlBQVksTUFBTTtBQUMzRCxRQUFNLGFBQWEsUUFBUyxTQUFTLFFBQVEsT0FBTyxVQUFXLFlBQWE7QUFFNUUsUUFBTSxTQUFlLEVBQUUsVUFBVSxHQUFHLFFBQVEsR0FBRyxhQUFhLEdBQUcsV0FBVyxFQUFFO0FBQzVFLDJCQUF5QixRQUFRLE1BQU0sV0FBVyxPQUFPLE9BQU8sVUFBVTtBQUMxRSxRQUFNLGNBQWMsUUFBUSxRQUFRLENBQUMsVUFBVTtBQUM3QyxVQUFNLFFBQVEsUUFDVix5QkFBeUIsTUFBTSxPQUFPLE1BQU0sV0FBVyxPQUFPLE9BQU8sVUFBVSxJQUMvRSxNQUFNO0FBQ1YsUUFBSSxDQUFDLE1BQU8sUUFBTyxDQUFDO0FBQ3BCLFFBQUksTUFBTSxLQUFLLFNBQVMsVUFBVyxRQUFPLENBQUMsRUFBRSxHQUFHLE9BQU8sTUFBTSxDQUFDO0FBQzlELFdBQU8sV0FBVyxvQkFBb0Isa0RBQWtEO0FBQ3hGLFVBQU0sYUFBYSxTQUFTLFFBQVEsUUFBUTtBQUM1QyxVQUFNLFNBQVMsU0FBUyxRQUFRLE1BQU0sTUFBTSxXQUFXLE1BQU0sTUFBTTtBQUVuRSxVQUFNQSxTQUNKLFNBQVMsY0FBYyxZQUFZLFVBQVUsU0FBUyxTQUFTLFFBQVEsUUFDbkUsUUFBUSxRQUFRLFNBQ2hCO0FBQ04sUUFBSTtBQUNKLFFBQUk7QUFDRixZQUFNLFNBQVNBLFNBQ1g7QUFBQSxRQUNFLE1BQU0sS0FBSztBQUFBLFFBQ1gsU0FBUyxRQUFRQSxTQUFRO0FBQUEsUUFDekIsU0FBUyxXQUFXQSxTQUFRO0FBQUEsTUFDOUIsSUFDQSxNQUFNLEtBQUs7QUFDZixVQUFJLFVBQVVBLFdBQVU7QUFDeEIsWUFBTSxtQkFBOEQsQ0FBQyxRQUFRO0FBQzNFLGFBQUssSUFBSSxTQUFTLFdBQVcsWUFBWSxNQUFNLFdBQVksUUFBTztBQUNsRSxjQUFNLFdBQVcsSUFBSSxVQUFVO0FBQy9CLFlBQUksV0FBVyxNQUFPLFFBQU87QUFDN0Isa0JBQVU7QUFDVixZQUFJLGNBQWMsU0FBVSxRQUFPLEVBQUUsR0FBRyxLQUFLLENBQUMsVUFBVSxHQUFHLFdBQVcsTUFBTTtBQUM1RSxlQUFPLFdBQVcsUUFBUSxRQUFRLE9BQU8sRUFBRSxHQUFHLEtBQUssQ0FBQyxVQUFVLEdBQUcsV0FBVyxNQUFNO0FBQUEsTUFDcEY7QUFDQSxZQUFNLFlBQVk7QUFBQSxRQUNoQixhQUFhLE1BQU07QUFBQSxRQUNuQjtBQUFBLFFBQ0EsY0FBYyxXQUNWLENBQUMsT0FBTyxRQUFRO0FBQ2QsZUFDRyxNQUFNLFNBQVMsV0FBVyxZQUFZLE1BQU0sZUFDNUMsSUFBSSxTQUFTLFdBQVcsWUFBWSxNQUFNLFlBQzNDO0FBQ0Esa0JBQU0sUUFBUSxpQkFBaUIsS0FBSyxHQUNsQyxPQUFPLGlCQUFpQixHQUFHO0FBQzdCLG1CQUFPLFNBQVMsT0FBTyxDQUFDLE9BQU8sSUFBSSxJQUFJO0FBQUEsVUFDekM7QUFDQSxnQkFBTUMsU0FBUSw2QkFBNkIsT0FBTyxLQUFLLE1BQU0sT0FBTyxLQUFLO0FBQ3pFLGNBQ0UsQ0FBQ0EsVUFDREEsT0FBTSxDQUFDLEVBQUUsVUFBVSxNQUFNLE1BQU0sVUFBVSxLQUN6Q0EsT0FBTSxDQUFDLEVBQUUsVUFBVSxNQUFNLElBQUksVUFBVTtBQUV2QyxzQkFBVTtBQUNaLGlCQUFPQTtBQUFBLFFBQ1QsSUFDQTtBQUFBLE1BQ047QUFDQSxtQkFBYSxVQUFVLGFBQWEsU0FBUyxJQUFJO0FBQUEsSUFDbkQsUUFBUTtBQUNOLGFBQU8sT0FBTyx1QkFBdUIsK0NBQStDO0FBQUEsSUFDdEY7QUFDQSxXQUFPLENBQUMsRUFBRSxHQUFHLE9BQU8sT0FBTyxNQUFNLEVBQUUsR0FBRyxNQUFNLE1BQU0sV0FBVyxFQUFFLENBQUM7QUFBQSxFQUNsRSxDQUFDO0FBQ0QsUUFBTSxRQUFRLFFBQVMsY0FBYyxXQUFXLFFBQVEsQ0FBQyxRQUFTO0FBQ2xFLFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQSxRQUFRLFNBQVMsUUFBUSxRQUFRO0FBQUEsSUFDakMsV0FBVyxTQUFTLFdBQVcsUUFBUTtBQUFBLEVBQ3pDO0FBQ0Y7IiwibmFtZXMiOlsiZGVsdGEiLCJyYW5nZSJdfQ==
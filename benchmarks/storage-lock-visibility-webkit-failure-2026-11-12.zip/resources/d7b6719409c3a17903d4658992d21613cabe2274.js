import { truth } from "/@fs/Volumes/github/private/opensheet/packages/formula/src/coercion.ts";
import { FormulaError } from "/@fs/Volumes/github/private/opensheet/packages/formula/src/errors.ts";
import { functionDefinition } from "/@fs/Volumes/github/private/opensheet/packages/formula/src/functions.ts";
function directNumber(value) {
  if (typeof value === "boolean") return Number(value);
  const text = value.trim();
  if (!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(text)) return void 0;
  const parsed = Number(text);
  return Number.isFinite(parsed) ? parsed : void 0;
}
export class Aggregate {
  constructor(name) {
    this.name = name;
    if (functionDefinition(name)?.evaluation !== "aggregate") throw new FormulaError("#NAME?");
  }
  name;
  sum = 0;
  count = 0;
  present = 0;
  min = Infinity;
  max = -Infinity;
  logicalCount = 0;
  and = true;
  or = false;
  error;
  controlError;
  add(value, referenced) {
    if (value !== null) this.present++;
    if (value && typeof value === "object") this.error ??= value;
    if (value && typeof value === "object" && ["#LIMIT!", "#CYCLE!"].includes(value.error))
      this.controlError ??= value;
    if (typeof value === "number") {
      this.sum += value;
      this.count++;
      this.min = Math.min(this.min, value);
      this.max = Math.max(this.max, value);
    } else if (!referenced && (typeof value === "string" || typeof value === "boolean"))
      this.addDirect(value);
    if (this.name === "AND" || this.name === "OR") {
      if (referenced && (value === null || typeof value === "string")) return;
      try {
        const logical = truth(value);
        this.logicalCount++;
        this.and &&= logical;
        this.or ||= logical;
      } catch (error) {
        if (!(error instanceof FormulaError)) throw error;
        this.error ??= { error: error.code };
      }
    }
  }
  addDirect(value) {
    if (this.name === "SUM" || this.name === "MIN" || this.name === "MAX") {
      const numeric = directNumber(value);
      if (numeric === void 0) this.error ??= { error: "#VALUE!" };
      else {
        this.sum += numeric;
        this.count++;
        this.min = Math.min(this.min, numeric);
        this.max = Math.max(this.max, numeric);
      }
    } else if (this.name === "AVERAGE" && typeof value === "string" && directNumber(value) === void 0)
      this.error ??= { error: "#VALUE!" };
    else if (this.name === "COUNT" && directNumber(value) !== void 0) this.count++;
  }
  result() {
    if (this.controlError) return this.controlError;
    if (this.name === "COUNT") return this.count;
    if (this.name === "COUNTA") return this.present;
    if (this.error) return this.error;
    if (this.name === "AND" || this.name === "OR")
      return this.logicalCount ? this.name === "AND" ? this.and : this.or : { error: "#VALUE!" };
    if (this.name === "MIN") return this.count ? this.min : 0;
    if (this.name === "MAX") return this.count ? this.max : 0;
    if (this.name === "AVERAGE" && !this.count) return { error: "#DIV/0!" };
    const result = this.name === "AVERAGE" ? this.sum / this.count : this.sum;
    return Number.isFinite(result) ? result : { error: "#NUM!" };
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFnZ3JlZ2F0ZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB0cnV0aCB9IGZyb20gJy4vY29lcmNpb24uanMnO1xuaW1wb3J0IHsgRm9ybXVsYUVycm9yIH0gZnJvbSAnLi9lcnJvcnMuanMnO1xuaW1wb3J0IHsgZnVuY3Rpb25EZWZpbml0aW9uIH0gZnJvbSAnLi9mdW5jdGlvbnMuanMnO1xuaW1wb3J0IHR5cGUgeyBGb3JtdWxhVmFsdWUgfSBmcm9tICcuL3R5cGVzLmpzJztcblxuZnVuY3Rpb24gZGlyZWN0TnVtYmVyKHZhbHVlOiBzdHJpbmcgfCBib29sZWFuKTogbnVtYmVyIHwgdW5kZWZpbmVkIHtcbiAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ2Jvb2xlYW4nKSByZXR1cm4gTnVtYmVyKHZhbHVlKTtcbiAgY29uc3QgdGV4dCA9IHZhbHVlLnRyaW0oKTtcbiAgaWYgKCEvXlsrLV0/KD86XFxkKyg/OlxcLlxcZCopP3xcXC5cXGQrKSg/OltlRV1bKy1dP1xcZCspPyQvLnRlc3QodGV4dCkpIHJldHVybiB1bmRlZmluZWQ7XG4gIGNvbnN0IHBhcnNlZCA9IE51bWJlcih0ZXh0KTtcbiAgcmV0dXJuIE51bWJlci5pc0Zpbml0ZShwYXJzZWQpID8gcGFyc2VkIDogdW5kZWZpbmVkO1xufVxuXG4vKiogQ29uc3RhbnQtc3BhY2UgYWNjdW11bGF0b3Igc2hhcmVkIGJ5IHB1cmUgYW5kIFdvcmtlci1iYWNrZWQgY2FsY3VsYXRpb24uICovXG5leHBvcnQgY2xhc3MgQWdncmVnYXRlIHtcbiAgcHJpdmF0ZSBzdW0gPSAwO1xuICBwcml2YXRlIGNvdW50ID0gMDtcbiAgcHJpdmF0ZSBwcmVzZW50ID0gMDtcbiAgcHJpdmF0ZSBtaW4gPSBJbmZpbml0eTtcbiAgcHJpdmF0ZSBtYXggPSAtSW5maW5pdHk7XG4gIHByaXZhdGUgbG9naWNhbENvdW50ID0gMDtcbiAgcHJpdmF0ZSBhbmQgPSB0cnVlO1xuICBwcml2YXRlIG9yID0gZmFsc2U7XG4gIHByaXZhdGUgZXJyb3I/OiB7IGVycm9yOiBzdHJpbmcgfTtcbiAgcHJpdmF0ZSBjb250cm9sRXJyb3I/OiB7IGVycm9yOiBzdHJpbmcgfTtcbiAgY29uc3RydWN0b3IocHJpdmF0ZSByZWFkb25seSBuYW1lOiBzdHJpbmcpIHtcbiAgICBpZiAoZnVuY3Rpb25EZWZpbml0aW9uKG5hbWUpPy5ldmFsdWF0aW9uICE9PSAnYWdncmVnYXRlJykgdGhyb3cgbmV3IEZvcm11bGFFcnJvcignI05BTUU/Jyk7XG4gIH1cbiAgYWRkKHZhbHVlOiBGb3JtdWxhVmFsdWUsIHJlZmVyZW5jZWQ6IGJvb2xlYW4pIHtcbiAgICBpZiAodmFsdWUgIT09IG51bGwpIHRoaXMucHJlc2VudCsrO1xuICAgIGlmICh2YWx1ZSAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnKSB0aGlzLmVycm9yID8/PSB2YWx1ZTtcbiAgICBpZiAodmFsdWUgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiBbJyNMSU1JVCEnLCAnI0NZQ0xFISddLmluY2x1ZGVzKHZhbHVlLmVycm9yKSlcbiAgICAgIHRoaXMuY29udHJvbEVycm9yID8/PSB2YWx1ZTtcbiAgICBpZiAodHlwZW9mIHZhbHVlID09PSAnbnVtYmVyJykge1xuICAgICAgdGhpcy5zdW0gKz0gdmFsdWU7XG4gICAgICB0aGlzLmNvdW50Kys7XG4gICAgICB0aGlzLm1pbiA9IE1hdGgubWluKHRoaXMubWluLCB2YWx1ZSk7XG4gICAgICB0aGlzLm1heCA9IE1hdGgubWF4KHRoaXMubWF4LCB2YWx1ZSk7XG4gICAgfSBlbHNlIGlmICghcmVmZXJlbmNlZCAmJiAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJyB8fCB0eXBlb2YgdmFsdWUgPT09ICdib29sZWFuJykpXG4gICAgICB0aGlzLmFkZERpcmVjdCh2YWx1ZSk7XG4gICAgaWYgKHRoaXMubmFtZSA9PT0gJ0FORCcgfHwgdGhpcy5uYW1lID09PSAnT1InKSB7XG4gICAgICBpZiAocmVmZXJlbmNlZCAmJiAodmFsdWUgPT09IG51bGwgfHwgdHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJykpIHJldHVybjtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGxvZ2ljYWwgPSB0cnV0aCh2YWx1ZSk7XG4gICAgICAgIHRoaXMubG9naWNhbENvdW50Kys7XG4gICAgICAgIHRoaXMuYW5kICYmPSBsb2dpY2FsO1xuICAgICAgICB0aGlzLm9yIHx8PSBsb2dpY2FsO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgaWYgKCEoZXJyb3IgaW5zdGFuY2VvZiBGb3JtdWxhRXJyb3IpKSB0aHJvdyBlcnJvcjtcbiAgICAgICAgdGhpcy5lcnJvciA/Pz0geyBlcnJvcjogZXJyb3IuY29kZSB9O1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBwcml2YXRlIGFkZERpcmVjdCh2YWx1ZTogc3RyaW5nIHwgYm9vbGVhbikge1xuICAgIGlmICh0aGlzLm5hbWUgPT09ICdTVU0nIHx8IHRoaXMubmFtZSA9PT0gJ01JTicgfHwgdGhpcy5uYW1lID09PSAnTUFYJykge1xuICAgICAgY29uc3QgbnVtZXJpYyA9IGRpcmVjdE51bWJlcih2YWx1ZSk7XG4gICAgICBpZiAobnVtZXJpYyA9PT0gdW5kZWZpbmVkKSB0aGlzLmVycm9yID8/PSB7IGVycm9yOiAnI1ZBTFVFIScgfTtcbiAgICAgIGVsc2Uge1xuICAgICAgICB0aGlzLnN1bSArPSBudW1lcmljO1xuICAgICAgICB0aGlzLmNvdW50Kys7XG4gICAgICAgIHRoaXMubWluID0gTWF0aC5taW4odGhpcy5taW4sIG51bWVyaWMpO1xuICAgICAgICB0aGlzLm1heCA9IE1hdGgubWF4KHRoaXMubWF4LCBudW1lcmljKTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKFxuICAgICAgdGhpcy5uYW1lID09PSAnQVZFUkFHRScgJiZcbiAgICAgIHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycgJiZcbiAgICAgIGRpcmVjdE51bWJlcih2YWx1ZSkgPT09IHVuZGVmaW5lZFxuICAgIClcbiAgICAgIHRoaXMuZXJyb3IgPz89IHsgZXJyb3I6ICcjVkFMVUUhJyB9O1xuICAgIGVsc2UgaWYgKHRoaXMubmFtZSA9PT0gJ0NPVU5UJyAmJiBkaXJlY3ROdW1iZXIodmFsdWUpICE9PSB1bmRlZmluZWQpIHRoaXMuY291bnQrKztcbiAgfVxuICByZXN1bHQoKTogRm9ybXVsYVZhbHVlIHtcbiAgICBpZiAodGhpcy5jb250cm9sRXJyb3IpIHJldHVybiB0aGlzLmNvbnRyb2xFcnJvcjtcbiAgICBpZiAodGhpcy5uYW1lID09PSAnQ09VTlQnKSByZXR1cm4gdGhpcy5jb3VudDtcbiAgICBpZiAodGhpcy5uYW1lID09PSAnQ09VTlRBJykgcmV0dXJuIHRoaXMucHJlc2VudDtcbiAgICBpZiAodGhpcy5lcnJvcikgcmV0dXJuIHRoaXMuZXJyb3I7XG4gICAgaWYgKHRoaXMubmFtZSA9PT0gJ0FORCcgfHwgdGhpcy5uYW1lID09PSAnT1InKVxuICAgICAgcmV0dXJuIHRoaXMubG9naWNhbENvdW50ID8gKHRoaXMubmFtZSA9PT0gJ0FORCcgPyB0aGlzLmFuZCA6IHRoaXMub3IpIDogeyBlcnJvcjogJyNWQUxVRSEnIH07XG4gICAgaWYgKHRoaXMubmFtZSA9PT0gJ01JTicpIHJldHVybiB0aGlzLmNvdW50ID8gdGhpcy5taW4gOiAwO1xuICAgIGlmICh0aGlzLm5hbWUgPT09ICdNQVgnKSByZXR1cm4gdGhpcy5jb3VudCA/IHRoaXMubWF4IDogMDtcbiAgICBpZiAodGhpcy5uYW1lID09PSAnQVZFUkFHRScgJiYgIXRoaXMuY291bnQpIHJldHVybiB7IGVycm9yOiAnI0RJVi8wIScgfTtcbiAgICBjb25zdCByZXN1bHQgPSB0aGlzLm5hbWUgPT09ICdBVkVSQUdFJyA/IHRoaXMuc3VtIC8gdGhpcy5jb3VudCA6IHRoaXMuc3VtO1xuICAgIHJldHVybiBOdW1iZXIuaXNGaW5pdGUocmVzdWx0KSA/IHJlc3VsdCA6IHsgZXJyb3I6ICcjTlVNIScgfTtcbiAgfVxufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLGFBQWE7QUFDdEIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUywwQkFBMEI7QUFHbkMsU0FBUyxhQUFhLE9BQTZDO0FBQ2pFLE1BQUksT0FBTyxVQUFVLFVBQVcsUUFBTyxPQUFPLEtBQUs7QUFDbkQsUUFBTSxPQUFPLE1BQU0sS0FBSztBQUN4QixNQUFJLENBQUMsa0RBQWtELEtBQUssSUFBSSxFQUFHLFFBQU87QUFDMUUsUUFBTSxTQUFTLE9BQU8sSUFBSTtBQUMxQixTQUFPLE9BQU8sU0FBUyxNQUFNLElBQUksU0FBUztBQUM1QztBQUdPLGFBQU0sVUFBVTtBQUFBLEVBV3JCLFlBQTZCLE1BQWM7QUFBZDtBQUMzQixRQUFJLG1CQUFtQixJQUFJLEdBQUcsZUFBZSxZQUFhLE9BQU0sSUFBSSxhQUFhLFFBQVE7QUFBQSxFQUMzRjtBQUFBLEVBRjZCO0FBQUEsRUFWckIsTUFBTTtBQUFBLEVBQ04sUUFBUTtBQUFBLEVBQ1IsVUFBVTtBQUFBLEVBQ1YsTUFBTTtBQUFBLEVBQ04sTUFBTTtBQUFBLEVBQ04sZUFBZTtBQUFBLEVBQ2YsTUFBTTtBQUFBLEVBQ04sS0FBSztBQUFBLEVBQ0w7QUFBQSxFQUNBO0FBQUEsRUFJUixJQUFJLE9BQXFCLFlBQXFCO0FBQzVDLFFBQUksVUFBVSxLQUFNLE1BQUs7QUFDekIsUUFBSSxTQUFTLE9BQU8sVUFBVSxTQUFVLE1BQUssVUFBVTtBQUN2RCxRQUFJLFNBQVMsT0FBTyxVQUFVLFlBQVksQ0FBQyxXQUFXLFNBQVMsRUFBRSxTQUFTLE1BQU0sS0FBSztBQUNuRixXQUFLLGlCQUFpQjtBQUN4QixRQUFJLE9BQU8sVUFBVSxVQUFVO0FBQzdCLFdBQUssT0FBTztBQUNaLFdBQUs7QUFDTCxXQUFLLE1BQU0sS0FBSyxJQUFJLEtBQUssS0FBSyxLQUFLO0FBQ25DLFdBQUssTUFBTSxLQUFLLElBQUksS0FBSyxLQUFLLEtBQUs7QUFBQSxJQUNyQyxXQUFXLENBQUMsZUFBZSxPQUFPLFVBQVUsWUFBWSxPQUFPLFVBQVU7QUFDdkUsV0FBSyxVQUFVLEtBQUs7QUFDdEIsUUFBSSxLQUFLLFNBQVMsU0FBUyxLQUFLLFNBQVMsTUFBTTtBQUM3QyxVQUFJLGVBQWUsVUFBVSxRQUFRLE9BQU8sVUFBVSxVQUFXO0FBQ2pFLFVBQUk7QUFDRixjQUFNLFVBQVUsTUFBTSxLQUFLO0FBQzNCLGFBQUs7QUFDTCxhQUFLLFFBQVE7QUFDYixhQUFLLE9BQU87QUFBQSxNQUNkLFNBQVMsT0FBTztBQUNkLFlBQUksRUFBRSxpQkFBaUIsY0FBZSxPQUFNO0FBQzVDLGFBQUssVUFBVSxFQUFFLE9BQU8sTUFBTSxLQUFLO0FBQUEsTUFDckM7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBQ1EsVUFBVSxPQUF5QjtBQUN6QyxRQUFJLEtBQUssU0FBUyxTQUFTLEtBQUssU0FBUyxTQUFTLEtBQUssU0FBUyxPQUFPO0FBQ3JFLFlBQU0sVUFBVSxhQUFhLEtBQUs7QUFDbEMsVUFBSSxZQUFZLE9BQVcsTUFBSyxVQUFVLEVBQUUsT0FBTyxVQUFVO0FBQUEsV0FDeEQ7QUFDSCxhQUFLLE9BQU87QUFDWixhQUFLO0FBQ0wsYUFBSyxNQUFNLEtBQUssSUFBSSxLQUFLLEtBQUssT0FBTztBQUNyQyxhQUFLLE1BQU0sS0FBSyxJQUFJLEtBQUssS0FBSyxPQUFPO0FBQUEsTUFDdkM7QUFBQSxJQUNGLFdBQ0UsS0FBSyxTQUFTLGFBQ2QsT0FBTyxVQUFVLFlBQ2pCLGFBQWEsS0FBSyxNQUFNO0FBRXhCLFdBQUssVUFBVSxFQUFFLE9BQU8sVUFBVTtBQUFBLGFBQzNCLEtBQUssU0FBUyxXQUFXLGFBQWEsS0FBSyxNQUFNLE9BQVcsTUFBSztBQUFBLEVBQzVFO0FBQUEsRUFDQSxTQUF1QjtBQUNyQixRQUFJLEtBQUssYUFBYyxRQUFPLEtBQUs7QUFDbkMsUUFBSSxLQUFLLFNBQVMsUUFBUyxRQUFPLEtBQUs7QUFDdkMsUUFBSSxLQUFLLFNBQVMsU0FBVSxRQUFPLEtBQUs7QUFDeEMsUUFBSSxLQUFLLE1BQU8sUUFBTyxLQUFLO0FBQzVCLFFBQUksS0FBSyxTQUFTLFNBQVMsS0FBSyxTQUFTO0FBQ3ZDLGFBQU8sS0FBSyxlQUFnQixLQUFLLFNBQVMsUUFBUSxLQUFLLE1BQU0sS0FBSyxLQUFNLEVBQUUsT0FBTyxVQUFVO0FBQzdGLFFBQUksS0FBSyxTQUFTLE1BQU8sUUFBTyxLQUFLLFFBQVEsS0FBSyxNQUFNO0FBQ3hELFFBQUksS0FBSyxTQUFTLE1BQU8sUUFBTyxLQUFLLFFBQVEsS0FBSyxNQUFNO0FBQ3hELFFBQUksS0FBSyxTQUFTLGFBQWEsQ0FBQyxLQUFLLE1BQU8sUUFBTyxFQUFFLE9BQU8sVUFBVTtBQUN0RSxVQUFNLFNBQVMsS0FBSyxTQUFTLFlBQVksS0FBSyxNQUFNLEtBQUssUUFBUSxLQUFLO0FBQ3RFLFdBQU8sT0FBTyxTQUFTLE1BQU0sSUFBSSxTQUFTLEVBQUUsT0FBTyxRQUFRO0FBQUEsRUFDN0Q7QUFDRjsiLCJuYW1lcyI6W119